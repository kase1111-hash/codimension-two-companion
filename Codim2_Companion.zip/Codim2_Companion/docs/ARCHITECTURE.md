# Codim2 Atlas Pipeline — Architecture

*This document sketches how the 38 pipeline steps from `CHAPTER_INVENTORY.md` get implemented, orchestrated, and tracked.*

---

## Design goals

1. **One step per chapter.** Each computational chapter from the book gets one pipeline module. The mapping is 1-to-1 so the companion book can mirror the structure.
2. **Steps hand off automatically.** When step A produces an artifact that step B needs, B reads it from a known location without explicit wiring.
3. **Progress is observable.** A single command shows what's done, what's running, what's pending, and what failed.
4. **Steps are resumable.** Long-running steps checkpoint themselves so a crash or interruption doesn't waste hours of compute.
5. **Steps integrate with `parallel-tests`.** All scripts use `kase_utils` for parallel map, presets (`--quick`/`--long`), seed control, colored output, JSON+CSV save.
6. **Independent of GUI / web.** Everything runs from CMD on Windows; output is plain text + JSON + CSV.

---

## Directory layout

```
Codim2_Companion/
├── pipeline/
│   ├── __init__.py
│   ├── runner.py                  # orchestrator (dependency-aware)
│   ├── status.py                  # progress dashboard
│   ├── registry.py                # auto-discovers steps
│   ├── kase_utils.py              # standard utility library (copy from skill)
│   │
│   ├── artifacts/                 # all step outputs land here
│   │   ├── ch_21_hassett/
│   │   │   ├── hassett_table.csv
│   │   │   ├── hassett_lattices.json
│   │   │   └── progress.json
│   │   ├── ch_25_hyperkahler/
│   │   │   └── ...
│   │   └── ...
│   │
│   ├── steps/
│   │   ├── ch_04_codim_grid/
│   │   │   ├── __init__.py
│   │   │   ├── spec.yaml          # step metadata
│   │   │   ├── compute.py         # entry point: python -m pipeline.steps.ch_04_codim_grid
│   │   │   └── README.md          # narrative description (becomes a book chapter)
│   │   ├── ch_06_lefschetz_action/
│   │   ├── ch_07_three_gifts_table/
│   │   ├── ... (38 total)
│   │   └── appendix_c_problems_status/
│   │
│   └── tests/
│       └── test_<step>.py         # per-step unit tests
│
├── docs/
│   ├── CHAPTER_INVENTORY.md       # mapping book → pipeline
│   ├── ARCHITECTURE.md            # this file
│   ├── PROGRESS.md                # auto-generated status dashboard
│   └── USAGE.md                   # how to run individual steps + the full pipeline
│
├── book/                          # the companion book itself (eventual)
│   └── chapters/                  # 1 chapter per pipeline step + intro/conclusion
│
├── _build/
│   ├── compile.py                 # book build pipeline (mirrors Codimension_Two)
│   └── ...
│
└── README.md                      # project overview
```

---

## Step specification (`spec.yaml`)

Every step declares itself with a `spec.yaml`:

```yaml
step_id: ch_21_hassett_discriminants
chapter: 21
title: "Hassett Discriminants for Cubic 4-Folds"
description: |
  Enumerates admissible discriminants for special cubic 4-folds,
  classifies K3-association status per discriminant, identifies
  embedded surface types.
category: L           # T/V/S/M/L/A from CHAPTER_INVENTORY.md
inputs:
  parameters:
    d_max:
      default: 100
      quick: 50       # --quick override
      long: 1000      # --long override
      description: "Discriminant upper bound"
dependencies:
  upstream: []        # no upstream artifacts
  downstream:         # what consumes this
    - ch_27_cubic_4fold_periods
    - ch_29_cycle_constructions
    - ch_37_tate_conjecture_atlas
    - ch_42_constructive_frontier
outputs:
  - path: hassett_table.csv
    description: "Discriminants with admissibility, K3-association, embedded surface, references"
    schema:
      d: int
      admissible: bool
      k3_associated: bool
      embedded_surface: string
      reference: string
  - path: hassett_lattices.json
    description: "Lattice data per discriminant"
runtime:
  quick: "1 min"
  standard: "10 min"
  long: "2 hours"
parallelizable: true   # parallel_map across discriminants
checkpoint: true       # save progress per N items
estimated_complexity: medium
priority: high          # high/medium/low for execution scheduling
```

The runner reads `spec.yaml` files to build the DAG and decide execution order.

---

## Step structure (`compute.py`)

Each step follows the `parallel-tests` template, but with added pipeline integration:

```python
#!/usr/bin/env python3
"""ch_21_hassett_discriminants — Enumerate Hassett discriminants for cubic 4-folds."""

import multiprocessing as mp
import os
from pathlib import Path
from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    parallel_map, save_results, save_csv, save_checkpoint, load_checkpoint,
    summary_table, interpret, Timer, PRESETS, C, debug
)
from pipeline.registry import (
    get_artifact_path,        # standard artifact location for this step
    load_upstream,            # read upstream artifacts (raises if missing)
    write_progress,           # update progress.json
    STEP_ID,                  # derived from directory name
)

# ═══════════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════

D_MAX_DEFAULT = 100
D_MAX_QUICK = 50
D_MAX_LONG = 1000


# ═══════════════════════════════════════════════════════════════════
#  WORKER
# ═══════════════════════════════════════════════════════════════════

def worker(item):
    """Verify admissibility and classify a single discriminant."""
    try:
        d = item['d']
        debug("Checking discriminant d=%d", d)
        
        # Admissibility: d ≡ 0 or 2 (mod 6), d > 6
        admissible = (d % 6 in (0, 2)) and d > 6
        
        # K3-association: arithmetic conditions on prime factorization + residues
        k3_associated = check_k3_association(d) if admissible else False
        
        # Embedded surface type from lattice classification
        embedded_surface = classify_surface_type(d) if admissible else None
        
        return {
            **item,
            'admissible': admissible,
            'k3_associated': k3_associated,
            'embedded_surface': embedded_surface,
            'reference': lookup_reference(d, admissible, k3_associated),
        }
    except Exception as e:
        return {'error': str(e), **item}


# (... build_work_list, analyze, etc., per kase_utils template ...)


# ═══════════════════════════════════════════════════════════════════
#  MAIN — with pipeline integration
# ═══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    parser.add_argument('--d-max', type=int, default=None,
                        help=f'Max discriminant (default: {D_MAX_DEFAULT})')
    args = parser.parse_args()
    args = resolve_args(args)
    
    # Resolve preset-dependent params
    if args.d_max is None:
        args.d_max = {'quick': D_MAX_QUICK, 'standard': D_MAX_DEFAULT,
                      'long': D_MAX_LONG}[args.preset]
    
    banner("Hassett Discriminants", {
        'd_max': args.d_max,
        'workers': args.workers,
        'preset': args.preset,
        'output': get_artifact_path(STEP_ID),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Progress tracking starts
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=args.d_max // 6 * 2)
    
    # Build, run, analyze (standard template)
    work_list = build_work_list(args)
    
    with Timer("Computation"):
        results = parallel_map(worker, work_list, args.workers,
                               desc="Discriminants",
                               progress_callback=lambda done, total:
                                   write_progress(STEP_ID, items_done=done,
                                                  items_total=total))
    
    analyze(results, args)
    
    # Save artifacts (pipeline-aware)
    save_results(results, output_dir / 'hassett_table.json',
                 metadata={'step': STEP_ID, 'preset': args.preset})
    save_csv(results, output_dir / 'hassett_table.csv')
    save_lattice_json(results, output_dir / 'hassett_lattices.json')
    
    # Mark complete
    write_progress(STEP_ID, status='complete',
                   items_done=len(results), items_total=len(results))


if __name__ == '__main__':
    mp.freeze_support()
    main()
```

The step is **self-contained**: it can be run alone (`python -m pipeline.steps.ch_21_hassett_discriminants --quick`) or as part of the full pipeline. The only pipeline-aware additions are `get_artifact_path`, `load_upstream`, and `write_progress`.

---

## Progress tracking

Each step writes to `pipeline/artifacts/<step_id>/progress.json`:

```json
{
  "step_id": "ch_21_hassett_discriminants",
  "status": "in_progress",
  "started_at": "2026-05-10T20:30:00Z",
  "last_update": "2026-05-10T20:33:14Z",
  "items_done": 47,
  "items_total": 100,
  "percent_complete": 47.0,
  "errors": 0,
  "preset": "standard",
  "artifacts_written": [
    "pipeline/artifacts/ch_21_hassett_discriminants/hassett_table.csv"
  ],
  "elapsed_seconds": 194,
  "estimated_remaining_seconds": 218
}
```

Status states: `pending` · `running` · `in_progress` (with items_done) · `complete` · `error` · `partial` (completed but with some items errored).

---

## Status dashboard

`python -m pipeline.status` reads all `progress.json` files and renders:

```
═══════════════════════════════════════════════════════════════════
  CODIM2 ATLAS PIPELINE — STATUS
  2026-05-10 20:33:14
═══════════════════════════════════════════════════════════════════

PART I — Setup
  ✓ ch_04_codim_grid                  complete   (figure generated)

PART II — Why Dim 4
  ✓ ch_06_lefschetz_action            complete   (8 varieties)
  ✓ ch_07_three_gifts_table           complete
  ◐ ch_09_intermediate_jacobians      running    (3/12 cases)
  ○ ch_10_griffiths_evidence          pending

PART III — The Arsenal
  ✓ ch_12_kuga_satake_construction    complete   (24 K3s)
  ✓ ch_13_standard_conjectures_status complete
  ◐ ch_14_tate_mirror_framework       running    (foundational module)
  ○ ch_15_noether_lefschetz_divisors  pending
  ○ ch_16_motivic_cohomology_table    pending
  ✓ ch_17_voevodsky_status            complete

PART IV — Variety Classes
  ✓ ch_18_abelian_status              complete
  ◐ ch_19_k3_atlas                    running    (47/100 K3s)
  ○ ch_20_hyperkahler_classification  blocked    (waiting on ch_19)
  ◐ ch_21_hassett_discriminants       running    (47/100 d ≤ 100)
  ○ ch_22_cy_4fold_hodge_numbers      pending
  ○ ch_23_fano_atlas                  pending
  ○ ch_24_moduli_status               pending

PART V — The Atlas
  ○ ch_25_hyperkahler_lattices        blocked    (waiting on ch_19, ch_20)
  ○ ch_26_tate_point_counting         blocked    (waiting on ch_14)
  ○ ch_27_cubic_4fold_periods         blocked    (waiting on ch_14, ch_21)
  ○ ch_28_diagonal_decomposition      blocked    (waiting on ch_22, ch_23)
  ○ ch_29_cycle_constructions         blocked    (waiting on ch_21, ch_18, ch_20)
  ○ ch_30_chow_regulators             blocked    (waiting on ch_19, ch_18, ch_22)
  ○ ch_31_mumford_weil                blocked    (waiting on ch_18)
  ○ ch_32_toric_cy_sweep              blocked    (waiting on ch_22)
  ○ ch_33_counterexample_search       blocked    (waiting on ch_22, ch_20, ch_30)
  ○ ch_34_pattern_analysis            blocked    (waiting on all)

PART VI — Sister Conjectures
  ○ ch_35_ghc_coniveau_table          pending
  ○ ch_36_standard_conjectures_atlas  blocked    (waiting on ch_13, chs 18-24)
  ○ ch_37_tate_conjecture_atlas       blocked    (waiting on ch_26)
  ○ ch_38_beilinson_l_values          blocked    (waiting on ch_30)
  ○ ch_39_implications_table          blocked    (waiting on chs 36, 37, 38)
  ○ ch_40_web_graph                   blocked    (waiting on all)

PART VII — Closing Arguments
  ○ ch_41_infrastructure_categories   blocked    (waiting on all)
  ○ ch_42_constructive_frontier       blocked    (waiting on chs 21, 20, 29)
  ○ ch_43_arithmetic_frontier         blocked    (waiting on chs 14, 26, 20/22/24)
  ○ ch_44_motivic_frontier            blocked    (waiting on chs 30, 38)

APPENDIX C
  ○ appendix_c_problems_status        blocked    (waiting on all)

───────────────────────────────────────────────────────────────────
SUMMARY
  Total steps:     38
  Complete:        7 (18%)
  In progress:     4 (11%)
  Pending/blocked: 27 (71%)
  Errored:         0

  Completed runtime:  4.2 min
  Active runtime:     12.8 min (4 steps running)

  Next steps unblocked when current steps complete:
    ch_20_hyperkahler_classification ← ch_19_k3_atlas (60% done)
    ch_25_hyperkahler_lattices       ← ch_19, ch_20
    ch_27_cubic_4fold_periods        ← ch_14, ch_21
═══════════════════════════════════════════════════════════════════
```

The dashboard color-codes by status (green for complete, yellow for in_progress, cyan for pending, gray for blocked, red for errored) and shows real-time progress fractions for active steps.

---

## Orchestration (`runner.py`)

The runner accepts several modes:

```bash
# Run a single step
python -m pipeline.runner --only ch_21_hassett_discriminants

# Run a single step with arguments
python -m pipeline.runner --only ch_21_hassett_discriminants -- --quick --workers 4

# Run a step and all its downstream dependencies (cascade)
python -m pipeline.runner --from ch_19_k3_atlas

# Run everything that's pending (full pipeline)
python -m pipeline.runner --all

# Run only Part V (the atlas)
python -m pipeline.runner --part 5

# Dry-run: show what would be executed
python -m pipeline.runner --all --dry-run

# Force re-run a complete step
python -m pipeline.runner --only ch_21_hassett_discriminants --force
```

The runner:
1. **Discovers steps** via `registry.py` (walks `pipeline/steps/` and reads `spec.yaml`).
2. **Builds the DAG** from declared dependencies.
3. **Topologically sorts** steps so dependencies run before consumers.
4. **Schedules in waves**: independent steps within a wave can run in parallel (subject to `--workers` budget).
5. **Watches for completion** via `progress.json` updates; unblocks downstream steps when an upstream finishes.
6. **Handles failures**: if a step errors, downstream steps stay blocked but other independent branches continue.
7. **Supports resume**: re-running `--all` picks up where it left off, skipping completed steps.

---

## Artifact handoff

When step B depends on step A, B reads A's artifacts via `load_upstream`:

```python
from pipeline.registry import load_upstream

# In ch_25_hyperkahler_lattices/compute.py
k3_atlas = load_upstream('ch_19_k3_atlas', 'k3_atlas.csv')
# Returns a parsed DataFrame / dict / whatever the artifact format is.
# Raises a clear error if the artifact doesn't exist (= A hasn't run).
```

The function knows where to look because `get_artifact_path()` resolves to a canonical location per step.

Artifacts are content-addressable in spirit but path-addressable in practice — the path encodes the step ID + filename, e.g. `pipeline/artifacts/ch_19_k3_atlas/k3_atlas.csv`. JSON sidecar files store metadata (preset used, seed, runtime).

---

## Per-step README files become book chapters

The companion book mirrors the pipeline structure. Each `pipeline/steps/<step_id>/README.md` is a narrative explanation of:

1. **What this step computes** (the chapter's topic from the parent book)
2. **The algorithm**, sketched in prose with key code excerpts
3. **The output**, what columns/fields the artifacts contain and what they mean
4. **The interpretation**, what the data tells us about the conjecture
5. **Cross-references** to the parent book chapter and to upstream/downstream steps

These READMEs are concatenated (with intro/conclusion chapters added) to form the companion book proper. The build pipeline (`_build/compile.py`, mirroring the parent book's build) assembles them into PDF/EPUB.

---

## Execution model summary

```
┌───────────────────────────────────────────────────────────────────┐
│                                                                   │
│   USER                                                            │
│     └─ python -m pipeline.runner --all                            │
│           │                                                       │
│           ▼                                                       │
│   ┌─────────────────┐                                             │
│   │   runner.py     │  reads spec.yaml from each step             │
│   │                 │  builds dependency DAG                      │
│   │                 │  topological sort                           │
│   └─────────────────┘                                             │
│           │                                                       │
│           ▼                                                       │
│   ┌─────────────────┐                                             │
│   │  Execution      │  schedules independent steps in parallel    │
│   │   scheduler     │  each step writes to progress.json          │
│   │                 │  downstream steps unblock as upstream done  │
│   └─────────────────┘                                             │
│           │                                                       │
│           ▼                                                       │
│   ┌─────────────────┐                                             │
│   │  Step process   │  python -m pipeline.steps.ch_XX_YYY         │
│   │   (per step)    │  uses kase_utils + parallel_map             │
│   │                 │  writes artifacts/<step_id>/                │
│   │                 │  writes progress.json continuously          │
│   └─────────────────┘                                             │
│           │                                                       │
│           ▼                                                       │
│   USER                                                            │
│     └─ python -m pipeline.status   (in another terminal)          │
│           reads all progress.json files                           │
│           renders the dashboard                                   │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

---

## Next steps (proof-of-concept order)

To validate the architecture before building out all 38 steps:

1. **Create `kase_utils.py`** in `pipeline/` (copy from skill, verify it works in the project).
2. **Create `registry.py`** with `get_artifact_path`, `load_upstream`, `write_progress`, step auto-discovery.
3. **Create `runner.py`** with DAG resolution, scheduling, parallel execution.
4. **Create `status.py`** with the dashboard renderer.
5. **Implement 2-3 reference steps** to prove the pattern works end-to-end:
   - `ch_04_codim_grid` (trivial — generates SVG)
   - `ch_17_voevodsky_status` (small — status table from literature data)
   - `ch_21_hassett_discriminants` (medium — first real calculation, exercises parallel_map and progress tracking)
6. **Run the pipeline** to confirm orchestration works.
7. **Generate the dashboard** to confirm status reporting.
8. **Build out the remaining 35 steps** one at a time, prioritizing high-value ones (Ch 25, Ch 26, Ch 32) and aggregators (Ch 34, Ch 40).

The reference-step phase should take 1-2 days; the full build-out 4-8 weeks depending on per-step complexity. The architecture is in place to grow incrementally — every new step adds an entry to the dashboard automatically.

---

## Open design questions for Kase

1. **Should `kase_utils.py` be vendored into the project** (a copy in `pipeline/`) or imported as a separate package? The skill suggests installing it on the machine; if so, just `import kase_utils` works. If the project should be self-contained, vendor it.

2. **Where do raw external databases live?** The Kreuzer-Skarke database (for Ch 32) is ~50 MB compressed. The hyperkähler / K3 lattice databases are smaller but still external. Suggest a top-level `data/` directory with a `README.md` documenting how to acquire each external dataset.

3. **Should the pipeline have a web dashboard** in addition to the CLI one? Useful for sharing progress with collaborators, but adds scope. Initial design is CLI-only; web dashboard could come later.

4. **How does the companion book get built?** Mirror the parent book's pipeline (LaTeX → PDF + EPUB)? Or use a different format (Jupyter Book, Quarto)? The parent's build works well; suggest mirroring.

5. **What's the public-facing repo name?** `codim2-atlas`, `codimension-two-companion`, `codim2-toolkit`, or something else? CC0 licensed, GitHub-hosted.

Once these are answered, the architecture is ready to implement.
