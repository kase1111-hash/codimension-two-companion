# Codimension Two Atlas Pipeline — Chapter Inventory

*Companion project to* Codimension Two: The Hodge Conjecture and What We Can Build Around It. *This document walks through all 45 chapters of the parent book and identifies what each contains computationally, what its pipeline counterpart should look like, what depends on what, and how progress is measured.*

---

## Classification scheme

Each chapter falls into one of six categories:

| Symbol | Category | Pipeline status |
|---|---|---|
| **T** | Theory only | No pipeline step |
| **V** | Visualization / artifact generation | Lightweight step (figure / table generator) |
| **S** | Small-scale computation | One pipeline step, ~minutes |
| **M** | Medium-scale computation | One pipeline step, ~hours |
| **L** | Large-scale computation | One pipeline step, ~hours-days, parallelizable |
| **A** | Aggregator (depends on others) | Pipeline step that consumes upstream artifacts |

---

## Part I — The Conjecture and Its Setting

### Chapter 1 — What Hodge Says · **T**
Pure theory: the conjecture's statement, history, why it matters. **No pipeline step.**

### Chapter 2 — The Hodge Decomposition · **T**
Pure theory: the (p,q) decomposition, harmonic forms, polarized variation. **No pipeline step.**

### Chapter 3 — Algebraic Cycles · **T**
Pure theory: Chow groups, cycle class map, equivalence relations. **No pipeline step.**

### Chapter 4 — The Codimension Grid · **V** → `ch_04_codim_grid`
The grid figure visualizing settled (green) / open (amber) cells across (n, k). Currently rendered via `render_figure_4_1.py` in the parent book. **Pipeline step: regenerate the grid SVG/PNG with current data.**
- *Inputs*: hardcoded grid bounds (n ≤ 5, k ≤ 5), settled/open status per cell
- *Outputs*: `figure_4_1_codim_grid.svg`, `figure_4_1_codim_grid.png`
- *Dependencies*: none
- *Algorithm*: cairosvg render from SVG template
- *Estimated time*: 1 second

---

## Part II — Why Dimension 4 Is the Threshold

### Chapter 5 — The Exponential Sequence · **T**
Pure theory: how the exponential sheaf sequence produces Lefschetz (1,1). **No pipeline step.**

### Chapter 6 — Hard Lefschetz Duality · **S** → `ch_06_lefschetz_action`
Theoretical but the Lefschetz operator action on cohomology IS computable for specific varieties. **Optional pipeline step: compute $L^k$ action on $H^*(X)$ for a sample of varieties to verify Hard Lefschetz numerically.**
- *Inputs*: variety specifications (e.g., smooth quartic 3-fold, sextic 4-fold)
- *Outputs*: `lefschetz_verification.csv` — matrix rank of $L^k$ vs predicted Hodge numbers
- *Dependencies*: none
- *Algorithm*: build Hodge diamond, apply Lefschetz operator, verify isomorphism
- *Estimated time*: minutes for a small sample

### Chapter 7 — The Gap at Codim 2 · **V** → `ch_07_three_gifts_table`
Visualization: the "three gifts" framing table comparing codim-1 vs codim-2. **Pipeline step: generate the table as a structured artifact.**
- *Inputs*: structured description of the three gifts (classifying sheaf, exact sequence, connecting map)
- *Outputs*: `three_gifts_table.csv`, `three_gifts_table.tex` (LaTeX-formatted)
- *Dependencies*: none
- *Algorithm*: template render
- *Estimated time*: seconds

### Chapter 8 — Hyperplane Induction Breaks · **T**
Pure theory. **No pipeline step.**

### Chapter 9 — Intermediate Jacobians · **S** → `ch_09_intermediate_jacobian_check`
For specific 3-folds (cubic, quartic, quintic), the intermediate Jacobian $J^2$ can be computed. **Pipeline step: compute $J^2$ dimension and identify algebraic part for sample 3-folds.**
- *Inputs*: list of 3-folds with known Hodge structure ($h^{2,1}$)
- *Outputs*: `intermediate_jacobian_table.csv`
- *Dependencies*: none
- *Algorithm*: $\dim J^2 = h^{2,1}$, check algebraicity status from literature
- *Estimated time*: minutes

### Chapter 10 — The Griffiths Group · **S** → `ch_10_griffiths_evidence`
Clemens 1983 showed Griff² of a generic quintic 3-fold is uncountable. **Pipeline step: catalogue the known Griffiths-group results across variety classes (mostly literature-collection rather than computation).**
- *Inputs*: variety list (quintic 3-fold, abelian 3-fold, K3 surface, etc.)
- *Outputs*: `griffiths_status.csv` with countability/dimension status per variety
- *Dependencies*: none
- *Algorithm*: literature lookup table + cross-reference to Ch 9 data
- *Estimated time*: seconds

---

## Part III — The Arsenal

### Chapter 11 — Bloch–Srinivas · **T**
Pure theory; computational counterpart lives in Ch 28 (diagonal decomposition tests). **No pipeline step here; Ch 28 carries the calculation.**

### Chapter 12 — Kuga–Satake · **S** → `ch_12_kuga_satake_construction`
For specific K3 surfaces, the Kuga–Satake variety can be constructed. **Pipeline step: build $A_{KS}(S)$ for sample K3 surfaces and verify the Hodge-structure correspondence.**
- *Inputs*: K3 surface data (transcendental lattice, Hodge structure)
- *Outputs*: `kuga_satake_table.csv` — K3 + dimension of $A_{KS}$ + Hodge correspondence verified
- *Dependencies*: none (or could depend on Ch 19 K3 atlas)
- *Algorithm*: Clifford algebra over transcendental lattice; identify abelian variety summand
- *Estimated time*: tens of minutes for a small atlas of K3s

### Chapter 13 — Standard Conjectures · **S** → `ch_13_standard_conjectures_status`
**Pipeline step: status table for B(X), C(X), D(X), I(X) across variety classes.**
- *Inputs*: variety class list, conjecture list
- *Outputs*: `standard_conjectures_status.csv` — (variety_class × conjecture) → status
- *Dependencies*: none (compiles literature)
- *Algorithm*: structured literature compilation
- *Estimated time*: seconds (mostly data entry)

### Chapter 14 — The Tate Mirror · **M** → `ch_14_tate_mirror_framework`
**Pipeline step: implement the Tate-mirror framework as a reusable module that downstream steps (Ch 26, Ch 43) consume.**
- *Inputs*: variety + $\mathbb{F}_p$ specification
- *Outputs*: `tate_mirror_module.py` (importable), `frobenius_eigenvalues.json` for sample varieties
- *Dependencies*: none (foundational)
- *Algorithm*: point-counting → zeta function → Frobenius polynomial → eigenvalue extraction → Tate-class identification
- *Estimated time*: implementation-medium; runtime depends on per-variety Ch 26 step

### Chapter 15 — Variational Arguments · **S** → `ch_15_noether_lefschetz_divisors`
**Pipeline step: enumerate Noether-Lefschetz divisors in moduli of K3 surfaces / cubic 4-folds.**
- *Inputs*: moduli space spec (e.g., K3 moduli $\mathcal{F}_g$, cubic 4-fold moduli)
- *Outputs*: `nl_divisors.csv` — divisor class, lattice signature, special-locus content
- *Dependencies*: none
- *Algorithm*: enumerate primitive embeddings of rank-1 lattices satisfying signature conditions
- *Estimated time*: minutes

### Chapter 16 — Motivic Cohomology · **S** → `ch_16_motivic_cohomology_table`
**Pipeline step: tabulate motivic cohomology data for sample varieties.**
- *Inputs*: variety list, motivic invariants of interest
- *Outputs*: `motivic_cohomology_table.csv`
- *Dependencies*: none
- *Algorithm*: literature compilation + cross-ref to Ch 30 regulator data
- *Estimated time*: seconds (mostly data entry)

### Chapter 17 — Voevodsky Nilpotence · **S** → `ch_17_voevodsky_status`
**Pipeline step: variety-class status table for Voevodsky nilpotence (known / open).**
- *Inputs*: variety class list
- *Outputs*: `voevodsky_status.csv`
- *Dependencies*: none
- *Algorithm*: literature compilation
- *Estimated time*: seconds

---

## Part IV — The Map of Known and Open

### Chapter 18 — Abelian Varieties · **M** → `ch_18_abelian_status`
**Pipeline step: tabulate HC status across abelian variety subclasses (CM, dim ≤ 3, Mumford-type, generic).**
- *Inputs*: Albert type, dimension, CM-by spec
- *Outputs*: `abelian_hc_status.csv`
- *Dependencies*: none
- *Algorithm*: Albert classification + Pohlmann/Lieberman lookup
- *Estimated time*: minutes
- *Connects to*: Ch 31 (Mumford-Weil catalog)

### Chapter 19 — K3 Surfaces · **M** → `ch_19_k3_atlas`
**Pipeline step: build a small atlas of K3 surfaces with Picard rank, Néron-Severi lattice, transcendental lattice, K3-type Hodge structure parameters.**
- *Inputs*: K3 specifications (degree, polarization, ambient projective space)
- *Outputs*: `k3_atlas.csv`, `k3_lattices.json`
- *Dependencies*: none
- *Algorithm*: standard K3 invariant computation + lattice signature
- *Estimated time*: tens of minutes for ~100 K3s
- *Connects to*: Ch 12 (Kuga-Satake input), Ch 25 (hyperkähler lattice), Ch 30 (regulator)

### Chapter 20 — Hyperkähler Manifolds · **M** → `ch_20_hyperkahler_classification`
**Pipeline step: classify hyperkähler 4-folds by deformation type ($\text{K3}^{[n]}$, $K_n(A)$, OG-6, OG-10), Beauville-Bogomolov form, second Betti number.**
- *Inputs*: hyperkähler specifications
- *Outputs*: `hyperkahler_atlas.csv`
- *Dependencies*: Ch 19 K3 atlas (for $\text{K3}^{[n]}$ derivations)
- *Algorithm*: deformation-type classification + BB-form computation
- *Estimated time*: minutes

### Chapter 21 — Cubic 4-Folds · **L** → `ch_21_hassett_discriminants`
**Pipeline step: enumerate Hassett admissible discriminants up to some bound, classify K3-association status, identify embedded surface types.** *(High-priority — this is one of the book's signature atlases.)*
- *Inputs*: discriminant range (default $d \leq 1000$), arithmetic conditions
- *Outputs*: `hassett_table.csv` (every admissible $d$ with K3-association status, embedded surface, references), `hassett_lattices.json`
- *Dependencies*: none
- *Algorithm*: arithmetic enumeration of admissible $d$ ($d \equiv 0, 2 \pmod 6$, $d > 6$, plus residue conditions); for each $d$, check lattice embedding into $\Lambda_{K3}(2)$ to determine K3-association
- *Estimated time*: minutes for $d \leq 100$; hours for $d \leq 1000$
- *Parallelizable*: yes (per-discriminant)

### Chapter 22 — Calabi–Yau 4-Folds · **M** → `ch_22_cy_4fold_hodge_numbers`
**Pipeline step: compute Hodge numbers for canonical CY 4-fold families (sextic, complete intersections, Borcea-Voisin, Fermat-type, low-$h^{1,1}$ toric).**
- *Inputs*: CY family specifications
- *Outputs*: `cy_4fold_atlas.csv` — variety, $h^{1,1}, h^{2,1}, h^{3,1}, h^{2,2}$, cycle-source rank, openness status
- *Dependencies*: none (but feeds Ch 32 toric sweep)
- *Algorithm*: standard Hodge-number formulas for each family + literature lookup for non-toric
- *Estimated time*: minutes

### Chapter 23 — Fano and Uniruled · **S** → `ch_23_fano_atlas`
**Pipeline step: tabulate Fano 4-folds (index, degree, cohomology) with Bloch-Srinivas applicability.**
- *Inputs*: Fano 4-fold classification list
- *Outputs*: `fano_atlas.csv`
- *Dependencies*: none
- *Algorithm*: standard Fano classification + Bloch-Srinivas verification
- *Estimated time*: minutes

### Chapter 24 — Moduli Spaces · **S** → `ch_24_moduli_status`
**Pipeline step: tabulate moduli space HC status ($\mathcal{A}_g$, $\mathcal{F}_g$, $\mathcal{M}$ cubic 4-folds, hyperkähler moduli, $\mathcal{M}_g$, etc.).**
- *Inputs*: moduli space specifications
- *Outputs*: `moduli_status.csv`
- *Dependencies*: none
- *Algorithm*: literature compilation
- *Estimated time*: seconds

---

## Part V — The Computational Atlas (the heart)

### Chapter 25 — Hyperkähler Lattice Atlas · **L** → `ch_25_hyperkahler_lattices`
**Pipeline step: build the complete lattice atlas for the four hyperkähler deformation types (K3$^{[n]}$, $K_n(A)$, OG-6, OG-10) — BB form, Picard, transcendental lattices for sample members.**
- *Inputs*: deformation type, polarization data
- *Outputs*: `hyperkahler_lattice_atlas.csv`, `hyperkahler_lattices.json`
- *Dependencies*: Ch 20 (hyperkähler classification), Ch 19 (K3 input for $\text{K3}^{[n]}$)
- *Algorithm*: lattice computation per deformation type; primitive embeddings into the global Mukai lattice
- *Estimated time*: hours for a comprehensive atlas
- *Parallelizable*: yes

### Chapter 26 — Tate Point Counting · **L** → `ch_26_tate_point_counting`
**Pipeline step: count $\mathbb{F}_p$-points for selected varieties (cubic 4-folds, K3 surfaces, sextic CYs, hyperkähler 4-folds), extract Frobenius eigenvalues, identify Tate-class structure.** *(High-priority — central to the arithmetic frontier.)*
- *Inputs*: variety list, prime list (e.g., $p \in \{2, 3, 5, 7, 11, ..., 1000\}$)
- *Outputs*: `point_counts.csv` (variety × prime → count), `frobenius_eigenvalues.json` (per variety: factored polynomial), `tate_classes.csv` (identified $q^2$-eigenvalue Tate classes)
- *Dependencies*: Ch 14 (Tate mirror framework module)
- *Algorithm*: exhaustive point enumeration for small $p$; standard algorithms (Schoof, SEA for elliptic-curve fibers); factor over $\mathbb{Z}$
- *Estimated time*: hours-to-days depending on prime range and variety count
- *Parallelizable*: yes (per-variety-prime pair)
- *Compute-heavy*

### Chapter 27 — Cubic 4-Fold Periods · **L** → `ch_27_cubic_4fold_periods`
**Pipeline step: compute period integrals for cubic 4-folds via Griffiths' formulation, solve Picard-Fuchs equations, identify K3-association via period map, perform numerical verification.**
- *Inputs*: cubic 4-fold parameter (e.g., coefficients of defining equation)
- *Outputs*: `period_data.csv`, `picard_fuchs_solutions.json`, `k3_association_via_periods.csv`
- *Dependencies*: Ch 14 (foundational), Ch 21 (Hassett discriminants for organizing)
- *Algorithm*: Jacobian ring computation → Hodge structure on $H^4$ → period integrals → PF system → numerical integration
- *Estimated time*: hours per cubic; days for an atlas
- *Parallelizable*: yes (per-cubic)
- *Compute-heavy*

### Chapter 28 — Diagonal Decomposition Tests · **M** → `ch_28_diagonal_decomposition`
**Pipeline step: verify Bloch-Srinivas hypotheses (CH_0 size, diagonal decomposition existence) on sample varieties.**
- *Inputs*: variety list (projective space, Fano 4-folds, K3-fibered varieties, sextic CY)
- *Outputs*: `diagonal_decomposition_status.csv` — variety, $\text{CH}_0$ status, decomposition $N$ (denominator), Bloch-Srinivas applicability
- *Dependencies*: Ch 22 (CY data), Ch 23 (Fano data)
- *Algorithm*: $\text{CH}_0$ rationality check + diagonal decomposition test via cycle-class images
- *Estimated time*: tens of minutes

### Chapter 29 — Cycle Construction · **M** → `ch_29_cycle_constructions`
**Pipeline step: enumerate explicit cycles across variety classes (Hassett surfaces on cubic 4-folds, Beauville-Donagi on hyperkähler, Pohlmann CM cycles on abelian).**
- *Inputs*: variety class + cycle construction method
- *Outputs*: `cycle_catalog.csv` — variety, cycle class, construction method, verification status
- *Dependencies*: Ch 21 (Hassett), Ch 18 (abelian CM), Ch 20 (hyperkähler)
- *Algorithm*: per-class explicit construction routines
- *Estimated time*: hours for comprehensive catalog

### Chapter 30 — Higher Chow Regulators · **L** → `ch_30_chow_regulators`
**Pipeline step: compute Beilinson regulator periods on K3 surfaces, abelian varieties, CY 3-folds (and as Problem 3.4 from Appendix C: extend to CY 4-folds where possible).**
- *Inputs*: variety + motivic cohomology class
- *Outputs*: `regulator_periods.csv` — variety, class, numerical period, comparison to predicted L-value
- *Dependencies*: Ch 19 (K3), Ch 18 (abelian), Ch 22 (CY families)
- *Algorithm*: iterated polylog evaluation ($\text{Li}_2, \text{Li}_3, \text{Li}_4$) on algebraic points + regulator-period assembly
- *Estimated time*: hours per family
- *Parallelizable*: yes
- *Compute-heavy*

### Chapter 31 — Mumford-Weil Catalog · **M** → `ch_31_mumford_weil`
**Pipeline step: catalogue abelian varieties by Albert type (I/II/III/IV), Mumford-Tate group structure, Néron-Severi rank, Hodge ring structure.**
- *Inputs*: Albert type, dimension, endomorphism algebra
- *Outputs*: `mumford_weil_catalog.csv`
- *Dependencies*: Ch 18 (abelian status)
- *Algorithm*: Albert classification + MT-group determination + NS computation
- *Estimated time*: tens of minutes

### Chapter 32 — Toric CY Sweep · **L** → `ch_32_toric_cy_sweep`
**Pipeline step: iterate Kreuzer-Skarke reflexive 5-polytopes, build the Batyrev CY 4-fold per polytope, compute Hodge numbers, identify cycle-source structure.** *(High-priority — vast atlas extension potential.)*
- *Inputs*: polytope range (default: small $h^{1,1}$, extendable to full database)
- *Outputs*: `toric_cy_sweep.csv` — polytope ID, Hodge numbers, cycle-source rank
- *Dependencies*: integration with the Kreuzer-Skarke binary database (external dependency)
- *Algorithm*: Batyrev-Borisov construction + Hodge number formulas from polytope combinatorics
- *Estimated time*: hours for $h^{1,1} \leq 5$; days/weeks for the full Kreuzer-Skarke database (473,800,776 polytopes)
- *Parallelizable*: yes (per-polytope)
- *Compute-heavy*

### Chapter 33 — Counterexample Hunt · **M** → `ch_33_counterexample_search`
**Pipeline step: systematically search for failure cases at the rational projective form of HC on candidate variety classes.**
- *Inputs*: variety classes to test, integral/rational form, Kähler/projective form
- *Outputs*: `counterexample_search_results.csv` — variety, conjecture form, result (no counterexample found / partial counterexample / verified)
- *Dependencies*: Ch 22 (CY), Ch 20 (hyperkähler), Ch 30 (regulator data for cross-checking)
- *Algorithm*: case-by-case verification via cycle class image vs Hodge classes; cross-check with known counterexamples (Atiyah-Hirzebruch, Kollár, etc.)
- *Estimated time*: hours

### Chapter 34 — Pattern Analysis · **A** → `ch_34_pattern_analysis`
**Pipeline step: meta-analysis consuming upstream artifacts to identify cross-class patterns (Mumford-Tate spectrum, structure-rich vs structure-poor, bridge graph topology, atlas-vs-existence gap).**
- *Inputs*: artifacts from Chs 18-33
- *Outputs*: `pattern_analysis_report.csv`, `bridge_graph.json` (network structure), `mt_spectrum.csv` (Mumford-Tate distribution)
- *Dependencies*: ALL Part IV + Part V steps
- *Algorithm*: graph algorithms on bridge structure, statistical analysis on lattice/MT data
- *Estimated time*: minutes (operates on aggregated data)

---

## Part VI — Sister Conjectures and Implications

### Chapter 35 — Generalized Hodge · **S** → `ch_35_ghc_coniveau_table`
**Pipeline step: tabulate GHC status at various coniveau across variety classes.**
- *Inputs*: variety class, coniveau range
- *Outputs*: `ghc_coniveau_status.csv`
- *Dependencies*: none
- *Algorithm*: literature compilation + coniveau filtration computation
- *Estimated time*: seconds

### Chapter 36 — Standard Conjectures (full) · **M** → `ch_36_standard_conjectures_atlas`
**Pipeline step: comprehensive status table for B(X), C(X), D(X), I(X) across all variety classes from Part IV.**
- *Inputs*: variety class list × conjecture list
- *Outputs*: `standard_conjectures_atlas.csv`
- *Dependencies*: Ch 13 (initial table), Chs 18-24 (variety class data)
- *Algorithm*: cross-reference compilation
- *Estimated time*: minutes (mostly aggregation)

### Chapter 37 — Tate Conjecture · **L** → `ch_37_tate_conjecture_atlas`
**Pipeline step: compile Tate conjecture verification across variety classes; integrate Ch 26 point-counting results to identify Tate-class verifications at codim 2.**
- *Inputs*: variety classes, primes
- *Outputs*: `tate_atlas.csv` — variety, prime, codim, Tate-fixed class count, verification status
- *Dependencies*: Ch 26 (point counts), Ch 14 (Tate mirror), Chs 18-24 (variety data)
- *Algorithm*: aggregate Ch 26 outputs + Frobenius-eigenvalue analysis at $q^2$
- *Estimated time*: hours (depends on Ch 26 data volume)

### Chapter 38 — Beilinson L-Values · **L** → `ch_38_beilinson_l_values`
**Pipeline step: L-function computation for motives from variety classes; compare leading coefficients at integer points to Ch 30 regulator periods.**
- *Inputs*: variety + motive
- *Outputs*: `beilinson_l_values.csv` — variety, L-function, integer point, predicted period, computed period, match status
- *Dependencies*: Ch 30 (regulator periods), Ch 37 (Tate conjecture data for L-function construction)
- *Algorithm*: zeta-function / L-function assembly + integer-point evaluation + comparison
- *Estimated time*: hours
- *Compute-heavy*

### Chapter 39 — Implications · **A** → `ch_39_implications_table`
**Pipeline step: cross-conjecture implications table.**
- *Inputs*: HC, Tate, Beilinson, standard conjectures verification status
- *Outputs*: `implications_table.csv` — implication arrows + bearing on codim-2 case
- *Dependencies*: Chs 36, 37, 38
- *Algorithm*: structured logical table assembly
- *Estimated time*: seconds

### Chapter 40 — The Web of Implications · **A** → `ch_40_web_graph`
**Pipeline step: full conjecture-network graph with central node (rational projective HC) and layered structure (sister conjectures, strategies, variety classes, atlas, failure modes).**
- *Inputs*: ALL upstream artifacts
- *Outputs*: `web_graph.json` (graph structure), `web_visualization.svg` (rendered)
- *Dependencies*: ALL prior steps
- *Algorithm*: network construction + layered graph layout
- *Estimated time*: minutes
- *Connects to*: bridge graph from Ch 34

---

## Part VII — Closing Arguments

### Chapter 41 — What We Can Build · **A** → `ch_41_infrastructure_categories`
**Pipeline step: report on the 5 infrastructure categories + adapting-to-higher-codim summary, drawing on all upstream computational data.**
- *Inputs*: ALL Parts I-VI artifacts
- *Outputs*: `infrastructure_report.md` (auto-generated structured report)
- *Dependencies*: Chs 25-34 (atlas data), Chs 35-40 (network data)
- *Algorithm*: report generator
- *Estimated time*: minutes

### Chapter 42 — Constructive Frontier · **A** → `ch_42_constructive_frontier`
**Pipeline step: compile the bridge graph, identify connected components (settled classes via constructive routes vs disconnected = open), enumerate gaps.**
- *Inputs*: Ch 29 cycle catalog, Ch 21 Hassett K3-association, Ch 20 hyperkähler bridges
- *Outputs*: `bridge_graph.json` (extends Ch 34), `frontier_gaps.csv` (disconnected classes)
- *Dependencies*: Ch 29, Ch 21, Ch 20
- *Algorithm*: connected-component analysis on bridge graph
- *Estimated time*: minutes

### Chapter 43 — Arithmetic Frontier · **L** → `ch_43_arithmetic_frontier`
**Pipeline step: comprehensive point-counting workflow application across CY 4-folds, hyperkähler 4-folds, high-genus moduli; eigenvalue extraction and Tate verification across primes.** *(Largest computational step — extends Ch 26 to broader scope.)*
- *Inputs*: variety classes from Ch 22, Ch 20, Ch 24; prime range up to $p \leq 10^4$
- *Outputs*: `arithmetic_frontier_atlas.csv`, comprehensive eigenvalue tables
- *Dependencies*: Ch 14 (framework), Ch 26 (initial point counts), Chs 20/22/24 (variety data)
- *Algorithm*: extends Ch 26 with broader variety coverage and prime range
- *Estimated time*: days-to-weeks for full coverage
- *Parallelizable*: yes
- *Compute-heavy*

### Chapter 44 — Motivic Frontier · **L** → `ch_44_motivic_frontier`
**Pipeline step: compute Beilinson regulator periods on CY 4-folds; compare to predicted L-values; explore motivic Langlands correspondences for low-rank cases.**
- *Inputs*: CY 4-fold families, abelian variety data
- *Outputs*: `motivic_frontier_atlas.csv`, regulator-vs-L-value comparison tables
- *Dependencies*: Ch 30 (regulator), Ch 38 (Beilinson L-values)
- *Algorithm*: extends Ch 30 + Ch 38 to higher-dim varieties
- *Estimated time*: days
- *Compute-heavy*

### Chapter 45 — Coda · **T**
Pure synthesis — closing reflection. **No pipeline step.**

---

## Appendix C — Open Problems · **A** → `appendix_c_problems_status`
**Pipeline step: track the 35 open problems' verification/extension status across the atlas. As the pipeline runs, each problem's "approachable / addressed / partially settled" status updates.**
- *Inputs*: ALL upstream artifacts + problem metadata from Appendix C
- *Outputs*: `problems_status.csv` — problem ID, current status, supporting atlas evidence
- *Dependencies*: ALL prior steps
- *Algorithm*: status engine consuming problem definitions + matching upstream artifacts
- *Estimated time*: minutes

---

## Summary by category

| Category | Count | Chapters |
|---|---|---|
| **T** Theory only | 7 | 1, 2, 3, 5, 8, 11, 45 |
| **V** Visualization | 2 | 4, 7 |
| **S** Small computation | 11 | 6, 9, 10, 12, 13, 15, 16, 17, 23, 24, 35 |
| **M** Medium computation | 9 | 14, 18, 19, 20, 22, 28, 29, 31, 33, 36 |
| **L** Large computation | 9 | 21, 25, 26, 27, 30, 32, 37, 38, 43, 44 |
| **A** Aggregator | 6 | 34, 39, 40, 41, 42, Appendix C |
| **Total pipeline steps** | **37** | (45 chapters − 7 theory − 1 Coda) |

Plus 1 step for Appendix C, total **38 pipeline steps**.

---

## Dependency graph (high level)

```
Foundation:
  ch_14_tate_mirror_framework  (no deps)
  ch_19_k3_atlas               (no deps)

Variety atlases (mostly independent):
  ch_18 abelian, ch_20 hyperkähler (← Ch 19), ch_21 Hassett, 
  ch_22 CY 4-fold, ch_23 Fano, ch_24 moduli

Atlas heavy computations:
  ch_25 hyperkähler lattices   (← Ch 19, Ch 20)
  ch_26 Tate point counting    (← Ch 14)
  ch_27 cubic 4-fold periods   (← Ch 14, Ch 21)
  ch_28 diagonal decomposition (← Ch 22, Ch 23)
  ch_29 cycle constructions    (← Ch 21, Ch 18, Ch 20)
  ch_30 Chow regulators        (← Ch 19, Ch 18, Ch 22)
  ch_31 Mumford-Weil catalog   (← Ch 18)
  ch_32 toric CY sweep         (← Ch 22)
  ch_33 counterexample search  (← Ch 22, Ch 20, Ch 30)

Aggregators:
  ch_34 pattern analysis       (← all Part IV + Part V)
  ch_36 standard conjectures   (← Ch 13, Chs 18-24)
  ch_37 Tate conjecture atlas  (← Ch 26, Ch 14, Chs 18-24)
  ch_38 Beilinson L-values     (← Ch 30, Ch 37)
  ch_39 implications           (← Chs 36, 37, 38)
  ch_40 web graph              (← all)
  ch_41 infrastructure report  (← all Parts I-VI)
  ch_42 constructive frontier  (← Chs 21, 20, 29)
  ch_43 arithmetic frontier    (← Ch 14, Ch 26, Chs 20/22/24)
  ch_44 motivic frontier       (← Ch 30, Ch 38)
  appendix_c problems_status   (← all)
```

The dependency graph is shallow — most variety-class steps are independent of each other, and the aggregators at the top depend on everything below. This means the pipeline parallelizes naturally at the variety-class layer.

---

## What this means for the pipeline architecture

The structure above suggests the following design:

1. **Each pipeline step is a Python module** under `pipeline/ch_NN_<name>/` with a `compute.py` entry point following the `kase_utils` standard (map-reduce, presets, parallel_map, checkpoints, JSON+CSV output).

2. **Each step has a `spec.yaml`** declaring its inputs, outputs, dependencies, and estimated complexity.

3. **A central `runner.py`** orchestrates execution: resolves the dependency DAG, runs steps in topologically-sorted order, parallelizes independent steps, supports `--resume` for partial completion, and supports `--only ch_21` for running a single step.

4. **A `status.py` command** generates the dashboard: walks all steps, reads their `progress.json` files, and produces a readable report showing what's done, what's in progress (with x-of-y counts), what's pending, and what failed.

5. **Artifacts live in `pipeline/artifacts/`** with consistent naming. Each step writes its outputs there. Downstream steps read upstream artifacts from there.

6. **Progress symbols**:
   - `○` pending
   - `◐` in progress (with x/y count)
   - `✓` complete
   - `✗` error / failed (with link to log)

The next document (`pipeline/ARCHITECTURE.md`) sketches the implementation in detail.
