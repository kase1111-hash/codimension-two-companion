# Preprint: Pipeline verification of Batyrev mirror symmetry on the complete Kreuzer-Skarke classification

LaTeX source for arXiv preprint reporting three connected empirical results:
1. 100.00% mirror-symmetry verification on all 473.8M Kreuzer-Skarke polytopes
2. Distribution analysis (mode at |χ| = 24 — possibly K3-fibration related)
3. 600-curve LMFDB-validated CM detection benchmark at 100% accuracy

## Files

- `main.tex` — the manuscript
- `references.bib` — bibliography
- `figures/` — figure PDFs (build step below)
- `README.md` — this file

## Build

```bash
# Generate figure PDFs from your local SVGs (one-time setup)
cd figures
cairosvg ../../analysis/chi_histogram.svg -o chi_histogram.pdf
cairosvg ../../analysis/sum_histogram.svg -o sum_histogram.pdf
cairosvg ../../analysis/h11_marginal.svg -o h11_marginal.pdf
cairosvg ../../pipeline/artifacts/ch_32_toric_cy_sweep/ks_hodge_shield.svg \
  -o ks_hodge_shield.pdf

# Compile
cd ..
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

The result is `main.pdf` — a 10-12 page arXiv-ready preprint.

## Figure preparation

The paper references three figures by relative path `figures/<name>.pdf`:
- `figures/chi_histogram.pdf` — the χ distribution histogram
- `figures/sum_histogram.pdf` — h¹¹+h¹² distribution

The shield plot is currently *referenced in prose* but the figure is **not yet
inserted**. If you want it as a figure, add this LaTeX block in
Section "Mirror-symmetry verification" near the results table:

```latex
\begin{figure}[ht]
\centering
\includegraphics[width=0.85\linewidth]{figures/ks_hodge_shield.pdf}
\caption{The canonical Kreuzer-Skarke ``shield plot'': all 30{,}108
distinct $(\hone, \htwo)$ Hodge pairs, rendered from the verified
pair set. Color encodes Euler characteristic $\chiE = 2(\hone - \htwo)$:
red for $\chiE < 0$, blue for $\chiE > 0$, gray on the mirror diagonal.}
\label{fig:shield}
\end{figure}
```

The paper already references `\ref{fig:shield}` in Section "Discussion and
future work" — that reference will work as soon as you insert the figure block.

## Author affiliation

Author block in `main.tex` currently lists:
- Name: Kase Branham
- Affiliation: Independent Researcher (Portland/Salem, Oregon)
- Code link: https://github.com/kase1111-hash
- License: CC0

Edit those fields if you want different attribution or to add an
ORCID/email line.

## arXiv submission

When ready:
1. Build locally to verify everything compiles
2. Bundle `main.tex`, `references.bib`, and `figures/*.pdf` into a tarball
3. Choose primary category `math.AG` with cross-list to `hep-th`
4. arXiv subject classifications: 14J32 (Calabi-Yau threefolds), 14J33
   (mirror symmetry), 14M25 (toric varieties), 11G05 (elliptic curves)
5. Upload at `https://arxiv.org/submit`

The manuscript is structured to fit arXiv's expectations. No special
preamble or class-file changes needed.
