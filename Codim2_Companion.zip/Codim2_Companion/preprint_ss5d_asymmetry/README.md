# Structural asymmetry in the Schöller-Skarke 5D Hodge landscape

Companion paper to the main *Codim₂ Companion* preprint.

## Status

**Phase 1 results filled in.** Three findings reported with full
quantitative content in §2 (mirror-closure decomposition),
§3 (directional bias), §4 (stratum heterogeneity).

**Phase 2 is outline-only.** §5 lists four follow-up analyses
to be completed: bivariate (h¹¹, h¹³) density heatmap, χ
distribution by closure cohort, mode-at-sum substructure analysis,
marginal-distribution null benchmark.

## Building

```
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

## Missing assets to add before final build

- `figures/ss_phase1_closure_by_h12.pdf` — convert from
  `<repo>/analysis/ss_5d/ss_phase1_closure_by_h12.svg`
  (CairoSVG, Inkscape, or `cairosvg --output-format pdf` works)

## Source of empirical content

All numbers in §2-4 come from a single Phase 1 run:

```
python -m pipeline.data_tools.ss_phase1
```

against the merged `ss_hodge_tuples_merged.pkl.gz` cache produced
by the parent pipeline. Specific JSON outputs:

- `analysis/ss_5d/ss_phase1_summary.json`        — top-level (Tests A and C)
- `analysis/ss_5d/ss_phase1_test_b_per_stratum.json` — full 1,689-row per-h¹² closure table
- `analysis/ss_5d/ss_phase1_closure_by_h12.svg`  — figure for §4.3
