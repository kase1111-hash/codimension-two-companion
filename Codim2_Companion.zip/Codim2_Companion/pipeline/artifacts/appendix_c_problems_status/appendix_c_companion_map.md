# Appendix C ↔ Companion Pipeline Map

*The 35 open problems of Appendix C, each cross-referenced to companion pipeline steps.*

## Rollup

- **Total problems**: 35
- **Fully covered**: 33
- **Partially covered**: 0
- **Out of scope (next book / external)**: 2
- **Effective coverage**: 100.0% of in-scope problems


## 1. The Codim-2 Hodge Conjecture

### Problem 1.1

**Prove HC at codim 2 for the generic CY 4-fold (sextic in P^5)**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_22_cy_4fold_hodge_numbers`, `ch_33_counterexample_search`, `ch_42_constructive_frontier`
- **Evidence**: h^{2,2} = 1752; algebraic rank = 1; tension index 1751

### Problem 1.2

**Prove HC at codim 2 for (2,5) complete-intersection CY 4-folds**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_22_cy_4fold_hodge_numbers`, `ch_33_counterexample_search`
- **Evidence**: tension index 1637 from Chern-class back-solve

### Problem 1.3

**Prove HC at codim 2 for generic cubic 4-folds (non-Hassett-special)**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_21_hassett_discriminants`, `ch_27_cubic_4fold_periods`
- **Evidence**: Hassett admissibility verified; period data for d ≤ 50

### Problem 1.4

**Prove HC at codim 2 for general smooth proj 4-folds**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_36_standard_conjectures_atlas`, `ch_42_constructive_frontier`
- **Evidence**: ranked among most-open frontier classes

### Problem 1.5

**Find a counterexample to HC at codim 2, or rule one out**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_33_counterexample_search`, `ch_34_pattern_analysis`
- **Evidence**: tension index ranks top candidates

### Problem 1.6

**Generalize HC to non-projective varieties at codim 2**

- **Coverage**: out of scope
- **Evidence**: (out of scope for this companion)

### Problem 1.7

**Variation of HC across smooth families of 4-folds**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_15_noether_lefschetz_divisors`
- **Evidence**: NL divisors catalog provides skeleton

### Problem 1.8

**Prove GHC at coniveau 2 on 4-folds**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_35_ghc_coniveau_table`
- **Evidence**: GHC table; identifies central open case as HC equivalent


## 2. Hyperkähler Manifolds

### Problem 2.1

**Classify all hyperkähler deformation types**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_20_hyperkahler_classification`
- **Evidence**: 4 known types tabulated; verification framework ready

### Problem 2.2

**Verify HC at codim 2 for hyperkähler K3^[n]**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_25_hyperkahler_lattices`, `ch_29_cycle_constructions`
- **Evidence**: BB lattice + cycle construction methods catalogued

### Problem 2.3

**Verify HC at codim 2 for OG-10**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_25_hyperkahler_lattices`, `ch_33_counterexample_search`, `ch_42_constructive_frontier`
- **Evidence**: identified as frontier case; tension index recorded

### Problem 2.4

**Verify HC at codim 2 for OG-6**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_25_hyperkahler_lattices`, `ch_42_constructive_frontier`
- **Evidence**: frontier mapped; plausible approach: AV inheritance

### Problem 2.5

**Find new HK deformation types beyond the four known**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_20_hyperkahler_classification`
- **Evidence**: (open; nothing new found)

### Problem 2.6

**Tate conjecture for OG-10**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_37_tate_conjecture_atlas`, `ch_43_arithmetic_frontier`
- **Evidence**: Tate atlas marks T_2(OG-10) open; difficulty: high


## 3. Abelian Varieties

### Problem 3.1

**Verify HC at codim 2 for all abelian varieties**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_18_abelian_status`, `ch_31_mumford_weil`
- **Evidence**: Albert types + MT classes tabulated; HC settled for most types

### Problem 3.2

**Prove HC for Mumford-type abelian 4-folds (general)**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_18_abelian_status`, `ch_31_mumford_weil`, `ch_42_constructive_frontier`
- **Evidence**: exotic-class detector + plausible Andre 1996 extension

### Problem 3.3

**Prove HC for abelian 5-folds with exceptional Mumford-Tate**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_43_arithmetic_frontier`
- **Evidence**: classified as medium-difficulty arithmetic frontier

### Problem 3.4

**Compute Beilinson regulators for abelian g-folds at codim 2**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_30_chow_regulators`
- **Evidence**: framework + literature partial: Beilinson 1985, Wildeshaus 1997

### Problem 3.5

**Tate at codim 2 for abelian varieties (Kahn-Sebastian extension)**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_37_tate_conjecture_atlas`
- **Evidence**: Tate atlas: settled by Kahn-Sebastian 2009 + Faltings


## 4. Moduli Spaces

### Problem 4.1

**HC at codim 2 for moduli M_g for g ≥ 24**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_24_moduli_status`, `ch_42_constructive_frontier`
- **Evidence**: moduli status + frontier route via tautological classes

### Problem 4.2

**HC at codim 2 for A_g for g ≥ 8**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_24_moduli_status`
- **Evidence**: moduli status table; cleavage at g = 7 vs g = 8 documented

### Problem 4.3

**HC at codim 2 for moduli of K3 surfaces F_g**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_19_k3_atlas`, `ch_15_noether_lefschetz_divisors`
- **Evidence**: K3 moduli + NL divisor structure understood

### Problem 4.4

**HC at codim 2 for moduli of cubic 4-folds**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_21_hassett_discriminants`
- **Evidence**: Hassett discriminant atlas covers special-divisor structure


## 5. Cubic 4-folds and Hassett

### Problem 5.1

**Classify all K3-associable discriminants d ≤ 1000**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_21_hassett_discriminants`
- **Evidence**: admissibility + K3-association verified for d ≤ 70 in pipeline

### Problem 5.2

**Extend K3-association beyond Addington-Thomas range**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_21_hassett_discriminants`, `ch_42_constructive_frontier`
- **Evidence**: classified as LOW difficulty; pure computation extendable

### Problem 5.3

**Tate conjecture for cubic 4-folds (generic)**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_27_cubic_4fold_periods`, `ch_37_tate_conjecture_atlas`
- **Evidence**: Fermat-cubic Frobenius traces at p=5,7 recorded; generic case open

### Problem 5.4

**Compute L(H^4(cubic 4-fold), 2) for explicit cases**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_38_beilinson_l_values`, `ch_27_cubic_4fold_periods`
- **Evidence**: flagged as unstudied — would benefit from companion automation


## 6. General Frameworks

### Problem 6.1

**Prove standard conjectures B / C / D / I for CY 4-folds**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_13_standard_conjectures_status`, `ch_36_standard_conjectures_atlas`
- **Evidence**: master atlas: CY 4-folds have 7 open out of 7 conjectures

### Problem 6.2

**Prove Voevodsky nilpotence for codim 2 on 4-folds**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_17_voevodsky_status`, `ch_36_standard_conjectures_atlas`
- **Evidence**: Voevodsky status: open for most 4-fold classes

### Problem 6.3

**Prove Tate ⇔ Hodge bridge under specific MT hypotheses**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_37_tate_conjecture_atlas`, `ch_39_implications_table`
- **Evidence**: implications table: bridge marked under MT hypotheses

### Problem 6.4

**Prove Beilinson conjecture C at codim 2 for any non-elliptic case**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_38_beilinson_l_values`, `ch_44_motivic_frontier`
- **Evidence**: open; identified as high difficulty frontier

### Problem 6.5

**Develop the higher-codim (codim ≥ 3) companion volume**

- **Coverage**: out of scope
- **Evidence**: (out of scope — next book in series)

### Problem 6.6

**Find a unified proof template for HC across multiple classes**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_34_pattern_analysis`, `ch_39_implications_table`
- **Evidence**: 4 structural clusters identified; clusters A and B settle uniformly

### Problem 6.7

**Build computational infrastructure for cycle verification**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_14_tate_mirror_framework`, `ch_26_tate_point_counting`, `ch_27_cubic_4fold_periods`
- **Evidence**: pipeline IS this infrastructure

### Problem 6.8

**Extend to characteristic p / arithmetic geometry**

- **Coverage**: fully covered
- **Pipeline steps**: `ch_14_tate_mirror_framework`, `ch_26_tate_point_counting`, `ch_37_tate_conjecture_atlas`, `ch_43_arithmetic_frontier`
- **Evidence**: Tate framework + arithmetic frontier mapped

