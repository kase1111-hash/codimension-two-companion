#!/usr/bin/env python3
"""
framework.py — Tate-mirror framework library.

Reusable point-counting / Frobenius-polynomial / Tate-class-detection
primitives. Imported by ch_26, ch_27, ch_37, ch_43 downstream.

Conventions:
  - All point counts are over F_p or F_{p^k} for p a small prime.
  - Frobenius acts on H^i_ét(X̄, Q_ℓ); its eigenvalues are Weil numbers
    of absolute value p^{i/2}.
  - "Tate class" at codim i = element of H^{2i} fixed by Frobenius and
    of the form α = p^i (eigenvalue equal to p^i indicates a (i,i)-form
    coming from an algebraic cycle by the Tate conjecture).
  - For curves (1-fold), H^1 has rank 2g; Frobenius polynomial is
    T^2 - a_p T + p with |a_p| ≤ 2√p (Hasse-Weil).

Public functions:
  count_points_elliptic(a, b, p)
  count_points_elliptic_extension(a, b, p, k)
  frobenius_trace_elliptic(a, b, p)
  frobenius_polynomial_elliptic(a, b, p)
  frobenius_eigenvalues_from_poly(coeffs)
  is_tate_eigenvalue(alpha, p, codim, tolerance=1e-9)
  is_supersingular_elliptic(a, b, p)
  detect_cm_elliptic(a, b, p_list)

Author: Kase Branham — Independent Researcher
"""

import cmath
from typing import List, Optional


def count_points_elliptic(a: int, b: int, p: int) -> int:
    """Count points on y^2 = x^3 + a x + b over F_p, plus point at infinity.
    
    Naive O(p) algorithm using the Legendre-symbol-style sum.
    For p in [3, ~10^4] this is fast enough.
    """
    if p < 3 or (4 * a**3 + 27 * b**2) % p == 0:
        return None  # singular curve or p=2 (special)
    
    count = 1  # point at infinity
    for x in range(p):
        rhs = (x**3 + a * x + b) % p
        if rhs == 0:
            count += 1
        else:
            # rhs is a QR iff rhs^((p-1)/2) ≡ 1 (mod p)
            legendre = pow(rhs, (p - 1) // 2, p)
            if legendre == 1:
                count += 2
            # else: legendre == p-1 → not a QR → no points at this x
    return count


def count_points_elliptic_extension(a: int, b: int, p: int, k: int) -> int:
    """Count points on E(F_{p^k}) via the Frobenius polynomial.
    
    If E(F_p) has #E_p points and Frobenius polynomial T^2 - a_p T + p,
    then by the standard Weil-conjectures recursion:
      #E(F_{p^k}) = p^k + 1 - (α^k + β^k)
    where α, β are the Frobenius eigenvalues.
    """
    a_p = frobenius_trace_elliptic(a, b, p)
    if a_p is None:
        return None
    poly_coefs = [1, -a_p, p]  # T^2 - a_p T + p
    eigs = frobenius_eigenvalues_from_poly(poly_coefs)
    if not eigs or len(eigs) != 2:
        return None
    alpha, beta = eigs
    trace_k = (alpha ** k + beta ** k).real
    # Round to integer (trace should be exact integer)
    return p**k + 1 - round(trace_k)


def frobenius_trace_elliptic(a: int, b: int, p: int) -> Optional[int]:
    """Compute a_p = p + 1 - #E(F_p) for elliptic curve y^2 = x^3 + ax + b."""
    n = count_points_elliptic(a, b, p)
    if n is None:
        return None
    return p + 1 - n


def frobenius_polynomial_elliptic(a: int, b: int, p: int) -> Optional[List[int]]:
    """Return Frobenius polynomial coefficients [1, -a_p, p] for T^2 - a_p T + p."""
    a_p = frobenius_trace_elliptic(a, b, p)
    if a_p is None:
        return None
    return [1, -a_p, p]


def frobenius_eigenvalues_from_poly(coeffs: List[int]) -> List[complex]:
    """Return roots of polynomial given by coefficients (descending degree).
    
    For Frobenius polynomial T^2 - a_p T + p, returns [α, β] where
    α + β = a_p and α·β = p. By Hasse, |α| = |β| = √p.
    """
    # Solve quadratic / quartic / etc. For degree 2:
    if len(coeffs) == 3:
        a, b, c = coeffs
        disc = b**2 - 4*a*c
        if disc >= 0:
            sq = disc**0.5
        else:
            sq = cmath.sqrt(disc)
        return [(-b + sq) / (2*a), (-b - sq) / (2*a)]
    # General polynomial via numpy roots if available
    try:
        import numpy as np
        roots = np.roots(coeffs)
        return [complex(r) for r in roots]
    except ImportError:
        return []


def is_tate_eigenvalue(alpha: complex, p: int, codim: int,
                       tolerance: float = 1e-9) -> bool:
    """Test if α equals p^codim (within tolerance), indicating a Tate class
    at codimension `codim`.
    
    The Tate conjecture says: an eigenvalue of Frobenius on H^{2·codim}
    equal to p^codim corresponds to an algebraic cycle of codimension
    `codim`.
    """
    target = p ** codim
    return abs(alpha - target) < tolerance and abs(alpha.imag) < tolerance


def is_supersingular_elliptic(a: int, b: int, p: int) -> Optional[bool]:
    """Test if y^2 = x^3 + a x + b is supersingular at p.
    
    A curve is supersingular iff #E(F_p) ≡ 1 (mod p), equivalently
    a_p ≡ 0 (mod p), equivalently the Frobenius trace is divisible by p.
    For p > 3 and ordinary supersingular distinction.
    """
    a_p = frobenius_trace_elliptic(a, b, p)
    if a_p is None:
        return None
    return a_p % p == 0


def detect_cm_elliptic(a: int, b: int, primes: List[int]) -> dict:
    """Heuristic CM detection: a CM elliptic curve has supersingular
    reduction at half the primes (those split in the CM field).
    
    Returns dict with primes split into supersingular / ordinary,
    plus a 'cm_signal' (fraction supersingular).
    """
    supersingular = []
    ordinary = []
    for p in primes:
        ss = is_supersingular_elliptic(a, b, p)
        if ss is None:
            continue
        if ss:
            supersingular.append(p)
        else:
            ordinary.append(p)
    total = len(supersingular) + len(ordinary)
    cm_signal = len(supersingular) / total if total > 0 else 0.0
    return {
        'supersingular_primes': supersingular,
        'ordinary_primes': ordinary,
        'cm_signal_fraction': cm_signal,
        # CM has ~50% supersingular; non-CM has density 0
        'cm_likely': cm_signal > 0.3,
    }


def hasse_bound_holds(a_p: int, p: int) -> bool:
    """Verify |a_p| ≤ 2√p (Hasse-Weil bound for elliptic curves over F_p)."""
    return abs(a_p) <= 2 * p**0.5


# ─── Convenience for K3 / surface stubs (downstream Ch 26 will flesh out) ───

def count_points_double_cover(sextic_coeffs: list, p: int) -> int:
    """STUB: count #X(F_p) for K3 X = double cover of P^2 branched over a
    smooth sextic curve y^2 = f(x_1, x_2, x_3) where f is the sextic.
    
    For real use, this needs (1) explicit sextic in 3 variables, (2)
    projective point enumeration, (3) careful handling of singular points.
    Ch 26 will implement the full version.
    """
    raise NotImplementedError(
        "K3 point-counting deferred to ch_26_tate_point_counting. "
        "This stub exists to document the framework signature for surfaces."
    )


def zeta_function_l_factor(N_list: List[int], p: int, dim: int) -> str:
    """Given counts N_k = #X(F_{p^k}) for k=1..K, return the zeta function
    Z(X, t) = exp(Σ_k N_k t^k / k) factored according to the Weil conjectures:
      Z(X, t) = P_1(t) P_3(t) ... / (P_0(t) P_2(t) ... P_{2n}(t))
    
    For a smooth proj variety of dim n, P_i(t) has degree b_i = i-th Betti
    number, and roots are inverse Frobenius eigenvalues.
    
    This is a STUB returning a description string; full implementation
    in ch_26.
    """
    return (f"Z(X, t) factored according to Weil conjectures: degree {dim}, "
            f"counts {N_list[:3]}{'...' if len(N_list) > 3 else ''} over F_p, p={p}")


# ─── Self-test ──────────────────────────────────────────────────────────

if __name__ == '__main__':
    # Quick sanity: count y^2 = x^3 - x over F_7 (CM by Z[i])
    # Expected: #E(F_7) = 8 (verified classical example)
    print("Sanity: y^2 = x^3 - x over F_7")
    n = count_points_elliptic(-1, 0, 7)
    print(f"  #E(F_7) = {n}  (expected: 8)")
    a_p = frobenius_trace_elliptic(-1, 0, 7)
    print(f"  a_7 = {a_p}  (expected: 0 — supersingular at 7)")
    
    poly = frobenius_polynomial_elliptic(-1, 0, 7)
    print(f"  Frobenius polynomial: T^2 - {-poly[1]} T + {poly[2]}")
    
    eigs = frobenius_eigenvalues_from_poly(poly)
    for i, e in enumerate(eigs):
        print(f"  α_{i} = {e}  |α| = {abs(e):.4f}  (expected: √7 ≈ {7**0.5:.4f})")
    
    print(f"  Hasse bound: |{a_p}| ≤ 2√7 ≈ {2*7**0.5:.4f}: "
          f"{'OK' if hasse_bound_holds(a_p, 7) else 'FAIL'}")
    
    # Sanity 2: ordinary curve, y^2 = x^3 + x + 1 over F_11
    print("\nSanity: y^2 = x^3 + x + 1 over F_11")
    n = count_points_elliptic(1, 1, 11)
    a_p = frobenius_trace_elliptic(1, 1, 11)
    print(f"  #E(F_11) = {n}, a_11 = {a_p}")
    print(f"  Supersingular? {is_supersingular_elliptic(1, 1, 11)}")
