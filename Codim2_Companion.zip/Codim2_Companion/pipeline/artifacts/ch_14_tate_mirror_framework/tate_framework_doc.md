# Tate-Mirror Framework — Reference

This document describes the framework provided by `ch_14_tate_mirror_framework`.
Downstream steps (`ch_26_tate_point_counting`, `ch_27_cubic_4fold_periods`,
`ch_37_tate_conjecture_atlas`, `ch_43_arithmetic_frontier`) import primitives
from `framework.py`.

## What this framework computes

Given a smooth projective variety X / F_p (or a family parameterized by
{a, b, ...} ⊂ Z), the Tate-mirror framework produces:

1. **Point counts**  `#X(F_{p^k})` for k = 1, 2, ...
2. **Frobenius polynomial**  `P_i(t)` on each cohomology degree i,
   where the eigenvalues of Frobenius on `H^i_ét(X̄, Q_ℓ)` are roots
   of `P_i`.
3. **Tate-class detection**  An eigenvalue `α = p^k` on `H^{2k}`
   indicates an algebraic codim-k cycle by the Tate conjecture.
4. **CM / supersingular detection**  Distinguish ordinary from
   supersingular reduction via the Frobenius trace mod p.

## Why this matters for codim 2

For codim-2 Hodge classes, the parallel Tate conjecture asks: do
all Frobenius-fixed classes in `H^4_ét(X)(2)` come from algebraic
codim-2 cycles?

Computational evidence at finite p, accumulated across primes, builds
empirical support that constrains the conjecture's truth-value.

## Public API

```python
from pipeline.steps.ch_14_tate_mirror_framework.framework import (
    count_points_elliptic,
    count_points_elliptic_extension,
    frobenius_trace_elliptic,
    frobenius_polynomial_elliptic,
    frobenius_eigenvalues_from_poly,
    is_tate_eigenvalue,
    is_supersingular_elliptic,
    detect_cm_elliptic,
    hasse_bound_holds,
)
```

## Verification

The framework's elliptic-curve primitives are verified against:
- **Hasse-Weil bound**  `|a_p| ≤ 2√p` for every (curve, p) tested
- **CM detection**  ~100% accuracy on known CM curves (j ∈ {0, 1728})
  vs known non-CM curves; CM curves show supersingular density ≥ 50%
  while non-CM curves show ≤ 10%.

## Conventions

- Frobenius polynomial for an elliptic curve E/F_p: `P(t) = t^2 - a_p t + p`
- Eigenvalues `α, β` are complex conjugates with `|α| = |β| = √p` (Hasse)
- Supersingular iff `a_p ≡ 0 (mod p)`
- For higher-dim X, P_i has degree b_i (i-th Betti number)

## Limitations

- Point-counting is O(p) per (curve, p) → impractical for p > ~10^5
  without algorithmic improvements (SEA algorithm, Schoof's algorithm).
- K3 / surface counting is deferred to `ch_26_tate_point_counting`,
  which will use polynomial-time methods.
- Currently no support for varieties of mixed characteristic, abelian
  varieties of dim > 1, or non-smooth curves.

## License

CC0. Companion to *Codimension Two* (Kase Branham, 2026).
