#!/usr/bin/env python3
"""
pipeline/runner.py — Dependency-aware execution orchestrator.

Reads each step's spec.yaml, builds the DAG, schedules execution in
topological order, parallelizes independent steps, supports resume.

Usage:
    python -m pipeline.runner --only ch_21_hassett_discriminants
    python -m pipeline.runner --only ch_21_hassett_discriminants -- --quick --workers 4
    python -m pipeline.runner --from ch_19_k3_atlas
    python -m pipeline.runner --all
    python -m pipeline.runner --part 5
    python -m pipeline.runner --part C    # Appendix C
    python -m pipeline.runner --all --dry-run
    python -m pipeline.runner --only ch_21 --force

For live monitoring during a run, open a second terminal and:
    python -m pipeline.tui

Author: Kase Branham — Independent Researcher
"""

import argparse
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from registry import (
    discover_steps, build_dag, topological_sort, get_unblocked_steps,
    is_step_complete, read_progress, write_progress, STEPS_ROOT,
)
from kase_utils import C, banner, section


def part_for_chapter(ch):
    """Map chapter number to part number for --part flag."""
    if ch is None:
        return None
    if isinstance(ch, str) and 'appendix' in ch.lower():
        return 'C'
    try:
        ch = int(ch)
    except (ValueError, TypeError):
        return None
    if 1 <= ch <= 4: return 1
    if 5 <= ch <= 10: return 2
    if 11 <= ch <= 17: return 3
    if 18 <= ch <= 24: return 4
    if 25 <= ch <= 34: return 5
    if 35 <= ch <= 40: return 6
    if 41 <= ch <= 45: return 7
    return None


def run_step(step_id: str, step_args: list = None, dry_run: bool = False) -> int:
    """
    Execute a single step in a subprocess. Returns exit code.
    
    Steps are invoked as `python -m pipeline.steps.<step_id>` so they
    can be run standalone or via the orchestrator.
    """
    step_args = step_args or []
    cmd = [sys.executable, '-m', f'pipeline.steps.{step_id}'] + step_args
    
    if dry_run:
        print(f"  {C.muted('[dry-run]')} {' '.join(cmd)}")
        return 0
    
    print(f"  {C.cyan('→')} Running {step_id} ...")
    try:
        # Set status to running before subprocess starts
        write_progress(step_id, status='running')
        result = subprocess.run(cmd, cwd=Path(__file__).parent.parent)
        return result.returncode
    except KeyboardInterrupt:
        print(f"  {C.yellow('!')} {step_id} interrupted")
        write_progress(step_id, status='error', error_message='interrupted')
        return 130
    except Exception as e:
        print(f"  {C.red('✗')} {step_id} failed to launch: {e}")
        write_progress(step_id, status='error', error_message=str(e))
        return 1


def get_steps_to_run(args, steps: dict, dag: dict) -> list:
    """Resolve --only / --from / --all / --part into a list of step_ids in topological order."""
    if args.only:
        return [args.only]
    
    if args.from_step:
        # Run from_step + all downstream (transitively)
        downstream = set([args.from_step])
        changed = True
        while changed:
            changed = False
            for step_id, deps in dag.items():
                if step_id not in downstream and (deps & downstream):
                    downstream.add(step_id)
                    changed = True
        # Sort topologically
        all_order = topological_sort(dag)
        return [s for s in all_order if s in downstream]
    
    if args.part:
        # Accept '5' / 5 / 'C' — coerce numeric strings to int for comparison
        target_part = args.part
        try:
            target_part = int(target_part)
        except (ValueError, TypeError):
            target_part = str(target_part).upper()
        filtered = []
        for step_id, spec in steps.items():
            if part_for_chapter(spec.get('chapter')) == target_part:
                filtered.append(step_id)
        # Sort topologically
        all_order = topological_sort(dag)
        return [s for s in all_order if s in filtered]
    
    if args.all:
        return topological_sort(dag)
    
    return []


def execute_pipeline(args, steps_to_run: list, dag: dict, step_args: list):
    """
    Run the steps in topological order, respecting dependencies and force flag.
    """
    if not steps_to_run:
        print(C.warn("No steps to run."))
        return
    
    section(f"Executing {len(steps_to_run)} step(s)")
    
    total_failed = 0
    total_completed = 0
    total_skipped = 0
    
    for step_id in steps_to_run:
        # Skip if already complete (unless --force)
        if is_step_complete(step_id) and not args.force:
            print(f"  {C.green('✓')} {step_id} already complete (use --force to re-run)")
            total_skipped += 1
            continue
        
        # Check upstream dependencies
        if not args.dry_run:
            upstream = dag.get(step_id, set())
            unmet = [u for u in upstream if not is_step_complete(u)]
            if unmet:
                print(f"  {C.yellow('!')} {step_id} blocked, unmet deps: {', '.join(unmet)}")
                total_failed += 1
                continue
        
        # Execute
        rc = run_step(step_id, step_args, dry_run=args.dry_run)
        
        if rc == 0:
            total_completed += 1
            print(f"  {C.green('✓')} {step_id} completed")
        else:
            total_failed += 1
            print(f"  {C.red('✗')} {step_id} failed (exit {rc})")
            if args.fail_fast:
                print(f"\n{C.fail('Fail-fast: stopping pipeline.')}")
                break
    
    # Summary
    print()
    section("Pipeline run summary")
    print(f"  {C.green('Completed')}: {total_completed}")
    if total_skipped:
        print(f"  {C.muted('Skipped')}:   {total_skipped}")
    if total_failed:
        print(f"  {C.red('Failed')}:    {total_failed}")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Codim2 pipeline runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    
    # Mode selection (mutually exclusive)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--only', metavar='STEP_ID',
                      help='Run a single step')
    mode.add_argument('--from', dest='from_step', metavar='STEP_ID',
                      help='Run a step + all downstream dependencies')
    mode.add_argument('--all', action='store_true',
                      help='Run the full pipeline (in dependency order)')
    mode.add_argument('--part', metavar='N',
                      help='Run all steps in part N (1-7 or C for Appendix)')
    mode.add_argument('--list', action='store_true',
                      help='List all registered steps without running')
    
    # Flags
    parser.add_argument('--dry-run', action='store_true',
                        help='Show what would run, do not execute')
    parser.add_argument('--force', action='store_true',
                        help='Re-run steps even if already complete')
    parser.add_argument('--fail-fast', action='store_true',
                        help='Stop on first failure (default: continue)')
    
    args, step_args = parser.parse_known_args()
    
    # Strip leading '--' from step_args if present
    if step_args and step_args[0] == '--':
        step_args = step_args[1:]
    
    banner("CODIM2 PIPELINE RUNNER", {
        'Mode': 'only ' + args.only if args.only
                else 'from ' + args.from_step if args.from_step
                else 'part ' + str(args.part) if args.part
                else 'all' if args.all else 'list',
        'Dry-run': args.dry_run,
        'Force': args.force,
        'Step args': ' '.join(step_args) if step_args else '(none)',
    })
    
    steps = discover_steps()
    if not steps:
        print(C.fail("No steps registered. Create steps under pipeline/steps/<step_id>/ with spec.yaml."))
        sys.exit(1)
    
    dag = build_dag(steps)
    
    if args.list:
        order = topological_sort(dag)
        print(f"Registered steps ({len(order)}, topological order):")
        for i, sid in enumerate(order, 1):
            spec = steps[sid]
            ch = spec.get('chapter', '?')
            title = spec.get('title', '?')
            deps = dag[sid]
            dep_str = f"  ← {','.join(sorted(deps))}" if deps else ''
            print(f"  {i:>3}. {sid:<42} ch {ch:>2}  {title}{dep_str}")
        return
    
    steps_to_run = get_steps_to_run(args, steps, dag)
    execute_pipeline(args, steps_to_run, dag, step_args)


if __name__ == '__main__':
    main()
