"""
Phase 1 structural tests on the Schöller-Skarke 5D Hodge catalog.

Three quantitative tests that explain the 12.80% mirror closure rate
observed on the SS 5D triple set (Section 6 of the preprint):

  A. (h11, h13)-only projected closure
     — drops h12 and checks closure on (h11, h13) pairs.
     — tests whether h12 is the structural obstruction.

  B. Closure rate stratified by h12
     — for each of ~1689 distinct h12 values, compute the closure rate
       within that h12 substratum (mirror swap preserves h12).
     — gives a closure-vs-h12 dependence curve.

  C. Asymmetry quantification
     — among unmatched tuples, count h11 < h13 vs h11 > h13.
     — tests whether the catalog is enumerated with a directional bias.

Usage:
  python -m pipeline.data_tools.ss_phase1

Auto-finds the largest .pkl.gz under data/cache/ss_5d/ and writes JSON
summaries + an SVG figure (closure-rate-by-h12) to analysis/ss_5d/.
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np

from pipeline.data_tools.ss_streamer import (
    load_tuples, SS_CACHE_DIR,
    H11_SHIFT, H12_SHIFT, H11_MASK, H12_MASK, H13_MASK, H12_INPLACE_MASK,
)


SS_ANALYSIS_DIR = Path(__file__).parent.parent.parent / 'analysis' / 'ss_5d'


# ─────────────────────────────────────────────────────────────────
# Test A: (h11, h13)-only projected closure
# ─────────────────────────────────────────────────────────────────

def test_a_projected_closure(packed_arr, chunk_size: int = 50_000_000):
    """Project (h11, h12, h13) tuples to (h11, h13) pairs, dedup, check closure.
    
    Closure under (h11, h13) <-> (h13, h11). If high (~80%+), h12 is the
    main obstruction. If still ~12-30%, obstruction is intrinsic to the
    (h11, h13) plane.
    """
    n = len(packed_arr)
    print(f"  [Test A] Extracting (h11, h13) projections from {n:,} tuples...")
    
    # Pack as (h11 << 24) | h13 — both fit in 24 bits (max 303,148 < 2^24)
    projected_chunks = []
    for start in range(0, n, chunk_size):
        end = min(start + chunk_size, n)
        chunk = packed_arr[start:end]
        h11 = chunk >> H11_SHIFT          # uint64, full bits
        h13 = chunk & H13_MASK
        pair = (h11 << 24) | h13
        projected_chunks.append(pair)
    
    projected = np.concatenate(projected_chunks)
    del projected_chunks
    print(f"  [Test A] Deduplicating {len(projected):,} projections...")
    projected_unique = np.unique(projected)  # sorted ascending
    del projected
    n_pairs = len(projected_unique)
    print(f"  [Test A] Distinct (h11, h13) pairs: {n_pairs:,} "
          f"({100*n_pairs/n:.2f}% of original triple count)")
    
    print(f"  [Test A] Computing closure of (h11, h13) pairs...")
    h11_part = projected_unique >> 24
    h13_part = projected_unique & 0xFFFFFF
    mirrored = (h13_part << 24) | h11_part
    
    is_self = h11_part == h13_part
    n_self = int(is_self.sum())
    
    idx = np.searchsorted(projected_unique, mirrored)
    idx_clamped = np.clip(idx, 0, n_pairs - 1)
    matches = projected_unique[idx_clamped] == mirrored
    n_matched_total = int((matches & ~is_self).sum())
    n_matched_pairs = n_matched_total // 2
    n_unmatched = int((~matches & ~is_self).sum())
    
    assert n_self + 2 * n_matched_pairs + n_unmatched == n_pairs
    coverage = (n_self + 2 * n_matched_pairs) / n_pairs * 100
    
    return {
        'n_original_triples': n,
        'n_distinct_pairs': n_pairs,
        'n_self_mirror': n_self,
        'n_matched_pairs': n_matched_pairs,
        'n_unmatched': n_unmatched,
        'coverage_pct': coverage,
    }


# ─────────────────────────────────────────────────────────────────
# Test B: closure stratified by h12
# ─────────────────────────────────────────────────────────────────

def test_b_closure_by_h12(packed_arr, chunk_size: int = 50_000_000):
    """Stratify by h12, compute closure rate within each substratum.
    
    Mirror swap preserves h12, so each substratum's closure is a
    well-defined sub-problem. Returns per-stratum results sorted by h12.
    """
    n = len(packed_arr)
    print(f"  [Test B] Grouping {n:,} tuples by h12 ({chunk_size//1_000_000}M-chunk passes)...")
    
    # Build {h12: [chunk slices]} via single pass.
    # Since master is sorted (h11, h12, h13), boolean-masked slices preserve order.
    strata_parts: dict[int, list[np.ndarray]] = {}
    for start in range(0, n, chunk_size):
        end = min(start + chunk_size, n)
        chunk = packed_arr[start:end]
        h12_chunk = ((chunk >> H12_SHIFT) & H12_MASK).astype(np.uint32)
        unique_h12 = np.unique(h12_chunk)
        for h12 in unique_h12:
            mask = h12_chunk == h12
            strata_parts.setdefault(int(h12), []).append(chunk[mask].copy())
        del h12_chunk
    
    print(f"  [Test B] Concatenating {len(strata_parts)} strata...")
    strata = {h12: np.concatenate(parts) for h12, parts in strata_parts.items()}
    del strata_parts
    
    print(f"  [Test B] Running closure on {len(strata)} h12 strata...")
    results = []
    for h12 in sorted(strata):
        stratum = strata[h12]
        n_total = len(stratum)
        if n_total == 0:
            continue
        
        h11_part = stratum >> H11_SHIFT
        h13_part = stratum & H13_MASK
        h12_in_place = stratum & np.uint64(H12_INPLACE_MASK)
        mirrored = (h13_part << H11_SHIFT) | h12_in_place | h11_part
        
        is_self = h11_part == h13_part
        n_self = int(is_self.sum())
        
        idx = np.searchsorted(stratum, mirrored)
        idx_clamped = np.clip(idx, 0, n_total - 1)
        matches = stratum[idx_clamped] == mirrored
        n_matched_total = int((matches & ~is_self).sum())
        n_matched_pairs = n_matched_total // 2
        n_unmatched = int((~matches & ~is_self).sum())
        coverage = (n_self + 2 * n_matched_pairs) / n_total * 100 if n_total else 0.0
        
        results.append({
            'h12': h12,
            'n_total': n_total,
            'n_self_mirror': n_self,
            'n_matched_pairs': n_matched_pairs,
            'n_unmatched': n_unmatched,
            'coverage_pct': coverage,
        })
    
    return {
        'n_strata': len(results),
        'per_stratum': results,
    }


# ─────────────────────────────────────────────────────────────────
# Test C: asymmetry of unmatched (h11 < h13 vs h11 > h13)
# ─────────────────────────────────────────────────────────────────

def test_c_asymmetry(packed_arr, chunk_size: int = 50_000_000):
    """Among unmatched tuples, count h11 < h13 vs h11 > h13.
    
    Strong asymmetry indicates the catalog is enumerated with a
    directional bias (one side of the mirror is preferred).
    """
    n = len(packed_arr)
    print(f"  [Test C] Scanning {n:,} tuples for unmatched ± sign(h11 - h13)...")
    
    n_self = 0
    n_matched = 0
    n_unmatched_h11_lt_h13 = 0
    n_unmatched_h11_gt_h13 = 0
    n_chunks = (n + chunk_size - 1) // chunk_size
    
    for ci, start in enumerate(range(0, n, chunk_size)):
        end = min(start + chunk_size, n)
        chunk = packed_arr[start:end]
        
        h11_part = chunk >> H11_SHIFT
        h13_part = chunk & H13_MASK
        h12_in_place = chunk & np.uint64(H12_INPLACE_MASK)
        mirrored = (h13_part << H11_SHIFT) | h12_in_place | h11_part
        
        is_self = h11_part == h13_part
        n_self += int(is_self.sum())
        
        idx = np.searchsorted(packed_arr, mirrored)
        idx_clamped = np.clip(idx, 0, n - 1)
        matches = packed_arr[idx_clamped] == mirrored
        n_matched += int((matches & ~is_self).sum())
        
        unmatched = ~matches & ~is_self
        h11_lt_h13 = h11_part < h13_part
        n_unmatched_h11_lt_h13 += int((unmatched & h11_lt_h13).sum())
        n_unmatched_h11_gt_h13 += int((unmatched & ~h11_lt_h13).sum())
        
        if n_chunks > 1:
            print(f"    [chunk {ci+1}/{n_chunks}] processed {end:,}/{n:,} ({end/n*100:.1f}%)")
    
    n_unmatched_total = n_unmatched_h11_lt_h13 + n_unmatched_h11_gt_h13
    pct_lt = (n_unmatched_h11_lt_h13 / n_unmatched_total * 100
              if n_unmatched_total else 0.0)
    pct_gt = (n_unmatched_h11_gt_h13 / n_unmatched_total * 100
              if n_unmatched_total else 0.0)
    
    return {
        'n_total_tuples': n,
        'n_self_mirror': n_self,
        'n_matched_tuples': n_matched,  # counted each side of pair once
        'n_unmatched_total': n_unmatched_total,
        'n_unmatched_h11_lt_h13': n_unmatched_h11_lt_h13,
        'n_unmatched_h11_gt_h13': n_unmatched_h11_gt_h13,
        'pct_h11_lt_h13': pct_lt,
        'pct_h11_gt_h13': pct_gt,
        'asymmetry_ratio': (n_unmatched_h11_lt_h13 / max(n_unmatched_h11_gt_h13, 1)),
    }


# ─────────────────────────────────────────────────────────────────
# Figure renderer for Test B (closure rate vs h12 scatter)
# ─────────────────────────────────────────────────────────────────

def render_closure_by_h12(per_stratum: list, output_svg: Path):
    """Scatter plot of closure rate vs h12, with point area ∝ log(n_total)."""
    if not per_stratum:
        raise ValueError("Empty per_stratum")
    
    W, H = 1400, 600
    ml, mr, mt, mb = 90, 30, 60, 70
    pw, ph = W - ml - mr, H - mt - mb
    
    xs = [s['h12'] for s in per_stratum]
    ys = [s['coverage_pct'] for s in per_stratum]
    ns = [s['n_total'] for s in per_stratum]
    
    x_min, x_max = min(xs), max(xs)
    x_span = max(x_max - x_min, 1)
    n_min, n_max = min(ns), max(ns)
    log_n_min = math.log10(max(n_min, 1))
    log_n_max = math.log10(max(n_max, 1))
    log_n_span = max(log_n_max - log_n_min, 1e-9)
    
    def x_pos(h12):
        return ml + (h12 - x_min) / x_span * pw
    
    def y_pos(pct):
        return mt + (1 - pct / 100) * ph
    
    def radius(n):
        # Marker area ∝ log(n): radius in 1.5–6 px
        if n_max == n_min:
            return 3.0
        t = (math.log10(max(n, 1)) - log_n_min) / log_n_span
        return 1.5 + t * 4.5
    
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
        f'viewBox="0 0 {W} {H}" font-family="ui-sans-serif, system-ui, sans-serif">',
        f'<rect width="{W}" height="{H}" fill="white"/>',
        f'<text x="{W/2}" y="32" font-size="20" font-weight="bold" '
        f'text-anchor="middle" fill="#111">'
        f'Mirror closure rate by h^{{1,2}} stratum (Schöller-Skarke 5D)</text>',
        f'<rect x="{ml}" y="{mt}" width="{pw}" height="{ph}" '
        f'fill="#fafafa" stroke="#999" stroke-width="1"/>',
    ]
    
    # Horizontal reference line at the catalog-level 12.80% closure
    overall_y = y_pos(12.80)
    parts.append(f'<line x1="{ml}" y1="{overall_y:.2f}" x2="{ml+pw}" y2="{overall_y:.2f}" '
                 f'stroke="#dc2626" stroke-width="1" stroke-dasharray="6,4" opacity="0.7"/>')
    parts.append(f'<text x="{ml+pw-8:.2f}" y="{overall_y-5:.2f}" font-size="11" '
                 f'text-anchor="end" fill="#dc2626">catalog-level closure: 12.80%</text>')
    
    # Scatter points
    for h12, pct, ntotal in zip(xs, ys, ns):
        cx = x_pos(h12)
        cy = y_pos(pct)
        r = radius(ntotal)
        parts.append(f'<circle cx="{cx:.2f}" cy="{cy:.2f}" r="{r:.2f}" '
                     f'fill="#7c3aed" opacity="0.55"/>')
    
    # X-axis ticks: nice round h12 values
    x_tick = 250
    while x_min - (x_min % x_tick) < x_max:
        t = (x_min // x_tick + (1 if x_min > 0 else 0)) * x_tick
        if t > x_max:
            break
        xp = x_pos(t)
        parts.append(f'<line x1="{xp:.2f}" y1="{mt+ph}" x2="{xp:.2f}" y2="{mt+ph+5}" stroke="#666"/>')
        parts.append(f'<text x="{xp:.2f}" y="{mt+ph+22}" font-size="11" '
                     f'text-anchor="middle" fill="#444">{t:,}</text>')
        x_min = t + 1  # move to next tick
        if x_min > x_max:
            break
    
    # Y-axis ticks: 0, 20, 40, 60, 80, 100 %
    for pct in [0, 20, 40, 60, 80, 100]:
        yp = y_pos(pct)
        parts.append(f'<line x1="{ml-5}" y1="{yp:.2f}" x2="{ml}" y2="{yp:.2f}" stroke="#666"/>')
        parts.append(f'<text x="{ml-10}" y="{yp+4:.2f}" font-size="11" '
                     f'text-anchor="end" fill="#444">{pct}%</text>')
    
    parts.append(f'<text x="{ml+pw/2}" y="{H-18}" font-size="13" '
                 f'text-anchor="middle" fill="#222">h^{{1,2}}</text>')
    parts.append(f'<g transform="translate(28, {mt+ph/2}) rotate(-90)">'
                 f'<text font-size="13" text-anchor="middle" fill="#222">'
                 f'closure rate within stratum (marker area ∝ log stratum size)</text></g>')
    parts.append('</svg>')
    
    output_svg.parent.mkdir(parents=True, exist_ok=True)
    output_svg.write_text('\n'.join(parts), encoding='utf-8')


# ─────────────────────────────────────────────────────────────────
# Pretty printers + CLI
# ─────────────────────────────────────────────────────────────────

def print_test_a(a):
    print("\n  ── Test A: (h¹¹, h¹³)-only projected closure ──")
    print(f"    Original distinct triples:           {a['n_original_triples']:>16,}")
    print(f"    Distinct (h¹¹, h¹³) pairs:           {a['n_distinct_pairs']:>16,}")
    print(f"    Self-mirror pairs (h¹¹ = h¹³):       {a['n_self_mirror']:>16,}")
    print(f"    Matched mirror pairs:                {a['n_matched_pairs']:>16,}")
    print(f"    Unmatched pairs:                     {a['n_unmatched']:>16,}")
    print(f"    Projected coverage:                  {a['coverage_pct']:>15.2f}%")


def print_test_b(b):
    per = b['per_stratum']
    print(f"\n  ── Test B: closure rate by h¹² stratum ──")
    print(f"    Number of strata:                    {b['n_strata']:>16,}")
    if not per:
        return
    cov = [s['coverage_pct'] for s in per]
    sz = [s['n_total'] for s in per]
    top5 = sorted(per, key=lambda s: s['coverage_pct'], reverse=True)[:5]
    bot5 = sorted(per, key=lambda s: s['coverage_pct'])[:5]
    big5 = sorted(per, key=lambda s: s['n_total'], reverse=True)[:5]
    
    print(f"    Closure-pct range:                   "
          f"[{min(cov):.2f}%, {max(cov):.2f}%]")
    print(f"    Stratum sizes:                       "
          f"[{min(sz):,}, {max(sz):,}]")
    
    # Catalog-weighted closure (sanity: should equal 12.80%)
    total_n = sum(sz)
    total_self = sum(s['n_self_mirror'] for s in per)
    total_matched_pairs = sum(s['n_matched_pairs'] for s in per)
    weighted = (total_self + 2 * total_matched_pairs) / total_n * 100
    print(f"    Catalog-weighted closure (sanity):   {weighted:>15.2f}%")
    
    print(f"\n    Top 5 highest-closure strata:")
    for s in top5:
        print(f"      h¹²={s['h12']:>4}: closure={s['coverage_pct']:6.2f}% "
              f"({s['n_total']:>10,} tuples)")
    print(f"    Top 5 lowest-closure strata (by size > 1000):")
    for s in [x for x in bot5 if x['n_total'] > 1000][:5]:
        print(f"      h¹²={s['h12']:>4}: closure={s['coverage_pct']:6.2f}% "
              f"({s['n_total']:>10,} tuples)")
    print(f"    Top 5 largest strata:")
    for s in big5:
        print(f"      h¹²={s['h12']:>4}: closure={s['coverage_pct']:6.2f}% "
              f"({s['n_total']:>10,} tuples)")


def print_test_c(c):
    print(f"\n  ── Test C: asymmetry of unmatched tuples ──")
    print(f"    Self-mirror:                         {c['n_self_mirror']:>16,}")
    print(f"    Matched (each side counted):         {c['n_matched_tuples']:>16,}")
    print(f"    Unmatched (total):                   {c['n_unmatched_total']:>16,}")
    print(f"      with h¹¹ < h¹³ (low h¹¹ side):     "
          f"{c['n_unmatched_h11_lt_h13']:>16,}  ({c['pct_h11_lt_h13']:6.2f}%)")
    print(f"      with h¹¹ > h¹³ (high h¹¹ side):    "
          f"{c['n_unmatched_h11_gt_h13']:>16,}  ({c['pct_h11_gt_h13']:6.2f}%)")
    print(f"    Asymmetry ratio (LT/GT):             {c['asymmetry_ratio']:>15.2f}×")


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Phase 1 structural tests on the SS 5D catalog.")
    parser.add_argument('--cache', type=str, default=None,
                        help="Path to merged tuple cache (auto-find largest if omitted).")
    parser.add_argument('--out-dir', type=str, default=None,
                        help=f"Output directory (default: {SS_ANALYSIS_DIR}).")
    parser.add_argument('--skip', choices=['a', 'b', 'c'], action='append',
                        default=[], help="Skip a specific test (may repeat).")
    args = parser.parse_args(argv)
    
    # Auto-find cache: prefer merged, else largest .pkl.gz
    if args.cache:
        path = Path(args.cache)
    else:
        if not SS_CACHE_DIR.exists():
            print(f"  ✗ No cache directory at {SS_CACHE_DIR}")
            return 1
        candidates = sorted(SS_CACHE_DIR.glob('ss_hodge_tuples*.pkl.gz'),
                            key=lambda p: p.stat().st_size, reverse=True)
        if not candidates:
            print(f"  ✗ No cache files in {SS_CACHE_DIR}")
            print(f"    Run `python -m pipeline.data_tools.ss_streamer scan-files` first.")
            return 1
        path = candidates[0]
    
    print(f"  Loading {path.name} ...")
    packed, meta = load_tuples(path)
    if not isinstance(packed, np.ndarray):
        # Convert set to array if needed
        from pipeline.data_tools.ss_streamer import _pack_tuples_to_uint64
        packed = np.sort(_pack_tuples_to_uint64(packed))
    
    # Defensive: production pipeline guarantees sorted (np.unique + sorted merges),
    # but a directly-saved cache could be unsorted. searchsorted requires sorted input.
    from pipeline.data_tools.ss_streamer import _is_sorted
    if not _is_sorted(packed):
        print(f"  [defensive] Loaded array not sorted — sorting now ...")
        packed = np.sort(packed)
    
    print(f"  Loaded {len(packed):,} tuples ({packed.nbytes/1024/1024:.1f} MB) "
          f"from {meta.get('_rows_scanned', '?'):,} rows")
    print("=" * 72)
    print("  SCHÖLLER-SKARKE 5D — PHASE 1 STRUCTURAL TESTS")
    print("=" * 72)
    
    results = {}
    
    if 'a' not in args.skip:
        a = test_a_projected_closure(packed)
        results['test_a_projected_closure'] = a
        print_test_a(a)
    
    if 'c' not in args.skip:
        # Run C before B to keep memory peak lower (B builds strata dict)
        c = test_c_asymmetry(packed)
        results['test_c_asymmetry'] = c
        print_test_c(c)
    
    if 'b' not in args.skip:
        b = test_b_closure_by_h12(packed)
        results['test_b_closure_by_h12_summary'] = {
            'n_strata': b['n_strata']
        }
        # Save full per-stratum separately
        print_test_b(b)
    
    out = Path(args.out_dir) if args.out_dir else SS_ANALYSIS_DIR
    out.mkdir(parents=True, exist_ok=True)
    summary_path = out / 'ss_phase1_summary.json'
    summary_path.write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(f"\n  → {summary_path}")
    
    if 'b' not in args.skip:
        b_path = out / 'ss_phase1_test_b_per_stratum.json'
        b_path.write_text(json.dumps(b, indent=2), encoding='utf-8')
        print(f"  → {b_path}")
        svg_path = out / 'ss_phase1_closure_by_h12.svg'
        render_closure_by_h12(b['per_stratum'], svg_path)
        print(f"  → {svg_path}")
    
    return 0


if __name__ == '__main__':
    import sys
    sys.exit(main())
