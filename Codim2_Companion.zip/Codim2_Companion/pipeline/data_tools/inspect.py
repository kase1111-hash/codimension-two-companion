#!/usr/bin/env python3
"""
pipeline/data_tools/inspect.py — Quick look at any TU Wien data file.

Auto-detects format by looking at the first non-empty line:
  - TU Wien .spec format (Hodge.K3, alltoric.spec, wp4.spec, toric.spec)
  - PALP polytope-list format (v05.gz ... v36.gz)

Usage:
    python -m pipeline.data_tools.inspect path/to/file.gz
    python -m pipeline.data_tools.inspect data/raw/v05.gz --stats
"""

import argparse
import gzip
import re
import sys
from pathlib import Path


def detect_format(path) -> str:
    """Return 'spec', 'palp', or 'unknown' based on the first useful line."""
    path = Path(path)
    opener = gzip.open if str(path).endswith('.gz') else open
    try:
        with opener(path, 'rt', encoding='utf-8', errors='replace') as f:
            for _ in range(20):  # try first 20 lines
                line = f.readline()
                if not line:
                    break
                line = line.strip()
                if not line:
                    continue
                # .spec lines have "=d" tokens and "H: x y"
                if '=d' in line and 'H:' in line:
                    return 'spec'
                # PALP lines start with two ints + comment, often with "H:x,y"
                # The comma in H: is the distinguishing feature
                if re.match(r'^\s*\d+\s+\d+\s+', line) and 'H:' in line and ',' in line:
                    return 'palp'
                # Pure header without H but with M:/N:
                if re.match(r'^\s*\d+\s+\d+\s+', line) and ('M:' in line or 'N:' in line):
                    return 'palp'
                # First line that's just integers is likely a PALP matrix row preceded
                # by a header we missed — keep looking
                if re.match(r'^\s*-?\d+(\s+-?\d+)+\s*$', line):
                    continue
    except Exception:
        return 'unknown'
    return 'unknown'


def main():
    parser = argparse.ArgumentParser(description='Inspect TU Wien data files')
    parser.add_argument('path', help='Path to file (gzipped or not). Supports globs on Windows.')
    parser.add_argument('--stats', action='store_true', help='Aggregate stats')
    parser.add_argument('--limit', type=int, default=5, help='Preview entries')
    args = parser.parse_args()
    
    # If a glob was passed (Windows cmd doesn't expand), pick the first match
    # and warn if there are multiple
    import glob as glob_mod
    if any(c in args.path for c in '*?['):
        matches = sorted(glob_mod.glob(args.path))
        if not matches:
            print(f"  ✗ No files match: {args.path}", file=sys.stderr)
            return 1
        if len(matches) > 1:
            print(f"  ⚠ Glob matched {len(matches)} files; inspecting only the first.")
            print(f"     For multi-file aggregate, use palp_parser directly.")
        p = Path(matches[0])
    else:
        p = Path(args.path)
    
    if not p.exists():
        print(f"  ✗ Not found: {p}", file=sys.stderr)
        return 1
    
    fmt = detect_format(p)
    print(f"  Path:   {p}")
    print(f"  Size:   {p.stat().st_size:,} bytes")
    print(f"  Format: {fmt}")
    print()
    
    if fmt == 'spec':
        from pipeline.data_tools.tuwien_parser import parse_tuwien_file
        if args.stats:
            n = 0
            pairs = set()
            for e in parse_tuwien_file(p):
                n += 1
                pairs.add((e.h11, e.h12))
            print(f"  Entries:           {n:,}")
            print(f"  Distinct (h11,h12): {len(pairs):,}")
        else:
            for i, e in enumerate(parse_tuwien_file(p)):
                if i >= args.limit:
                    break
                print(f"  [{i}] h11={e.h11} h12={e.h12} type={e.type_code} "
                      f"M=({e.m_points},{e.m_vertices}) N=({e.n_points},{e.n_vertices})")
    
    elif fmt == 'palp':
        from pipeline.data_tools.palp_parser import parse_palp_file, palp_summary
        if args.stats:
            s = palp_summary([p])
            print(f"  Total polytopes:    {s['total_entries']:,}")
            print(f"  Distinct (h11,h12): {s['distinct_hodge_pairs']:,}")
            print(f"  h11 range:          {s['h11_range']}")
            print(f"  h12 range:          {s['h12_range']}")
            print(f"  Euler range:        {s['euler_range']}")
            ec = s['euler_cross_check']
            print(f"  Euler cross-check:  {ec['consistent']:,} ok / "
                  f"{ec['inconsistent']:,} mismatch")
            vd = s['vertex_count_distribution']
            print(f"  Vertex counts:      {dict(list(vd.items())[:8])}{' ...' if len(vd)>8 else ''}")
        else:
            for i, e in enumerate(parse_palp_file(p)):
                if i >= args.limit:
                    break
                chk = "✓" if e.euler == e.euler_from_hodge else "?"
                print(f"  [{i}] dim={e.ambient_dim} V={e.n_vertices} "
                      f"h11={e.h11} h12={e.h12} chi={e.euler} {chk}")
                print(f"      M=({e.m_points},{e.m_vertices})  "
                      f"N=({e.n_points},{e.n_vertices_dual})")
                if e.vertices:
                    print(f"      vertices[0]={e.vertices[0]}  "
                          f"({len(e.vertices)} total)")
    else:
        print("  ✗ Unknown format. Showing first 10 lines raw:")
        opener = gzip.open if str(p).endswith('.gz') else open
        with opener(p, 'rt', encoding='utf-8', errors='replace') as f:
            for i, line in enumerate(f):
                if i >= 10: break
                print(f"  | {line.rstrip()}")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
