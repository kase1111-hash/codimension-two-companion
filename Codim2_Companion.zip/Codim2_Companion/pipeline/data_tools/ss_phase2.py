"""
Phase 2 structural analyses on the SS 5D catalog.

Four follow-up tests that build on Phase 1's three findings:
  D. Bivariate (h11, h13) density heatmap + closure-status breakdown
  E. Chi distribution by closure cohort (self-mirror / matched / unmatched)
  F. Mode-at-(sum=2114) substructure analysis
  G. Marginal-distribution null benchmark

Usage:
  python -m pipeline.data_tools.ss_phase2

Auto-finds the largest .pkl.gz under data/cache/ss_5d/. Writes JSON
summaries and four SVG figures to analysis/ss_5d/.
"""

import argparse
import gc
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np

from pipeline.data_tools.ss_streamer import (
    load_tuples, closure_partition, SS_CACHE_DIR,
    _is_sorted, _pack_tuples_to_uint64,
    H11_SHIFT, H12_SHIFT, H11_MASK, H12_MASK, H13_MASK, H12_INPLACE_MASK,
)


SS_ANALYSIS_DIR = Path(__file__).parent.parent.parent / 'analysis' / 'ss_5d'


# ─────────────────────────────────────────────────────────────────
# Helpers: chunked closure-status iteration
# ─────────────────────────────────────────────────────────────────

def _iter_chunks_with_status(packed_arr, chunk_size: int):
    """Yield (chunk, h11, h12, h13, is_self, is_matched, is_unmatched) per chunk.
    
    Performs mirror lookup once per chunk; downstream tests reuse this.
    Master must be sorted."""
    n = len(packed_arr)
    for start in range(0, n, chunk_size):
        end = min(start + chunk_size, n)
        chunk = packed_arr[start:end]
        h11 = (chunk >> H11_SHIFT).astype(np.int64)
        h12 = ((chunk >> H12_SHIFT) & H12_MASK).astype(np.int64)
        h13 = (chunk & H13_MASK).astype(np.int64)
        h12_in_place = chunk & np.uint64(H12_INPLACE_MASK)
        mirrored = ((h13.astype(np.uint64) << H11_SHIFT)
                    | h12_in_place
                    | h11.astype(np.uint64))
        idx = np.searchsorted(packed_arr, mirrored)
        idx_clamped = np.clip(idx, 0, n - 1)
        matches = packed_arr[idx_clamped] == mirrored
        is_self = h11 == h13
        is_matched = matches & ~is_self
        is_unmatched = ~matches & ~is_self
        yield (start, end, n, h11, h12, h13, is_self, is_matched, is_unmatched)


# ─────────────────────────────────────────────────────────────────
# Test D: bivariate (h11, h13) density
# ─────────────────────────────────────────────────────────────────

def test_d_bivariate_density(packed_arr, n_bins: int = 300,
                              chunk_size: int = 50_000_000):
    """Bin (h11, h13) into n_bins × n_bins; track total / matched / unmatched
    counts per cell. Returns three matrices."""
    n = len(packed_arr)
    print(f"  [Test D] Determining (h11, h13) extent on {n:,} tuples...")
    
    # Extent from packed master
    h_max = 0
    for start in range(0, n, chunk_size):
        end = min(start + chunk_size, n)
        chunk = packed_arr[start:end]
        h_max = max(h_max,
                    int((chunk >> H11_SHIFT).max()),
                    int((chunk & H13_MASK).max()))
    print(f"  [Test D] max(h11, h13) = {h_max:,}; binning into {n_bins}×{n_bins}")
    
    bin_edge = h_max + 1
    total = np.zeros((n_bins, n_bins), dtype=np.uint64)
    matched = np.zeros((n_bins, n_bins), dtype=np.uint64)
    unmatched = np.zeros((n_bins, n_bins), dtype=np.uint64)
    
    n_chunks = (n + chunk_size - 1) // chunk_size
    for ci, (start, end, _, h11, h12, h13, is_self, is_matched, is_unmatched) in enumerate(
            _iter_chunks_with_status(packed_arr, chunk_size)):
        bx = ((h11 * n_bins) // bin_edge).astype(np.int32)
        by = ((h13 * n_bins) // bin_edge).astype(np.int32)
        np.clip(bx, 0, n_bins - 1, out=bx)
        np.clip(by, 0, n_bins - 1, out=by)
        
        np.add.at(total, (bx, by), 1)
        np.add.at(matched, (bx[is_matched], by[is_matched]), 1)
        np.add.at(unmatched, (bx[is_unmatched], by[is_unmatched]), 1)
        # self-mirror tuples have h11 == h13, so they land on the diagonal;
        # we add them to `total` (already done above) but not to matched/unmatched
        
        if n_chunks > 1:
            print(f"    [chunk {ci+1}/{n_chunks}] processed {end:,}/{n:,}")
    
    return {
        'h_max': h_max,
        'n_bins': n_bins,
        'bin_width': bin_edge / n_bins,
        'total': total,
        'matched': matched,
        'unmatched': unmatched,
        'n_total': int(total.sum()),
        'n_matched': int(matched.sum()),
        'n_unmatched': int(unmatched.sum()),
    }


# ─────────────────────────────────────────────────────────────────
# Test E: chi distribution by closure cohort
# ─────────────────────────────────────────────────────────────────

def test_e_chi_by_cohort(packed_arr, chunk_size: int = 50_000_000):
    """Split χ counts by closure status into three Counters."""
    n = len(packed_arr)
    print(f"  [Test E] Splitting χ distribution on {n:,} tuples...")
    
    chi_self: Counter = Counter()
    chi_matched: Counter = Counter()
    chi_unmatched: Counter = Counter()
    
    n_chunks = (n + chunk_size - 1) // chunk_size
    for ci, (start, end, _, h11, h12, h13, is_self, is_matched, is_unmatched) in enumerate(
            _iter_chunks_with_status(packed_arr, chunk_size)):
        chi = 48 + 6 * (h11 - h12 + h13)
        
        for mask, counter in [(is_self, chi_self),
                               (is_matched, chi_matched),
                               (is_unmatched, chi_unmatched)]:
            chi_sub = chi[mask]
            if len(chi_sub) > 0:
                u, c = np.unique(chi_sub, return_counts=True)
                for k, v in zip(u.tolist(), c.tolist()):
                    counter[k] += v
        
        if n_chunks > 1:
            print(f"    [chunk {ci+1}/{n_chunks}] processed {end:,}/{n:,}")
    
    return {
        'self_mirror': chi_self,
        'matched': chi_matched,
        'unmatched': chi_unmatched,
        'n_self_mirror': sum(chi_self.values()),
        'n_matched': sum(chi_matched.values()),
        'n_unmatched': sum(chi_unmatched.values()),
    }


# ─────────────────────────────────────────────────────────────────
# Test F: mode-at-sum substructure
# ─────────────────────────────────────────────────────────────────

def test_f_mode_substructure(packed_arr, target_sum: int = 2114,
                              chunk_size: int = 50_000_000):
    """Collect all tuples with h11+h12+h13 == target_sum; analyze structure."""
    n = len(packed_arr)
    print(f"  [Test F] Scanning {n:,} tuples for sum == {target_sum}...")
    
    matched_tuples = []
    n_chunks = (n + chunk_size - 1) // chunk_size
    
    for ci, start in enumerate(range(0, n, chunk_size)):
        end = min(start + chunk_size, n)
        chunk = packed_arr[start:end]
        h11 = (chunk >> H11_SHIFT).astype(np.int64)
        h12 = ((chunk >> H12_SHIFT) & H12_MASK).astype(np.int64)
        h13 = (chunk & H13_MASK).astype(np.int64)
        sums = h11 + h12 + h13
        mask = sums == target_sum
        if mask.any():
            for a, b, c in zip(h11[mask].tolist(), h12[mask].tolist(), h13[mask].tolist()):
                matched_tuples.append((a, b, c))
        if n_chunks > 1 and (ci + 1) % 3 == 0:
            print(f"    [chunk {ci+1}/{n_chunks}] target tuples so far: {len(matched_tuples):,}")
    
    n_total = len(matched_tuples)
    print(f"  [Test F] Found {n_total:,} tuples with sum == {target_sum}")
    if n_total == 0:
        return {'target_sum': target_sum, 'n_tuples': 0}
    
    # Marginals within the subset
    h11_vals = Counter(t[0] for t in matched_tuples)
    h12_vals = Counter(t[1] for t in matched_tuples)
    h13_vals = Counter(t[2] for t in matched_tuples)
    
    # Closure status (check mirrors against the FULL master)
    target_packed = np.fromiter(
        ((a << H11_SHIFT) | (b << H12_SHIFT) | c
         for (a, b, c) in matched_tuples),
        dtype=np.uint64, count=n_total
    )
    target_packed_sorted = np.sort(target_packed)
    
    h11_arr = (target_packed_sorted >> H11_SHIFT)
    h13_arr = (target_packed_sorted & H13_MASK)
    h12_in_place = target_packed_sorted & np.uint64(H12_INPLACE_MASK)
    mirrored = ((h13_arr.astype(np.uint64) << H11_SHIFT)
                | h12_in_place
                | h11_arr.astype(np.uint64))
    is_self_arr = h11_arr == h13_arr
    n_self = int(is_self_arr.sum())
    
    idx = np.searchsorted(packed_arr, mirrored)
    idx_clamped = np.clip(idx, 0, n - 1)
    matches = packed_arr[idx_clamped] == mirrored
    n_matched = int((matches & ~is_self_arr).sum())
    n_unmatched = int((~matches & ~is_self_arr).sum())
    
    coverage = (n_self + n_matched) / n_total * 100  # tuples that have a partner
    
    return {
        'target_sum': target_sum,
        'n_tuples': n_total,
        'h11_distinct': len(h11_vals),
        'h11_range': [min(h11_vals), max(h11_vals)],
        'h12_distinct': len(h12_vals),
        'h12_range': [min(h12_vals), max(h12_vals)],
        'h13_distinct': len(h13_vals),
        'h13_range': [min(h13_vals), max(h13_vals)],
        'n_self_mirror': n_self,
        'n_matched_in_full_catalog': n_matched,
        'n_unmatched_in_full_catalog': n_unmatched,
        'coverage_pct': coverage,
        'h12_top20': dict(h12_vals.most_common(20)),
        'sample_tuples': matched_tuples[:20],
        'sample_extreme_h11': sorted(matched_tuples, key=lambda t: t[0])[-5:],
        'sample_extreme_h13': sorted(matched_tuples, key=lambda t: t[2])[-5:],
    }


# ─────────────────────────────────────────────────────────────────
# Test G: marginal-distribution null benchmark
# ─────────────────────────────────────────────────────────────────

def _extract_marginals(packed_arr, chunk_size: int = 50_000_000):
    """One-pass extraction of empirical h11, h12, h13 marginals."""
    n = len(packed_arr)
    h11_counts: Counter = Counter()
    h12_counts: Counter = Counter()
    h13_counts: Counter = Counter()
    for start in range(0, n, chunk_size):
        end = min(start + chunk_size, n)
        chunk = packed_arr[start:end]
        h11 = (chunk >> H11_SHIFT).astype(np.int64)
        h12 = ((chunk >> H12_SHIFT) & H12_MASK).astype(np.int64)
        h13 = (chunk & H13_MASK).astype(np.int64)
        for arr, ctr in [(h11, h11_counts), (h12, h12_counts), (h13, h13_counts)]:
            u, c = np.unique(arr, return_counts=True)
            for k, v in zip(u.tolist(), c.tolist()):
                ctr[k] += v
    return h11_counts, h12_counts, h13_counts


def test_g_null_benchmark_from_marginals(h11_c, h12_c, h13_c,
                                          n_draws: int = 600_000_000,
                                          n_realizations: int = 1, seed: int = 42):
    """Independent-marginals null benchmark, given pre-extracted marginals.
    
    Caller must extract marginals from the master, then free the master
    before calling this function (the master is not used here and holding
    it doubles peak memory). Uses sort-based dedup instead of np.unique to
    avoid the hash-table OOM on 500M+ tuples."""
    h11_keys = np.array(list(h11_c.keys()), dtype=np.int64)
    h11_probs = np.array(list(h11_c.values()), dtype=np.float64)
    h11_probs /= h11_probs.sum()
    h11_cum = np.cumsum(h11_probs)
    
    h12_keys = np.array(list(h12_c.keys()), dtype=np.int64)
    h12_probs = np.array(list(h12_c.values()), dtype=np.float64)
    h12_probs /= h12_probs.sum()
    h12_cum = np.cumsum(h12_probs)
    
    h13_keys = np.array(list(h13_c.keys()), dtype=np.int64)
    h13_probs = np.array(list(h13_c.values()), dtype=np.float64)
    h13_probs /= h13_probs.sum()
    h13_cum = np.cumsum(h13_probs)
    
    print(f"  [Test G] Marginals: h11 {len(h11_keys):,} values, "
          f"h12 {len(h12_keys):,} values, h13 {len(h13_keys):,} values")
    
    realizations = []
    rng = np.random.default_rng(seed)
    draw_chunk = 50_000_000
    
    for r in range(n_realizations):
        print(f"  [Test G] Realization {r+1}/{n_realizations}: "
              f"drawing {n_draws:,} samples (in {draw_chunk//1_000_000}M chunks)...")
        # Pre-allocate the final array (avoids the 2× peak from list+concatenate)
        null_packed = np.empty(n_draws, dtype=np.uint64)
        
        for chunk_start in range(0, n_draws, draw_chunk):
            chunk_end = min(chunk_start + draw_chunk, n_draws)
            cnt = chunk_end - chunk_start
            # Inverse-CDF sampling via searchsorted (faster than rng.choice with p=)
            u11 = rng.random(cnt)
            h11_idx = np.searchsorted(h11_cum, u11)
            np.clip(h11_idx, 0, len(h11_keys) - 1, out=h11_idx)
            del u11
            h11_draws = h11_keys[h11_idx]
            del h11_idx
            
            u12 = rng.random(cnt)
            h12_idx = np.searchsorted(h12_cum, u12)
            np.clip(h12_idx, 0, len(h12_keys) - 1, out=h12_idx)
            del u12
            h12_draws = h12_keys[h12_idx]
            del h12_idx
            
            u13 = rng.random(cnt)
            h13_idx = np.searchsorted(h13_cum, u13)
            np.clip(h13_idx, 0, len(h13_keys) - 1, out=h13_idx)
            del u13
            h13_draws = h13_keys[h13_idx]
            del h13_idx
            
            null_packed[chunk_start:chunk_end] = (
                (h11_draws.astype(np.uint64) << H11_SHIFT)
                | (h12_draws.astype(np.uint64) << H12_SHIFT)
                | h13_draws.astype(np.uint64))
            del h11_draws, h12_draws, h13_draws
            print(f"    [draw chunk {chunk_start//draw_chunk + 1}/"
                  f"{(n_draws+draw_chunk-1)//draw_chunk}] filled "
                  f"{chunk_end:,}/{n_draws:,}")
        
        print(f"  [Test G] Sorting {len(null_packed):,} draws in-place...")
        null_packed.sort()  # in-place
        
        print(f"  [Test G] Sort-based dedup...")
        # Build boolean keep mask: keep first occurrence of each distinct value
        keep = np.empty(len(null_packed), dtype=bool)
        keep[0] = True
        np.not_equal(null_packed[1:], null_packed[:-1], out=keep[1:])
        null_unique = null_packed[keep]
        del null_packed, keep
        gc.collect()
        
        n_null = len(null_unique)
        print(f"  [Test G] Null catalog: {n_null:,} distinct tuples "
              f"({n_null/n_draws*100:.2f}% of draws)")
        
        print(f"  [Test G] Closure on null catalog...")
        p = closure_partition(null_unique)
        realizations.append({
            'n_draws': n_draws,
            'n_distinct': n_null,
            'n_self_mirror': p['n_self_mirror'],
            'n_matched_pairs': p['n_matched_pairs'],
            'n_unmatched': p['n_unmatched'],
            'closure_pct': p['coverage_pct'],
        })
        del null_unique
        gc.collect()
    
    closures = [r['closure_pct'] for r in realizations]
    return {
        'n_realizations': n_realizations,
        'realizations': realizations,
        'closure_pct_mean': float(np.mean(closures)),
        'closure_pct_std': float(np.std(closures)) if len(closures) > 1 else 0.0,
        'closure_pct_min': float(min(closures)) if closures else 0.0,
        'closure_pct_max': float(max(closures)) if closures else 0.0,
    }


def test_g_null_benchmark(packed_arr, n_draws: int = 600_000_000,
                          n_realizations: int = 1, seed: int = 42,
                          chunk_size: int = 50_000_000):
    """Wrapper that extracts marginals from a master then runs the null benchmark.
    
    NOTE: Holds the master in memory during the test, which doubles peak memory.
    Prefer the from_marginals variant if you can free the master first."""
    print(f"  [Test G] Extracting empirical marginals from {len(packed_arr):,} tuples...")
    h11_c, h12_c, h13_c = _extract_marginals(packed_arr, chunk_size)
    return test_g_null_benchmark_from_marginals(
        h11_c, h12_c, h13_c, n_draws, n_realizations, seed)


# ─────────────────────────────────────────────────────────────────
# Figure renderers
# ─────────────────────────────────────────────────────────────────

def render_heatmap(matrix, output_svg, *, title, value_label='log count',
                    h_max, color_scheme='viridis', log_scale=True,
                    width=900, height=820):
    """Render a 2D heatmap of a square matrix on linear axes."""
    n_bins = matrix.shape[0]
    
    W, H = width, height
    ml, mr, mt, mb = 90, 100, 60, 70  # extra right margin for colorbar
    pw = H - mt - mb  # square plot
    ph = pw
    
    # Color scale
    vals = matrix.astype(np.float64)
    if log_scale:
        vals = np.log10(vals + 1)
    v_max = float(vals.max()) if vals.max() > 0 else 1.0
    v_min = 0.0
    
    # Viridis-like (5-stop interpolation)
    stops = [(0.0, '#440154'), (0.25, '#3b528b'), (0.5, '#21918c'),
             (0.75, '#5ec962'), (1.0, '#fde725')] \
        if color_scheme == 'viridis' else [
            (0.0, '#08306b'), (0.5, '#4292c6'), (1.0, '#f7fbff')]
    
    def hex_to_rgb(h):
        return tuple(int(h[i:i+2], 16) for i in (1, 3, 5))
    
    def color_at(t):
        t = max(0.0, min(1.0, t))
        for (t1, c1), (t2, c2) in zip(stops, stops[1:]):
            if t1 <= t <= t2:
                u = (t - t1) / (t2 - t1) if t2 > t1 else 0
                r1, g1, b1 = hex_to_rgb(c1)
                r2, g2, b2 = hex_to_rgb(c2)
                r = int(r1 + u * (r2 - r1))
                g = int(g1 + u * (g2 - g1))
                b = int(b1 + u * (b2 - b1))
                return f'rgb({r},{g},{b})'
        return stops[-1][1]
    
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
        f'viewBox="0 0 {W} {H}" font-family="ui-sans-serif, system-ui, sans-serif">',
        f'<rect width="{W}" height="{H}" fill="white"/>',
        f'<text x="{ml + pw/2}" y="32" font-size="18" font-weight="bold" '
        f'text-anchor="middle" fill="#111">{title}</text>',
        f'<rect x="{ml}" y="{mt}" width="{pw}" height="{ph}" fill="#222"/>',
    ]
    
    # Cell rectangles. Skip zeros.
    cell_w = pw / n_bins
    cell_h = ph / n_bins
    nz_idx = np.argwhere(vals > 0)
    for (i, j) in nz_idx:
        # i = h11 bin (x), j = h13 bin (y; y axis inverted so larger y at top)
        x = ml + i * cell_w
        y = mt + (n_bins - 1 - j) * cell_h
        v = float(vals[i, j])
        t = (v - v_min) / (v_max - v_min) if v_max > v_min else 0
        c = color_at(t)
        parts.append(f'<rect x="{x:.2f}" y="{y:.2f}" '
                     f'width="{cell_w+0.5:.2f}" height="{cell_h+0.5:.2f}" '
                     f'fill="{c}"/>')
    
    # Axes labels and ticks
    parts.append(f'<text x="{ml + pw/2}" y="{H - 18}" font-size="13" '
                 f'text-anchor="middle" fill="#222">$h^{{1,1}}$ ({h_max:,} max)</text>')
    parts.append(f'<g transform="translate(28, {mt + ph/2}) rotate(-90)">'
                 f'<text font-size="13" text-anchor="middle" fill="#222">'
                 f'$h^{{1,3}}$ ({h_max:,} max)</text></g>')
    
    # Tick marks
    n_ticks = 6
    for i in range(n_ticks + 1):
        t_val = int(i / n_ticks * h_max)
        # x-axis tick
        xp = ml + i / n_ticks * pw
        parts.append(f'<line x1="{xp:.2f}" y1="{mt+ph}" x2="{xp:.2f}" y2="{mt+ph+5}" stroke="#444"/>')
        parts.append(f'<text x="{xp:.2f}" y="{mt+ph+18}" font-size="10" '
                     f'text-anchor="middle" fill="#444">{t_val:,}</text>')
        # y-axis tick
        yp = mt + ph - i / n_ticks * ph
        parts.append(f'<line x1="{ml-5}" y1="{yp:.2f}" x2="{ml}" y2="{yp:.2f}" stroke="#444"/>')
        parts.append(f'<text x="{ml-8}" y="{yp+4:.2f}" font-size="10" '
                     f'text-anchor="end" fill="#444">{t_val:,}</text>')
    
    # Diagonal reference line (h11 == h13)
    parts.append(f'<line x1="{ml}" y1="{mt+ph}" x2="{ml+pw}" y2="{mt}" '
                 f'stroke="#fff" stroke-width="0.8" stroke-dasharray="4,4" opacity="0.5"/>')
    
    # Colorbar
    cb_x = ml + pw + 20
    cb_w = 18
    cb_y = mt
    cb_h = ph
    n_cb_segments = 100
    for k in range(n_cb_segments):
        t = k / (n_cb_segments - 1)
        seg_y = cb_y + (1 - t) * cb_h
        seg_h = cb_h / n_cb_segments + 1
        parts.append(f'<rect x="{cb_x}" y="{seg_y:.2f}" width="{cb_w}" height="{seg_h:.2f}" '
                     f'fill="{color_at(t)}"/>')
    parts.append(f'<rect x="{cb_x}" y="{cb_y}" width="{cb_w}" height="{cb_h}" '
                 f'fill="none" stroke="#444"/>')
    # Colorbar ticks
    for i in range(5 + 1):
        t = i / 5
        yp = cb_y + (1 - t) * cb_h
        if log_scale:
            label = f'{10**(v_min + t * (v_max - v_min)):.0f}'
        else:
            label = f'{v_min + t * (v_max - v_min):.2f}'
        parts.append(f'<text x="{cb_x + cb_w + 4}" y="{yp+4:.2f}" font-size="10" '
                     f'fill="#444">{label}</text>')
    parts.append(f'<g transform="translate({cb_x + cb_w + 60}, {cb_y + cb_h/2}) rotate(-90)">'
                 f'<text font-size="11" text-anchor="middle" fill="#222">{value_label}</text></g>')
    
    parts.append('</svg>')
    output_svg.parent.mkdir(parents=True, exist_ok=True)
    output_svg.write_text('\n'.join(parts), encoding='utf-8')


def render_chi_cohort_overlay(cohorts: dict, output_svg, *,
                                title: str = 'χ distribution by closure cohort',
                                width: int = 1400, height: int = 600,
                                max_bars: int = 500):
    """Three overlaid histograms on log-y. cohorts = {'matched': Counter, ...}."""
    # Common binning across cohorts
    all_chi = set()
    for c in cohorts.values():
        all_chi.update(c.keys())
    if not all_chi:
        raise ValueError("Empty cohorts")
    
    x_min, x_max = min(all_chi), max(all_chi)
    x_span = max(x_max - x_min, 1)
    
    # Choose bin width
    bin_width_raw = x_span / max_bars
    nice_widths = [1, 2, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000]
    for nw in nice_widths:
        if nw >= bin_width_raw:
            bin_width = nw
            break
    else:
        bin_width = int(bin_width_raw)
    
    # Bin each cohort
    binned = {}
    for name, ctr in cohorts.items():
        b: dict = {}
        for k, v in ctr.items():
            bin_key = ((k - x_min) // bin_width) * bin_width + x_min
            b[bin_key] = b.get(bin_key, 0) + v
        binned[name] = b
    
    # Determine y_max across all cohorts (log)
    all_v = []
    for b in binned.values():
        all_v.extend(b.values())
    v_max_disp = math.log10(max(all_v) + 1) if all_v else 1
    
    W, H = width, height
    ml, mr, mt, mb = 90, 200, 60, 70
    pw, ph = W - ml - mr, H - mt - mb
    
    def x_pos(k):
        return ml + (k - x_min) / x_span * pw
    
    def y_pos(v):
        return mt + (1 - math.log10(v + 1) / max(v_max_disp, 1)) * ph
    
    colors = {'matched':    '#2563eb',   # blue
              'unmatched':  '#dc2626',   # red
              'self_mirror': '#16a34a'}  # green
    labels = {'matched': 'matched', 'unmatched': 'unmatched',
              'self_mirror': 'self-mirror (h¹¹=h¹³)'}
    
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
        f'viewBox="0 0 {W} {H}" font-family="ui-sans-serif, system-ui, sans-serif">',
        f'<rect width="{W}" height="{H}" fill="white"/>',
        f'<text x="{ml + pw/2}" y="32" font-size="20" font-weight="bold" '
        f'text-anchor="middle" fill="#111">{title}</text>',
        f'<rect x="{ml}" y="{mt}" width="{pw}" height="{ph}" '
        f'fill="#fafafa" stroke="#999" stroke-width="1"/>',
    ]
    
    bar_px = max(pw * bin_width / x_span, 1.0)
    
    # Draw cohorts in order (smallest first so bigger ones don't hide it)
    cohort_order = sorted(binned.keys(),
                          key=lambda n: -sum(binned[n].values()))
    for name in reversed(cohort_order):
        b = binned[name]
        color = colors.get(name, '#666')
        for k, v in b.items():
            if v == 0:
                continue
            x = x_pos(k) + bar_px / 2
            y = y_pos(v)
            bar_h = (mt + ph) - y
            parts.append(f'<rect x="{x - bar_px/2:.2f}" y="{y:.2f}" '
                         f'width="{bar_px*0.95:.2f}" height="{bar_h:.2f}" '
                         f'fill="{color}" opacity="0.55"/>')
    
    # Legend (top-right)
    lg_x = ml + pw + 18
    lg_y = mt + 10
    for i, name in enumerate(cohort_order):
        n_total = sum(binned[name].values())
        parts.append(f'<rect x="{lg_x}" y="{lg_y + i*30}" width="14" height="14" '
                     f'fill="{colors[name]}" opacity="0.7"/>')
        parts.append(f'<text x="{lg_x + 22}" y="{lg_y + 12 + i*30}" font-size="11" '
                     f'fill="#222">{labels[name]}</text>')
        parts.append(f'<text x="{lg_x + 22}" y="{lg_y + 24 + i*30}" font-size="10" '
                     f'fill="#666">n = {n_total:,}</text>')
    
    # Axis labels
    parts.append(f'<text x="{ml + pw/2}" y="{H - 18}" font-size="13" '
                 f'text-anchor="middle" fill="#222">χ = 48 + 6(h¹¹ − h¹² + h¹³)</text>')
    parts.append(f'<g transform="translate(28, {mt+ph/2}) rotate(-90)">'
                 f'<text font-size="13" text-anchor="middle" fill="#222">'
                 f'count (log scale)</text></g>')
    
    # X-axis ticks: pick ~8 nice values
    tick_target = 8
    raw_tick = x_span / tick_target
    nice = [1, 2, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000,
            10000, 25000, 50000, 100000, 250000, 500000]
    for nt in nice:
        if nt >= raw_tick:
            x_tick = nt
            break
    else:
        x_tick = int(raw_tick)
    first_tick = (x_min // x_tick) * x_tick
    if first_tick < x_min:
        first_tick += x_tick
    t = first_tick
    while t <= x_max:
        xp = x_pos(t)
        parts.append(f'<line x1="{xp:.2f}" y1="{mt+ph}" x2="{xp:.2f}" y2="{mt+ph+5}" stroke="#666"/>')
        parts.append(f'<text x="{xp:.2f}" y="{mt+ph+18}" font-size="10" '
                     f'text-anchor="middle" fill="#444">{t:,}</text>')
        t += x_tick
    
    # Y-axis ticks: powers of 10
    for exp in range(int(v_max_disp) + 1):
        v = 10 ** exp
        yp = y_pos(v)
        parts.append(f'<line x1="{ml-5}" y1="{yp:.2f}" x2="{ml}" y2="{yp:.2f}" stroke="#666"/>')
        parts.append(f'<text x="{ml-10}" y="{yp+4:.2f}" font-size="10" '
                     f'text-anchor="end" fill="#444">10^{exp}</text>')
    
    parts.append('</svg>')
    output_svg.parent.mkdir(parents=True, exist_ok=True)
    output_svg.write_text('\n'.join(parts), encoding='utf-8')


# ─────────────────────────────────────────────────────────────────
# Pretty printers
# ─────────────────────────────────────────────────────────────────

def print_test_d(d):
    print(f"\n  ── Test D: bivariate (h¹¹, h¹³) density ──")
    print(f"    max(h¹¹, h¹³):                       {d['h_max']:>16,}")
    print(f"    Grid bins:                           {d['n_bins']:>10,}×{d['n_bins']:,}")
    print(f"    Bin width:                           {d['bin_width']:>15.1f}")
    print(f"    Total tuples placed:                 {d['n_total']:>16,}")
    print(f"    Matched (mass):                      {d['n_matched']:>16,}")
    print(f"    Unmatched (mass):                    {d['n_unmatched']:>16,}")
    print(f"    Densest cell — total:                "
          f"({d['total'].argmax()//d['n_bins']:>3}, {d['total'].argmax()%d['n_bins']:>3}) "
          f"count {int(d['total'].max()):,}")


def print_test_e(e):
    print(f"\n  ── Test E: χ distribution by closure cohort ──")
    print(f"    Self-mirror tuples:                  {e['n_self_mirror']:>16,}")
    print(f"    Matched tuples (each side):          {e['n_matched']:>16,}")
    print(f"    Unmatched tuples:                    {e['n_unmatched']:>16,}")
    for name in ['self_mirror', 'matched', 'unmatched']:
        c = e[name]
        if not c:
            continue
        mode_chi, mode_count = c.most_common(1)[0]
        chi_vals = list(c.keys())
        total_chi = sum(k * v for k, v in c.items())
        n_cohort = sum(c.values())
        mean_chi = total_chi / n_cohort if n_cohort else 0
        print(f"    {name:>14s}: χ range [{min(chi_vals):,}, {max(chi_vals):,}], "
              f"mean {mean_chi:,.1f}, mode χ={mode_chi:,} ({mode_count:,} tuples)")


def print_test_f(f):
    if f.get('n_tuples', 0) == 0:
        print(f"\n  ── Test F: mode-at-sum substructure ──")
        print(f"    No tuples found with sum == {f['target_sum']}")
        return
    print(f"\n  ── Test F: mode-at-sum substructure (sum = {f['target_sum']}) ──")
    print(f"    Tuples in sum-stratum:               {f['n_tuples']:>16,}")
    print(f"    Distinct h¹¹ values:                 {f['h11_distinct']:>10,}"
          f"  (range {f['h11_range'][0]:,}–{f['h11_range'][1]:,})")
    print(f"    Distinct h¹² values:                 {f['h12_distinct']:>10,}"
          f"  (range {f['h12_range'][0]:,}–{f['h12_range'][1]:,})")
    print(f"    Distinct h¹³ values:                 {f['h13_distinct']:>10,}"
          f"  (range {f['h13_range'][0]:,}–{f['h13_range'][1]:,})")
    print(f"    Self-mirror in stratum:              {f['n_self_mirror']:>16,}")
    print(f"    Matched (mirror in full catalog):    {f['n_matched_in_full_catalog']:>16,}")
    print(f"    Unmatched:                           {f['n_unmatched_in_full_catalog']:>16,}")
    print(f"    Stratum coverage:                    {f['coverage_pct']:>15.2f}%")
    print(f"    Top 10 h¹² values within stratum:")
    for k, v in sorted(f['h12_top20'].items(), key=lambda x: -x[1])[:10]:
        print(f"      h¹²={k:>4}: {v:,} tuples")


def print_test_g(g):
    print(f"\n  ── Test G: marginal-distribution null benchmark ──")
    print(f"    Number of realizations:              {g['n_realizations']:>10,}")
    for i, r in enumerate(g['realizations']):
        print(f"    Realization {i+1}: drew {r['n_draws']:,}, "
              f"distinct {r['n_distinct']:,}, closure {r['closure_pct']:.2f}%")
    print(f"    Null closure (mean):                 {g['closure_pct_mean']:>15.2f}%")
    if g['n_realizations'] > 1:
        print(f"    Null closure (std):                  {g['closure_pct_std']:>15.2f}%")
        print(f"    Null closure range:                  "
              f"[{g['closure_pct_min']:.2f}%, {g['closure_pct_max']:.2f}%]")
    print(f"    Empirical closure:                   {' ' * 12}12.80%")
    diff = g['closure_pct_mean'] - 12.80
    sign = '+' if diff >= 0 else ''
    print(f"    Empirical vs null (Δ):               {sign}{diff:>14.2f} pp")


# ─────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────

def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Phase 2 structural tests on the SS 5D catalog.")
    parser.add_argument('--cache', type=str, default=None)
    parser.add_argument('--out-dir', type=str, default=None)
    parser.add_argument('--skip', choices=['d', 'e', 'f', 'g'], action='append',
                        default=[], help="Skip a specific test (may repeat).")
    parser.add_argument('--target-sum', type=int, default=2114,
                        help="Sum-value for Test F (default 2114).")
    parser.add_argument('--n-bins', type=int, default=300,
                        help="Heatmap grid size for Test D (default 300).")
    parser.add_argument('--n-draws', type=int, default=600_000_000,
                        help="Null-benchmark sample count for Test G.")
    parser.add_argument('--n-realizations', type=int, default=1,
                        help="Number of null-benchmark realizations (default 1).")
    args = parser.parse_args(argv)
    
    if args.cache:
        path = Path(args.cache)
    else:
        if not SS_CACHE_DIR.exists():
            print(f"  ✗ No cache at {SS_CACHE_DIR}")
            return 1
        candidates = sorted(SS_CACHE_DIR.glob('ss_hodge_tuples*.pkl.gz'),
                            key=lambda p: p.stat().st_size, reverse=True)
        if not candidates:
            print(f"  ✗ No cache files in {SS_CACHE_DIR}")
            return 1
        path = candidates[0]
    
    print(f"  Loading {path.name} ...")
    packed, meta = load_tuples(path)
    if not isinstance(packed, np.ndarray):
        packed = np.sort(_pack_tuples_to_uint64(packed))
    if not _is_sorted(packed):
        print(f"  [defensive] sorting ...")
        packed = np.sort(packed)
    print(f"  Loaded {len(packed):,} tuples ({packed.nbytes/1024/1024:.1f} MB) "
          f"from {meta.get('_rows_scanned', '?'):,} rows")
    print("=" * 72)
    print("  SCHÖLLER-SKARKE 5D — PHASE 2 STRUCTURAL ANALYSES")
    print("=" * 72)
    
    out = Path(args.out_dir) if args.out_dir else SS_ANALYSIS_DIR
    out.mkdir(parents=True, exist_ok=True)
    summary_path = out / 'ss_phase2_summary.json'
    results = {}
    
    def _save_partial():
        """Write the JSON summary with whatever results are accumulated so far —
        called after each test so a crash mid-run doesn't lose earlier work."""
        summary_path.write_text(json.dumps(results, indent=2,
                                            default=lambda o: int(o) if hasattr(o, 'item') else o),
                                encoding='utf-8')
    
    # Order: F (tiny) → D (heatmap arrays) → E (Counters) → G (frees master before draws)
    if 'f' not in args.skip:
        f = test_f_mode_substructure(packed, target_sum=args.target_sum)
        results['test_f_mode_substructure'] = f
        print_test_f(f)
        _save_partial()
    
    if 'd' not in args.skip:
        d = test_d_bivariate_density(packed, n_bins=args.n_bins)
        d_summary = {k: v for k, v in d.items()
                     if k not in ('total', 'matched', 'unmatched')}
        results['test_d_bivariate_density'] = d_summary
        print_test_d(d)
        svg_total = out / 'ss_phase2_density_total.svg'
        render_heatmap(d['total'], svg_total,
                       title='Bivariate (h¹¹, h¹³) tuple density (log-scaled)',
                       value_label='log10(count + 1)',
                       h_max=d['h_max'], log_scale=True)
        print(f"  → {svg_total}")
        svg_matched = out / 'ss_phase2_density_matched.svg'
        render_heatmap(d['matched'], svg_matched,
                       title='Matched tuples by (h¹¹, h¹³) cell',
                       value_label='log10(count + 1)',
                       h_max=d['h_max'], log_scale=True)
        print(f"  → {svg_matched}")
        svg_unmatched = out / 'ss_phase2_density_unmatched.svg'
        render_heatmap(d['unmatched'], svg_unmatched,
                       title='Unmatched tuples by (h¹¹, h¹³) cell',
                       value_label='log10(count + 1)',
                       h_max=d['h_max'], log_scale=True)
        print(f"  → {svg_unmatched}")
        _save_partial()
    
    if 'e' not in args.skip:
        e = test_e_chi_by_cohort(packed)
        results['test_e_chi_by_cohort'] = {
            'n_self_mirror': e['n_self_mirror'],
            'n_matched': e['n_matched'],
            'n_unmatched': e['n_unmatched'],
            'self_mirror_top20': dict(e['self_mirror'].most_common(20)),
            'matched_top20': dict(e['matched'].most_common(20)),
            'unmatched_top20': dict(e['unmatched'].most_common(20)),
        }
        print_test_e(e)
        svg_chi = out / 'ss_phase2_chi_by_cohort.svg'
        render_chi_cohort_overlay(
            {'self_mirror': e['self_mirror'],
             'matched': e['matched'],
             'unmatched': e['unmatched']},
            svg_chi)
        print(f"  → {svg_chi}")
        _save_partial()
    
    if 'g' not in args.skip:
        # Extract marginals while master is still in memory
        print(f"  [Test G] Extracting empirical marginals from "
              f"{len(packed):,} tuples...")
        h11_c, h12_c, h13_c = _extract_marginals(packed)
        # Free the master before allocating the large null arrays — this is
        # what prevents the np.unique OOM hit on the previous architecture.
        print(f"  [Test G] Freeing master ({packed.nbytes/1024/1024:.1f} MB) ...")
        del packed
        gc.collect()
        
        g = test_g_null_benchmark_from_marginals(
            h11_c, h12_c, h13_c,
            n_draws=args.n_draws,
            n_realizations=args.n_realizations)
        results['test_g_null_benchmark'] = g
        print_test_g(g)
        _save_partial()
    
    print(f"\n  → {summary_path}")
    
    return 0


if __name__ == '__main__':
    import sys
    sys.exit(main())
