#!/usr/bin/env python3
"""
pipeline/data_tools/lmfdb_connector.py — Client for the LMFDB REST API.

LMFDB (https://www.lmfdb.org) is the L-functions and Modular Forms Database,
a community-curated database of number-theoretic objects with millions of
records: elliptic curves over ℚ (3.8M+), genus-2 curves, modular forms,
abelian varieties, number fields, Galois representations, and more.

This connector provides:
  - LMFDBClient: generic query interface to any table
  - Convenience methods for the tables most relevant to codim-2 work
  - Local on-disk cache (skip API calls for queries already seen)
  - Polite rate limiting (1 req/sec by default)
  - Pagination support via _offset

Tables most relevant to this pipeline:
  - ec_curvedata    : elliptic curves over Q (ch_14, ch_26)
  - ec_classdata    : isogeny class data
  - ec_localdata    : per-prime local data including a_p values
  - g2c_curves      : genus 2 curves → abelian surfaces (ch_18)
  - mf_newforms     : modular forms (ch_38)
  - av_fq_isog      : abelian varieties over F_q

API format (per https://www.lmfdb.org/api/):
    https://www.lmfdb.org/api/<table>/?<key>=<typed_value>&_format=json
    Type prefixes:  i (int), f (float), s (str), li (list-int), ls (list-str), py (Python lit)
    Pagination:     _offset=N, _max_count=N (each page max 100, total cap 10,000)

Usage:
    from pipeline.data_tools.lmfdb_connector import LMFDBClient
    client = LMFDBClient()
    curves = list(client.elliptic_curves(conductor=11))
    for c in curves:
        print(c.lmfdb_label, c.rank, c.cm)

    # Or paginate over thousands:
    for c in client.elliptic_curves_iter(rank=2, hard_limit=500):
        ...

CLI:
    python -m pipeline.data_tools.lmfdb_connector query ec_curvedata --rank 2 --limit 5
    python -m pipeline.data_tools.lmfdb_connector curve 11.a1
    python -m pipeline.data_tools.lmfdb_connector cache-stats

Author: Kase Branham — Independent Researcher
"""

import argparse
import hashlib
import json
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Union


# ─────────────────────────────────────────────────────────────────
# SSL / HTTP
# ─────────────────────────────────────────────────────────────────

def _ssl_context():
    """Same logic as download.py — prefer certifi on Windows."""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


def _urlopen(url: str, timeout: int = 30):
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Codim2-Companion-pipeline (research client; rate-limited)',
        'Accept': 'application/json',
    })
    return urllib.request.urlopen(req, timeout=timeout, context=_ssl_context())


# ─────────────────────────────────────────────────────────────────
# Typed parameter encoding (LMFDB's i/f/s/li/ls/py prefixes)
# ─────────────────────────────────────────────────────────────────

def _typed_param(value) -> str:
    """Encode a Python value with LMFDB's type prefix."""
    if isinstance(value, bool):
        # LMFDB doesn't have a bool type; use int 0/1
        return f'i{int(value)}'
    if isinstance(value, int):
        return f'i{value}'
    if isinstance(value, float):
        return f'f{value}'
    if isinstance(value, str):
        # LMFDB strings need 's' prefix unless already prefixed
        if len(value) >= 2 and value[:2] in ('i ', 'f ', 's ', 'ls', 'li', 'cs', 'ci', 'cf', 'py'):
            return value  # caller pre-typed
        if len(value) >= 1 and value[0] in ('i', 'f', 's'):
            # Heuristic: short prefix may collide with real strings; require explicit
            pass
        return f's{value}'
    if isinstance(value, list):
        if not value:
            return 'li'  # empty list of ints (LMFDB convention)
        if all(isinstance(x, int) for x in value):
            return 'li' + ';'.join(str(x) for x in value)
        if all(isinstance(x, str) for x in value):
            return 'ls' + ';'.join(value)
        # Fallback: Python literal
        return f'py{value!r}'
    # Fallback: Python literal
    return f'py{value!r}'


# ─────────────────────────────────────────────────────────────────
# Cache
# ─────────────────────────────────────────────────────────────────

class _Cache:
    """On-disk JSON cache keyed by URL hash."""
    
    def __init__(self, cache_dir: Path):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def _key(self, url: str) -> Path:
        h = hashlib.sha1(url.encode('utf-8')).hexdigest()[:16]
        return self.cache_dir / f'{h}.json'
    
    def get(self, url: str) -> Optional[Dict]:
        p = self._key(url)
        if not p.exists():
            return None
        try:
            with open(p, encoding='utf-8') as f:
                wrapped = json.load(f)
            # Sanity: stored URL should match (avoid hash collision)
            if wrapped.get('_url') == url:
                return wrapped.get('data')
        except (OSError, json.JSONDecodeError):
            return None
        return None
    
    def put(self, url: str, data: Dict) -> None:
        p = self._key(url)
        try:
            with open(p, 'w', encoding='utf-8') as f:
                json.dump({'_url': url, '_cached_at': time.time(), 'data': data}, f)
        except OSError:
            pass  # cache write failures shouldn't crash queries
    
    def stats(self) -> Dict:
        files = list(self.cache_dir.glob('*.json'))
        total_bytes = sum(f.stat().st_size for f in files)
        return {
            'cache_dir': str(self.cache_dir),
            'entries': len(files),
            'total_kb': round(total_bytes / 1024, 1),
        }


# ─────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────

@dataclass
class EllipticCurve:
    """One row of ec_curvedata."""
    lmfdb_label: str = ''         # e.g. "11.a1"  (LMFDB labels, not Cremona)
    Clabel: str = ''               # Cremona label, e.g. "11a1"
    iso: str = ''                  # isogeny class
    conductor: Optional[int] = None
    ainvs: List[int] = field(default_factory=list)  # [a1, a2, a3, a4, a6]
    rank: Optional[int] = None
    torsion_order: Optional[int] = None
    torsion_structure: List[int] = field(default_factory=list)
    cm: Optional[int] = None       # 0 if non-CM, else negative discriminant
    # LMFDB stores j as [numerator, denominator] list; keep raw + offer .j_fraction
    j_invariant: Any = None
    extras: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def is_cm(self) -> bool:
        return bool(self.cm)
    
    @property
    def cm_discriminant(self) -> Optional[int]:
        return self.cm if self.cm else None
    
    @property
    def j_fraction(self):
        """Return j-invariant as a fractions.Fraction (or None if absent/malformed)."""
        from fractions import Fraction
        if self.j_invariant is None:
            return None
        if isinstance(self.j_invariant, list) and len(self.j_invariant) == 2:
            try:
                return Fraction(self.j_invariant[0], self.j_invariant[1])
            except (ValueError, ZeroDivisionError):
                return None
        if isinstance(self.j_invariant, str) and '/' in self.j_invariant:
            try:
                n, d = self.j_invariant.split('/', 1)
                return Fraction(int(n), int(d))
            except (ValueError, ZeroDivisionError):
                return None
        try:
            return Fraction(self.j_invariant)
        except (ValueError, TypeError):
            return None
    
    @classmethod
    def from_row(cls, row: Dict) -> 'EllipticCurve':
        """Build from an LMFDB row dict, stashing unknown fields in extras."""
        known_keys = {f.name for f in cls.__dataclass_fields__.values()
                      if f.name != 'extras'}
        kwargs = {}
        extras = {}
        # LMFDB field name overrides
        field_map = {
            'Clabel': 'Clabel',
            'lmfdb_label': 'lmfdb_label',
            'iso': 'iso',
            'conductor': 'conductor',
            'ainvs': 'ainvs',
            'rank': 'rank',
            'torsion': 'torsion_order',
            'torsion_order': 'torsion_order',
            'torsion_structure': 'torsion_structure',
            'cm': 'cm',
            'jinv': 'j_invariant',
            'j_invariant': 'j_invariant',
        }
        for k, v in row.items():
            if k in field_map:
                kwargs[field_map[k]] = v
            elif k in known_keys:
                kwargs[k] = v
            else:
                extras[k] = v
        if extras:
            kwargs['extras'] = extras
        return cls(**kwargs)
    
    def to_short_weierstrass(self) -> Optional[Dict]:
        """Convert LMFDB ainvs [a1,a2,a3,a4,a6] → short Weierstrass dict
        in ch_14's format (y² = x³ + A·x + B).
        
        The conversion produces a curve ℚ-isomorphic to the original at primes ≥ 5.
        At p = 2, 3 there can be subtleties; ch_14's quick preset only uses p ≤ 13
        starting from 5, so this is safe in practice.
        
        Returns None if ainvs are malformed.
        """
        if not self.ainvs or len(self.ainvs) != 5:
            return None
        a1, a2, a3, a4, a6 = self.ainvs
        # b-invariants
        b2 = a1 * a1 + 4 * a2
        b4 = 2 * a4 + a1 * a3
        b6 = a3 * a3 + 4 * a6
        # c-invariants
        c4 = b2 * b2 - 24 * b4
        c6 = -b2 * b2 * b2 + 36 * b2 * b4 - 216 * b6
        # Short Weierstrass: Y² = X³ + A·X + B with A = -27·c4, B = -54·c6
        A = -27 * c4
        B = -54 * c6
        return {
            'a': A,
            'b': B,
            'label': f'LMFDB {self.lmfdb_label}',
            'j': self.j_invariant,
            'has_cm': self.is_cm,
            'cm_field': f'discriminant {self.cm}' if self.cm else None,
            'lmfdb_label': self.lmfdb_label,
            'conductor': self.conductor,
            'rank': self.rank,
            'torsion_order': self.torsion_order,
            'source': 'lmfdb',
        }


# ─────────────────────────────────────────────────────────────────
# Client
# ─────────────────────────────────────────────────────────────────

class LMFDBClient:
    """Client for the LMFDB REST API.
    
    Cache is on by default — repeated queries hit disk, not the network.
    Rate limit is 1 req/sec by default to be a good citizen.
    """
    
    BASE = 'https://www.lmfdb.org/api'
    PAGE_SIZE = 100      # LMFDB hard max
    TOTAL_CAP = 10_000   # LMFDB's overall result cap; refine query past this
    
    def __init__(
        self,
        cache_dir: Optional[Union[str, Path]] = None,
        rate_limit_sec: float = 1.0,
        verbose: bool = False,
    ):
        project_root = Path(__file__).parent.parent.parent
        self.cache = _Cache(Path(cache_dir or project_root / 'data' / 'cache' / 'lmfdb'))
        self.rate_limit_sec = rate_limit_sec
        self.verbose = verbose
        self._last_request_time = 0.0
        self._req_count = 0
        self._cache_hits = 0
    
    # ── HTTP layer ───────────────────────────────────────────────
    
    def _build_url(self, table: str, params: Dict[str, str]) -> str:
        encoded = '&'.join(f'{k}={urllib.parse.quote(str(v))}'
                          for k, v in params.items())
        return f'{self.BASE}/{table}/?{encoded}'
    
    def _fetch(self, url: str, use_cache: bool = True) -> Dict:
        if use_cache:
            cached = self.cache.get(url)
            if cached is not None:
                self._cache_hits += 1
                if self.verbose:
                    print(f"  [cache] {url}")
                return cached
        
        # Rate limit
        elapsed = time.time() - self._last_request_time
        if elapsed < self.rate_limit_sec:
            time.sleep(self.rate_limit_sec - elapsed)
        
        if self.verbose:
            print(f"  [http] {url}")
        try:
            with _urlopen(url, timeout=30) as r:
                body = r.read()
            data = json.loads(body)
            self._last_request_time = time.time()
            self._req_count += 1
            if use_cache:
                self.cache.put(url, data)
            return data
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"LMFDB HTTP {e.code}: {e.reason} — {url}") from e
        except urllib.error.URLError as e:
            if 'CERTIFICATE_VERIFY_FAILED' in str(e):
                raise RuntimeError(
                    f"SSL verify failed for {url}. "
                    f"On Windows, run: pip install certifi"
                ) from e
            raise
    
    # ── Generic query interface ─────────────────────────────────
    
    def query(self, table: str, filters: Optional[Dict] = None,
              max_count: int = 100, offset: int = 0,
              extra_params: Optional[Dict] = None,
              use_cache: bool = True) -> Dict:
        """Return one page of results. Caller can paginate via offset.
        
        filters: dict of {field: python_value}, encoded with LMFDB type prefixes.
        Returns the parsed JSON envelope, which has fields:
            data:         list of records
            next:         URL for next page (or None)
            query:        the URL queried
        """
        params: Dict[str, str] = {}
        if filters:
            for k, v in filters.items():
                params[k] = _typed_param(v)
        params['_format'] = 'json'
        params['_max_count'] = str(min(max_count, self.PAGE_SIZE))
        if offset:
            params['_offset'] = str(offset)
        if extra_params:
            params.update(extra_params)
        url = self._build_url(table, params)
        return self._fetch(url, use_cache=use_cache)
    
    def query_iter(self, table: str, filters: Optional[Dict] = None,
                   hard_limit: int = 1000, use_cache: bool = True) -> Iterator[Dict]:
        """Paginate through rows, yielding records one at a time.
        Honors LMFDB's 10k overall cap; if you need more, refine the filter.
        """
        offset = 0
        yielded = 0
        while yielded < hard_limit:
            page_size = min(self.PAGE_SIZE, hard_limit - yielded)
            page = self.query(table, filters=filters,
                              max_count=page_size, offset=offset,
                              use_cache=use_cache)
            rows = page.get('data') or []
            if not rows:
                break
            for row in rows:
                yield row
                yielded += 1
                if yielded >= hard_limit:
                    return
            offset += len(rows)
            if offset >= self.TOTAL_CAP:
                if self.verbose:
                    print(f"  [stop] hit LMFDB 10k cap; refine query for more")
                break
            # If page returned fewer than requested, no more data
            if len(rows) < page_size:
                break
    
    # ── Elliptic curve convenience ──────────────────────────────
    
    def elliptic_curves(self, *, conductor: Optional[int] = None,
                        rank: Optional[int] = None,
                        cm: Optional[int] = None,
                        torsion: Optional[int] = None,
                        limit: int = 100,
                        **extra_filters) -> List[EllipticCurve]:
        """Convenience: query ec_curvedata with common filters."""
        filters = {}
        if conductor is not None: filters['conductor'] = conductor
        if rank is not None:      filters['rank'] = rank
        if cm is not None:        filters['cm'] = cm
        if torsion is not None:   filters['torsion'] = torsion
        filters.update(extra_filters)
        return [EllipticCurve.from_row(r)
                for r in self.query_iter('ec_curvedata', filters=filters,
                                          hard_limit=limit)]
    
    def elliptic_curves_iter(self, *, conductor: Optional[int] = None,
                              rank: Optional[int] = None,
                              cm: Optional[int] = None,
                              torsion: Optional[int] = None,
                              hard_limit: int = 10_000,
                              **extra_filters) -> Iterator[EllipticCurve]:
        """Same as elliptic_curves() but yields lazily for big result sets."""
        filters = {}
        if conductor is not None: filters['conductor'] = conductor
        if rank is not None:      filters['rank'] = rank
        if cm is not None:        filters['cm'] = cm
        if torsion is not None:   filters['torsion'] = torsion
        filters.update(extra_filters)
        for r in self.query_iter('ec_curvedata', filters=filters, hard_limit=hard_limit):
            yield EllipticCurve.from_row(r)
    
    def get_elliptic_curve(self, lmfdb_label: str) -> Optional[EllipticCurve]:
        """Look up a single curve by its LMFDB label like '11.a1'."""
        rows = list(self.query_iter('ec_curvedata',
                                     filters={'lmfdb_label': lmfdb_label},
                                     hard_limit=2))
        if not rows:
            return None
        return EllipticCurve.from_row(rows[0])
    
    # ── Stats ───────────────────────────────────────────────────
    
    def request_stats(self) -> Dict:
        return {
            'http_requests': self._req_count,
            'cache_hits': self._cache_hits,
            'cache': self.cache.stats(),
        }


# ─────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────

def _cli_query(args):
    client = LMFDBClient(verbose=args.verbose)
    filters = {}
    for kv in args.filter or []:
        if '=' not in kv:
            print(f"  ⚠ Bad filter (expected key=value): {kv}", file=sys.stderr)
            continue
        k, v = kv.split('=', 1)
        # Auto-type: int if integral, float if numeric, else string
        try:
            v = int(v)
        except ValueError:
            try:
                v = float(v)
            except ValueError:
                pass
        filters[k] = v
    
    rows = list(client.query_iter(args.table, filters=filters, hard_limit=args.limit))
    
    # Output mode
    if args.json:
        print(json.dumps(rows, indent=2))
    elif args.fields:
        # Field projection
        keys = [k.strip() for k in args.fields.split(',')]
        # Header
        widths = {k: max(len(k), 8) for k in keys}
        for row in rows:
            for k in keys:
                widths[k] = max(widths[k], len(str(row.get(k, ''))))
        widths = {k: min(w, 30) for k, w in widths.items()}
        print('  ' + '  '.join(f'{k:<{widths[k]}}' for k in keys))
        print('  ' + '  '.join('-' * widths[k] for k in keys))
        for row in rows:
            print('  ' + '  '.join(
                f'{str(row.get(k, "")):<{widths[k]}}'[:widths[k]] for k in keys))
    elif args.brief:
        # Brief mode: pick a sensible default set per table
        DEFAULT_FIELDS = {
            'ec_curvedata': ['lmfdb_label', 'Clabel', 'conductor', 'rank',
                              'torsion', 'cm', 'ainvs'],
            'g2c_curves': ['lmfdb_label', 'cond', 'disc', 'two_selmer_rank',
                           'analytic_rank'],
            'mf_newforms': ['label', 'level', 'weight', 'dim', 'cm_discs'],
        }
        keys = DEFAULT_FIELDS.get(args.table)
        if not keys and rows:
            # Pick first 5 non-internal keys
            keys = [k for k in rows[0].keys() if not k.startswith('_')][:5]
        widths = {k: max(len(k), 10) for k in (keys or [])}
        for row in rows:
            for k in keys or []:
                widths[k] = max(widths[k], len(str(row.get(k, ''))))
        widths = {k: min(w, 28) for k, w in widths.items()}
        print('  ' + '  '.join(f'{k:<{widths[k]}}' for k in keys))
        print('  ' + '  '.join('-' * widths[k] for k in keys))
        for row in rows:
            print('  ' + '  '.join(
                f'{str(row.get(k, "")):<{widths[k]}}'[:widths[k]] for k in keys))
    else:
        # Full dump (legacy)
        for i, row in enumerate(rows):
            print(f"  [{i}] {row}")
    
    stats = client.request_stats()
    print(f"\n  Results: {len(rows)}  ·  http={stats['http_requests']}  "
          f"cache_hits={stats['cache_hits']}  cache_entries={stats['cache']['entries']}")
    return 0


def _cli_curve(args):
    client = LMFDBClient(verbose=args.verbose)
    c = client.get_elliptic_curve(args.label)
    if c is None:
        print(f"  ✗ No curve with label {args.label}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(asdict(c), indent=2, default=str))
    else:
        print(f"  Curve: {c.lmfdb_label}")
        print(f"    ainvs:        {c.ainvs}")
        print(f"    conductor:    {c.conductor}")
        print(f"    rank:         {c.rank}")
        print(f"    torsion:      {c.torsion_order} (structure: {c.torsion_structure})")
        print(f"    CM:           {c.cm if c.cm else 'no'}"
              f"{' (discriminant=' + str(c.cm) + ')' if c.cm else ''}")
        print(f"    j-invariant:  {c.j_invariant}")
    return 0


def _cli_cache_stats(args):
    client = LMFDBClient()
    s = client.cache.stats()
    print(f"  Cache directory: {s['cache_dir']}")
    print(f"  Entries:         {s['entries']}")
    print(f"  Total size:      {s['total_kb']} KB")
    return 0


def _cli_export_ch14(args):
    """Fetch curves from LMFDB and write them as a ch_14-compatible JSON file."""
    client = LMFDBClient(verbose=args.verbose)
    filters = {}
    if args.rank is not None:        filters['rank'] = args.rank
    if args.cm is not None:          filters['cm'] = args.cm
    if args.torsion is not None:     filters['torsion'] = args.torsion
    if args.conductor is not None:   filters['conductor'] = args.conductor
    
    out_curves = []
    skipped = 0
    for ec in client.elliptic_curves_iter(hard_limit=args.limit, **filters):
        sw = ec.to_short_weierstrass()
        if sw is None:
            skipped += 1
            continue
        out_curves.append(sw)
    
    out_path = Path(args.out)
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump({
            'source': 'lmfdb.ec_curvedata',
            'filters': filters,
            'count': len(out_curves),
            'skipped': skipped,
            'curves': out_curves,
        }, f, indent=2)
    
    stats = client.request_stats()
    print(f"  ✓ Wrote {len(out_curves)} curves → {out_path}")
    print(f"  (skipped {skipped} with malformed ainvs)")
    print(f"  http={stats['http_requests']}  cache_hits={stats['cache_hits']}")
    return 0


def main():
    parser = argparse.ArgumentParser(description='LMFDB REST API connector')
    parser.add_argument('-v', '--verbose', action='store_true', help='Show HTTP/cache activity')
    sub = parser.add_subparsers(dest='command', required=True)
    
    qp = sub.add_parser('query', help='Generic query on any LMFDB table')
    qp.add_argument('table', help='Table name, e.g. ec_curvedata')
    qp.add_argument('--filter', '-f', action='append',
                    help='key=value filter; repeat for multiple. Auto-typed.')
    qp.add_argument('--limit', type=int, default=10, help='Max rows (default 10)')
    out_mode = qp.add_mutually_exclusive_group()
    out_mode.add_argument('--brief', action='store_true',
                          help='Compact table view of common fields')
    out_mode.add_argument('--fields',
                          help='Comma-separated list of fields to show')
    out_mode.add_argument('--json', action='store_true', help='JSON output')
    qp.set_defaults(func=_cli_query)
    
    cp = sub.add_parser('curve', help='Look up one elliptic curve by LMFDB label')
    cp.add_argument('label', help='LMFDB label, e.g. 11.a1')
    cp.add_argument('--json', action='store_true', help='JSON output')
    cp.set_defaults(func=_cli_curve)
    
    ep = sub.add_parser('export-ch14',
                        help='Fetch LMFDB curves + convert to ch_14 short-Weierstrass JSON')
    ep.add_argument('--out', default='data/cache/lmfdb_curves.json',
                    help='Output JSON file')
    ep.add_argument('--rank', type=int, help='Filter: rank')
    ep.add_argument('--cm', type=int, help='Filter: CM discriminant (0 = non-CM)')
    ep.add_argument('--torsion', type=int, help='Filter: torsion order')
    ep.add_argument('--conductor', type=int, help='Filter: conductor')
    ep.add_argument('--limit', type=int, default=100, help='Max curves (default 100)')
    ep.set_defaults(func=_cli_export_ch14)
    
    csp = sub.add_parser('cache-stats', help='Show local cache stats')
    csp.set_defaults(func=_cli_cache_stats)
    
    args = parser.parse_args()
    return args.func(args)


if __name__ == '__main__':
    sys.exit(main())
