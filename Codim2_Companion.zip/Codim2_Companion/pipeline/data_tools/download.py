#!/usr/bin/env python3
"""
pipeline/data_tools/download.py — Download external databases for pipeline steps.

Usage:
    python -m pipeline.data_tools.download --list
    python -m pipeline.data_tools.download --dataset kreuzer-skarke
    python -m pipeline.data_tools.download --all
    python -m pipeline.data_tools.download --verify

Author: Kase Branham — Independent Researcher
"""

import argparse
import hashlib
import json
import ssl
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from kase_utils import C, banner, section, step
import yaml


def _get_ssl_context():
    """Return an SSL context that actually works on Windows.
    
    Windows Python's default verify uses the OS cert store, which urllib doesn't
    know how to read. The fix is to use certifi's bundled CA file if available;
    otherwise fall back to the system store and hope.
    """
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


def _urlopen(url: str, timeout: int = 60):
    """urlopen with a real User-Agent + a sane SSL context.
    
    On Windows, the default urllib SSL verify often fails with
    `CERTIFICATE_VERIFY_FAILED` because Python can't read the OS cert store.
    The fix is `pip install certifi`, which our SSL context picks up.
    """
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (Codim2-Companion-pipeline)',
    })
    try:
        return urllib.request.urlopen(req, timeout=timeout, context=_get_ssl_context())
    except urllib.error.URLError as e:
        # If certifi isn't installed and verify failed, give a useful hint
        if 'CERTIFICATE_VERIFY_FAILED' in str(e):
            try:
                import certifi  # noqa
            except ImportError:
                print(C.warn("    Hint: SSL verify failed. On Windows, run:"))
                print(C.warn("        pip install certifi"))
                print(C.warn("    Then re-run this command."))
        raise


PROJECT_ROOT = Path(__file__).parent.parent.parent
DATA_DIR = PROJECT_ROOT / 'data'
RAW_DIR = DATA_DIR / 'raw'
PROCESSED_DIR = DATA_DIR / 'processed'
MANIFEST_PATH = DATA_DIR / 'manifest.yaml'


# Manifest is bundled; this is the canonical reference for what datasets exist.
#
# IMPORTANT — none of these are required for the default pipeline. All 39
# steps run cleanly against bundled sample data. These are OPTIONAL extensions
# for scaling up specific steps. The download tool below tries real sources
# but each dataset has a "manual" fallback with copy-paste instructions.
DEFAULT_MANIFEST = {
    'datasets': {
        'tuwien-hodge-summary': {
            'description': 'TU Wien Hodge summary — 30,108 distinct (h11,h12) pairs across all 473M polytopes',
            'urls': [
                'http://hep.itp.tuwien.ac.at/~kreuzer/pub/misc/alltoric.spec.gz',
            ],
            'sha256': 'TBD',
            'size_bytes': 250_000,
            'unpacks_to': 'alltoric.spec',
            'required_for': ['ch_32_toric_cy_sweep'],
            'manual_sources': [
                'Canonical source: http://hep.itp.tuwien.ac.at/~kreuzer/CY/CYcy.html',
                'Mirror via Hugging Face if TU Wien is down:',
                '    https://huggingface.co/datasets/calabi-yau-data/polytopes-4d',
            ],
            'note': 'Smallest useful Kreuzer-Skarke extract. One line per distinct '
                    'Hodge pair, with point/vertex counts. Parser: pipeline.data_tools.tuwien_parser.',
        },
        'tuwien-polytopes-byvertex': {
            'description': 'TU Wien reflexive 4-polytope lists indexed by vertex count (PALP format)',
            'urls': [
                # 30 files: v05.gz, v06.gz, ..., v33.gz, plus v36.gz.
                # Each file contains all reflexive 4-polytopes with that vertex count.
                # Sizes range from ~27 KB (v05) to several GB (v11 and up).
                # The downloader processes these one at a time.
                'http://quark.itp.tuwien.ac.at/~kreuzer/V/v05.gz',
                'http://quark.itp.tuwien.ac.at/~kreuzer/V/v06.gz',
                'http://quark.itp.tuwien.ac.at/~kreuzer/V/v07.gz',
                'http://quark.itp.tuwien.ac.at/~kreuzer/V/v08.gz',
                'http://quark.itp.tuwien.ac.at/~kreuzer/V/v09.gz',
                'http://quark.itp.tuwien.ac.at/~kreuzer/V/v10.gz',
                # v11.gz through v33.gz typically run to GB scale; download manually
                # via browser if you want them all. v36.gz exists separately.
                'http://quark.itp.tuwien.ac.at/~kreuzer/V/v30.gz',
            ],
            'sha256': 'N/A',
            'size_bytes': 300_000_000,  # ~300 MB for v05-v10 plus v30 (lower end)
            'unpacks_to': 'tuwien-polytopes/',
            'required_for': ['ch_32_toric_cy_sweep'],
            'manual_sources': [
                '# All 30 files at the TU Wien mirror:',
                '    http://quark.itp.tuwien.ac.at/~kreuzer/V/',
                '',
                '# Files: v05.gz through v33.gz, plus v36.gz',
                '# Each contains all reflexive 4-polytopes with that vertex count.',
                '# Sizes: v05.gz ~27KB, v10.gz ~200MB, v15.gz+ multi-GB.',
                '',
                '# Drop completed downloads in data/raw/tuwien-polytopes/',
                '# (or anywhere under data/raw/ — ch_32 will find them automatically)',
            ],
            'note': 'PALP polytope-list format, one polytope per record. Each record '
                    'has the full vertex matrix plus M/N lattice data, Hodge numbers, '
                    'and Euler characteristic. Parser: pipeline.data_tools.palp_parser. '
                    'ch_32 will aggregate the Hodge spectrum across all available files. '
                    'Use `inspect` to peek at any single file.',
        },
        'tuwien-hodge-k3': {
            'description': 'TU Wien K3-fibration Hodge data — 184,026 IP weight systems with full data',
            'urls': [
                'http://hep.itp.tuwien.ac.at/~kreuzer/pub/misc/Hodge.K3.gz',
            ],
            'sha256': 'TBD',
            'size_bytes': 2_500_000,  # 2.37 MB compressed (~10.6 MB uncompressed) per the page
            'unpacks_to': 'Hodge.K3',
            'required_for': ['ch_32_toric_cy_sweep'],
            'manual_sources': [
                'Canonical source: http://hep.itp.tuwien.ac.at/~kreuzer/CY/CYcy.html',
            ],
            'note': '184,026 IP weight systems with weights, degree, transversality '
                    'flag, Hodge numbers, M/N lattice point counts, K3-fibration count, '
                    'and reflexive-facet-projection data. Per the TU Wien page. Format '
                    'documented in pipeline/data_tools/tuwien_parser.py.',
        },
        'kreuzer-skarke-full': {
            'description': 'Full Kreuzer-Skarke list — all 473,800,776 reflexive 4-polytopes',
            'urls': [],  # No automated download; far too large for casual use
            'sha256': 'N/A',
            'size_bytes': 15_800_000_000,  # 15.8 GB across parquet shards on HF
            'required_for': ['ch_32_toric_cy_sweep (extended)'],
            'manual_sources': [
                '# Vertex-count-stratified gzipped ASCII (30 files, ~few GB total):',
                '    http://quark.itp.tuwien.ac.at/~kreuzer/V/v05.gz',
                '    http://quark.itp.tuwien.ac.at/~kreuzer/V/v06.gz   ... through ...',
                '    http://quark.itp.tuwien.ac.at/~kreuzer/V/v33.gz',
                '    http://quark.itp.tuwien.ac.at/~kreuzer/V/v36.gz',
                '',
                '# Parquet shards (Hugging Face, 473M rows, 15.8 GB):',
                '    pip install datasets',
                '    python -c "from datasets import load_dataset; '
                'ds = load_dataset(\'calabi-yau-data/polytopes-4d\')"',
                '',
                '# CYTools (computes on demand, no full download needed):',
                '    pip install cytools           # cytools.liammcallistergroup.com',
            ],
            'note': 'Almost no one needs all 473M polytopes loaded into memory. For '
                    'Hodge-number statistics, tuwien-hodge-summary (30,108 distinct pairs) '
                    'is sufficient. For per-polytope analysis with weights/fibrations, '
                    'tuwien-hodge-k3 (184,026 entries) covers the IP weight systems. '
                    'Reach for this only if you need vertex-count distributions, '
                    'enumerations, or polytope-by-polytope geometry.',
        },
        'k3-lattices': {
            'description': 'K3 surface lattice classifications (Picard ranks, transcendental lattices)',
            'urls': [],  # no automated source; manual acquisition only
            'sha256': 'N/A',
            'size_bytes': 0,
            'required_for': ['ch_19_k3_atlas', 'ch_25_hyperkahler_lattices'],
            'manual_sources': [
                'There is no canonical single-file dataset for this. Compile from:',
                '  - Huybrechts, "Lectures on K3 Surfaces" (2016), Tables in Ch 14',
                '  - Nikulin 1979, "Integral Symmetric Bilinear Forms and Some of '
                'Their Applications"',
                '  - Brakkee 2018, arXiv:1803.07527 (Hassett discriminants table)',
                '  - Shimada 2014 lattice classifications, online supplementary tables',
            ],
            'note': 'The 17-K3 atlas baked into ch_19 + the BB-form computations in '
                    'ch_25 are computed from theoretical formulas; no external file '
                    'needed for the default pipeline.',
        },
        'hassett-extended': {
            'description': 'Hassett discriminant K3-association table for d > 70',
            'urls': [],  # no canonical source
            'sha256': 'N/A',
            'size_bytes': 0,
            'required_for': ['ch_21_hassett_discriminants'],
            'manual_sources': [
                'ch_21 now classifies d > 70 ANALYTICALLY via the Loeschian-number',
                'criterion (Hassett 2000 / Addington-Thomas 2014 / Nikulin embedding).',
                'No external file is needed — the criterion is implemented in the step.',
                'For cross-verification, see:',
                '  - Addington-Thomas 2014, arXiv:1211.3758, Section 5',
                '  - Brakkee 2018, arXiv:1803.07527 (extended discriminant tables)',
                '  - Bayer-Macrì 2014, arXiv:1406.4633',
            ],
            'note': 'OBSOLETE — superseded by the Nikulin/Loeschian extension in '
                    'ch_21 (added 2026-05-11). Kept in manifest for documentation only.',
        },
    },
    'manifest_version': '0.2',
    'last_updated': '2026-05-11',
}


def load_manifest() -> dict:
    """Load manifest from disk, or fall back to bundled default."""
    if MANIFEST_PATH.exists():
        with open(MANIFEST_PATH, encoding='utf-8') as f:
            return yaml.safe_load(f)
    return DEFAULT_MANIFEST


def save_manifest(manifest: dict):
    """Write manifest to disk."""
    MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(MANIFEST_PATH, 'w', encoding='utf-8') as f:
        yaml.dump(manifest, f, default_flow_style=False, sort_keys=False)


def compute_sha256(path: Path) -> str:
    """Compute SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()


def list_datasets(manifest: dict):
    """Print available datasets."""
    section("AVAILABLE DATASETS")
    for name, info in manifest['datasets'].items():
        size_mb = info.get('size_bytes', 0) / 1_000_000
        raw_path = RAW_DIR / name
        status = C.green('✓ present') if raw_path.exists() else C.muted('  missing')
        print(f"  {status}  {C.highlight(name):<25}  {info['description']}")
        print(f"       Size: ~{size_mb:.0f} MB    Required for: {', '.join(info.get('required_for', []))}")
        if info.get('note'):
            print(f"       {C.muted(info['note'])}")


def download_dataset(name: str, manifest: dict, force: bool = False) -> bool:
    """Download one dataset. Returns True on success."""
    if name not in manifest['datasets']:
        print(C.fail(f"  ✗ Unknown dataset: {name}"))
        print(f"  Available: {', '.join(manifest['datasets'].keys())}")
        return False
    
    info = manifest['datasets'][name]
    target_dir = RAW_DIR / name
    target_dir.mkdir(parents=True, exist_ok=True)
    
    # If already present and not forcing, skip
    if any(target_dir.iterdir()) and not force:
        print(C.muted(f"  · {name} already present at {target_dir} (use --force to re-download)"))
        return True
    
    urls = info.get('urls', [])
    manual_sources = info.get('manual_sources', [])
    
    if not urls:
        # No automated source — print manual acquisition instructions
        print(C.warn(f"  · {name}: no automated download source"))
        if manual_sources:
            print()
            print(C.muted("    Manual acquisition (copy-paste as needed):"))
            for line in manual_sources:
                print(f"      {line}")
        if info.get('note'):
            print()
            print(C.muted(f"    Note: {info['note']}"))
        return False
    
    print(f"  Downloading {name} ...")
    
    last_err = None
    for url in urls:
        if 'PLACEHOLDER' in url:
            print(C.warn(f"    URL placeholder: {url}"))
            continue
        try:
            filename = Path(url).name
            out_path = target_dir / filename
            print(f"    URL: {url}")
            with _urlopen(url, timeout=60) as response:
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                with open(out_path, 'wb') as f:
                    while True:
                        chunk = response.read(65536)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size:
                            pct = 100 * downloaded / total_size
                            print(f"\r    Progress: {downloaded//1_000_000} MB / "
                                  f"{total_size//1_000_000} MB ({pct:.1f}%)", end='', flush=True)
            print()  # newline after progress
            print(C.green(f"    ✓ Downloaded {out_path.name} ({downloaded//1_000_000} MB)"))
            
            # Verify checksum if known
            expected = info.get('sha256')
            if expected and expected not in ('TBD', 'N/A'):
                print(f"    Verifying SHA-256...")
                actual = compute_sha256(out_path)
                if actual != expected:
                    print(C.fail(f"    ✗ Checksum mismatch! Expected {expected[:12]}..., got {actual[:12]}..."))
                    return False
                print(C.green(f"    ✓ Checksum verified"))
            else:
                # Record the checksum for future verification
                actual = compute_sha256(out_path)
                print(C.muted(f"    SHA-256: {actual} (no expected value in manifest yet)"))
            
            return True
        except Exception as e:
            last_err = e
            print(C.warn(f"    ⚠ Failed from {url}: {e}"))
            continue
    
    # All URLs failed — print manual sources
    print(C.fail(f"  ✗ All URLs failed for {name}. Last error: {last_err}"))
    if manual_sources:
        print()
        print(C.muted("    Manual acquisition (copy-paste as needed):"))
        for line in manual_sources:
            print(f"      {line}")
    if info.get('note'):
        print()
        print(C.muted(f"    Note: {info['note']}"))
    return False


def verify_dataset(name: str, manifest: dict) -> bool:
    """Verify a downloaded dataset's checksum."""
    if name not in manifest['datasets']:
        return False
    info = manifest['datasets'][name]
    target_dir = RAW_DIR / name
    expected = info.get('sha256')
    if not expected or expected == 'TBD':
        print(C.warn(f"  · {name}: no checksum in manifest"))
        return True
    if not target_dir.exists():
        print(C.fail(f"  ✗ {name}: not downloaded"))
        return False
    files = list(target_dir.iterdir())
    if not files:
        print(C.fail(f"  ✗ {name}: directory empty"))
        return False
    # Verify first archive file
    archive = next((f for f in files if f.suffix in ('.gz', '.tar', '.zip', '.bz2')), files[0])
    actual = compute_sha256(archive)
    if actual == expected:
        print(C.green(f"  ✓ {name}: checksum OK"))
        return True
    else:
        print(C.fail(f"  ✗ {name}: checksum mismatch"))
        return False


def main():
    parser = argparse.ArgumentParser(description='Download external pipeline data')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--list', action='store_true', help='List available datasets')
    group.add_argument('--dataset', help='Download a specific dataset')
    group.add_argument('--all', action='store_true', help='Download all datasets')
    group.add_argument('--verify', action='store_true', help='Verify all downloaded datasets')
    parser.add_argument('--force', action='store_true', help='Re-download even if present')
    args = parser.parse_args()
    
    banner("CODIM2 DATA DOWNLOAD TOOL", {
        'Manifest': str(MANIFEST_PATH),
        'Raw dir':  str(RAW_DIR),
    })
    
    # Ensure dirs
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    
    # If no manifest on disk, write the default so user can edit
    if not MANIFEST_PATH.exists():
        print(C.warn(f"No manifest at {MANIFEST_PATH}; writing default."))
        save_manifest(DEFAULT_MANIFEST)
    
    manifest = load_manifest()
    
    if args.list:
        list_datasets(manifest)
        return
    
    if args.verify:
        section("VERIFYING CHECKSUMS")
        for name in manifest['datasets']:
            verify_dataset(name, manifest)
        return
    
    if args.all:
        section("DOWNLOADING ALL DATASETS")
        for name in manifest['datasets']:
            download_dataset(name, manifest, args.force)
        return
    
    if args.dataset:
        section(f"DOWNLOADING {args.dataset}")
        ok = download_dataset(args.dataset, manifest, args.force)
        sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
