#!/usr/bin/env python3
"""
pipeline/data_tools/mirror_check.py — Verify mirror symmetry of the Kreuzer-Skarke
Hodge spectrum at scale.

For CY 3-folds built from reflexive 4-polytopes (Batyrev construction), mirror
symmetry says: if (h11, h12) appears in the set of distinct Hodge pairs, then
(h12, h11) must also appear. The two come from a polytope and its dual.

Over the FULL set of 473,800,776 reflexive 4-polytopes, this is closure.
Over a SUBSET (e.g. just v05.gz ... v10.gz), some mirrors may be in vertex-count
files you don't have. That doesn't violate mirror symmetry — it measures the
"mirror coverage" of your subset.

This tool partitions the distinct (h11, h12) pairs into three classes:
  - SELF-MIRROR:  pairs with h11 == h12 (always closed under swap)
  - MATCHED:      pairs (a, b) with a != b where both (a,b) and (b,a) are present
  - UNMATCHED:    pairs (a, b) where the mirror partner is missing from this subset

Usage:
    python -m pipeline.data_tools.mirror_check data/raw/tuwien-polytopes/v*.gz
    python -m pipeline.data_tools.mirror_check data/raw/tuwien-polytopes/v*.gz --json
    python -m pipeline.data_tools.mirror_check data/raw/tuwien-polytopes/v*.gz --csv unmatched.csv

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import glob as glob_mod
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from pipeline.data_tools.palp_parser import parse_palp_file
from pipeline.data_tools.tuwien_parser import parse_tuwien_file


def collect_pairs(paths, *, verbose: bool = True):
    """Stream all files, collect distinct (h11, h12) pairs + per-pair record of
    which file(s) each came from. Returns (pairs_set, pair_to_files dict, n_entries).
    
    Per-polytope file attribution is expensive at scale; we accumulate pairs
    per-file then update the attribution dict once per file.
    """
    import time
    pairs = set()
    pair_to_files = {}
    n_entries = 0
    t0 = time.time()
    n_files = len(paths)
    
    for i, raw_path in enumerate(paths, 1):
        p = Path(raw_path)
        with _peek(p) as preview:
            is_spec = '=d' in preview and 'H:' in preview
        parser = parse_tuwien_file if is_spec else parse_palp_file
        
        file_t0 = time.time()
        file_n = 0
        file_pairs = set()
        for entry in parser(p):
            if entry.h11 is None or entry.h12 is None:
                continue
            file_n += 1
            file_pairs.add((entry.h11, entry.h12))
        
        # Attribute this file's pairs once (not once per polytope)
        pairs.update(file_pairs)
        for fp in file_pairs:
            pair_to_files.setdefault(fp, set()).add(p.name)
        
        n_entries += file_n
        if verbose:
            elapsed = time.time() - file_t0
            total = time.time() - t0
            rate = file_n / elapsed if elapsed > 0 else 0
            print(f"  [{i:>2}/{n_files}] {p.name:<10} {file_n:>13,} entries "
                  f"({elapsed:>6.1f}s, {rate/1e6:>5.2f}M/s; total {total:>6.1f}s, "
                  f"cumulative {n_entries:>13,})")
    
    return pairs, pair_to_files, n_entries


def _peek(path):
    """Read first 200 chars of a file to detect format."""
    import gzip
    from contextlib import contextmanager
    
    @contextmanager
    def _peek_ctx():
        opener = gzip.open if str(path).endswith('.gz') else open
        with opener(path, 'rt', encoding='utf-8', errors='replace') as f:
            yield f.read(2000)
    return _peek_ctx()


def classify_mirror(pairs):
    """Partition pairs into (self_mirror, matched_pairs, unmatched_pairs).
    
    self_mirror: list of (a, a) pairs (h11 == h12)
    matched_pairs: list of (min, max) for pairs (a,b) with a<b that have both orderings
    unmatched_pairs: list of (h11, h12) pairs missing their mirror
    """
    pairs_set = set(pairs)
    self_mirror = []
    matched_pairs = []
    unmatched_pairs = []
    seen = set()
    
    for (a, b) in pairs_set:
        if (a, b) in seen:
            continue
        if a == b:
            self_mirror.append((a, b))
            seen.add((a, b))
        elif (b, a) in pairs_set:
            matched_pairs.append((min(a, b), max(a, b)))
            seen.add((a, b))
            seen.add((b, a))
        else:
            unmatched_pairs.append((a, b))
            seen.add((a, b))
    
    return sorted(self_mirror), sorted(matched_pairs), sorted(unmatched_pairs)


def mirror_check(paths) -> dict:
    """Run the full check. Returns a JSON-serializable result dict."""
    pairs, pair_to_files, n_entries = collect_pairs(paths)
    self_mirror, matched, unmatched = classify_mirror(pairs)
    
    n_distinct = len(pairs)
    n_self = len(self_mirror)
    n_matched = len(matched)  # counted once per pair
    n_unmatched = len(unmatched)
    
    # Sanity: 2*n_matched + n_self + n_unmatched should equal n_distinct
    accounted = 2 * n_matched + n_self + n_unmatched
    sanity_ok = (accounted == n_distinct)
    
    coverage = ((n_self + 2 * n_matched) / n_distinct) if n_distinct else 0.0
    
    return {
        'total_entries_scanned': n_entries,
        'distinct_hodge_pairs': n_distinct,
        'self_mirror_count': n_self,
        'matched_mirror_count': n_matched,  # pairs (a<b) with both (a,b) and (b,a) present
        'unmatched_count': n_unmatched,
        'mirror_coverage_fraction': round(coverage, 6),
        'self_mirror_pairs': self_mirror,
        'matched_pairs_sample': matched[:20],  # first 20 for readability
        'matched_pairs_total': n_matched,
        'unmatched_sample': unmatched[:30],  # first 30
        'unmatched_total': n_unmatched,
        'sanity_check': {
            'expected': n_distinct,
            'accounted': accounted,
            'ok': sanity_ok,
        },
        'per_unmatched_file_attribution_sample': {
            f"{a},{b}": sorted(pair_to_files.get((a, b), set()))
            for (a, b) in unmatched[:10]
        },
    }


def format_report(result: dict, cache_path: str = None) -> str:
    """Pretty-print the result for terminal output."""
    lines = []
    lines.append("=" * 70)
    lines.append("  MIRROR-SYMMETRY VERIFICATION")
    lines.append("=" * 70)
    lines.append(f"  Entries scanned:     {result['total_entries_scanned']:>10,}")
    lines.append(f"  Distinct (h11,h12):  {result['distinct_hodge_pairs']:>10,}")
    lines.append("")
    lines.append("  Partition:")
    lines.append(f"    Self-mirror (a==b):                {result['self_mirror_count']:>6,}")
    lines.append(f"    Matched (a<b, both orderings):     {result['matched_mirror_count']:>6,}")
    lines.append(f"    Unmatched (mirror absent in set):  {result['unmatched_count']:>6,}")
    lines.append("")
    lines.append(f"  Mirror coverage:  {result['mirror_coverage_fraction']*100:>6.2f}%")
    lines.append(f"  Sanity check:     {'OK' if result['sanity_check']['ok'] else 'FAILED'}  "
                 f"({result['sanity_check']['accounted']:,} accounted vs "
                 f"{result['sanity_check']['expected']:,} expected)")
    lines.append("")
    
    if result['self_mirror_pairs']:
        sm = result['self_mirror_pairs']
        preview = ', '.join(f"({a},{b})" for a, b in sm[:10])
        if len(sm) > 10:
            preview += f", ... ({len(sm)-10} more)"
        lines.append("  Self-mirror pairs (h11 == h12):")
        lines.append(f"    {preview}")
        lines.append("")
    
    if result['unmatched_sample']:
        us = result['unmatched_sample']
        lines.append(f"  Unmatched sample (first {len(us)} of {result['unmatched_total']:,}):")
        for i, (a, b) in enumerate(us):
            files = result['per_unmatched_file_attribution_sample'].get(f"{a},{b}", [])
            files_str = f"  files=[{', '.join(files)}]" if files and i < 10 else ""
            lines.append(f"    ({a:>4}, {b:>4}) — mirror ({b}, {a}) not in subset{files_str}")
        lines.append("")
    
    if cache_path:
        lines.append(f"  Cached {result['distinct_hodge_pairs']:,} pairs to: {cache_path}")
        lines.append("  Future tools (hodge_plot, ch_32) can read from this cache,")
        lines.append("  avoiding the full re-scan.")
        lines.append("")
    
    # Only show the "unmatched ≠ violation" note when there ARE unmatched pairs
    if result['unmatched_count'] > 0:
        lines.append("  Note:")
        lines.append("  Unmatched pairs do NOT violate mirror symmetry over the full")
        lines.append("  Kreuzer-Skarke set. They mean the mirror's vertex-count file is")
        lines.append("  not in this subset. To verify mirror closure over all 473M")
        lines.append("  polytopes, all 30 vertex-count files (v05-v33 + v36) would be needed.")
    elif (result['self_mirror_count'] + 2 * result['matched_mirror_count']
          == result['distinct_hodge_pairs'] == 30108):
        lines.append("  ✓ Complete Kreuzer-Skarke spectrum verified: 30,108/30,108 pairs,")
        lines.append("    full closure under (h¹¹, h¹²) ↔ (h¹², h¹¹) swap.")
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description='Mirror-symmetry verification of KS Hodge spectrum')
    parser.add_argument('paths', nargs='+', help='Paths to .gz files (glob supported on Windows)')
    parser.add_argument('--json', action='store_true', help='Output full JSON instead of pretty report')
    parser.add_argument('--csv', help='Write unmatched pairs to this CSV file')
    parser.add_argument('--save-pairs',
                        help='Save the distinct (h11, h12) pair set to this JSON file. '
                             'Default: data/cache/ks_pairs.json (use --no-cache to disable).')
    parser.add_argument('--no-cache', action='store_true',
                        help='Skip the auto-save of pairs to data/cache/ks_pairs.json')
    args = parser.parse_args()
    
    # Expand globs
    expanded = []
    for raw in args.paths:
        if any(c in raw for c in '*?['):
            matches = sorted(glob_mod.glob(raw))
            if not matches:
                print(f"  ⚠ No files match: {raw}", file=sys.stderr)
            expanded.extend(matches)
        else:
            expanded.append(raw)
    
    if not expanded:
        print("  ✗ No files to process.", file=sys.stderr)
        return 1
    
    print(f"  Processing {len(expanded)} file(s) ...")
    
    # One scan: collect pairs + classify
    pairs, pair_to_files, n_entries = collect_pairs(expanded)
    self_mirror, matched, unmatched = classify_mirror(pairs)
    n_distinct = len(pairs)
    n_self = len(self_mirror)
    n_matched = len(matched)
    n_unmatched = len(unmatched)
    accounted = 2 * n_matched + n_self + n_unmatched
    coverage = ((n_self + 2 * n_matched) / n_distinct) if n_distinct else 0.0
    result = {
        'total_entries_scanned': n_entries,
        'distinct_hodge_pairs': n_distinct,
        'self_mirror_count': n_self,
        'matched_mirror_count': n_matched,
        'unmatched_count': n_unmatched,
        'mirror_coverage_fraction': round(coverage, 6),
        'self_mirror_pairs': self_mirror,
        'matched_pairs_sample': matched[:20],
        'matched_pairs_total': n_matched,
        'unmatched_sample': unmatched[:30],
        'unmatched_total': n_unmatched,
        'sanity_check': {
            'expected': n_distinct,
            'accounted': accounted,
            'ok': (accounted == n_distinct),
        },
        'per_unmatched_file_attribution_sample': {
            f"{a},{b}": sorted(pair_to_files.get((a, b), set()))
            for (a, b) in unmatched[:10]
        },
    }
    
    # Save pairs cache
    cache_path = None
    if not args.no_cache:
        if args.save_pairs:
            cache_path = Path(args.save_pairs)
        else:
            project_root = Path(__file__).parent.parent.parent
            cache_path = project_root / 'data' / 'cache' / 'ks_pairs.json'
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump({
                '_format': 'ks_pairs_cache_v1',
                '_source_files': [Path(p).name for p in expanded],
                '_total_polytopes_scanned': n_entries,
                'n_distinct_pairs': n_distinct,
                'self_mirror_count': n_self,
                'matched_mirror_count': n_matched,
                'unmatched_count': n_unmatched,
                'mirror_coverage_fraction': round(coverage, 6),
                'pairs': sorted(list(pairs)),
            }, f)
    
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(format_report(result, cache_path=str(cache_path) if cache_path else None))
    
    if args.csv:
        csv_path = Path(args.csv)
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            w = csv.writer(f)
            w.writerow(['h11', 'h12', 'mirror_h11', 'mirror_h12', 'present_in_files'])
            for (a, b) in unmatched:
                files = sorted(pair_to_files.get((a, b), set()))
                w.writerow([a, b, b, a, ';'.join(files)])
        print(f"\n  Wrote {len(unmatched):,} unmatched pairs to {csv_path}")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
