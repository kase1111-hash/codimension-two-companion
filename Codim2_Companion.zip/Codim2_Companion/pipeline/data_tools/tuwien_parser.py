#!/usr/bin/env python3
"""
pipeline/data_tools/tuwien_parser.py — Parse the TU Wien Kreuzer-Skarke data files.

Files supported:
  - alltoric.spec  (30,108 distinct Hodge data across all 473M polytopes)
  - toric.spec     (10,237 Hodge data from 184k IP weight systems)
  - wp4.spec       (2,780 Hodge data from 7,555 hypersurfaces in WPs)
  - Hodge.K3       (184,026 IP weight systems with full per-system data)
  - Hodge54.K3     (smallest subset, ~54 KB, useful for testing)

Each line follows the format documented at
http://hep.itp.tuwien.ac.at/~kreuzer/CY/CYcy.html

Example line (Hodge.K3 / weight-system format):
    1 1 1  1  1   5=d  TS  H: 1 101  M:126  5  N: 6  5  P:0  F:0

Fields:
    weights:       n integers before "=d" (n=5 for 4-fold ambient; sum=d)
    degree:        integer N before "=d" (= sum of weights)
    type_code:     2-char code in {TS, rS, Tn, rn}
                     T/r = Transverse / non-transverse (reflexive)
                     S/n = Newton polytope Spans / does not span coordinate hyperplanes
    H:             h11 h12 (Hodge numbers)
    M:             p v (Newton polytope point count, vertex count)
    N:             p v (dual polytope point count, vertex count)
    P:             p  (number of K3-fibration projections; "-" if unknown)
    F:             f w1 w2 ... wf  (count of reflexive-facet projections + weight indices)

alltoric.spec is similar but contains only distinct Hodge pairs (no per-polytope weights).

Usage:
    from pipeline.data_tools.tuwien_parser import parse_tuwien_file, load_hodge_summary
    
    entries = list(parse_tuwien_file('data/raw/tuwien-hodge-k3/Hodge.K3'))
    print(f"Loaded {len(entries)} polytopes")
    
    pairs = load_hodge_summary('data/raw/tuwien-hodge-summary/alltoric.spec')
    print(f"{len(pairs)} distinct (h11, h12) pairs")

Author: Kase Branham — Independent Researcher
"""

import gzip
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterator, List, Optional, Tuple


@dataclass
class TUWienEntry:
    """One line from a TU Wien .spec or .K3 file."""
    weights: List[int] = field(default_factory=list)
    degree: Optional[int] = None
    type_code: Optional[str] = None      # 'TS' | 'rS' | 'Tn' | 'rn' | None
    h11: Optional[int] = None
    h12: Optional[int] = None
    m_points: Optional[int] = None       # Newton polytope point count
    m_vertices: Optional[int] = None     # Newton polytope vertex count
    n_points: Optional[int] = None       # Dual polytope point count
    n_vertices: Optional[int] = None     # Dual polytope vertex count
    k3_fibrations: Optional[int] = None  # P: value (None if "P: -")
    facet_projections: Optional[int] = None  # F: count
    facet_weights: List[int] = field(default_factory=list)  # F: weight indices
    
    @property
    def euler(self) -> Optional[int]:
        """Euler characteristic chi = 2(h11 - h12) for CY 3-folds.
        Adjust the formula if working with other dimensions."""
        if self.h11 is None or self.h12 is None:
            return None
        return 2 * (self.h11 - self.h12)
    
    @property
    def transverse(self) -> Optional[bool]:
        if self.type_code is None:
            return None
        return self.type_code.startswith('T')
    
    @property
    def spanning(self) -> Optional[bool]:
        if self.type_code is None:
            return None
        return self.type_code.endswith('S')


# Tokens that introduce known field groups, e.g. "H:", "M:", "N:", "P:", "F:"
# Also capture bare alpha tokens like type codes TS/rS/Tn/rn (no trailing colon).
# We tokenize the whole line and then extract by these markers.
_RE_TOKEN = re.compile(r"(\d+=d|[A-Za-z]+:|[A-Za-z]+|-?\d+|-)")


def parse_line(line: str) -> Optional[TUWienEntry]:
    """Parse one .spec / .K3 line into a TUWienEntry.
    
    Returns None for blank lines and lines without recognizable content.
    Be permissive — files may include header lines or empty entries.
    """
    line = line.strip()
    if not line or line.startswith('#'):
        return None
    
    tokens = _RE_TOKEN.findall(line)
    if not tokens:
        return None
    
    entry = TUWienEntry()
    i = 0
    n = len(tokens)
    
    # Phase 1: prefix integers up to "<N>=d" are the weights.
    while i < n:
        tok = tokens[i]
        if tok.endswith('=d'):
            # The degree token, e.g. "5=d"
            try:
                entry.degree = int(tok[:-2])
            except ValueError:
                pass
            i += 1
            break
        if tok.lstrip('-').isdigit():
            try:
                entry.weights.append(int(tok))
            except ValueError:
                pass
            i += 1
        else:
            # Hit a marker before degree — line has no weight prefix
            break
    
    # Phase 2: type code (TS/rS/Tn/rn) is the next alpha token after "=d"
    if i < n:
        tok = tokens[i]
        if tok in ('TS', 'rS', 'Tn', 'rn'):
            entry.type_code = tok
            i += 1
    
    # Phase 3: walk tokens looking for marker fields
    while i < n:
        tok = tokens[i]
        if tok == 'H:':
            # Next two integers: h11, h12
            i += 1
            h_values = _take_ints(tokens, i, count=2)
            if len(h_values) >= 2:
                entry.h11, entry.h12 = h_values[0], h_values[1]
                i += 2
            else:
                i += len(h_values)
        elif tok == 'M:':
            i += 1
            m_values = _take_ints(tokens, i, count=2)
            if len(m_values) >= 2:
                entry.m_points, entry.m_vertices = m_values[0], m_values[1]
                i += 2
            else:
                i += len(m_values)
        elif tok == 'N:':
            i += 1
            n_values = _take_ints(tokens, i, count=2)
            if len(n_values) >= 2:
                entry.n_points, entry.n_vertices = n_values[0], n_values[1]
                i += 2
            else:
                i += len(n_values)
        elif tok == 'P:':
            # "P:0", "P:5", or "P:-" depending on whether fibration count known
            i += 1
            if i < n:
                next_tok = tokens[i]
                if next_tok == '-':
                    entry.k3_fibrations = None
                else:
                    try:
                        entry.k3_fibrations = int(next_tok)
                    except ValueError:
                        pass
                i += 1
        elif tok == 'F:':
            # "F:0" or "F:2  7 12" (count followed by that many weight indices)
            i += 1
            if i < n:
                try:
                    fcount = int(tokens[i])
                    entry.facet_projections = fcount
                    i += 1
                    # Read fcount more integers as facet weight indices
                    for _ in range(fcount):
                        if i < n and tokens[i].lstrip('-').isdigit():
                            entry.facet_weights.append(int(tokens[i]))
                            i += 1
                        else:
                            break
                except (ValueError, IndexError):
                    pass
        else:
            # Skip unrecognized token
            i += 1
    
    return entry


def _take_ints(tokens, start, count):
    """Take up to `count` consecutive integer tokens starting at index `start`."""
    out = []
    for j in range(start, min(start + count, len(tokens))):
        t = tokens[j]
        if t.lstrip('-').isdigit():
            out.append(int(t))
        else:
            break
    return out


def _open_text(path: Path):
    """Open a possibly-gzipped text file."""
    if str(path).endswith('.gz'):
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, encoding='utf-8', errors='replace')


def parse_tuwien_file(path) -> Iterator[TUWienEntry]:
    """Stream-parse a TU Wien .spec or .K3 file (gzipped or plain).
    
    Auto-detects between two formats:
    
    1. **Compact alltoric.spec**: three whitespace-separated integers per line:
       `h11 h12 chi`. This is the format of the alltoric.spec.gz on the TU Wien
       mirror — 30,108 distinct Hodge pairs, one per line. Each line yields a
       minimal TUWienEntry with h11, h12, and euler set.
    
    2. **Verbose .K3 / structured .spec**: lines with weight prefixes, "=d"
       degree markers, type codes (TS/rS/Tn/rn), and H:/M:/N:/P:/F: fields.
       This is what wp4.spec, Hodge.K3, and the per-polytope spec files use.
    
    The detection looks at the first non-blank line. If it has exactly 3 tokens
    and they're all integers, the file is parsed as compact alltoric.spec.
    Otherwise the verbose parser is used.
    """
    path = Path(path)
    
    # Peek at first non-blank line to detect format
    with _open_text(path) as f:
        first_line = ''
        for line in f:
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                first_line = stripped
                break
    
    tokens = first_line.split()
    is_compact = (len(tokens) == 3 and
                  all(t.lstrip('-').isdigit() for t in tokens))
    
    with _open_text(path) as f:
        if is_compact:
            for line in f:
                parts = line.split()
                if len(parts) < 2:
                    continue
                try:
                    h11 = int(parts[0])
                    h12 = int(parts[1])
                except ValueError:
                    continue
                # If a third column is present, cross-check it equals 2(h11-h12)
                if len(parts) >= 3:
                    try:
                        chi_file = int(parts[2])
                        if chi_file != 2 * (h11 - h12):
                            # Format mismatch — skip; could log if verbose
                            continue
                    except ValueError:
                        pass
                entry = TUWienEntry()
                entry.h11 = h11
                entry.h12 = h12
                yield entry
        else:
            for line in f:
                entry = parse_line(line)
                if entry is not None:
                    yield entry


def load_hodge_summary(path) -> List[Tuple[int, int]]:
    """Load all (h11, h12) pairs from a file. Convenience wrapper.
    Returns a deduplicated, sorted list of pairs."""
    seen = set()
    for e in parse_tuwien_file(path):
        seen.add((e.h11, e.h12))
    return sorted(seen)


def hodge_histogram(entries) -> dict:
    """Build a frequency histogram of (h11, h12) → count from an iterable of entries."""
    hist = {}
    for e in entries:
        if e.h11 is not None and e.h12 is not None:
            key = (e.h11, e.h12)
            hist[key] = hist.get(key, 0) + 1
    return hist


# ─────────────────────────────────────────────────────────────────
# CLI for ad-hoc inspection
# ─────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    import argparse
    import json
    import sys
    
    parser = argparse.ArgumentParser(description='Parse TU Wien Kreuzer-Skarke data')
    parser.add_argument('path', help='Path to .spec / .K3 file (gzipped or not)')
    parser.add_argument('--limit', type=int, default=10,
                        help='Show this many entries (default 10)')
    parser.add_argument('--json', action='store_true', help='Output JSON')
    parser.add_argument('--stats', action='store_true', help='Aggregate stats only')
    args = parser.parse_args()
    
    p = Path(args.path)
    if not p.exists():
        print(f"  ✗ Not found: {p}", file=sys.stderr)
        sys.exit(1)
    
    if args.stats:
        # Aggregate
        n = 0
        h11_min, h11_max = None, None
        h12_min, h12_max = None, None
        unique_pairs = set()
        weight_dim_counts = {}
        type_counts = {}
        for e in parse_tuwien_file(p):
            n += 1
            unique_pairs.add((e.h11, e.h12))
            if h11_min is None or e.h11 < h11_min: h11_min = e.h11
            if h11_max is None or e.h11 > h11_max: h11_max = e.h11
            if h12_min is None or e.h12 < h12_min: h12_min = e.h12
            if h12_max is None or e.h12 > h12_max: h12_max = e.h12
            if e.weights:
                k = len(e.weights)
                weight_dim_counts[k] = weight_dim_counts.get(k, 0) + 1
            if e.type_code:
                type_counts[e.type_code] = type_counts.get(e.type_code, 0) + 1
        print(f"  Entries:           {n:,}")
        print(f"  Distinct (h11,h12): {len(unique_pairs):,}")
        print(f"  h11 range:         [{h11_min}, {h11_max}]")
        print(f"  h12 range:         [{h12_min}, {h12_max}]")
        if weight_dim_counts:
            print(f"  Weight dimensions: {dict(weight_dim_counts)}")
        if type_counts:
            print(f"  Type codes:        {dict(type_counts)}")
    else:
        entries = []
        for i, e in enumerate(parse_tuwien_file(p)):
            if i >= args.limit:
                break
            entries.append(asdict(e))
        if args.json:
            print(json.dumps(entries, indent=2))
        else:
            for i, e in enumerate(entries):
                print(f"  [{i:>4}] h11={e['h11']:<4} h12={e['h12']:<4} "
                      f"type={e['type_code'] or '-':<3} "
                      f"weights={e['weights']} deg={e['degree']} "
                      f"P={e['k3_fibrations']} F={e['facet_projections']}")
