#!/usr/bin/env python3
"""
pipeline/data_tools/palp_parser.py — Parse PALP polytope-list files.

The TU Wien `v05.gz` ... `v36.gz` files contain reflexive 4-polytopes in PALP
output format, one polytope per record. Each record looks like:

    4 5  M:6 5 N:126 5 H:1,101 [-200]
    1 0 0 0 -2
    0 1 0 0 -3
    0 0 1 0 -4
    0 0 0 1 -5

The header line is:

    <rows> <cols> [<comment>]

For 4D polytopes with V vertices, this is typically "4 V" — 4 rows × V columns
where each column is a vertex (or "V 4" with each row a vertex; we handle both).

The comment carries:
    M:p v   Newton polytope: lattice point count, vertex count
    N:p v   Dual polytope: lattice point count, vertex count
    H:h11,h12   Hodge numbers (for 4D polytopes → CY 3-folds; convention h11,h12)
    [chi]   Euler characteristic (= 2(h11 - h12) for CY 3-folds)

The parser streams records lazily so that 200 MB files don't blow up memory.

Usage:
    from pipeline.data_tools.palp_parser import parse_palp_file, palp_summary
    
    for entry in parse_palp_file('data/raw/tuwien-polytopes/v05.gz'):
        print(entry.h11, entry.h12, entry.vertices)
    
    # Aggregate stats over a list of files
    summary = palp_summary(['v05.gz', 'v06.gz', ...])

Author: Kase Branham — Independent Researcher
"""

import gzip
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterator, List, Optional


# Header regex: "<rows> <cols> <rest of line>"
_RE_HEADER = re.compile(r'^\s*(\d+)\s+(\d+)\s*(.*)$')
# Comment field extractors
_RE_M = re.compile(r'M:\s*(\d+)\s+(\d+)')
_RE_N = re.compile(r'N:\s*(\d+)\s+(\d+)')
_RE_H = re.compile(r'H:\s*(\d+)\s*,\s*(\d+)')
_RE_CHI = re.compile(r'\[\s*(-?\d+)\s*\]')


@dataclass
class PALPEntry:
    """One reflexive polytope from a PALP-format file."""
    ambient_dim: int                              # ambient dimension (4 for v*.gz)
    n_vertices: int                               # number of vertices
    vertices: List[List[int]] = field(default_factory=list)  # vertices as rows
    h11: Optional[int] = None
    h12: Optional[int] = None
    m_points: Optional[int] = None                # Newton polytope lattice point count
    m_vertices: Optional[int] = None              # Newton polytope vertex count
    n_points: Optional[int] = None                # Dual polytope lattice point count
    n_vertices_dual: Optional[int] = None         # Dual polytope vertex count
    euler: Optional[int] = None                   # chi from "[chi]" in header
    raw_header: str = ''                          # full original header line
    
    @property
    def euler_from_hodge(self) -> Optional[int]:
        """For CY 3-folds: chi = 2(h11 - h12). Use to cross-check stored euler."""
        if self.h11 is None or self.h12 is None:
            return None
        return 2 * (self.h11 - self.h12)


def _parse_header(line: str) -> Optional[tuple]:
    """Parse a PALP header line. Returns (rows, cols, comment) or None."""
    m = _RE_HEADER.match(line)
    if not m:
        return None
    try:
        return int(m.group(1)), int(m.group(2)), m.group(3)
    except (ValueError, TypeError):
        return None


def _extract_meta(comment: str) -> dict:
    """Pull H:, M:, N:, [chi] out of a PALP comment line."""
    meta = {}
    if (m := _RE_H.search(comment)):
        meta['h11'], meta['h12'] = int(m.group(1)), int(m.group(2))
    if (m := _RE_M.search(comment)):
        meta['m_points'], meta['m_vertices'] = int(m.group(1)), int(m.group(2))
    if (m := _RE_N.search(comment)):
        meta['n_points'], meta['n_vertices_dual'] = int(m.group(1)), int(m.group(2))
    if (m := _RE_CHI.search(comment)):
        meta['euler'] = int(m.group(1))
    return meta


def _open_text(path):
    """Open a file or gzipped file as text."""
    path = Path(path)
    if str(path).endswith('.gz'):
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return open(path, 'r', encoding='utf-8', errors='replace')


def parse_palp_file(path) -> Iterator[PALPEntry]:
    """Yield PALPEntry objects from a PALP polytope-list file.
    Streams record-by-record so memory stays bounded even on 200 MB files."""
    path = Path(path)
    
    with _open_text(path) as f:
        line = f.readline()
        while line:
            header = _parse_header(line)
            if header is None:
                # Not a header; skip and continue (handles stray blanks / dirt)
                line = f.readline()
                continue
            
            rows, cols, comment = header
            meta = _extract_meta(comment)
            
            # Read `rows` lines of matrix data
            matrix_rows = []
            for _ in range(rows):
                row_line = f.readline()
                if not row_line:
                    break  # truncated file
                try:
                    nums = [int(x) for x in row_line.split()]
                    if len(nums) >= cols:
                        matrix_rows.append(nums[:cols])
                except ValueError:
                    matrix_rows.append([])  # malformed row; keep slot
            
            # Determine vertex orientation: smaller dim = ambient, larger = vertex count
            # Standard PALP convention: <ambient_dim> <n_vertices> as columns
            if rows <= cols:
                ambient = rows
                nv = cols
                # Each column is a vertex → transpose
                if all(len(r) == cols for r in matrix_rows):
                    vertices = [list(col) for col in zip(*matrix_rows)]
                else:
                    vertices = matrix_rows
            else:
                ambient = cols
                nv = rows
                # Each row is a vertex
                vertices = matrix_rows
            
            entry = PALPEntry(
                ambient_dim=ambient,
                n_vertices=nv,
                vertices=vertices,
                raw_header=line.strip(),
                **meta,
            )
            yield entry
            
            line = f.readline()


def palp_summary(paths, return_pairs: bool = False, verbose: bool = True) -> dict:
    """Aggregate Hodge spectrum and basic stats over one or more PALP files.
    
    Streams files; safe for 200 MB+ inputs. Returns a dict suitable for
    JSON serialization.
    
    If return_pairs=True, also includes 'distinct_pairs' (list of [h11, h12])
    in the result — useful for downstream analyses like mirror_check without
    needing a second pass over the data.
    
    If verbose=True, prints per-file progress as it goes.
    """
    import time
    distinct_pairs = set()
    n_entries = 0
    h11_min, h11_max = None, None
    h12_min, h12_max = None, None
    chi_min, chi_max = None, None
    n_vertices_dist = {}
    euler_consistent = 0
    euler_inconsistent = 0
    per_file = []
    t0 = time.time()
    n_files = len(list(paths))
    
    for i, p in enumerate(paths, 1):
        p = Path(p)
        file_n = 0
        file_t0 = time.time()
        for entry in parse_palp_file(p):
            n_entries += 1
            file_n += 1
            if entry.h11 is not None and entry.h12 is not None:
                distinct_pairs.add((entry.h11, entry.h12))
                if h11_min is None or entry.h11 < h11_min: h11_min = entry.h11
                if h11_max is None or entry.h11 > h11_max: h11_max = entry.h11
                if h12_min is None or entry.h12 < h12_min: h12_min = entry.h12
                if h12_max is None or entry.h12 > h12_max: h12_max = entry.h12
                if entry.euler is not None and entry.euler_from_hodge is not None:
                    if entry.euler == entry.euler_from_hodge:
                        euler_consistent += 1
                    else:
                        euler_inconsistent += 1
            if entry.euler is not None:
                if chi_min is None or entry.euler < chi_min: chi_min = entry.euler
                if chi_max is None or entry.euler > chi_max: chi_max = entry.euler
            v = entry.n_vertices
            n_vertices_dist[v] = n_vertices_dist.get(v, 0) + 1
        per_file.append({'file': p.name, 'entries': file_n})
        if verbose:
            elapsed = time.time() - file_t0
            total = time.time() - t0
            rate = file_n / elapsed if elapsed > 0 else 0
            print(f"  [{i:>2}/{n_files}] {p.name:<10} {file_n:>13,} entries "
                  f"({elapsed:>6.1f}s, {rate/1e6:>5.2f}M/s; total {total:>6.1f}s)")
    
    result = {
        'total_entries': n_entries,
        'distinct_hodge_pairs': len(distinct_pairs),
        'h11_range': [h11_min, h11_max],
        'h12_range': [h12_min, h12_max],
        'euler_range': [chi_min, chi_max],
        'vertex_count_distribution': dict(sorted(n_vertices_dist.items())),
        'euler_cross_check': {
            'consistent': euler_consistent,
            'inconsistent': euler_inconsistent,
            'note': 'chi == 2(h11 - h12) for CY 3-folds',
        },
        'per_file': per_file,
    }
    if return_pairs:
        result['distinct_pairs'] = sorted(distinct_pairs)
    return result


# ─────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    import argparse
    import glob
    import json
    import sys
    
    parser = argparse.ArgumentParser(
        description='Parse PALP polytope-list files (TU Wien v*.gz)')
    parser.add_argument('paths', nargs='+', help='Paths to .gz or plain text PALP files '
                        '(supports glob patterns like v*.gz; Windows cmd does not expand '
                        'globs, so we expand here)')
    parser.add_argument('--limit', type=int, default=5, help='Entries to show in preview (default 5)')
    parser.add_argument('--stats', action='store_true', help='Aggregate stats only')
    parser.add_argument('--json', action='store_true', help='JSON output')
    args = parser.parse_args()
    
    # Expand globs ourselves (cmd.exe doesn't)
    expanded = []
    for raw_path in args.paths:
        if any(c in raw_path for c in '*?['):
            matches = glob.glob(raw_path)
            if not matches:
                print(f"  ⚠ No files match: {raw_path}", file=sys.stderr)
            expanded.extend(sorted(matches))
        else:
            expanded.append(raw_path)
    
    if not expanded:
        print("  ✗ No files to process.", file=sys.stderr)
        sys.exit(1)
    
    if args.stats:
        summary = palp_summary(expanded)
        if args.json:
            print(json.dumps(summary, indent=2))
        else:
            print(f"  Files processed:    {len(expanded)}")
            print(f"  Total polytopes:    {summary['total_entries']:,}")
            print(f"  Distinct (h11,h12): {summary['distinct_hodge_pairs']:,}")
            print(f"  h11 range: {summary['h11_range']}")
            print(f"  h12 range: {summary['h12_range']}")
            print(f"  Euler range: {summary['euler_range']}")
            print(f"  Vertex count distribution: {summary['vertex_count_distribution']}")
            ec = summary['euler_cross_check']
            print(f"  Euler cross-check: {ec['consistent']:,} consistent, "
                  f"{ec['inconsistent']:,} inconsistent")
            print(f"  Per file:")
            for pf in summary['per_file']:
                print(f"    {pf['file']:<20} {pf['entries']:>12,} entries")
    else:
        n_shown = 0
        for p in expanded:
            for entry in parse_palp_file(p):
                if n_shown >= args.limit:
                    break
                if args.json:
                    print(json.dumps(asdict(entry)))
                else:
                    print(f"  [{n_shown:>3}] file={Path(p).name}  "
                          f"dim={entry.ambient_dim}  V={entry.n_vertices}  "
                          f"h11={entry.h11}  h12={entry.h12}  chi={entry.euler}")
                    print(f"        header: {entry.raw_header[:80]}")
                    print(f"        vertices: {entry.vertices[:3]}{'...' if len(entry.vertices)>3 else ''}")
                n_shown += 1
            if n_shown >= args.limit:
                break
