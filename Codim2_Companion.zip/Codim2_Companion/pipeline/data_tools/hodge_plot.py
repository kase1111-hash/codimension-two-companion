#!/usr/bin/env python3
"""
pipeline/data_tools/hodge_plot.py — Render the Kreuzer-Skarke shield plot.

The canonical Hodge-number scatter plot for CY 3-folds from 4D reflexive
polytopes. Each distinct (h11, h12) pair appears as a point. Color encodes
Euler characteristic χ = 2(h11 - h12). The plot is approximately symmetric
across the diagonal h11 = h12 (mirror axis); deviations are pairs whose
mirror partners weren't in the input subset.

Outputs:
    SVG primary (vector, no native dependencies)
    PNG via cairosvg if available

Usage:
    from pipeline.data_tools.hodge_plot import render_ks_shield
    render_ks_shield(pairs, 'shield.svg',
                     title='Kreuzer-Skarke Hodge Spectrum',
                     n_total_polytopes=200_575_439)
    
    # Or via CLI:
    python -m pipeline.data_tools.hodge_plot data/raw/v*.gz --out shield.svg

Author: Kase Branham — Independent Researcher
"""

import argparse
import glob as glob_mod
import json
import sys
from pathlib import Path


def render_ks_shield(
    pairs,
    output_svg,
    *,
    title: str = 'Kreuzer-Skarke Hodge Spectrum',
    subtitle: str = None,
    n_total_polytopes: int = None,
    width: int = 1200,
    height: int = 1200,
    point_size: float = 2.0,
    color_by: str = 'chi',
):
    """Render a shield plot to SVG.
    
    pairs: iterable of (h11, h12) tuples
    output_svg: pathlib.Path or str
    title: top title
    subtitle: optional second line; auto-computed if None
    n_total_polytopes: optional, for the subtitle annotation
    color_by: 'chi' (default; color by Euler char) or 'mono' (all one color)
    """
    pairs = list(pairs)
    if not pairs:
        raise ValueError("No pairs to plot")
    
    # Extents
    h11_vals = [p[0] for p in pairs]
    h12_vals = [p[1] for p in pairs]
    h11_min, h11_max = min(h11_vals), max(h11_vals)
    h12_min, h12_max = min(h12_vals), max(h12_vals)
    # Use symmetric range so the mirror line is the visual diagonal
    domain_min = min(h11_min, h12_min)
    domain_max = max(h11_max, h12_max)
    # Add a small padding
    span = domain_max - domain_min
    pad = max(1, span * 0.02)
    domain_min -= pad
    domain_max += pad
    
    W, H = width, height
    ml, mr, mt, mb = 90, 50, 90, 80  # margins
    pw, ph = W - ml - mr, H - mt - mb
    
    def to_x(h11):
        return ml + (h11 - domain_min) / (domain_max - domain_min) * pw
    def to_y(h12):
        return mt + (1 - (h12 - domain_min) / (domain_max - domain_min)) * ph
    
    # Chi → color
    chi_max = 2 * (domain_max - domain_min)  # upper bound on |chi|
    def chi_color(h11, h12):
        if color_by == 'mono':
            return '#2563eb'  # blue-600
        chi = 2 * (h11 - h12)
        if chi == 0:
            return '#525252'  # gray-600 (on the mirror line)
        # Diverging palette: red for chi<0 (h12>h11, more complex structure deformations)
        #                   blue for chi>0 (h11>h12)
        t = min(1.0, abs(chi) / chi_max)
        if chi > 0:
            # Blue gradient: lighter to darker
            r = int(220 - 180 * t)
            g = int(230 - 150 * t)
            b = int(255 - 30 * t)
        else:
            r = int(255 - 30 * t)
            g = int(220 - 160 * t)
            b = int(220 - 180 * t)
        return f'rgb({r},{g},{b})'
    
    # Build SVG
    parts = []
    parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
                 f'viewBox="0 0 {W} {H}" font-family="ui-sans-serif, system-ui, sans-serif">')
    parts.append(f'<rect width="{W}" height="{H}" fill="white"/>')
    
    # Title + subtitle
    parts.append(f'<text x="{W/2}" y="38" font-size="24" font-weight="bold" '
                 f'text-anchor="middle" fill="#111">{title}</text>')
    if subtitle is None:
        subtitle = f'{len(pairs):,} distinct (h^(1,1), h^(1,2)) pairs'
        if n_total_polytopes:
            subtitle += f'  ·  {n_total_polytopes:,} polytopes scanned'
    parts.append(f'<text x="{W/2}" y="64" font-size="13" '
                 f'text-anchor="middle" fill="#666">{subtitle}</text>')
    
    # Plot frame
    parts.append(f'<rect x="{ml}" y="{mt}" width="{pw}" height="{ph}" '
                 f'fill="#fafafa" stroke="#999" stroke-width="1"/>')
    
    # Grid + tick labels
    # Choose a tick step that gives 5-10 ticks
    raw_step = span / 7
    # Round to nice number
    for candidate in (1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500):
        if candidate >= raw_step:
            tick_step = candidate
            break
    else:
        tick_step = 1000
    
    # Start at first tick at or above domain_min, snapped
    first_tick = ((int(domain_min) // tick_step) + (1 if domain_min > 0 else 0)) * tick_step
    if first_tick < 1: first_tick = tick_step
    tick = first_tick
    while tick <= domain_max:
        # Vertical grid + x-axis label
        x = to_x(tick)
        parts.append(f'<line x1="{x:.2f}" y1="{mt}" x2="{x:.2f}" y2="{mt+ph}" '
                     f'stroke="#e5e5e5" stroke-width="0.5"/>')
        parts.append(f'<text x="{x:.2f}" y="{mt+ph+20}" font-size="11" '
                     f'text-anchor="middle" fill="#555">{tick}</text>')
        # Horizontal grid + y-axis label
        y = to_y(tick)
        parts.append(f'<line x1="{ml}" y1="{y:.2f}" x2="{ml+pw}" y2="{y:.2f}" '
                     f'stroke="#e5e5e5" stroke-width="0.5"/>')
        parts.append(f'<text x="{ml-8}" y="{y+4:.2f}" font-size="11" '
                     f'text-anchor="end" fill="#555">{tick}</text>')
        tick += tick_step
    
    # Mirror line h11 = h12
    x1, y1 = to_x(domain_min), to_y(domain_min)
    x2, y2 = to_x(domain_max), to_y(domain_max)
    parts.append(f'<line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" '
                 f'stroke="#dc2626" stroke-width="1" stroke-dasharray="5,4" opacity="0.6"/>')
    
    # Data points — use <rect> for speed at 30k+ points
    parts.append('<g id="ks-points" shape-rendering="crispEdges">')
    s = point_size
    for h11, h12 in pairs:
        x = to_x(h11)
        y = to_y(h12)
        color = chi_color(h11, h12)
        parts.append(f'<rect x="{x-s/2:.2f}" y="{y-s/2:.2f}" '
                     f'width="{s}" height="{s}" fill="{color}"/>')
    parts.append('</g>')
    
    # Axis labels (outside the plot)
    parts.append(f'<text x="{ml+pw/2}" y="{H-25}" font-size="15" font-weight="500" '
                 f'text-anchor="middle" fill="#222">h^(1,1)</text>')
    parts.append(f'<g transform="translate(28, {mt+ph/2}) rotate(-90)">'
                 f'<text font-size="15" font-weight="500" text-anchor="middle" '
                 f'fill="#222">h^(1,2)</text></g>')
    
    # Mirror-axis annotation
    mid_x = to_x((domain_min + domain_max) / 2 - span * 0.1)
    mid_y = to_y((domain_min + domain_max) / 2 - span * 0.1)
    parts.append(f'<text x="{mid_x:.2f}" y="{mid_y-8:.2f}" font-size="11" fill="#dc2626" '
                 f'transform="rotate(-45 {mid_x:.2f} {mid_y-8:.2f})" '
                 f'text-anchor="middle">mirror axis (h^(1,1) = h^(1,2))</text>')
    
    # Color legend (mini gradient bar at top-right)
    if color_by == 'chi':
        lg_x = W - 230
        lg_y = mt + 12
        parts.append(f'<text x="{lg_x}" y="{lg_y-4}" font-size="10" fill="#555">'
                     f'χ = 2(h^(1,1) − h^(1,2))</text>')
        # 11 swatches across
        for i in range(11):
            t = i / 10
            chi_val = -chi_max + 2 * chi_max * t
            c = chi_color(domain_min + t * span, domain_min + (1-t) * span)
            parts.append(f'<rect x="{lg_x + i*16}" y="{lg_y}" width="16" height="10" fill="{c}"/>')
        parts.append(f'<text x="{lg_x}" y="{lg_y+22}" font-size="9" fill="#666" '
                     f'text-anchor="start">{-int(chi_max)}</text>')
        parts.append(f'<text x="{lg_x + 80}" y="{lg_y+22}" font-size="9" fill="#666" '
                     f'text-anchor="middle">0</text>')
        parts.append(f'<text x="{lg_x + 176}" y="{lg_y+22}" font-size="9" fill="#666" '
                     f'text-anchor="end">+{int(chi_max)}</text>')
    
    parts.append('</svg>')
    
    output_svg = Path(output_svg)
    output_svg.write_text('\n'.join(parts), encoding='utf-8')
    return output_svg


def render_ks_shield_png(svg_path, png_path, width: int = 1400):
    """Convert SVG → PNG via cairosvg. Returns True on success, False on cairo failure.
    
    Catches OSError (Windows without GTK+) gracefully.
    """
    try:
        import cairosvg
        cairosvg.svg2png(url=str(svg_path), write_to=str(png_path), output_width=width)
        return True
    except (ImportError, OSError):
        return False


# ─────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='Render the KS shield plot')
    parser.add_argument('paths', nargs='*', help='Paths to .gz files (glob supported). '
                        'Omit if using --from-cache.')
    parser.add_argument('--from-cache',
                        help='Read the pair set from a ks_pairs.json cache instead of '
                             'scanning raw files. Use the file written by mirror_check '
                             '(default location: data/cache/ks_pairs.json).')
    parser.add_argument('--out', default='ks_hodge_shield.svg', help='Output SVG path')
    parser.add_argument('--png', help='Also render PNG (requires libcairo)')
    parser.add_argument('--title', default='Kreuzer-Skarke Hodge Spectrum')
    parser.add_argument('--mono', action='store_true', help='Single-color points')
    args = parser.parse_args()
    
    pairs = None
    n_total = None
    
    if args.from_cache:
        cache_path = Path(args.from_cache)
        if not cache_path.exists():
            print(f"  ✗ Cache file not found: {cache_path}", file=sys.stderr)
            print(f"     (run mirror_check first to generate it)", file=sys.stderr)
            return 1
        with open(cache_path, encoding='utf-8') as f:
            cache = json.load(f)
        pairs = [tuple(p) for p in cache['pairs']]
        n_total = cache.get('_total_polytopes_scanned')
        print(f"  Loaded {len(pairs):,} pairs from cache: {cache_path}")
        if n_total:
            print(f"  Source: {n_total:,} polytopes from "
                  f"{len(cache.get('_source_files', []))} files")
    elif args.paths:
        # Expand globs
        expanded = []
        for raw in args.paths:
            if any(c in raw for c in '*?['):
                expanded.extend(sorted(glob_mod.glob(raw)))
            else:
                expanded.append(raw)
        if not expanded:
            print("  ✗ No files to process", file=sys.stderr)
            return 1
        print(f"  Scanning {len(expanded)} file(s) (this may take a while for the full KS set)...")
        from pipeline.data_tools.palp_parser import palp_summary
        s = palp_summary(expanded, return_pairs=True)
        pairs = [tuple(p) for p in s['distinct_pairs']]
        n_total = s['total_entries']
        print(f"  Collected {len(pairs):,} distinct (h11, h12) pairs from {n_total:,} polytopes")
    else:
        # Try the default cache location
        project_root = Path(__file__).parent.parent.parent
        default_cache = project_root / 'data' / 'cache' / 'ks_pairs.json'
        if default_cache.exists():
            with open(default_cache, encoding='utf-8') as f:
                cache = json.load(f)
            pairs = [tuple(p) for p in cache['pairs']]
            n_total = cache.get('_total_polytopes_scanned')
            print(f"  Loaded {len(pairs):,} pairs from default cache: {default_cache}")
        else:
            print("  ✗ No paths given and no cache at data/cache/ks_pairs.json", file=sys.stderr)
            print("     Either pass file paths or run mirror_check first.", file=sys.stderr)
            return 1
    
    svg_path = Path(args.out)
    render_ks_shield(
        pairs, svg_path,
        title=args.title,
        n_total_polytopes=n_total,
        color_by='mono' if args.mono else 'chi',
    )
    print(f"  ✓ Wrote {svg_path} ({svg_path.stat().st_size / 1024:.1f} KB)")
    
    if args.png:
        ok = render_ks_shield_png(svg_path, args.png)
        if ok:
            png_path = Path(args.png)
            print(f"  ✓ Wrote {png_path} ({png_path.stat().st_size / 1024:.1f} KB)")
        else:
            print("  ⚠ PNG render skipped (libcairo not available)")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
