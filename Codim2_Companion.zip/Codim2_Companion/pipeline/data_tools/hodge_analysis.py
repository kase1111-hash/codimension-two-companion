#!/usr/bin/env python3
"""
pipeline/data_tools/hodge_analysis.py — Distribution analyses on the
Kreuzer-Skarke Hodge spectrum.

Operates on the cached pair set (data/cache/ks_pairs.json) — no re-scan needed.

Analyses produced:
  - Euler characteristic χ = 2(h¹¹ − h¹²) distribution histogram
  - h¹¹ + h¹² sum distribution (≈ complex-moduli structural count)
  - Per-h¹¹ marginal: distinct h¹² values present for each h¹¹
  - Self-mirror line frequency
  - Extremes: pairs achieving max |χ|, max h¹¹+h¹², etc.

Outputs:
  - chi_histogram.svg / .png — bar chart of χ frequency
  - sum_histogram.svg / .png — bar chart of (h¹¹+h¹²) frequency
  - h11_marginal.svg / .png — distinct h¹² count per h¹¹
  - hodge_analysis_summary.json — all numeric findings + sample extremes
  - Stdout: pretty-printed summary table

Usage:
    python -m pipeline.data_tools.hodge_analysis
    python -m pipeline.data_tools.hodge_analysis --from-cache data/cache/ks_pairs.json
    python -m pipeline.data_tools.hodge_analysis --out-dir analysis/
    python -m pipeline.data_tools.hodge_analysis --json

Author: Kase Branham — Independent Researcher
"""

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple


# ─────────────────────────────────────────────────────────────────
# Distribution analyses
# ─────────────────────────────────────────────────────────────────

def chi_distribution(pairs) -> Counter:
    """Euler characteristic frequency: χ = 2(h¹¹ − h¹²) per distinct pair."""
    return Counter(2 * (a - b) for (a, b) in pairs)


def sum_distribution(pairs) -> Counter:
    """h¹¹ + h¹² distribution. The sum is a structural quantity related to
    the total dimension of the Calabi-Yau moduli space (modulo h²¹ which is
    zero for these reflexive-polytope CY 3-folds)."""
    return Counter(a + b for (a, b) in pairs)


def h11_marginal(pairs) -> Dict[int, int]:
    """For each h¹¹ value, how many distinct h¹² values appear with it?"""
    out: Dict[int, set] = {}
    for (a, b) in pairs:
        out.setdefault(a, set()).add(b)
    return {a: len(s) for a, s in out.items()}


def h12_marginal(pairs) -> Dict[int, int]:
    """For each h¹² value, how many distinct h¹¹ values appear with it?
    By mirror symmetry this should equal h11_marginal(pairs) under (a↔b)."""
    out: Dict[int, set] = {}
    for (a, b) in pairs:
        out.setdefault(b, set()).add(a)
    return {b: len(s) for b, s in out.items()}


def find_extremes(pairs) -> Dict:
    """Locate the most-extreme pairs across various dimensions."""
    pairs_list = list(pairs)
    
    # Max |χ|
    chi_pairs = [(p, 2 * (p[0] - p[1])) for p in pairs_list]
    max_neg_chi = min(chi_pairs, key=lambda x: x[1])
    max_pos_chi = max(chi_pairs, key=lambda x: x[1])
    chi_zero_pairs = [p for (p, c) in chi_pairs if c == 0]
    
    # Max h¹¹+h¹²
    sum_pairs = sorted(pairs_list, key=lambda p: p[0] + p[1])
    
    # Max h¹¹, max h¹²
    max_h11 = max(pairs_list, key=lambda p: p[0])
    max_h12 = max(pairs_list, key=lambda p: p[1])
    min_h11 = min(pairs_list, key=lambda p: p[0])
    min_h12 = min(pairs_list, key=lambda p: p[1])
    
    return {
        'max_negative_chi': {'pair': list(max_neg_chi[0]), 'chi': max_neg_chi[1]},
        'max_positive_chi': {'pair': list(max_pos_chi[0]), 'chi': max_pos_chi[1]},
        'chi_zero_count': len(chi_zero_pairs),
        'chi_zero_h11_range': [min(p[0] for p in chi_zero_pairs),
                                max(p[0] for p in chi_zero_pairs)] if chi_zero_pairs else None,
        'max_h11_sum': {'pair': list(sum_pairs[-1]), 'sum': sum_pairs[-1][0] + sum_pairs[-1][1]},
        'min_h11_sum': {'pair': list(sum_pairs[0]), 'sum': sum_pairs[0][0] + sum_pairs[0][1]},
        'max_h11': {'pair': list(max_h11), 'h11': max_h11[0]},
        'max_h12': {'pair': list(max_h12), 'h12': max_h12[1]},
        'min_h11': {'pair': list(min_h11), 'h11': min_h11[0]},
        'min_h12': {'pair': list(min_h12), 'h12': min_h12[1]},
    }


def compute_summary(pairs) -> Dict:
    """All numeric findings in a single dict."""
    pairs_list = list(pairs)
    n_pairs = len(pairs_list)
    
    chi_dist = chi_distribution(pairs)
    sum_dist = sum_distribution(pairs)
    h11_marg = h11_marginal(pairs)
    h12_marg = h12_marginal(pairs)
    
    chis = [2 * (a - b) for (a, b) in pairs_list]
    sums = [a + b for (a, b) in pairs_list]
    
    # Mirror-symmetry check on the distributions:
    # For each χ ≠ 0, count(χ) should equal count(-χ) (because (a,b) is paired with (b,a)).
    chi_symmetric = all(chi_dist[c] == chi_dist[-c] for c in chi_dist if c != 0)
    
    # Mode (most-common χ; for CY 3-folds this is usually χ=0 — the self-mirror line)
    chi_mode = chi_dist.most_common(1)[0]
    sum_mode = sum_dist.most_common(1)[0]
    
    return {
        'n_distinct_pairs': n_pairs,
        'chi_distribution': {
            'n_distinct_chi_values': len(chi_dist),
            'min': min(chis), 'max': max(chis),
            'mean': round(sum(chis) / n_pairs, 4),
            'mode_chi': chi_mode[0], 'mode_count': chi_mode[1],
            'mirror_symmetric': chi_symmetric,
            'chi_zero_count': chi_dist.get(0, 0),
            # Stratified sample at every 100 units
            'sample_histogram': {str(c): chi_dist[c] for c in sorted(chi_dist)},
        },
        'sum_distribution': {
            'n_distinct_sum_values': len(sum_dist),
            'min': min(sums), 'max': max(sums),
            'mean': round(sum(sums) / n_pairs, 4),
            'mode_sum': sum_mode[0], 'mode_count': sum_mode[1],
        },
        'h11_marginal': h11_marg,
        'h12_marginal': h12_marg,
        'extremes': find_extremes(pairs),
    }


# ─────────────────────────────────────────────────────────────────
# Histogram renderer (SVG)
# ─────────────────────────────────────────────────────────────────

def render_histogram(
    counts: Counter,
    output_svg: Path,
    *,
    title: str,
    x_label: str = 'value',
    y_label: str = 'count',
    color: str = '#2563eb',
    width: int = 1400,
    height: int = 600,
    bar_color_fn=None,
    log_y: bool = False,
):
    """Render a histogram of a Counter to SVG.
    
    bar_color_fn(x_value) -> color string overrides the default color per bar.
    """
    if not counts:
        raise ValueError("Empty counts")
    
    keys = sorted(counts.keys())
    values = [counts[k] for k in keys]
    
    W, H = width, height
    ml, mr, mt, mb = 90, 30, 60, 70
    pw, ph = W - ml - mr, H - mt - mb
    
    x_min, x_max = keys[0], keys[-1]
    x_span = max(x_max - x_min, 1)
    
    import math
    if log_y:
        # +1 to handle zeros gracefully
        v_max_disp = math.log10(max(values) + 1)
        v_min_disp = 0
    else:
        v_max_disp = max(values)
        v_min_disp = 0
    
    def x_pos(k):
        return ml + (k - x_min) / x_span * pw
    
    def y_pos(v):
        if log_y:
            v_disp = math.log10(v + 1)
        else:
            v_disp = v
        return mt + (1 - (v_disp - v_min_disp) / max(v_max_disp - v_min_disp, 1)) * ph
    
    parts = []
    parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
                 f'viewBox="0 0 {W} {H}" font-family="ui-sans-serif, system-ui, sans-serif">')
    parts.append(f'<rect width="{W}" height="{H}" fill="white"/>')
    parts.append(f'<text x="{W/2}" y="32" font-size="20" font-weight="bold" '
                 f'text-anchor="middle" fill="#111">{title}</text>')
    
    # Plot frame
    parts.append(f'<rect x="{ml}" y="{mt}" width="{pw}" height="{ph}" '
                 f'fill="#fafafa" stroke="#999" stroke-width="1"/>')
    
    # Bars
    if len(keys) <= 200:
        bar_w = max(pw / len(keys) * 0.85, 1.0)
    else:
        bar_w = max(pw / len(keys), 0.5)
    
    for k, v in zip(keys, values):
        if v == 0:
            continue
        x = x_pos(k)
        y = y_pos(v)
        bar_h = (mt + ph) - y
        c = bar_color_fn(k) if bar_color_fn else color
        parts.append(f'<rect x="{x - bar_w/2:.2f}" y="{y:.2f}" '
                     f'width="{bar_w:.2f}" height="{bar_h:.2f}" '
                     f'fill="{c}" opacity="0.85"/>')
    
    # X-axis ticks
    n_x_ticks = 9
    tick_step_raw = x_span / (n_x_ticks - 1)
    for candidate in (1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000):
        if candidate >= tick_step_raw:
            x_tick = candidate
            break
    else:
        x_tick = 5000
    t = ((x_min // x_tick) + (1 if x_min > 0 else 0)) * x_tick
    while t <= x_max:
        xp = x_pos(t)
        parts.append(f'<line x1="{xp:.2f}" y1="{mt+ph}" x2="{xp:.2f}" y2="{mt+ph+5}" '
                     f'stroke="#666"/>')
        parts.append(f'<text x="{xp:.2f}" y="{mt+ph+22}" font-size="11" '
                     f'text-anchor="middle" fill="#444">{t}</text>')
        t += x_tick
    
    # Y-axis ticks (5 levels)
    for i in range(6):
        if log_y:
            v_disp = i * v_max_disp / 5
            v_label = int(10 ** v_disp) - 1 if v_disp > 0 else 0
        else:
            v_disp = i * v_max_disp / 5
            v_label = int(v_disp)
        yp = mt + ph - (v_disp / max(v_max_disp, 1)) * ph
        parts.append(f'<line x1="{ml-5}" y1="{yp:.2f}" x2="{ml}" y2="{yp:.2f}" stroke="#666"/>')
        parts.append(f'<line x1="{ml}" y1="{yp:.2f}" x2="{ml+pw}" y2="{yp:.2f}" '
                     f'stroke="#e8e8e8" stroke-width="0.5"/>')
        parts.append(f'<text x="{ml-10}" y="{yp+4:.2f}" font-size="11" '
                     f'text-anchor="end" fill="#444">{v_label:,}</text>')
    
    # Axis labels
    parts.append(f'<text x="{ml+pw/2}" y="{H-18}" font-size="13" '
                 f'text-anchor="middle" fill="#222">{x_label}</text>')
    parts.append(f'<g transform="translate(28, {mt+ph/2}) rotate(-90)">'
                 f'<text font-size="13" text-anchor="middle" fill="#222">'
                 f'{y_label}{" (log scale)" if log_y else ""}</text></g>')
    
    parts.append('</svg>')
    output_svg.write_text('\n'.join(parts), encoding='utf-8')
    return output_svg


def render_chi_histogram(pairs, out_svg):
    """The Euler-characteristic distribution. Color positive blue, negative red,
    zero gray (consistent with the shield plot palette)."""
    chi_dist = chi_distribution(pairs)
    
    def chi_bar_color(chi):
        if chi == 0:
            return '#525252'
        if chi > 0:
            return '#2563eb'  # blue
        return '#dc2626'      # red
    
    return render_histogram(
        chi_dist, out_svg,
        title='Kreuzer-Skarke Euler-characteristic distribution',
        x_label='χ = 2(h^(1,1) − h^(1,2))',
        y_label='number of distinct (h^(1,1), h^(1,2)) pairs',
        bar_color_fn=chi_bar_color,
    )


def render_sum_histogram(pairs, out_svg):
    """h11 + h12 distribution."""
    sum_dist = sum_distribution(pairs)
    return render_histogram(
        sum_dist, out_svg,
        title='Kreuzer-Skarke (h^(1,1) + h^(1,2)) distribution',
        x_label='h^(1,1) + h^(1,2)',
        y_label='number of distinct pairs',
        color='#7c3aed',  # purple
    )


def render_h11_marginal_histogram(pairs, out_svg):
    """For each h11, how many distinct h12 values appear with it?"""
    marg = h11_marginal(pairs)
    counter = Counter(marg)
    # But we want it indexed by h11 value
    keys = sorted(marg.keys())
    counts = Counter()
    for k in keys:
        counts[k] = marg[k]
    return render_histogram(
        counts, out_svg,
        title='Distinct h^(1,2) values per h^(1,1)',
        x_label='h^(1,1)',
        y_label='count of distinct h^(1,2) values',
        color='#059669',  # green
    )


def render_png(svg_path, png_path, width=1600):
    """Convert SVG → PNG via cairosvg. Returns True on success."""
    try:
        import cairosvg
        cairosvg.svg2png(url=str(svg_path), write_to=str(png_path), output_width=width)
        return True
    except (ImportError, OSError):
        return False


# ─────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────

def format_summary(summary: Dict) -> str:
    """Pretty-print the summary as a terminal-friendly report."""
    lines = []
    lines.append("=" * 72)
    lines.append("  KREUZER-SKARKE HODGE-SPECTRUM DISTRIBUTION ANALYSIS")
    lines.append("=" * 72)
    lines.append(f"  Distinct (h¹¹, h¹²) pairs:  {summary['n_distinct_pairs']:,}")
    lines.append("")
    
    cd = summary['chi_distribution']
    lines.append("  ── Euler characteristic χ = 2(h¹¹ − h¹²) ──")
    lines.append(f"    range:              [{cd['min']}, {cd['max']}]")
    lines.append(f"    mean:               {cd['mean']:.2f}")
    lines.append(f"    distinct χ values:  {cd['n_distinct_chi_values']:,}")
    lines.append(f"    most common χ:      {cd['mode_chi']}  ({cd['mode_count']:,} pairs)")
    lines.append(f"    χ = 0 count:        {cd['chi_zero_count']:,}  (self-mirror line)")
    lines.append(f"    mirror-symmetric:   {'✓' if cd['mirror_symmetric'] else '✗'}  "
                 f"(count(χ) == count(−χ) for all χ ≠ 0)")
    lines.append("")
    
    sd = summary['sum_distribution']
    lines.append("  ── h¹¹ + h¹² sum ──")
    lines.append(f"    range:              [{sd['min']}, {sd['max']}]")
    lines.append(f"    mean:               {sd['mean']:.2f}")
    lines.append(f"    distinct sums:      {sd['n_distinct_sum_values']:,}")
    lines.append(f"    most common sum:    {sd['mode_sum']}  ({sd['mode_count']:,} pairs)")
    lines.append("")
    
    ex = summary['extremes']
    lines.append("  ── Extremes ──")
    p = ex['max_negative_chi']
    lines.append(f"    most-negative χ:    {p['chi']:>5}  at (h¹¹, h¹²) = ({p['pair'][0]}, {p['pair'][1]})")
    p = ex['max_positive_chi']
    lines.append(f"    most-positive χ:    {p['chi']:>5}  at (h¹¹, h¹²) = ({p['pair'][0]}, {p['pair'][1]})  (mirror of above)")
    p = ex['max_h11_sum']
    lines.append(f"    max h¹¹ + h¹²:      {p['sum']:>5}  at (h¹¹, h¹²) = ({p['pair'][0]}, {p['pair'][1]})")
    p = ex['min_h11_sum']
    lines.append(f"    min h¹¹ + h¹²:      {p['sum']:>5}  at (h¹¹, h¹²) = ({p['pair'][0]}, {p['pair'][1]})")
    lines.append(f"    max h¹¹:            {ex['max_h11']['h11']:>5}  in pair {tuple(ex['max_h11']['pair'])}")
    lines.append(f"    max h¹²:            {ex['max_h12']['h12']:>5}  in pair {tuple(ex['max_h12']['pair'])}")
    lines.append("")
    
    # h¹¹ marginal — show extremes
    h11m = summary['h11_marginal']
    sorted_marg = sorted(h11m.items(), key=lambda kv: -kv[1])
    lines.append("  ── Per-h¹¹ marginal (top 10 h¹¹ by number of distinct h¹² partners) ──")
    for h11, n in sorted_marg[:10]:
        lines.append(f"    h¹¹ = {h11:>3}:  {n:>4} distinct h¹² values")
    lines.append("")
    
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description='KS Hodge-spectrum distribution analysis')
    parser.add_argument('--from-cache', help='Path to ks_pairs.json (default: data/cache/ks_pairs.json)')
    parser.add_argument('--out-dir', default='analysis',
                        help='Output directory for SVG/PNG/JSON artifacts (default: analysis/)')
    parser.add_argument('--json', action='store_true', help='Print summary as JSON instead of pretty text')
    parser.add_argument('--png', action='store_true', help='Also render PNGs (needs libcairo)')
    args = parser.parse_args()
    
    project_root = Path(__file__).parent.parent.parent
    cache_path = Path(args.from_cache) if args.from_cache else (
        project_root / 'data' / 'cache' / 'ks_pairs.json')
    
    if not cache_path.exists():
        print(f"  ✗ Cache file not found: {cache_path}", file=sys.stderr)
        print("    Run mirror_check or ch_32 first to populate the cache.", file=sys.stderr)
        return 1
    
    with open(cache_path, encoding='utf-8') as f:
        cache = json.load(f)
    pairs = [tuple(p) for p in cache['pairs']]
    print(f"  Loaded {len(pairs):,} pairs from {cache_path.name}")
    
    summary = compute_summary(pairs)
    
    # Print
    if args.json:
        print(json.dumps(summary, indent=2))
    else:
        print(format_summary(summary))
    
    # Write artifacts
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    
    chi_svg = out_dir / 'chi_histogram.svg'
    render_chi_histogram(pairs, chi_svg)
    print(f"  → {chi_svg} ({chi_svg.stat().st_size / 1024:.1f} KB)")
    
    sum_svg = out_dir / 'sum_histogram.svg'
    render_sum_histogram(pairs, sum_svg)
    print(f"  → {sum_svg} ({sum_svg.stat().st_size / 1024:.1f} KB)")
    
    marg_svg = out_dir / 'h11_marginal.svg'
    render_h11_marginal_histogram(pairs, marg_svg)
    print(f"  → {marg_svg} ({marg_svg.stat().st_size / 1024:.1f} KB)")
    
    summary_json = out_dir / 'hodge_analysis_summary.json'
    # Strip the very-large nested dicts for the on-disk JSON
    compact = dict(summary)
    if 'sample_histogram' in compact.get('chi_distribution', {}):
        ch = compact['chi_distribution'].copy()
        ch.pop('sample_histogram', None)
        compact['chi_distribution'] = ch
    with open(summary_json, 'w', encoding='utf-8') as f:
        json.dump(compact, f, indent=2)
    print(f"  → {summary_json} ({summary_json.stat().st_size / 1024:.1f} KB)")
    
    if args.png:
        for svg in [chi_svg, sum_svg, marg_svg]:
            png = svg.with_suffix('.png')
            if render_png(svg, png):
                print(f"  → {png} ({png.stat().st_size / 1024:.1f} KB)")
            else:
                print(f"  ⚠ PNG render skipped for {svg.name} (no libcairo)")
                break
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
