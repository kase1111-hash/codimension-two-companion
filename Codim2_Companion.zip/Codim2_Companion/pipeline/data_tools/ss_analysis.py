#!/usr/bin/env python3
"""
pipeline/data_tools/ss_analysis.py — Distribution analyses on the
Schöller-Skarke 5D Hodge spectrum (CY 4-folds).

Operates on a cached tuple set produced by ss_streamer.py — no re-scan needed.

Analyses produced:
  - χ = 48 + 6·(h11 − h12 + h13) distribution
  - h22 = 44 + 4·h11 − 2·h12 + 4·h13 distribution
  - h11 + h12 + h13 sum distribution
  - h12 marginal (since h12 is its own mirror it's a natural slicing variable)
  - Self-mirror diagonal (h11 = h13) sub-population analysis
  - Extremes: max/min for each Hodge number, max |χ|, max h22, etc.

Outputs:
  - chi_histogram_4fold.svg / .png
  - h22_histogram.svg / .png
  - sum_histogram_4fold.svg / .png
  - ss_analysis_summary.json
  - Stdout: pretty-printed report

Usage:
    python -m pipeline.data_tools.ss_analysis
    python -m pipeline.data_tools.ss_analysis --cache data/cache/ss_5d/<file>.json.gz
    python -m pipeline.data_tools.ss_analysis --out-dir analysis/ss_5d
"""

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, Tuple

# Reuse the streamer's cache loaders
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from pipeline.data_tools.ss_streamer import load_tuples, SS_CACHE_DIR


def derive_h22(h11, h12, h13):
    """h22 = 44 + 4·h11 − 2·h12 + 4·h13 (Schöller-Skarke arXiv:1808.02422)."""
    return 44 + 4*h11 - 2*h12 + 4*h13


def derive_chi(h11, h12, h13):
    """χ = 48 + 6·(h11 − h12 + h13)."""
    return 48 + 6*(h11 - h12 + h13)


def compute_summary(tuples: set) -> Dict:
    """Compute all summary statistics on the tuple set."""
    n = len(tuples)
    
    chi_counts: Counter = Counter()
    h22_counts: Counter = Counter()
    sum_counts: Counter = Counter()
    h12_counts: Counter = Counter()
    h11_counts: Counter = Counter()
    h13_counts: Counter = Counter()
    
    chis = []
    h22s = []
    sums = []
    self_mirror_count = 0
    
    extremes = {
        'max_h11': (None, -1),
        'max_h12': (None, -1),
        'max_h13': (None, -1),
        'min_h11': (None, float('inf')),
        'min_h12': (None, float('inf')),
        'min_h13': (None, float('inf')),
        'max_h22': (None, -1),
        'max_chi': (None, float('-inf')),
        'min_chi': (None, float('inf')),
        'max_sum': (None, -1),
        'min_sum': (None, float('inf')),
    }
    
    for t in tuples:
        h11, h12, h13 = t
        chi = derive_chi(h11, h12, h13)
        h22 = derive_h22(h11, h12, h13)
        s = h11 + h12 + h13
        
        chi_counts[chi] += 1
        h22_counts[h22] += 1
        sum_counts[s] += 1
        h12_counts[h12] += 1
        h11_counts[h11] += 1
        h13_counts[h13] += 1
        chis.append(chi)
        h22s.append(h22)
        sums.append(s)
        
        if h11 == h13:
            self_mirror_count += 1
        
        # Track extremes
        if h11 > extremes['max_h11'][1]: extremes['max_h11'] = (t, h11)
        if h12 > extremes['max_h12'][1]: extremes['max_h12'] = (t, h12)
        if h13 > extremes['max_h13'][1]: extremes['max_h13'] = (t, h13)
        if h11 < extremes['min_h11'][1]: extremes['min_h11'] = (t, h11)
        if h12 < extremes['min_h12'][1]: extremes['min_h12'] = (t, h12)
        if h13 < extremes['min_h13'][1]: extremes['min_h13'] = (t, h13)
        if h22 > extremes['max_h22'][1]: extremes['max_h22'] = (t, h22)
        if chi > extremes['max_chi'][1]: extremes['max_chi'] = (t, chi)
        if chi < extremes['min_chi'][1]: extremes['min_chi'] = (t, chi)
        if s > extremes['max_sum'][1]: extremes['max_sum'] = (t, s)
        if s < extremes['min_sum'][1]: extremes['min_sum'] = (t, s)
    
    chi_mode = chi_counts.most_common(1)[0]
    h22_mode = h22_counts.most_common(1)[0]
    sum_mode = sum_counts.most_common(1)[0]
    
    # Mirror-symmetry check: χ is mirror-symmetric iff the underlying
    # tuple set is closed under (h11, h13) swap. Specifically: for a swap
    # that fixes h12 and replaces (h11, h13) with (h13, h11), χ flips its
    # (h11-h13) component, so χ → 48 + 6·(h13 - h12 + h11) = same! Actually
    # χ is invariant under the mirror swap (because it's symmetric in h11
    # and h13). So χ-symmetry isn't a non-trivial check here.
    # Instead, check that count((h11, h12, h13)) and count((h13, h12, h11))
    # are equal in our set (this IS the mirror closure condition).
    
    return {
        'n_distinct_tuples': n,
        'self_mirror_count': self_mirror_count,
        'chi': {
            'min': min(chis), 'max': max(chis),
            'mean': sum(chis) / n,
            'mode': chi_mode[0], 'mode_count': chi_mode[1],
            'n_distinct': len(chi_counts),
        },
        'h22': {
            'min': min(h22s), 'max': max(h22s),
            'mean': sum(h22s) / n,
            'mode': h22_mode[0], 'mode_count': h22_mode[1],
            'n_distinct': len(h22_counts),
        },
        'sum_h11_h12_h13': {
            'min': min(sums), 'max': max(sums),
            'mean': sum(sums) / n,
            'mode': sum_mode[0], 'mode_count': sum_mode[1],
            'n_distinct': len(sum_counts),
        },
        'h12_distinct_values': len(h12_counts),
        'h11_distinct_values': len(h11_counts),
        'h13_distinct_values': len(h13_counts),
        'extremes': {k: {'tuple': list(v[0]) if v[0] else None, 'value': v[1]}
                     for k, v in extremes.items()},
        '_chi_counts': dict(chi_counts.most_common(20)),
        '_h22_counts': dict(h22_counts.most_common(20)),
    }


def render_histogram(counts: Counter, output_svg: Path, *,
                     title: str, x_label: str = 'value',
                     y_label: str = 'count', color: str = '#7c3aed',
                     width: int = 1400, height: int = 600, log_y: bool = False):
    """SVG histogram renderer; same style as hodge_analysis.render_histogram."""
    if not counts:
        raise ValueError("Empty counts")
    import math
    
    keys = sorted(counts.keys())
    values = [counts[k] for k in keys]
    
    W, H = width, height
    ml, mr, mt, mb = 90, 30, 60, 70
    pw, ph = W - ml - mr, H - mt - mb
    
    x_min, x_max = keys[0], keys[-1]
    x_span = max(x_max - x_min, 1)
    
    if log_y:
        v_max_disp = math.log10(max(values) + 1)
    else:
        v_max_disp = max(values)
    
    def x_pos(k):
        return ml + (k - x_min) / x_span * pw
    
    def y_pos(v):
        v_disp = math.log10(v + 1) if log_y else v
        return mt + (1 - v_disp / max(v_max_disp, 1)) * ph
    
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
        f'viewBox="0 0 {W} {H}" font-family="ui-sans-serif, system-ui, sans-serif">',
        f'<rect width="{W}" height="{H}" fill="white"/>',
        f'<text x="{W/2}" y="32" font-size="20" font-weight="bold" '
        f'text-anchor="middle" fill="#111">{title}</text>',
        f'<rect x="{ml}" y="{mt}" width="{pw}" height="{ph}" '
        f'fill="#fafafa" stroke="#999" stroke-width="1"/>',
    ]
    
    bar_w = max(pw / max(len(keys), 1), 0.5) if len(keys) > 200 else max(pw / len(keys) * 0.85, 1.0)
    
    for k, v in zip(keys, values):
        if v == 0:
            continue
        x = x_pos(k)
        y = y_pos(v)
        bar_h = (mt + ph) - y
        parts.append(f'<rect x="{x - bar_w/2:.2f}" y="{y:.2f}" '
                     f'width="{bar_w:.2f}" height="{bar_h:.2f}" '
                     f'fill="{color}" opacity="0.85"/>')
    
    # Ticks (simplified — fewer than hodge_analysis)
    n_x_ticks = 8
    tick_step_raw = x_span / (n_x_ticks - 1)
    for c in (1, 2, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000):
        if c >= tick_step_raw:
            x_tick = c
            break
    else:
        x_tick = 50000
    t = ((x_min // x_tick) + (1 if x_min > 0 else 0)) * x_tick
    while t <= x_max:
        xp = x_pos(t)
        parts.append(f'<line x1="{xp:.2f}" y1="{mt+ph}" x2="{xp:.2f}" y2="{mt+ph+5}" stroke="#666"/>')
        parts.append(f'<text x="{xp:.2f}" y="{mt+ph+22}" font-size="11" '
                     f'text-anchor="middle" fill="#444">{t:,}</text>')
        t += x_tick
    
    for i in range(6):
        v_disp = i * v_max_disp / 5
        if log_y:
            v_label = int(10**v_disp) - 1 if v_disp > 0 else 0
        else:
            v_label = int(v_disp)
        yp = mt + ph - (v_disp / max(v_max_disp, 1)) * ph
        parts.append(f'<line x1="{ml-5}" y1="{yp:.2f}" x2="{ml}" y2="{yp:.2f}" stroke="#666"/>')
        parts.append(f'<text x="{ml-10}" y="{yp+4:.2f}" font-size="11" '
                     f'text-anchor="end" fill="#444">{v_label:,}</text>')
    
    parts.append(f'<text x="{ml+pw/2}" y="{H-18}" font-size="13" '
                 f'text-anchor="middle" fill="#222">{x_label}</text>')
    parts.append(f'<g transform="translate(28, {mt+ph/2}) rotate(-90)">'
                 f'<text font-size="13" text-anchor="middle" fill="#222">{y_label}'
                 f'{" (log)" if log_y else ""}</text></g>')
    
    parts.append('</svg>')
    output_svg.write_text('\n'.join(parts), encoding='utf-8')
    return output_svg


def format_summary(s: Dict) -> str:
    """Pretty-print the summary."""
    L = []
    L.append("=" * 72)
    L.append("  SCHÖLLER-SKARKE 5D HODGE-TUPLE DISTRIBUTION ANALYSIS")
    L.append("=" * 72)
    L.append(f"  Distinct (h11, h12, h13) tuples:   {s['n_distinct_tuples']:>14,}")
    L.append(f"  Self-mirror (h11 = h13):           {s['self_mirror_count']:>14,}")
    L.append(f"  Distinct h11 values:               {s['h11_distinct_values']:>14,}")
    L.append(f"  Distinct h12 values:               {s['h12_distinct_values']:>14,}")
    L.append(f"  Distinct h13 values:               {s['h13_distinct_values']:>14,}")
    L.append("")
    
    L.append("  ── Euler characteristic χ = 48 + 6(h11 − h12 + h13) ──")
    c = s['chi']
    L.append(f"    range:        [{c['min']:>6,}, {c['max']:>7,}]")
    L.append(f"    mean:         {c['mean']:.2f}")
    L.append(f"    distinct:     {c['n_distinct']:,}")
    L.append(f"    mode:         χ = {c['mode']:,} ({c['mode_count']:,} tuples)")
    L.append("")
    
    L.append("  ── h22 = 44 + 4h11 − 2h12 + 4h13 ──")
    h22 = s['h22']
    L.append(f"    range:        [{h22['min']:>6,}, {h22['max']:>7,}]")
    L.append(f"    mean:         {h22['mean']:.2f}")
    L.append(f"    distinct:     {h22['n_distinct']:,}")
    L.append(f"    mode:         h22 = {h22['mode']:,} ({h22['mode_count']:,} tuples)")
    L.append("")
    
    L.append("  ── h11 + h12 + h13 (Hodge sum) ──")
    sm = s['sum_h11_h12_h13']
    L.append(f"    range:        [{sm['min']:>6,}, {sm['max']:>7,}]")
    L.append(f"    mean:         {sm['mean']:.2f}")
    L.append(f"    mode:         sum = {sm['mode']:,} ({sm['mode_count']:,} tuples)")
    L.append("")
    
    L.append("  ── Extremes ──")
    ex = s['extremes']
    for key in ['max_h11', 'max_h12', 'max_h13', 'max_h22', 'max_chi', 'min_chi',
                'min_h11', 'min_h12', 'min_h13']:
        e = ex[key]
        if e['tuple']:
            L.append(f"    {key:<10}  {e['value']:>9,}  at (h11,h12,h13) = "
                     f"({e['tuple'][0]}, {e['tuple'][1]}, {e['tuple'][2]})")
    L.append("")
    
    return '\n'.join(L)


def main():
    parser = argparse.ArgumentParser(description='SS 5D Hodge-tuple distribution analysis')
    parser.add_argument('--cache', help='Path to a cached tuple file (default: largest in cache dir)')
    parser.add_argument('--out-dir', default='analysis/ss_5d', help='Output directory')
    parser.add_argument('--json', action='store_true', help='Print summary as JSON')
    parser.add_argument('--png', action='store_true', help='Also render PNGs')
    args = parser.parse_args()
    
    if args.cache:
        path = Path(args.cache)
    else:
        paths = sorted(SS_CACHE_DIR.glob('ss_hodge_tuples*.json.gz')) if SS_CACHE_DIR.exists() else []
        if not paths:
            print(f"  ✗ No cached tuple files found in {SS_CACHE_DIR}", file=sys.stderr)
            print(f"  Run `python -m pipeline.data_tools.ss_streamer scan` first.", file=sys.stderr)
            return 1
        path = max(paths, key=lambda p: p.stat().st_size)
    
    print(f"  Loading {path.name} ...")
    packed_or_set, meta = load_tuples(path)
    # load_tuples now returns numpy packed array; convert to set for analysis
    # (this is the memory-heavy step for very large caches)
    import numpy as np
    if isinstance(packed_or_set, np.ndarray):
        from pipeline.data_tools.ss_streamer import _unpack_uint64_array
        print(f"  Unpacking {len(packed_or_set):,} packed tuples to Python set ...")
        tuples = _unpack_uint64_array(packed_or_set)
    else:
        tuples = packed_or_set
    print(f"  Loaded {len(tuples):,} tuples from {meta.get('_rows_scanned', '?'):,} rows")
    
    summary = compute_summary(tuples)
    
    if args.json:
        print(json.dumps(summary, indent=2))
    else:
        print(format_summary(summary))
    
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    
    chi_counts = Counter()
    h22_counts = Counter()
    sum_counts = Counter()
    for t in tuples:
        h11, h12, h13 = t
        chi_counts[derive_chi(h11, h12, h13)] += 1
        h22_counts[derive_h22(h11, h12, h13)] += 1
        sum_counts[h11 + h12 + h13] += 1
    
    chi_svg = out / 'chi_histogram_4fold.svg'
    render_histogram(chi_counts, chi_svg,
                     title='Schöller-Skarke χ distribution (CY 4-folds)',
                     x_label='χ = 48 + 6(h^(1,1) − h^(1,2) + h^(1,3))',
                     y_label='number of distinct (h11, h12, h13) tuples',
                     color='#dc2626', log_y=True)
    print(f"  → {chi_svg}")
    
    h22_svg = out / 'h22_histogram.svg'
    render_histogram(h22_counts, h22_svg,
                     title='Schöller-Skarke h^(2,2) distribution (CY 4-folds)',
                     x_label='h^(2,2) = 44 + 4h^(1,1) − 2h^(1,2) + 4h^(1,3)',
                     y_label='number of distinct tuples',
                     color='#7c3aed', log_y=True)
    print(f"  → {h22_svg}")
    
    sum_svg = out / 'sum_histogram_4fold.svg'
    render_histogram(sum_counts, sum_svg,
                     title='Schöller-Skarke h^(1,1) + h^(1,2) + h^(1,3) distribution',
                     x_label='h^(1,1) + h^(1,2) + h^(1,3)',
                     y_label='number of distinct tuples',
                     color='#059669', log_y=True)
    print(f"  → {sum_svg}")
    
    summary_path = out / 'ss_analysis_summary.json'
    compact = {k: v for k, v in summary.items() if not k.startswith('_')}
    with open(summary_path, 'w') as f:
        json.dump(compact, f, indent=2)
    print(f"  → {summary_path}")
    
    if args.png:
        try:
            import cairosvg
            for svg_path in [chi_svg, h22_svg, sum_svg]:
                png_path = svg_path.with_suffix('.png')
                cairosvg.svg2png(url=str(svg_path), write_to=str(png_path), output_width=1600)
                print(f"  → {png_path}")
        except ImportError:
            print(f"  ⚠ PNG render skipped (cairosvg not available)")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
