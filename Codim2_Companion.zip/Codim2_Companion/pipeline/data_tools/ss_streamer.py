#!/usr/bin/env python3
"""
pipeline/data_tools/ss_streamer.py — Schöller-Skarke 5D reflexive-polytope
data streamer + mirror-closure checker.

The Schöller-Skarke 2018 classification (arXiv:1808.02422) enumerates
185,269,499,015 reflexive 5-polytopes giving CY 4-folds, with 532,600,483
distinct Hodge tuples. The data is hosted on Hugging Face as
'calabi-yau-data/ws-5d' (subset 'reflexive') in Parquet format, ~3 TB
on disk, streamable.

For each row the dataset stores h11, h12, h13. The fourth Hodge number
h22 is derived from the diamond:
    h22 = 44 + 4·h11 - 2·h12 + 4·h13.
The Euler characteristic:
    χ = 48 + 6·(h11 - h12 + h13).

Mirror symmetry for CY 4-folds: the mirror swap exchanges complex
structure (h^{3,1} = h13) with Kähler (h^{1,1} = h11), keeping h12 and
h22 fixed. Closure check: for every (h11, h12, h13) in the set,
(h13, h12, h11) must also be in the set.

Usage:
    # Quick smoke test (1000 rows)
    python -m pipeline.data_tools.ss_streamer smoke

    # First parquet file (~50M rows, ~3 min)
    python -m pipeline.data_tools.ss_streamer scan --limit 50_000_000

    # Phase B: 3% sample for >99.99% spectrum coverage (~3-8 hours)
    python -m pipeline.data_tools.ss_streamer scan --limit 5_500_000_000

    # Phase C: full scan (multi-day)
    python -m pipeline.data_tools.ss_streamer scan --full

    # Run closure check on cached pair set
    python -m pipeline.data_tools.ss_streamer mirror-check
"""

import argparse
import gzip
import json
import sys
import time
from pathlib import Path
from typing import Iterator, Optional, Tuple

HodgeTuple = Tuple[int, int, int]  # (h11, h12, h13)

# Cache location (relative to project root)
SS_CACHE_DIR = Path(__file__).parent.parent.parent / 'data' / 'cache' / 'ss_5d'

# Expected totals from arXiv:1808.02422
EXPECTED_REFLEXIVE_ROWS = 185_269_499_015
EXPECTED_DISTINCT_TUPLES = 532_600_483

# ─────────────────────────────────────────────────────────────────
# Packing scheme (v4 — 24/16/24 layout for uint64)
# ─────────────────────────────────────────────────────────────────
# Earlier v3 used 16/16/16 bits, which silently aliased Hodge numbers
# > 65535 (the actual catalog has h11 up to 303,148 and h13 up to ≥166,646).
# v4 uses 24 bits for h11 and h13 (max 16,777,215 each — well over the
# observed maxima) and 16 bits for h12 (max 65,535, vs observed max ~2,010).
H11_BITS = 24
H12_BITS = 16
H13_BITS = 24
H11_MASK = (1 << H11_BITS) - 1   # 0x00FFFFFF
H12_MASK = (1 << H12_BITS) - 1   # 0x0000FFFF
H13_MASK = (1 << H13_BITS) - 1   # 0x00FFFFFF
H12_SHIFT = H13_BITS              # 24
H11_SHIFT = H13_BITS + H12_BITS   # 40
# Mid-mask: keep h12 bits in place during mirror swap
H12_INPLACE_MASK = H12_MASK << H12_SHIFT  # 0xFFFF000000


# ─────────────────────────────────────────────────────────────────
# Streaming from Hugging Face
# ─────────────────────────────────────────────────────────────────

def stream_reflexive(limit: Optional[int] = None) -> Iterator[HodgeTuple]:
    """Yield (h11, h12, h13) tuples from the HF reflexive subset.
    
    If limit is None, streams the entire dataset (~185B rows).
    If limit is an int, stops after that many rows.
    
    NOTE: This streaming path is SLOW (~600 rows/sec even with auth).
    For real work, use scan_files() which downloads parquet files directly
    and processes them with pyarrow at 1000x+ throughput.
    """
    try:
        from datasets import load_dataset
    except ImportError:
        raise RuntimeError(
            "The 'datasets' library is required. Install with:\n"
            "    pip install datasets pyarrow"
        )
    
    ds = load_dataset(
        "calabi-yau-data/ws-5d",
        name="reflexive",
        split="full",
        streaming=True,
    )
    
    if limit is not None:
        ds = ds.take(limit)
    
    for row in ds:
        yield (row['h11'], row['h12'], row['h13'])


# ─────────────────────────────────────────────────────────────────
# Direct parquet download (fast path)
# ─────────────────────────────────────────────────────────────────

# Filename pattern in the HF repo. Verified from the dataset's actual files.
REFLEXIVE_FILE_PATTERN = "reflexive/ws-5d-reflexive-{idx:04d}.parquet"
N_REFLEXIVE_FILES = 4000


def hf_cache_dir() -> Path:
    """Where downloaded parquet files live. Project-relative so cleanups
    don't accidentally hit the user's HF home directory."""
    d = SS_CACHE_DIR / 'parquet'
    d.mkdir(parents=True, exist_ok=True)
    return d


def process_one_parquet_file(file_idx: int, verbose: bool = False,
                              delete_after: bool = False) -> dict:
    """Download and parse a single parquet file. Returns a dict with:
      - file_idx, n_rows
      - tuples_packed: numpy uint64 array of unique packed (h11, h12, h13)
      - vertex_count_counts, facet_count_counts,
        point_count_counts, dual_point_count_counts: per-file Counters
    
    Memory-efficient throughout — uses numpy and returns the packed array
    directly, so the IPC pickle is ~80 MB instead of ~1.5 GB (which is
    the size a Python set of 10M tuples would require).
    """
    from huggingface_hub import hf_hub_download
    import pyarrow.parquet as pq
    import numpy as np
    
    filename = REFLEXIVE_FILE_PATTERN.format(idx=file_idx)
    
    local_path = hf_hub_download(
        repo_id="calabi-yau-data/ws-5d",
        filename=filename,
        repo_type="dataset",
        cache_dir=str(hf_cache_dir()),
    )
    
    # Pass 1: Hodge columns — find unique rows + pack to uint64 in one go
    table = pq.read_table(local_path, columns=['h11', 'h12', 'h13'])
    h11 = table.column('h11').to_numpy()
    h12 = table.column('h12').to_numpy()
    h13 = table.column('h13').to_numpy()
    n_rows = len(h11)
    del table
    
    # Pack directly to uint64 (8 bytes/row), then dedup via np.unique on 1D array
    # This is faster AND uses less memory than np.unique(axis=0).
    # v4 layout: h11<<40 | h12<<24 | h13 (24/16/24 bits — catalog has h11≤303148, h13≥166646)
    packed = (h11.astype(np.uint64) << H11_SHIFT) | \
             (h12.astype(np.uint64) << H12_SHIFT) | \
             h13.astype(np.uint64)
    del h11, h12, h13
    
    unique_packed = np.unique(packed)  # ~10M × 8 bytes = 80 MB
    del packed
    
    # Pass 2: Structural columns — counters via np.unique with counts
    table = pq.read_table(local_path, columns=[
        'vertex_count', 'facet_count', 'point_count', 'dual_point_count'
    ])
    
    def np_counter(col_name):
        arr = table.column(col_name).to_numpy()
        u, c = np.unique(arr, return_counts=True)
        return dict(zip(u.tolist(), c.tolist()))
    
    vertex_counter = np_counter('vertex_count')
    facet_counter = np_counter('facet_count')
    point_counter = np_counter('point_count')
    dual_point_counter = np_counter('dual_point_count')
    
    del table
    
    if delete_after:
        try:
            real_path = Path(local_path).resolve()
            if Path(local_path).is_symlink():
                Path(local_path).unlink()
            if real_path.exists():
                real_path.unlink()
        except Exception as e:
            if verbose:
                print(f"    ⚠ Could not delete {local_path}: {e}")
    
    if verbose:
        print(f"    file {file_idx:04d}: {n_rows:,} rows → {len(unique_packed):,} distinct tuples"
              f"{' (parquet deleted)' if delete_after else ''}")
    
    return {
        'file_idx': file_idx,
        'n_rows': n_rows,
        'unique_packed': unique_packed,  # numpy uint64 array — small to pickle
        'vertex_count_counts': vertex_counter,
        'facet_count_counts': facet_counter,
        'point_count_counts': point_counter,
        'dual_point_count_counts': dual_point_counter,
    }


def _worker_wrapper(args):
    """multiprocessing.Pool needs a single-arg function."""
    file_idx, delete_after = args
    return process_one_parquet_file(file_idx, verbose=False, delete_after=delete_after)


def _pack_tuples_to_uint64(tuple_set):
    """Pack a Python set of (h11, h12, h13) into a numpy uint64 array (v4 layout).
    
    Layout: h11 in bits 40-63 (24 bits), h12 in bits 24-39 (16 bits),
    h13 in bits 0-23 (24 bits). Max values: h11/h13 ≤ 16,777,215; h12 ≤ 65,535.
    Catalog observed maxima: h11 = 303,148; h12 = ~2,010; h13 ≥ 166,646."""
    import numpy as np
    if not tuple_set:
        return np.zeros(0, dtype=np.uint64)
    arr = np.fromiter(
        ((h11 << H11_SHIFT) | (h12 << H12_SHIFT) | h13 for (h11, h12, h13) in tuple_set),
        dtype=np.uint64, count=len(tuple_set)
    )
    return arr


def _unpack_uint64_array(packed_arr):
    """Unpack a uint64 numpy array (v4 layout) to a set of (h11, h12, h13) tuples."""
    h13 = (packed_arr & H13_MASK).astype(int)
    h12 = ((packed_arr >> H12_SHIFT) & H12_MASK).astype(int)
    h11 = (packed_arr >> H11_SHIFT).astype(int)
    return {(int(h11[i]), int(h12[i]), int(h13[i])) for i in range(len(packed_arr))}


def _is_sorted(arr):
    """Check if a numpy 1D array is sorted ascending."""
    import numpy as np
    if len(arr) < 2:
        return True
    return bool(np.all(arr[:-1] <= arr[1:]))


def scan_files(file_indices: list, workers: int = 1, verbose: bool = True,
                delete_after: bool = False,
                dedup_batch_size: int = 4,
                checkpoint_path: Optional[Path] = None,
                full_checkpoint_path: Optional[Path] = None,
                full_checkpoint_every: int = 4,
                resume: bool = False) -> dict:
    """Download and parse a list of parquet files (in parallel if workers > 1).
    
    Memory-safe design:
      - Workers recycled after each file (maxtasksperchild=1)
      - Master set stored on disk between dedups (not in RAM)
      - Default dedup_batch_size=4 keeps pending list bounded at ~320 MB
      - Periodic full checkpoints (with counters + files_processed) every
        full_checkpoint_every dedups, enabling clean resume after crash
    
    Resume mode: if full_checkpoint_path exists AND resume=True, loads the
    previous state and skips files already in _files_processed.
    
    Returns a dict with combined results across all files.
    """
    import numpy as np
    import gzip, pickle, gc
    from collections import Counter
    
    if not file_indices:
        return {
            'tuples_packed': np.zeros(0, dtype=np.uint64),
            'n_distinct': 0, 'n_rows': 0, 'n_files': 0,
            'vertex_count_counts': Counter(),
            'facet_count_counts': Counter(),
            'point_count_counts': Counter(),
            'dual_point_count_counts': Counter(),
        }
    
    if checkpoint_path is None:
        checkpoint_path = SS_CACHE_DIR / f'_scan_master_temp_{file_indices[0]:04d}_{file_indices[-1]:04d}.npy.gz'
    if full_checkpoint_path is None:
        full_checkpoint_path = SS_CACHE_DIR / f'ss_checkpoint_{file_indices[0]:04d}_{file_indices[-1]:04d}.pkl.gz'
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    
    combined_vc, combined_fc = Counter(), Counter()
    combined_pc, combined_dpc = Counter(), Counter()
    total_rows = 0
    files_processed_so_far: list = []
    dedup_count = 0
    
    # ─── RESUME MODE ─────────────────────────────────────────────
    if resume and full_checkpoint_path.exists():
        if verbose:
            print(f"  ↺ Resume: loading checkpoint {full_checkpoint_path.name}")
        loaded_packed, meta = load_tuples(full_checkpoint_path)
        # Save loaded packed as the temp master so dedup picks up from here
        with gzip.open(checkpoint_path, 'wb', compresslevel=3) as f:
            np.save(f, loaded_packed)
        # Restore counters and counts
        combined_vc = Counter(meta.get('vertex_count_distribution', {}))
        combined_fc = Counter(meta.get('facet_count_distribution', {}))
        combined_pc = Counter(meta.get('point_count_distribution', {}))
        combined_dpc = Counter(meta.get('dual_point_count_distribution', {}))
        total_rows = meta.get('_rows_scanned', 0)
        files_processed_so_far = list(meta.get('_files_processed', []))
        already_done_set = set(files_processed_so_far)
        original_count = len(file_indices)
        file_indices = [i for i in file_indices if i not in already_done_set]
        if verbose:
            print(f"  ↺ {len(loaded_packed):,} master tuples loaded; "
                  f"{len(already_done_set)} files already done; "
                  f"{len(file_indices)} remaining (of {original_count})")
        del loaded_packed
        gc.collect()
    
    if not file_indices:
        # Everything already done; just return what's there
        with gzip.open(checkpoint_path, 'rb') as f:
            final = np.load(f, allow_pickle=False)
        return {
            'tuples_packed': final, 'n_distinct': len(final),
            'n_rows': total_rows, 'n_files': len(files_processed_so_far),
            'vertex_count_counts': combined_vc, 'facet_count_counts': combined_fc,
            'point_count_counts': combined_pc, 'dual_point_count_counts': combined_dpc,
            '_temp_checkpoint': checkpoint_path,
        }
    
    pending_packed = []
    
    def _load_master():
        if checkpoint_path.exists():
            with gzip.open(checkpoint_path, 'rb') as f:
                return np.load(f, allow_pickle=False)
        return np.zeros(0, dtype=np.uint64)
    
    def _save_master(master):
        with gzip.open(checkpoint_path, 'wb', compresslevel=3) as f:
            np.save(f, master)
    
    def _save_full_checkpoint():
        """Save complete state to a pkl.gz checkpoint for crash recovery."""
        master = _load_master()
        save_tuples(
            master, full_checkpoint_path,
            n_rows_scanned=total_rows,
            vertex_count_counts=combined_vc,
            facet_count_counts=combined_fc,
            point_count_counts=combined_pc,
            dual_point_count_counts=combined_dpc,
            files_processed=files_processed_so_far,
        )
        size_mb = full_checkpoint_path.stat().st_size / 1024 / 1024
        del master
        gc.collect()
        return size_mb
    
    def _periodic_dedup():
        """Merge pending arrays into master via sorted-array set operations.
        
        Avoids np.unique's hash-based path which can build a 5-10 GB hash
        table for 250M+ uint64 inputs. Instead uses searchsorted (O(n log m)
        time, O(n) memory) to find truly new values, then a single mostly-
        sorted sort of two runs. Peak memory ~2× master size instead of ~5×.
        """
        nonlocal dedup_count
        if not pending_packed:
            return
        
        # Step 1: Combine pending arrays + dedup among themselves
        if len(pending_packed) == 1:
            pending = pending_packed[0]
            if not _is_sorted(pending):
                pending = np.sort(pending)
        else:
            pending_concat = np.concatenate(pending_packed)
            pending_concat.sort(kind='stable')  # mostly two+ sorted runs → fast
            # Dedup in place using forward-diff mask
            if len(pending_concat) > 0:
                pmask = np.empty(len(pending_concat), dtype=bool)
                pmask[0] = True
                np.not_equal(pending_concat[1:], pending_concat[:-1], out=pmask[1:])
                pending = pending_concat[pmask]
                del pmask
            else:
                pending = pending_concat
            del pending_concat
        
        pending_packed.clear()
        gc.collect()
        
        # Step 2: Load master and find which pending values are truly new
        master = _load_master()
        
        if len(master) == 0:
            # First dedup — pending IS the new master
            _save_master(pending)
            dedup_count += 1
            result_size = len(pending)
            del pending, master
            gc.collect()
            if dedup_count % full_checkpoint_every == 0:
                ckpt_mb = _save_full_checkpoint()
                if verbose:
                    print(f"    [checkpoint] saved → {full_checkpoint_path.name} ({ckpt_mb:.1f} MB)")
            return result_size
        
        # searchsorted: find insertion points; if master[idx]==pending[i], it's a duplicate
        if len(pending) > 0:
            idx = np.searchsorted(master, pending)
            in_range = idx < len(master)
            is_dup = np.zeros(len(pending), dtype=bool)
            is_dup[in_range] = master[idx[in_range]] == pending[in_range]
            new_values = pending[~is_dup]
            del idx, in_range, is_dup, pending
        else:
            new_values = np.zeros(0, dtype=np.uint64)
            del pending
        
        gc.collect()
        
        # Step 3: Merge new_values (sorted) into master (sorted)
        if len(new_values) == 0:
            # Nothing new — keep master unchanged
            result_size = len(master)
            del master, new_values
            dedup_count += 1
        else:
            # Allocate output of exact size
            n_master, n_new = len(master), len(new_values)
            new_master = np.empty(n_master + n_new, dtype=np.uint64)
            np.concatenate([master, new_values], out=new_master)
            del master, new_values
            new_master.sort(kind='stable')  # two sorted runs → TimSort fast
            _save_master(new_master)
            result_size = len(new_master)
            del new_master
            dedup_count += 1
        
        gc.collect()
        
        # Periodic full checkpoint
        if dedup_count % full_checkpoint_every == 0:
            ckpt_mb = _save_full_checkpoint()
            if verbose:
                print(f"    [checkpoint] saved → {full_checkpoint_path.name} ({ckpt_mb:.1f} MB)")
        
        return result_size
    
    def _merge(result: dict):
        nonlocal total_rows
        if len(result['unique_packed']) > 0:
            pending_packed.append(result['unique_packed'])
        for k, v in result['vertex_count_counts'].items(): combined_vc[k] += v
        for k, v in result['facet_count_counts'].items(): combined_fc[k] += v
        for k, v in result['point_count_counts'].items(): combined_pc[k] += v
        for k, v in result['dual_point_count_counts'].items(): combined_dpc[k] += v
        total_rows += result['n_rows']
        files_processed_so_far.append(result['file_idx'])
    
    if workers == 1:
        for idx in file_indices:
            try:
                result = process_one_parquet_file(idx, verbose=verbose, delete_after=delete_after)
                _merge(result)
                del result
                if len(pending_packed) >= dedup_batch_size:
                    result_size = _periodic_dedup()
                    if verbose:
                        print(f"    [dedup #{dedup_count}] master set: {result_size:,} distinct tuples")
            except (MemoryError, KeyboardInterrupt) as e:
                print(f"\n  ⚠ Interrupted on file {idx}: {type(e).__name__}")
                print(f"  Saving emergency checkpoint ...")
                _periodic_dedup()
                _save_full_checkpoint()
                raise
    else:
        # KEY ARCHITECTURE: process in mini-batches of size dedup_batch_size,
        # creating + tearing down a fresh Pool per batch. This guarantees
        # workers are NOT running concurrently with the dedup operation,
        # which prevents peak memory spike of (4 workers × 2 GB) + (master
        # load + np.unique working ~5-8 GB) all at once.
        #
        # Sequence per batch:
        #   1. Spin up Pool with `workers` workers
        #   2. pool.map distributes batch's files; workers process in parallel
        #   3. Pool exits, ALL worker processes terminate, all worker memory freed
        #   4. Main process now alone — dedup runs without competing memory pressure
        from multiprocessing import Pool
        
        n_files = len(file_indices)
        files_done_total = 0
        
        for batch_start in range(0, n_files, dedup_batch_size):
            batch = file_indices[batch_start:batch_start + dedup_batch_size]
            worker_args = [(idx, delete_after) for idx in batch]
            
            try:
                # Phase 1: workers active, main waits
                with Pool(processes=workers, maxtasksperchild=1) as pool:
                    batch_results = pool.map(_worker_wrapper, worker_args)
                # Pool exited — all workers killed and memory reclaimed by OS
                
                # Phase 2: merge results into main process (workers no longer running)
                for result in batch_results:
                    _merge(result)
                    files_done_total += 1
                    if verbose:
                        pending_size = sum(len(p) for p in pending_packed)
                        print(f"  [{files_done_total}/{n_files}] file {result['file_idx']:04d}: "
                              f"+{result['n_rows']:,} rows, "
                              f"pending = {pending_size:,} tuples")
                del batch_results
                gc.collect()
                
                # Phase 3: dedup with no workers competing for RAM
                result_size = _periodic_dedup()
                if verbose and result_size is not None:
                    print(f"    [dedup #{dedup_count}] master set: {result_size:,} distinct tuples (on disk)")
                
            except (MemoryError, KeyboardInterrupt) as e:
                print(f"\n  ⚠ Interrupted after {files_done_total} files: {type(e).__name__}")
                print(f"  Flushing pending + saving emergency checkpoint ...")
                _periodic_dedup()
                _save_full_checkpoint()
                print(f"  ✓ Checkpoint saved to: {full_checkpoint_path}")
                print(f"  ✓ Resume next run with: --resume")
                raise
    
    # Final dedup + checkpoint
    _periodic_dedup()
    _save_full_checkpoint()
    
    final_master = _load_master()
    
    return {
        'tuples_packed': final_master,
        'n_distinct': len(final_master),
        'n_rows': total_rows,
        'n_files': len(files_processed_so_far),
        'vertex_count_counts': combined_vc,
        'facet_count_counts': combined_fc,
        'point_count_counts': combined_pc,
        'dual_point_count_counts': combined_dpc,
        '_temp_checkpoint': checkpoint_path,
        '_full_checkpoint': full_checkpoint_path,
    }


# ─────────────────────────────────────────────────────────────────
# Cache merging (combine multiple cache files into one master set)
# ─────────────────────────────────────────────────────────────────
# The merge logic now lives inline in cmd_merge to handle the v2 schema
# (which includes per-file distribution Counters).


# ─────────────────────────────────────────────────────────────────
# Cached pair-set persistence
# ─────────────────────────────────────────────────────────────────

def cache_path(suffix: str = '') -> Path:
    """Default cache path for the SS 5D Hodge tuple set."""
    name = f'ss_hodge_tuples{suffix}.json.gz'
    return SS_CACHE_DIR / name


def save_tuples(tuples_or_packed, path: Path, *, n_rows_scanned: int,
                vertex_count_counts: Optional[dict] = None,
                facet_count_counts: Optional[dict] = None,
                point_count_counts: Optional[dict] = None,
                dual_point_count_counts: Optional[dict] = None,
                files_processed: Optional[list] = None):
    """Save a Hodge-tuple set + per-file aggregate distributions.

    Accepts either:
      - A Python set/iterable of (h11, h12, h13) tuples
      - A numpy uint64 packed array (preferred for large sets)

    Format: gzip-pickle (v3 schema). Handles numpy arrays + dicts natively.
    The .pkl.gz extension is used; legacy .json.gz files remain readable via
    load_tuples for backward compat with v1/v2 caches.
    """
    import numpy as np
    import pickle
    
    path = Path(path)
    # Switch extension from .json.gz to .pkl.gz for the new format
    if path.name.endswith('.json.gz'):
        path = path.with_name(path.name[:-len('.json.gz')] + '.pkl.gz')
    elif not path.name.endswith('.pkl.gz'):
        path = path.with_suffix('.pkl.gz')
    
    if isinstance(tuples_or_packed, np.ndarray):
        packed = tuples_or_packed
    else:
        packed = _pack_tuples_to_uint64(tuples_or_packed)
    
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        '_format': 'ss_hodge_tuples_v4_pickle',
        '_packing': '24/16/24 (h11<<40 | h12<<24 | h13)',
        '_source': 'calabi-yau-data/ws-5d (reflexive)',
        '_rows_scanned': n_rows_scanned,
        '_expected_total_rows': EXPECTED_REFLEXIVE_ROWS,
        '_files_processed': files_processed or [],
        'n_distinct_tuples': len(packed),
        'tuples_packed': packed,  # numpy uint64 array
        'vertex_count_distribution': dict(vertex_count_counts) if vertex_count_counts else {},
        'facet_count_distribution': dict(facet_count_counts) if facet_count_counts else {},
        'point_count_distribution': dict(point_count_counts) if point_count_counts else {},
        'dual_point_count_distribution': dict(dual_point_count_counts) if dual_point_count_counts else {},
    }
    
    with gzip.open(path, 'wb') as f:
        pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)
    
    return path  # actual path written (may differ from requested if extension was swapped)


def load_tuples(path: Path) -> Tuple:
    """Load a cached tuple set + metadata.

    Returns (tuples_packed, metadata_dict). tuples_packed is a numpy uint64
    array. Use _unpack_uint64_array(tuples_packed) to get a Python set if
    needed (memory-heavy for large caches).
    
    Reads both new v3 pickle format and legacy v1/v2 JSON formats.
    """
    import numpy as np
    import pickle
    path = Path(path)
    
    if path.name.endswith('.pkl.gz') or path.suffix == '.pkl':
        # Pickle format — v3 (16/16/16, broken for h11/h13 > 65535) or v4 (24/16/24, correct)
        with gzip.open(path, 'rb') as f:
            payload = pickle.load(f)
        fmt = payload.get('_format', '')
        if 'v3' in fmt:
            raise RuntimeError(
                f"Cache file {path.name} is v3 (16-bit-per-Hodge-number packing). "
                f"This format silently corrupted tuples with h11 or h13 > 65535 "
                f"(catalog has h11 up to 303,148 and h13 up to ≥166,646). "
                f"Delete v3 caches and re-scan with `python -m pipeline.data_tools.ss_streamer scan-files`."
            )
        packed = payload['tuples_packed']
        meta = {k: v for k, v in payload.items() if k != 'tuples_packed'}
        return packed, meta
    
    elif path.name.endswith('.json.gz') or path.suffix == '.json':
        # Legacy v1/v2 JSON format
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            payload = json.load(f)
        # Convert tuple list to packed numpy
        tuple_list = payload.get('tuples', [])
        if tuple_list:
            packed = np.fromiter(
                ((int(t[0]) << H11_SHIFT) | (int(t[1]) << H12_SHIFT) | int(t[2]) for t in tuple_list),
                dtype=np.uint64, count=len(tuple_list)
            )
        else:
            packed = np.zeros(0, dtype=np.uint64)
        meta = {k: v for k, v in payload.items() if k != 'tuples'}
        # Convert stringified counter keys back to ints
        for k in ('vertex_count_distribution', 'facet_count_distribution',
                   'point_count_distribution', 'dual_point_count_distribution'):
            if k in meta:
                meta[k] = {int(kk): vv for kk, vv in meta[k].items()}
        return packed, meta
    
    else:
        raise ValueError(f"Unrecognized cache format: {path.suffix}")


def closure_partition(packed_or_set, chunk_size: int = 50_000_000):
    """Partition a Hodge-tuple set under the (h11, h13) mirror swap.

    Accepts either a numpy uint64 packed array (preferred) OR a Python set
    of (h11, h12, h13) tuples.
    
    For large arrays (250M+ tuples), processes in chunks of `chunk_size`
    to bound peak memory at ~packed_arr_size + 3 GB instead of ~3× that.
    """
    import numpy as np
    import gc
    
    if not isinstance(packed_or_set, np.ndarray):
        packed_arr = _pack_tuples_to_uint64(packed_or_set)
        packed_arr = np.sort(packed_arr)  # set->array path: ensure sorted for searchsorted
    else:
        packed_arr = packed_or_set
        # The pipeline produces sorted arrays (workers return np.unique; master is
        # built via sorted-union merges). But validate to avoid silent corruption
        # if a caller forgets — checking sortedness is O(n) and dwarfed by the swap.
        if not _is_sorted(packed_arr):
            packed_arr = np.sort(packed_arr)
    
    n = len(packed_arr)
    if n == 0:
        return {
            'n_total': 0, 'n_self_mirror': 0, 'n_matched_pairs': 0,
            'n_unmatched': 0, 'coverage_pct': 0.0,
            'self_mirror_examples': [], 'unmatched_examples': [],
        }
    
    n_self_mirror = 0
    n_matched_total = 0     # each non-self-mirror match counted twice (once per side)
    n_unmatched = 0
    self_mirror_examples = []
    unmatched_examples = []
    
    n_chunks = (n + chunk_size - 1) // chunk_size
    
    for ci, start in enumerate(range(0, n, chunk_size)):
        end = min(start + chunk_size, n)
        chunk = packed_arr[start:end]
        
        # Mirror swap via bitwise ops (avoids creating full-size h11/h12/h13 arrays)
        # v4 packed = (h11 << 40) | (h12 << 24) | h13
        # mirror   = (h13 << 40) | (h12 << 24) | h11
        h11_part = chunk >> H11_SHIFT                # top 24 bits = h11
        h13_part = chunk & H13_MASK                  # bottom 24 bits = h13
        mid = chunk & np.uint64(H12_INPLACE_MASK)    # middle 16 bits = h12 (in place)
        mirrored = (h13_part << H11_SHIFT) | mid | h11_part
        del mid
        
        # Self-mirror: original packed value == mirrored (i.e., h11 == h13)
        is_self_mirror = mirrored == chunk
        n_self_chunk = int(is_self_mirror.sum())
        n_self_mirror += n_self_chunk
        
        # Look up mirrored values in the (sorted) full packed_arr
        idx = np.searchsorted(packed_arr, mirrored)
        in_range = idx < n
        # Safe-clamped index (any out-of-range entries get index 0 — will fail equality check)
        idx_safe = np.where(in_range, idx, 0)
        matches = (packed_arr[idx_safe] == mirrored) & in_range
        del idx, idx_safe, in_range
        
        # Tally non-self-mirror matched + unmatched for this chunk
        non_self_matched = matches & ~is_self_mirror
        n_matched_total += int(non_self_matched.sum())
        non_self_unmatched = (~matches) & (~is_self_mirror)
        n_unmatched += int(non_self_unmatched.sum())
        
        # Collect small example samples (only while we still need them)
        if len(self_mirror_examples) < 10 and n_self_chunk > 0:
            sm_idx = np.where(is_self_mirror)[0][:10 - len(self_mirror_examples)]
            for i in sm_idx:
                v = int(chunk[i])
                self_mirror_examples.append(
                    (v >> H11_SHIFT, (v >> H12_SHIFT) & H12_MASK, v & H13_MASK))
        if len(unmatched_examples) < 20:
            need = 20 - len(unmatched_examples)
            um_idx = np.where(non_self_unmatched)[0][:need]
            for i in um_idx:
                v = int(chunk[i])
                unmatched_examples.append(
                    (v >> H11_SHIFT, (v >> H12_SHIFT) & H12_MASK, v & H13_MASK))
        
        del chunk, h11_part, h13_part, mirrored, is_self_mirror, matches
        del non_self_matched, non_self_unmatched
        gc.collect()
    
    n_matched_pairs = n_matched_total // 2  # each pair counted twice across chunks
    coverage = (n_self_mirror + 2 * n_matched_pairs) / n * 100 if n > 0 else 0.0
    
    return {
        'n_total': n,
        'n_self_mirror': n_self_mirror,
        'n_matched_pairs': n_matched_pairs,
        'n_unmatched': n_unmatched,
        'self_mirror_examples': self_mirror_examples,
        'unmatched_examples': unmatched_examples,
        'coverage_pct': coverage,
    }


# ─────────────────────────────────────────────────────────────────
# Closure check (CY 4-fold mirror swap on 3-tuples)
# ─────────────────────────────────────────────────────────────────
# (closure_partition is defined above near the cache loaders, using numpy
# for memory-efficient operation on packed uint64 arrays.)


# ─────────────────────────────────────────────────────────────────
# CLI subcommands
# ─────────────────────────────────────────────────────────────────

def cmd_smoke(args):
    """Quick connectivity test: stream rows, print first 5, measure warm throughput."""
    n_total = args.n
    print(f"Smoke test: streaming {n_total:,} reflexive rows from HF ...")
    print(f"  (First several seconds include cold-start overhead.)")
    
    t0 = time.time()
    tuples = set()
    sample_rows = []
    
    # Track warm throughput by measuring rate after first 1000 rows
    warm_start_time = None
    warm_start_rows = 1000
    
    for i, t in enumerate(stream_reflexive(limit=n_total)):
        if i < 5:
            sample_rows.append(t)
        if i == warm_start_rows:
            warm_start_time = time.time()
        tuples.add(t)
    
    elapsed = time.time() - t0
    
    print(f"\n  Total: {n_total:,} rows in {elapsed:.2f}s "
          f"({n_total/elapsed:.0f} rows/sec average)")
    
    if warm_start_time is not None and n_total > warm_start_rows:
        warm_elapsed = time.time() - warm_start_time
        warm_rows = n_total - warm_start_rows
        warm_rate = warm_rows / warm_elapsed if warm_elapsed > 0 else 0
        print(f"  Warm rate (after first {warm_start_rows:,} rows): "
              f"{warm_rate:,.0f} rows/sec")
        # Project full scan time
        full_eta_hours = EXPECTED_REFLEXIVE_ROWS / warm_rate / 3600 if warm_rate > 0 else 0
        print(f"  Projected full-scan wall time at warm rate: "
              f"{full_eta_hours:.1f} hours ({full_eta_hours/24:.1f} days)")
    
    print(f"  Distinct (h11, h12, h13) tuples: {len(tuples):,}")
    print(f"\n  First 5 Hodge tuples:")
    for t in sample_rows:
        h11, h12, h13 = t
        h22 = 44 + 4*h11 - 2*h12 + 4*h13
        chi = 48 + 6*(h11 - h12 + h13)
        print(f"    (h11={h11:>4}, h12={h12:>4}, h13={h13:>4})"
              f" → h22={h22:>5}, χ={chi:>6}")
    return 0


def cmd_scan(args):
    """Stream the reflexive subset, accumulate Hodge tuples, save to cache."""
    if args.full:
        limit = None
        print(f"FULL SCAN of {EXPECTED_REFLEXIVE_ROWS:,} reflexive rows.")
        print("Estimated wall time: ~100 hours on consumer hardware.")
    elif args.limit:
        limit = args.limit
        print(f"Sampling {limit:,} rows from the reflexive subset.")
    else:
        limit = 50_000_000
        print(f"Default scan: {limit:,} rows (first Parquet file).")
    
    out_path = cache_path(f'_n{limit if limit else "full"}')
    print(f"Output: {out_path}")
    print(f"Press Ctrl-C at any time to checkpoint progress.\n")
    
    tuples = set()
    t0 = time.time()
    last_progress = t0
    rows_done = 0
    
    try:
        for t in stream_reflexive(limit=limit):
            tuples.add(t)
            rows_done += 1
            
            # Progress every 5 seconds
            now = time.time()
            if now - last_progress >= 5:
                rate = rows_done / (now - t0)
                eta_str = ""
                if limit:
                    eta_sec = (limit - rows_done) / rate if rate > 0 else 0
                    eta_str = f", ETA {eta_sec/60:.1f}m"
                print(f"  {rows_done:>14,} rows  ·  {len(tuples):>11,} distinct "
                      f"·  {rate:>8,.0f} rows/sec{eta_str}")
                last_progress = now
    except KeyboardInterrupt:
        print(f"\n  ⚠ Interrupted at {rows_done:,} rows. Saving progress ...")
    
    elapsed = time.time() - t0
    print(f"\n  Scan complete: {rows_done:,} rows in {elapsed/60:.1f}m "
          f"({rows_done/elapsed:.0f} rows/sec)")
    print(f"  Distinct (h11, h12, h13) tuples: {len(tuples):,}")
    
    print(f"\n  Saving to {out_path} ...")
    actual_path = save_tuples(tuples, out_path, n_rows_scanned=rows_done)
    size_mb = actual_path.stat().st_size / 1024 / 1024
    print(f"  Saved ({size_mb:.1f} MB compressed) → {actual_path.name}")
    
    # Quick closure check on whatever we have
    print(f"\n  Quick closure check on current set ...")
    p = closure_partition(tuples)
    print(f"    Self-mirror tuples (h11 = h13):  {p['n_self_mirror']:,}")
    print(f"    Matched mirror pairs:             {p['n_matched_pairs']:,}")
    print(f"    Unmatched:                        {p['n_unmatched']:,}")
    print(f"    Coverage:                         {p['coverage_pct']:.2f}%")
    if rows_done < EXPECTED_REFLEXIVE_ROWS:
        print(f"\n  Note: A partial scan typically shows unmatched tuples because")
        print(f"  the mirror partner may not have been streamed yet. Full closure")
        print(f"  is only meaningful for complete scans or balanced random samples.")
    
    return 0


def cmd_recover_temp(args):
    """Recover a crashed scan's temp master file as a checkpoint cache file.
    
    Use this to rescue the master tuple set from a scan that crashed before
    saving its full checkpoint. The temp file contains only the deduplicated
    Hodge tuples — counters are lost and must be regenerated by re-running
    affected files with --resume.
    """
    import numpy as np, gzip
    
    if args.temp:
        temp_path = Path(args.temp)
    else:
        # Find newest temp master file in cache dir
        temps = sorted(SS_CACHE_DIR.glob('_scan_master_temp_*.npy.gz')) if SS_CACHE_DIR.exists() else []
        if not temps:
            print(f"  ✗ No temp master files found in {SS_CACHE_DIR}", file=sys.stderr)
            return 1
        temp_path = max(temps, key=lambda p: p.stat().st_mtime)
    
    if not temp_path.exists():
        print(f"  ✗ Temp file not found: {temp_path}", file=sys.stderr)
        return 1
    
    print(f"  Loading temp master: {temp_path.name} ({temp_path.stat().st_size/1024/1024:.1f} MB)")
    with gzip.open(temp_path, 'rb') as f:
        master = np.load(f, allow_pickle=False)
    print(f"  Recovered {len(master):,} distinct tuples")
    
    # Determine output path
    if args.output:
        out_path = Path(args.output)
    else:
        # Infer from temp filename like _scan_master_temp_0000_0499.npy.gz
        stem = temp_path.name.replace('_scan_master_temp_', '').replace('.npy.gz', '')
        out_path = SS_CACHE_DIR / f'ss_checkpoint_{stem}.pkl.gz'
    
    # Save as a v3 checkpoint (with empty counters — they were lost in the crash)
    actual_path = save_tuples(
        master, out_path,
        n_rows_scanned=0,  # unknown — counters will say zero
        vertex_count_counts={}, facet_count_counts={},
        point_count_counts={}, dual_point_count_counts={},
        files_processed=[],  # unknown which files contributed
    )
    out_mb = actual_path.stat().st_size / 1024 / 1024
    
    print(f"  ✓ Saved checkpoint: {actual_path.name} ({out_mb:.1f} MB)")
    print(f"  Coverage: {len(master)/EXPECTED_DISTINCT_TUPLES*100:.2f}% of {EXPECTED_DISTINCT_TUPLES:,}")
    print(f"\n  NOTE: counters and files_processed are empty in the recovered checkpoint.")
    print(f"  The Hodge tuple set is intact. To regenerate counters, run the chunk")
    print(f"  again (the tuple union will dedupe against existing tuples).")
    
    return 0


def cmd_scan_files(args):
    """Direct-parquet scan: download and parse specific reflexive files."""
    if args.all:
        file_indices = list(range(N_REFLEXIVE_FILES))
    elif args.range:
        lo, hi = args.range
        file_indices = list(range(lo, hi))
    elif args.files:
        file_indices = args.files
    else:
        file_indices = [0]
    
    file_indices = [i for i in file_indices if 0 <= i < N_REFLEXIVE_FILES]
    if not file_indices:
        print("  ✗ No valid file indices specified.", file=sys.stderr)
        return 1
    
    print(f"  Processing {len(file_indices)} parquet file(s) with {args.workers} worker(s)")
    print(f"  Files {file_indices[0]:04d}..{file_indices[-1]:04d}"
          f" (out of {N_REFLEXIVE_FILES} total)")
    print(f"  Estimated row count: {len(file_indices) * 46_000_000:,} (~46M rows/file)")
    if args.delete_after_parse:
        print(f"  ⚙ Auto-delete: parquet files will be removed after parsing")
    print(f"  ⚙ Extracting: Hodge tuples + vertex/facet/point/dual_point counts")
    print(f"  ⚙ Memory: numpy-packed accumulator (uint64); dedup every {args.dedup_batch} files; "
          f"full checkpoint every 4 dedups")
    if args.resume:
        print(f"  ⚙ Resume mode: enabled (will load existing checkpoint if found)")
    print()
    
    t0 = time.time()
    result = scan_files(file_indices, workers=args.workers, verbose=True,
                         delete_after=args.delete_after_parse,
                         dedup_batch_size=args.dedup_batch,
                         resume=args.resume)
    elapsed = time.time() - t0
    
    packed = result['tuples_packed']
    n_rows = result['n_rows']
    n_distinct = result['n_distinct']
    
    print(f"\n  ✓ {n_rows:,} rows processed in {elapsed/60:.1f} minutes "
          f"({n_rows/elapsed:.0f} rows/sec)")
    print(f"  Distinct (h11, h12, h13) tuples: {n_distinct:,}")
    print(f"  Coverage of expected spectrum: {n_distinct/EXPECTED_DISTINCT_TUPLES*100:.2f}% "
          f"of {EXPECTED_DISTINCT_TUPLES:,}")
    print(f"  Packed array memory: {packed.nbytes / 1024 / 1024:.1f} MB")
    print(f"\n  Aggregate distributions:")
    print(f"    Distinct vertex counts:     {len(result['vertex_count_counts']):,}")
    print(f"    Distinct facet counts:      {len(result['facet_count_counts']):,}")
    print(f"    Distinct point counts:      {len(result['point_count_counts']):,}")
    print(f"    Distinct dual point counts: {len(result['dual_point_count_counts']):,}")
    
    # Save (use .pkl.gz extension automatically)
    out_path = cache_path(f'_files{file_indices[0]:04d}_{file_indices[-1]:04d}')
    print(f"\n  Saving to {out_path} ...")
    actual_path = save_tuples(packed, out_path,
                                n_rows_scanned=n_rows,
                                vertex_count_counts=result['vertex_count_counts'],
                                facet_count_counts=result['facet_count_counts'],
                                point_count_counts=result['point_count_counts'],
                                dual_point_count_counts=result['dual_point_count_counts'],
                                files_processed=file_indices)
    size_mb = actual_path.stat().st_size / 1024 / 1024
    print(f"  Saved ({size_mb:.1f} MB compressed) → {actual_path.name}")
    
    # Clean up temp master checkpoint (now redundant — final cache has the data)
    temp_path = result.get('_temp_checkpoint')
    if temp_path and Path(temp_path).exists():
        try:
            Path(temp_path).unlink()
            print(f"  Cleaned up temp checkpoint: {Path(temp_path).name}")
        except Exception as e:
            print(f"  ⚠ Could not remove temp checkpoint {temp_path}: {e}")
    
    # Quick closure check on numpy packed array
    print(f"\n  Quick closure check (numpy-based) ...")
    p = closure_partition(packed)
    print(f"    Self-mirror (h11 = h13): {p['n_self_mirror']:,}")
    print(f"    Matched mirror pairs:    {p['n_matched_pairs']:,}")
    print(f"    Unmatched:               {p['n_unmatched']:,}  "
          f"(expected for partial scans — mirror partner may live in a later file)")
    print(f"    Coverage:                {p['coverage_pct']:.2f}%")
    
    return 0


def cmd_merge(args):
    """Merge multiple ss_hodge_tuples cache files into one.
    
    Uses pairwise sorted-array union (searchsorted-based) to avoid the
    np.unique hash-table memory bomb that would otherwise need ~8+ GB
    to dedup 8 chunks × 281M tuples.
    """
    import numpy as np, gc
    from collections import Counter
    
    if args.inputs:
        paths = [Path(p) for p in args.inputs]
    else:
        # Match both new .pkl.gz and legacy .json.gz formats
        paths = sorted(set(
            list(SS_CACHE_DIR.glob('ss_hodge_tuples*.pkl.gz')) +
            list(SS_CACHE_DIR.glob('ss_hodge_tuples*.json.gz'))
        ))
        if not paths:
            print(f"  ✗ No cache files found in {SS_CACHE_DIR}", file=sys.stderr)
            return 1
        paths = [p for p in paths if 'merged' not in p.name.lower()]
    
    missing = [p for p in paths if not p.exists()]
    if missing:
        print(f"  ✗ Missing files: {missing}", file=sys.stderr)
        return 1
    
    output = Path(args.output) if args.output else SS_CACHE_DIR / 'ss_hodge_tuples_merged.pkl.gz'
    
    print(f"  Merging {len(paths)} cache file(s) into {output.name} ...")
    print(f"  Strategy: pairwise sorted-array union (memory-efficient)\n")
    
    combined_vc, combined_fc = Counter(), Counter()
    combined_pc, combined_dpc = Counter(), Counter()
    total_rows = 0
    all_files = []
    merged_packed = None
    
    for i, p in enumerate(paths):
        size_mb = p.stat().st_size / 1024 / 1024
        print(f"    [{i+1}/{len(paths)}] + {p.name} ({size_mb:.1f} MB)")
        packed, meta = load_tuples(p)
        total_rows += meta.get('_rows_scanned', 0)
        all_files.extend(meta.get('_files_processed', []))
        for k, v in meta.get('vertex_count_distribution', {}).items(): combined_vc[k] += v
        for k, v in meta.get('facet_count_distribution', {}).items(): combined_fc[k] += v
        for k, v in meta.get('point_count_distribution', {}).items(): combined_pc[k] += v
        for k, v in meta.get('dual_point_count_distribution', {}).items(): combined_dpc[k] += v
        
        if merged_packed is None:
            merged_packed = packed
        else:
            # Pairwise union: find which packed values are not in merged, append, re-sort
            idx = np.searchsorted(merged_packed, packed)
            in_range = idx < len(merged_packed)
            is_dup = np.zeros(len(packed), dtype=bool)
            is_dup[in_range] = merged_packed[idx[in_range]] == packed[in_range]
            new_values = packed[~is_dup]
            del idx, in_range, is_dup, packed
            gc.collect()
            
            if len(new_values) > 0:
                combined = np.empty(len(merged_packed) + len(new_values), dtype=np.uint64)
                np.concatenate([merged_packed, new_values], out=combined)
                del merged_packed, new_values
                gc.collect()
                combined.sort(kind='stable')
                merged_packed = combined
            else:
                del new_values
                gc.collect()
        
        print(f"      cumulative distinct: {len(merged_packed):,} "
              f"({len(merged_packed)/EXPECTED_DISTINCT_TUPLES*100:.2f}% of spectrum)")
    
    actual_path = save_tuples(merged_packed, output,
                                n_rows_scanned=total_rows,
                                vertex_count_counts=combined_vc,
                                facet_count_counts=combined_fc,
                                point_count_counts=combined_pc,
                                dual_point_count_counts=combined_dpc,
                                files_processed=sorted(set(all_files)))
    
    out_mb = actual_path.stat().st_size / 1024 / 1024
    print(f"\n  ✓ Combined distinct tuples: {len(merged_packed):,}")
    print(f"  Total rows scanned (across all sources): {total_rows:,}")
    print(f"  Unique files processed:    {len(set(all_files)):,}")
    print(f"  Distinct vertex counts:    {len(combined_vc):,}")
    print(f"  Distinct facet counts:     {len(combined_fc):,}")
    print(f"  Distinct point counts:     {len(combined_pc):,}")
    print(f"  Output: {actual_path} ({out_mb:.1f} MB)")
    print(f"  Spectrum coverage: {len(merged_packed)/EXPECTED_DISTINCT_TUPLES*100:.2f}% "
          f"of {EXPECTED_DISTINCT_TUPLES:,}")
    
    return 0


def cmd_mirror_check(args):
    """Run the closure check on a cached tuple set (numpy-based)."""
    if args.cache:
        path = Path(args.cache)
        if not path.exists():
            print(f"  ✗ Cache file not found: {path}", file=sys.stderr)
            return 1
    else:
        # Find the largest cache file in the SS cache directory
        if not SS_CACHE_DIR.exists():
            print(f"  ✗ No cache directory: {SS_CACHE_DIR}", file=sys.stderr)
            return 1
        paths = (list(SS_CACHE_DIR.glob('ss_hodge_tuples*.pkl.gz')) +
                 list(SS_CACHE_DIR.glob('ss_hodge_tuples*.json.gz')))
        if not paths:
            print(f"  ✗ No cached tuple files found in {SS_CACHE_DIR}", file=sys.stderr)
            print(f"  Run `scan-files` first to produce one, or pass --cache <path>.", file=sys.stderr)
            return 1
        path = max(paths, key=lambda p: p.stat().st_size)
    
    print(f"Loading cached tuple set: {path.name}")
    packed, meta = load_tuples(path)
    print(f"  Distinct tuples loaded: {len(packed):,}")
    print(f"  Rows scanned to produce this set: {meta.get('_rows_scanned', '?'):,}")
    
    print(f"\nRunning closure partition (numpy-based) ...")
    p = closure_partition(packed)
    print(f"\n  CY 4-fold mirror closure: (h11, h12, h13) ↔ (h13, h12, h11)")
    print(f"  ───────────────────────────────────────────────────────────")
    print(f"    Total distinct tuples:         {p['n_total']:>14,}")
    print(f"    Self-mirror (h11 = h13):       {p['n_self_mirror']:>14,}")
    print(f"    Matched mirror pairs:          {p['n_matched_pairs']:>14,}")
    print(f"    Unmatched:                     {p['n_unmatched']:>14,}")
    sum_full = p['n_self_mirror'] + 2 * p['n_matched_pairs'] + p['n_unmatched']
    sum_ok = '✓' if sum_full == p['n_total'] else '✗ (data inconsistency!)'
    print(f"    Sum check: self + 2·pairs + unmatched = {sum_full:,} {sum_ok}")
    if p['n_unmatched'] == 0:
        coverage_note = 'fully mirror-closed'
    else:
        coverage_note = f"{p['n_unmatched']:,} unmatched"
    print(f"    Coverage:                      {p['coverage_pct']:>13.2f}%  ({coverage_note})")
    
    if p['self_mirror_examples']:
        print(f"\n  Sample self-mirror tuples:")
        for t in p['self_mirror_examples'][:5]:
            print(f"    (h11={t[0]:>4}, h12={t[1]:>4}, h13={t[2]:>4})")
    
    if p['unmatched_examples']:
        print(f"\n  Sample unmatched tuples (their mirror partner is absent):")
        for t in p['unmatched_examples'][:5]:
            print(f"    (h11={t[0]:>4}, h12={t[1]:>4}, h13={t[2]:>4})"
                  f"  → mirror would be ({t[2]}, {t[1]}, {t[0]})")
    
    return 0


def main():
    parser = argparse.ArgumentParser(description='Schöller-Skarke 5D streamer + mirror checker')
    sub = parser.add_subparsers(dest='cmd', required=True)
    
    sp_smoke = sub.add_parser('smoke', help='Connectivity test + warm-throughput benchmark')
    sp_smoke.add_argument('--n', type=int, default=10_000,
                          help='Rows to stream (default 10K; bigger = more accurate warm rate)')
    
    sp_scan = sub.add_parser('scan', help='[SLOW] Streaming scan of reflexive subset')
    sp_scan.add_argument('--limit', type=int, help='Stop after N rows')
    sp_scan.add_argument('--full', action='store_true',
                          help=f'Full scan ({EXPECTED_REFLEXIVE_ROWS:,} rows, multi-day)')
    
    sp_files = sub.add_parser('scan-files', help='[FAST] Direct-parquet scan (recommended)')
    grp = sp_files.add_mutually_exclusive_group()
    grp.add_argument('--files', type=int, nargs='+',
                     help='Specific file indices (e.g. --files 0 1 2)')
    grp.add_argument('--range', type=int, nargs=2, metavar=('LO', 'HI'),
                     help='Range of file indices [LO, HI) (e.g. --range 0 100)')
    grp.add_argument('--all', action='store_true',
                     help=f'All {N_REFLEXIVE_FILES} files (multi-hour with parallel workers)')
    sp_files.add_argument('--workers', type=int, default=4,
                           help='Parallel worker count (default 4; try up to your core count)')
    sp_files.add_argument('--delete-after-parse', action='store_true',
                           help='Delete each parquet file after parsing (keeps peak disk ~workers·800MB)')
    sp_files.add_argument('--resume', action='store_true',
                           help='Resume from a previous checkpoint (skips already-processed files)')
    sp_files.add_argument('--dedup-batch', type=int, default=4,
                           help='Dedup pending list every N files (default 4; smaller = less memory)')
    
    sp_merge = sub.add_parser('merge', help='Combine multiple cache files into one master set')
    sp_merge.add_argument('--inputs', nargs='+', help='Specific cache files (default: all in cache dir)')
    sp_merge.add_argument('--output', help='Output path (default: ss_hodge_tuples_merged.json.gz)')
    
    sp_recover = sub.add_parser('recover-temp', help='Recover a crashed scan\'s temp master file as a checkpoint')
    sp_recover.add_argument('--temp', help='Path to _scan_master_temp_*.npy.gz file (default: newest)')
    sp_recover.add_argument('--output', help='Output checkpoint path (default: ss_checkpoint_<range>.pkl.gz)')
    
    sp_mirror = sub.add_parser('mirror-check', help='Closure check on cached tuple set')
    sp_mirror.add_argument('--cache', help='Path to a specific cache file (default: largest in cache dir)')
    
    args = parser.parse_args()
    return {'smoke': cmd_smoke, 'scan': cmd_scan,
            'scan-files': cmd_scan_files, 'merge': cmd_merge,
            'recover-temp': cmd_recover_temp,
            'mirror-check': cmd_mirror_check}[args.cmd](args)


if __name__ == '__main__':
    sys.exit(main())
