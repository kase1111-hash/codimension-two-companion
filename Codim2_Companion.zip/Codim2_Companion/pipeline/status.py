#!/usr/bin/env python3
"""
pipeline/status.py — Renders the pipeline progress dashboard.

Usage:
    python -m pipeline.status              # full dashboard (one-shot)
    python -m pipeline.status --compact    # one-line summary per step
    python -m pipeline.status --json       # machine-readable

For a live, refreshing dashboard with progress bars, use the real TUI:

    python -m pipeline.tui                 # live, refreshing 0.5s
    python -m pipeline.tui --once          # render once (non-TTY safe)
    python -m pipeline.tui --refresh 1     # custom refresh rate

The TUI runs in a separate terminal alongside `pipeline.runner`. Run the
runner in one terminal and the TUI in another for live monitoring.

Author: Kase Branham — Independent Researcher
"""

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# Add pipeline/ to path so we can import siblings
sys.path.insert(0, str(Path(__file__).parent))

from registry import (
    discover_steps, read_progress, build_dag, is_step_complete,
    get_unblocked_steps, get_step_status_summary,
)
from kase_utils import C


# Status symbols
SYMBOLS = {
    'pending':     '○',
    'running':     '◐',
    'in_progress': '◐',
    'complete':    '✓',
    'error':       '✗',
    'partial':     '◑',
    'blocked':     '·',
}


def colorize_status(symbol: str, status: str) -> str:
    if status == 'complete':
        return C.green(symbol)
    elif status in ('running', 'in_progress'):
        return C.yellow(symbol)
    elif status == 'error':
        return C.red(symbol)
    elif status == 'partial':
        return C.yellow(symbol)
    elif status == 'blocked':
        return C.muted(symbol)
    else:  # pending
        return C.cyan(symbol)


def step_is_blocked(step_id: str, steps: dict) -> bool:
    """Return True if step is pending AND has uncompleted upstream deps."""
    prog = read_progress(step_id)
    if prog.get('status') in ('complete', 'running', 'in_progress', 'error'):
        return False
    deps = steps[step_id].get('dependencies', {}) or {}
    upstream = deps.get('upstream') or []
    return any(not is_step_complete(u) for u in upstream)


def format_step_line(step_id: str, spec: dict) -> str:
    """Format one step's status line."""
    prog = read_progress(step_id)
    status = prog.get('status', 'pending')
    
    # Re-classify pending → blocked if upstream not done
    steps_all = discover_steps()
    if status == 'pending' and step_is_blocked(step_id, steps_all):
        status = 'blocked'
    
    symbol = SYMBOLS.get(status, '?')
    sym_colored = colorize_status(symbol, status)
    
    # Step id padded
    name_field = f"{step_id:<42}"
    
    # Status field
    status_field = f"{status:<11}"
    
    # Detail field (varies by status)
    detail = ''
    if status == 'complete':
        elapsed = prog.get('elapsed_seconds')
        if elapsed:
            detail = f"({_format_duration(elapsed)})"
    elif status in ('running', 'in_progress'):
        done = prog.get('items_done', 0)
        total = prog.get('items_total', 0)
        if total > 0:
            pct = 100 * done / total
            detail = f"({done}/{total}, {pct:.0f}%)"
        else:
            detail = "(running)"
    elif status == 'partial':
        done = prog.get('items_done', 0)
        total = prog.get('items_total', 0)
        errs = prog.get('errors', 0)
        detail = f"({done}/{total}, {errs} errors)"
    elif status == 'error':
        msg = prog.get('error_message', '')[:40]
        detail = f"({msg})" if msg else "(failed)"
    elif status == 'blocked':
        deps = spec.get('dependencies', {}) or {}
        upstream = deps.get('upstream') or []
        waiting = [u for u in upstream if not is_step_complete(u)]
        if waiting:
            detail = f"(waiting on {', '.join(waiting[:2])}{'...' if len(waiting) > 2 else ''})"
    
    return f"  {sym_colored} {name_field}  {C.muted(status_field)}  {detail}"


def _format_duration(seconds: float) -> str:
    """Human-readable duration."""
    if seconds < 60:
        return f"{seconds:.0f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}m"
    else:
        return f"{seconds/3600:.1f}h"


def group_steps_by_part(steps: dict) -> dict:
    """Group steps by their part field for display."""
    # Map chapter number → part name
    def part_for_chapter(ch):
        if ch is None:
            return 'Other'
        if isinstance(ch, str) and 'appendix' in ch.lower():
            return 'Appendix C — Open Problems'
        try:
            ch = int(ch)
        except (ValueError, TypeError):
            return 'Other'
        if 1 <= ch <= 4: return 'Part I — The Conjecture and Its Setting'
        if 5 <= ch <= 10: return 'Part II — Why Dimension 4 Is the Threshold'
        if 11 <= ch <= 17: return 'Part III — The Arsenal'
        if 18 <= ch <= 24: return 'Part IV — The Map of Known and Open'
        if 25 <= ch <= 34: return 'Part V — The Computational Atlas'
        if 35 <= ch <= 40: return 'Part VI — Sister Conjectures and Implications'
        if 41 <= ch <= 45: return 'Part VII — Closing Arguments'
        return 'Other'
    
    groups = {}
    for step_id, spec in sorted(steps.items()):
        part = part_for_chapter(spec.get('chapter'))
        groups.setdefault(part, []).append((step_id, spec))
    return groups


def render_dashboard(compact: bool = False):
    """Render the full dashboard to stdout."""
    steps = discover_steps()
    
    print()
    print("═" * 75)
    print(f"  {C.highlight('CODIM2 ATLAS PIPELINE — STATUS')}")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("═" * 75)
    
    if not steps:
        print()
        print(C.muted("  No steps registered yet."))
        print(C.muted("  Create steps under pipeline/steps/<step_id>/ with spec.yaml."))
        print()
        return
    
    groups = group_steps_by_part(steps)
    for part, step_list in groups.items():
        print()
        print(C.highlight(part))
        for step_id, spec in step_list:
            print(format_step_line(step_id, spec))
    
    # Summary
    print()
    print("─" * 75)
    print(C.highlight("SUMMARY"))
    summary = get_step_status_summary()
    total = sum(summary.values())
    print(f"  Total steps:     {total}")
    if total > 0:
        complete_pct = 100 * summary.get('complete', 0) / total
        print(f"  {C.green('Complete')}:        {summary.get('complete', 0)} ({complete_pct:.0f}%)")
        active = summary.get('running', 0) + summary.get('in_progress', 0)
        print(f"  {C.yellow('In progress')}:     {active}")
        pending = summary.get('pending', 0)
        print(f"  {C.cyan('Pending/blocked')}: {pending}")
        if summary.get('error', 0):
            print(f"  {C.red('Errored')}:         {summary.get('error', 0)}")
        if summary.get('partial', 0):
            print(f"  {C.yellow('Partial')}:         {summary.get('partial', 0)}")
    
    # Next unblocked
    unblocked = get_unblocked_steps(build_dag(steps))
    # Filter to actually-pending (not in_progress)
    pending_unblocked = [u for u in unblocked
                         if read_progress(u).get('status') == 'pending']
    if pending_unblocked:
        print()
        print(C.highlight("READY TO RUN") + f"  (no upstream deps blocking)")
        for u in pending_unblocked[:5]:
            print(f"  • {u}")
        if len(pending_unblocked) > 5:
            print(f"  ... and {len(pending_unblocked) - 5} more")
    
    print()
    print("═" * 75)


def render_json():
    """Output status as JSON."""
    steps = discover_steps()
    out = {
        'timestamp': datetime.now(timezone.utc).isoformat(timespec='seconds'),
        'summary': get_step_status_summary(),
        'steps': {}
    }
    for step_id in steps:
        out['steps'][step_id] = read_progress(step_id)
    print(json.dumps(out, indent=2))


def main():
    parser = argparse.ArgumentParser(description="Codim2 pipeline status dashboard")
    parser.add_argument('--compact', action='store_true',
                        help='One-line summary per step')
    parser.add_argument('--json', action='store_true',
                        help='Output JSON (machine-readable)')
    parser.add_argument('--watch', action='store_true',
                        help='Refresh every 2 seconds')
    parser.add_argument('--watch-interval', type=float, default=2.0,
                        help='Watch refresh interval in seconds')
    args = parser.parse_args()
    
    if args.json:
        render_json()
        return
    
    if args.watch:
        try:
            while True:
                # Clear screen
                print('\033[2J\033[H', end='')
                render_dashboard(args.compact)
                time.sleep(args.watch_interval)
        except KeyboardInterrupt:
            print("\nWatch stopped.")
    else:
        render_dashboard(args.compact)


if __name__ == '__main__':
    main()
