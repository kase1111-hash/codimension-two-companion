#!/usr/bin/env python3
"""
pipeline/registry.py — Step discovery, artifact paths, progress tracking, upstream loading.

Every pipeline step imports from this module to integrate with the orchestrator
without knowing anything about how the orchestrator works.

Author: Kase Branham — Independent Researcher
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Any
import yaml
import csv


# ═══════════════════════════════════════════════════════════════════
#  PROJECT PATHS
# ═══════════════════════════════════════════════════════════════════

PIPELINE_ROOT = Path(__file__).parent.resolve()
PROJECT_ROOT = PIPELINE_ROOT.parent
ARTIFACTS_ROOT = PIPELINE_ROOT / 'artifacts'
STEPS_ROOT = PIPELINE_ROOT / 'steps'
DATA_ROOT = PROJECT_ROOT / 'data'


# ═══════════════════════════════════════════════════════════════════
#  STEP DISCOVERY
# ═══════════════════════════════════════════════════════════════════

def discover_steps() -> dict:
    """
    Walk pipeline/steps/ and return {step_id: spec_dict} for every step
    that has a valid spec.yaml.
    """
    steps = {}
    if not STEPS_ROOT.exists():
        return steps
    for step_dir in sorted(STEPS_ROOT.iterdir()):
        if not step_dir.is_dir():
            continue
        spec_path = step_dir / 'spec.yaml'
        if not spec_path.exists():
            continue
        try:
            with open(spec_path, encoding='utf-8') as f:
                spec = yaml.safe_load(f)
        except Exception as e:
            print(f"  ⚠ {step_dir.name}: spec.yaml parse error: {e}")
            continue
        spec['_dir'] = step_dir
        spec['_step_id'] = step_dir.name
        # Sanity check: spec.step_id must match directory name
        declared_id = spec.get('step_id')
        if declared_id and declared_id != step_dir.name:
            print(f"  ⚠ {step_dir.name}: spec.yaml step_id={declared_id} doesn't match dir name")
        steps[step_dir.name] = spec
    return steps


def get_step_spec(step_id: str) -> dict:
    """Read a single step's spec.yaml. Raises if missing."""
    spec_path = STEPS_ROOT / step_id / 'spec.yaml'
    if not spec_path.exists():
        raise FileNotFoundError(f"No spec.yaml for step {step_id} at {spec_path}")
    with open(spec_path, encoding='utf-8') as f:
        spec = yaml.safe_load(f)
    spec['_dir'] = STEPS_ROOT / step_id
    spec['_step_id'] = step_id
    return spec


# ═══════════════════════════════════════════════════════════════════
#  ARTIFACT PATHS
# ═══════════════════════════════════════════════════════════════════

def get_artifact_path(step_id: str, filename: Optional[str] = None) -> Path:
    """
    Resolve the canonical artifact path for a step.
    
    get_artifact_path('ch_21_hassett_discriminants')
        → /home/.../pipeline/artifacts/ch_21_hassett_discriminants/
    
    get_artifact_path('ch_21_hassett_discriminants', 'hassett_table.csv')
        → /home/.../pipeline/artifacts/ch_21_hassett_discriminants/hassett_table.csv
    """
    step_artifacts = ARTIFACTS_ROOT / step_id
    if filename is None:
        return step_artifacts
    return step_artifacts / filename


def load_upstream(step_id: str, filename: str, format: Optional[str] = None) -> Any:
    """
    Load an artifact produced by an upstream step. Raises if missing.
    
    Format inferred from extension unless overridden:
        .json → dict / list (parsed JSON)
        .csv  → list of dicts
        .yaml → dict
        else  → string
    
    Raises FileNotFoundError with a helpful message if the artifact
    doesn't exist (i.e., the upstream step hasn't run yet).
    """
    path = get_artifact_path(step_id, filename)
    if not path.exists():
        raise FileNotFoundError(
            f"Upstream artifact not found: {path}\n"
            f"  Step '{step_id}' has not produced '{filename}' yet.\n"
            f"  Run: python -m pipeline.runner --only {step_id}"
        )
    if format is None:
        format = path.suffix.lower().lstrip('.')
    
    if format == 'json':
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    elif format == 'csv':
        with open(path, newline='', encoding='utf-8') as f:
            return list(csv.DictReader(f))
    elif format in ('yaml', 'yml'):
        with open(path, encoding='utf-8') as f:
            return yaml.safe_load(f)
    else:
        with open(path, encoding='utf-8') as f:
            return f.read()


# ═══════════════════════════════════════════════════════════════════
#  PROGRESS TRACKING
# ═══════════════════════════════════════════════════════════════════

def _progress_path(step_id: str) -> Path:
    return get_artifact_path(step_id, 'progress.json')


def write_progress(
    step_id: str,
    status: Optional[str] = None,
    items_done: Optional[int] = None,
    items_total: Optional[int] = None,
    errors: Optional[int] = None,
    preset: Optional[str] = None,
    artifacts: Optional[list] = None,
    error_message: Optional[str] = None,
    **kwargs
) -> dict:
    """
    Update progress.json for a step. Reads existing, updates fields,
    writes back atomically. Returns the updated dict.
    
    Status values: pending, running, in_progress, complete, error, partial
    """
    p = _progress_path(step_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    
    # Read existing or initialize
    if p.exists():
        with open(p, encoding='utf-8') as f:
            prog = json.load(f)
    else:
        prog = {
            'step_id': step_id,
            'status': 'pending',
            'started_at': None,
            'items_done': 0,
            'items_total': 0,
            'errors': 0,
            'percent_complete': 0.0,
        }
    
    # Update fields
    now = datetime.now(timezone.utc).isoformat(timespec='seconds')
    prog['last_update'] = now
    
    if status is not None:
        prog['status'] = status
        if status == 'running' and prog.get('started_at') is None:
            prog['started_at'] = now
        if status in ('complete', 'error', 'partial'):
            prog['finished_at'] = now
            if prog.get('started_at'):
                start = datetime.fromisoformat(prog['started_at'])
                end = datetime.fromisoformat(now)
                prog['elapsed_seconds'] = (end - start).total_seconds()
    if items_done is not None:
        prog['items_done'] = items_done
    if items_total is not None:
        prog['items_total'] = items_total
    if errors is not None:
        prog['errors'] = errors
    if preset is not None:
        prog['preset'] = preset
    if artifacts is not None:
        prog['artifacts'] = artifacts
    if error_message is not None:
        prog['error_message'] = error_message
    for k, v in kwargs.items():
        prog[k] = v
    
    # Compute percent_complete
    if prog.get('items_total', 0) > 0:
        prog['percent_complete'] = 100.0 * prog['items_done'] / prog['items_total']
    
    # Atomic write (temp file + rename)
    tmp = p.with_suffix('.json.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(prog, f, indent=2)
    tmp.replace(p)
    
    return prog


def read_progress(step_id: str) -> dict:
    """Read a step's progress.json. Returns 'pending' status if file doesn't exist."""
    p = _progress_path(step_id)
    if not p.exists():
        return {
            'step_id': step_id,
            'status': 'pending',
            'items_done': 0,
            'items_total': 0,
            'percent_complete': 0.0,
        }
    with open(p, encoding='utf-8') as f:
        return json.load(f)


def is_step_complete(step_id: str) -> bool:
    """Check if a step has completed successfully."""
    prog = read_progress(step_id)
    return prog.get('status') == 'complete'


# ═══════════════════════════════════════════════════════════════════
#  DEPENDENCY GRAPH
# ═══════════════════════════════════════════════════════════════════

def build_dag(steps: Optional[dict] = None) -> dict:
    """
    Build the dependency DAG from step specs.
    
    Returns dict {step_id: set(upstream_step_ids)}.
    """
    if steps is None:
        steps = discover_steps()
    dag = {}
    for step_id, spec in steps.items():
        deps = spec.get('dependencies', {}) or {}
        upstream = set(deps.get('upstream') or [])
        dag[step_id] = upstream
    return dag


def topological_sort(dag: dict) -> list:
    """
    Topologically sort steps so dependencies run before dependents.
    Raises ValueError on cycles.
    """
    in_degree = {step: len(deps) for step, deps in dag.items()}
    queue = [s for s, d in in_degree.items() if d == 0]
    order = []
    while queue:
        # Sort for deterministic ordering
        queue.sort()
        step = queue.pop(0)
        order.append(step)
        for other_step, other_deps in dag.items():
            if step in other_deps:
                in_degree[other_step] -= 1
                if in_degree[other_step] == 0:
                    queue.append(other_step)
    if len(order) != len(dag):
        unprocessed = set(dag.keys()) - set(order)
        raise ValueError(f"Dependency cycle detected in: {unprocessed}")
    return order


def get_unblocked_steps(dag: dict) -> list:
    """
    Return list of step_ids that are pending and have all upstream
    dependencies complete.
    """
    unblocked = []
    for step_id, upstream in dag.items():
        prog = read_progress(step_id)
        if prog.get('status') == 'complete':
            continue
        if all(is_step_complete(u) for u in upstream):
            unblocked.append(step_id)
    return unblocked


def get_step_status_summary() -> dict:
    """Return counts: {'pending': N, 'running': N, 'in_progress': N, 'complete': N, 'error': N}."""
    steps = discover_steps()
    counts = {'pending': 0, 'running': 0, 'in_progress': 0,
              'complete': 0, 'error': 0, 'partial': 0}
    for step_id in steps:
        s = read_progress(step_id).get('status', 'pending')
        counts[s] = counts.get(s, 0) + 1
    return counts


if __name__ == '__main__':
    # Self-test: discover steps, print summary
    print(f"Pipeline root: {PIPELINE_ROOT}")
    print(f"Artifacts root: {ARTIFACTS_ROOT}")
    steps = discover_steps()
    print(f"\nDiscovered {len(steps)} steps:")
    for sid, spec in steps.items():
        print(f"  {sid}  ch_{spec.get('chapter', '?'):>2} — {spec.get('title', '?')}")
    if steps:
        dag = build_dag(steps)
        try:
            order = topological_sort(dag)
            print(f"\nTopological order ({len(order)} steps):")
            for i, sid in enumerate(order, 1):
                print(f"  {i:>3}. {sid}")
        except ValueError as e:
            print(f"\nDAG error: {e}")
        print("\nStatus summary:")
        for status, count in get_step_status_summary().items():
            if count > 0:
                print(f"  {status:>12}: {count}")
