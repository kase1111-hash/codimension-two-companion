"""ch_32_toric_cy_sweep — Toric CY 4-fold sweep."""
from .compute import main
if __name__ == '__main__':
    main()
