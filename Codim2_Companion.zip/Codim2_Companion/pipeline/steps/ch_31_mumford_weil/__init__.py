"""ch_31_mumford_weil — Mumford-Weil exotic class detector."""
from .compute import main
if __name__ == '__main__':
    main()
