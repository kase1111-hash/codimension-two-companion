"""ch_13_standard_conjectures_status — Standard conjectures status by variety class."""
from .compute import main

if __name__ == '__main__':
    main()
