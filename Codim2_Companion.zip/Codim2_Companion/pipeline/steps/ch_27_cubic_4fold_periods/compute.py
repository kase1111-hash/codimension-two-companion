#!/usr/bin/env python3
"""
ch_27_cubic_4fold_periods — Cubic 4-fold period and Frobenius data.

Two computations:

  1. For each Hassett discriminant d from ch_21, compute the rank-2
     sublattice K_d ⊂ H^{2,2}(X, Z) ∩ H^4(X, Z): intersection form
     [[3, t], [t, T]] where (3, t, T) is determined by d, signature,
     and the K3-association check.
     
  2. Point-count the Fermat cubic 4-fold x_0^3 + x_1^3 + ... + x_5^3 = 0
     in P^5 over small primes F_p, extract the Frobenius trace on H^4,
     and check for arithmetic Tate classes (algebraic codim-2 classes
     visible via Frobenius eigenvalue = p^2).

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import multiprocessing as mp
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    parallel_map, summary_table, C, debug, Timer,
)
from registry import get_artifact_path, write_progress, load_upstream

# Import ch_14 framework
sys.path.insert(0, str(Path(__file__).parent.parent / 'ch_14_tate_mirror_framework'))
from framework import is_tate_eigenvalue


STEP_ID = 'ch_27_cubic_4fold_periods'

# Cubic 4-fold cohomology data
# H^2(X, Z) has rank 1 (just hyperplane h)
# H^4(X, Z) has rank 23 (primitive rank 22 + hyperplane^2)
# Of the primitive H^4: 21 transcendental + algebraic part
# For generic cubic 4-fold: H^{2,2}_alg = <h^2> (rank 1)
# For Hassett-special with disc d: H^{2,2}_alg has rank ≥ 2

CUBIC_4FOLD_H4_RANK = 23
CUBIC_4FOLD_H4_PRIM_RANK = 22  # primitive part
CUBIC_4FOLD_HODGE_SIGNATURE = (21, 2)  # signature of <(2,2) ∩ Q> ; actually H^{2,2}_prim has sig (1, 20)


def kd_lattice_for_discriminant(d: int) -> dict:
    """For a Hassett-special cubic 4-fold of discriminant d, the
    rank-2 sublattice K_d of H^{2,2}(X, Z) has Gram matrix
    
        K_d = [[3, t], [t, T]]
    
    where d = 3T - t^2 and t ∈ Z, T ∈ Z. The minimal (t, T) giving
    discriminant d depends on d mod 6:
      d = 6T - 0 (t=0, d ≡ 0 mod 6): K_d = [[3,0],[0, d/3]]; but
        we need d to be admissible: d ≡ 0 or 2 mod 6.
      d = 6T - 4 (t=2, d ≡ 2 mod 6): K_d = [[3,2],[2, (d+4)/3]]
    """
    if d <= 6:
        return None
    if d % 6 == 0:
        t, T = 0, d // 3
    elif d % 6 == 2:
        t, T = 2, (d + 4) // 3
    else:
        return None
    return {
        'gram': [[3, t], [t, T]],
        't': t,
        'T': T,
        'discriminant': 3 * T - t * t,
        'signature': '(1, 1) — hyperbolic',
    }


# ═══════════════════════════════════════════════════════════════════
#  FERMAT CUBIC 4-FOLD POINT COUNTING
# ═══════════════════════════════════════════════════════════════════

def count_points_fermat_cubic_P5(p: int) -> int:
    """Count #X(F_p) where X = V(x_0^3 + x_1^3 + ... + x_5^3) ⊂ P^5.
    
    Naive enumeration is O(p^5) — only feasible for p ≤ 13.
    """
    if p < 5:
        return None
    # For p ≡ 2 mod 3: all elements have unique cube root, so x^3 is a bijection
    # → equation x_0^3 + ... + x_5^3 = 0 transforms to y_0 + ... + y_5 = 0,
    #   which has p^5 solutions affinely. Projective count = (p^5 - 1)/(p-1) = p^4 + p^3 + p^2 + p + 1.
    if p % 3 == 2:
        return p**4 + p**3 + p**2 + p + 1
    
    # For p ≡ 1 mod 3: 1/3 of nonzero elements are cubes (each cube has 3 cube roots)
    # The count requires character-sum techniques. We do naive enumeration for small p.
    if p > 13:
        return None  # too expensive
    
    # Precompute cubes
    cubes = [(x ** 3) % p for x in range(p)]
    
    # Count affine solutions x_0^3 + ... + x_5^3 ≡ 0 (mod p)
    affine_count = 0
    for x0 in cubes:
        for x1 in cubes:
            s01 = (x0 + x1) % p
            for x2 in cubes:
                s012 = (s01 + x2) % p
                for x3 in cubes:
                    s0123 = (s012 + x3) % p
                    for x4 in cubes:
                        s01234 = (s0123 + x4) % p
                        # Need x_5^3 ≡ -s01234 mod p
                        target = (-s01234) % p
                        if target == 0:
                            affine_count += 1  # x_5 = 0
                        else:
                            # Count x_5 with x_5^3 = target
                            # For p ≡ 1 mod 3, exactly 0 or 3 such x_5
                            n = sum(1 for c in cubes[1:] if c == target)
                            affine_count += n
    # Subtract origin (0,...,0) which is always a solution
    affine_count -= 1
    # Divide by (p-1) for projective
    return affine_count // (p - 1)


def fermat_cubic_h4_trace(p: int):
    """Compute Frobenius trace on H^4(X, Q_ℓ) for X the Fermat cubic 4-fold.
    
    For a smooth proj 4-fold X with b_0 = b_8 = 1 and (for Fermat cubic)
    b_1 = b_3 = b_5 = b_7 = 0, b_2 = b_6 = 1 (just hyperplane class
    and its dual), b_4 = 23:
    
      #X(F_p) = 1 + tr(F|H^2) + tr(F|H^4) + tr(F|H^6) + p^4
    
    For the cubic 4-fold:
      tr(F|H^2) = p (just hyperplane class, eigenvalue p on H^2)
      tr(F|H^6) = p^3 (dual class on H^6, eigenvalue p^3)
    
    So: tr(F|H^4) = #X(F_p) - 1 - p - p^3 - p^4
    """
    n = count_points_fermat_cubic_P5(p)
    if n is None:
        return None
    trace = n - 1 - p - p**3 - p**4
    return {
        'p': p,
        'n_X': n,
        'h4_trace': trace,
        # Algebraic eigenvalues: Frobenius eigenvalue α on H^{2,2}_alg equals p^2
        # If trace contains a +p^2 contribution from k algebraic classes:
        # estimate k = trace / p^2 (rough; transcendental part contributes too)
        'algebraic_eigenvalue_target': p**2,
        'tate_class_estimate': trace / (p**2) if p > 0 else None,
        # Weil bound: |tr(F|H^4)| ≤ 23 * p^2
        'weil_bound_h4': CUBIC_4FOLD_H4_RANK * p**2,
        'weil_ok': abs(trace) <= CUBIC_4FOLD_H4_RANK * p**2,
    }


# ═══════════════════════════════════════════════════════════════════
#  WORKERS
# ═══════════════════════════════════════════════════════════════════

def period_worker(item: dict) -> dict:
    """Compute K_d lattice for one Hassett discriminant."""
    try:
        d = item['d']
        kd = kd_lattice_for_discriminant(d)
        if kd is None:
            return {**item, 'error': f'd={d} not admissible'}
        return {
            **item,
            **kd,
            'algebraic_codim2_rank': 2,  # K_d has rank 2
            'transcendental_rank': CUBIC_4FOLD_H4_PRIM_RANK - 1,
        }
    except Exception as e:
        return {**item, 'error': str(e)}


def fermat_worker(item: dict) -> dict:
    """Compute Frobenius trace on H^4 for Fermat cubic at prime p."""
    try:
        return fermat_cubic_h4_trace(item['p'])
    except Exception as e:
        return {**item, 'error': str(e)}


# ═══════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    parser.add_argument('--d-max', type=int, default=None)
    parser.add_argument('--p-max', type=int, default=None)
    args = parser.parse_args()
    args = resolve_args(args)
    
    d_max_map = {'quick': 30, 'standard': 50, 'long': 100}
    p_max_map = {'quick': 7, 'standard': 11, 'long': 13}
    if args.d_max is None:
        args.d_max = d_max_map.get(args.preset, 50)
    if args.p_max is None:
        args.p_max = p_max_map.get(args.preset, 11)
    
    banner("ch_27_cubic_4fold_periods — Cubic 4-fold Periods", {
        'd_max': args.d_max,
        'p_max': args.p_max,
        'workers': args.workers,
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # ─────────────────────────────────────────────────
        # Part A: Period data per discriminant
        # ─────────────────────────────────────────────────
        step(1, 5, "Loading Hassett discriminants from ch_21 ...")
        hassett = load_upstream('ch_21_hassett_discriminants', 'hassett_table.json')
        admissible = [r for r in hassett['data']
                      if r.get('admissible') and r.get('d', 0) <= args.d_max]
        print(f"    {len(admissible)} admissible discriminants ≤ {args.d_max}")
        
        write_progress(STEP_ID, status='running', items_done=0,
                       items_total=len(admissible) + args.p_max,
                       preset=args.preset)
        
        step(2, 5, "Computing K_d lattices ...")
        period_work = [{'d': r['d'], 'k3_status': r.get('k3_status')} for r in admissible]
        period_results = parallel_map(period_worker, period_work, args.workers,
                                      desc="K_d lattices")
        good_periods = [r for r in period_results if 'error' not in r]
        
        # ─────────────────────────────────────────────────
        # Part B: Fermat cubic point counting
        # ─────────────────────────────────────────────────
        step(3, 5, "Point-counting Fermat cubic 4-fold over small primes ...")
        primes = [p for p in [5, 7, 11, 13] if p <= args.p_max]
        fermat_work = [{'p': p} for p in primes]
        with Timer("Fermat cubic counting"):
            fermat_results = parallel_map(fermat_worker, fermat_work,
                                          min(args.workers, 4), desc="Fermat at p")
        good_fermat = [r for r in fermat_results if r is not None and 'error' not in r]
        
        # ─────────────────────────────────────────────────
        # Display
        # ─────────────────────────────────────────────────
        step(4, 5, "Compiling results ...")
        section("CUBIC 4-FOLD K_d LATTICES (admissible discriminants)")
        rows = []
        for r in sorted(good_periods, key=lambda r: r.get('d', 0))[:20]:
            d = r.get('d')
            gram = r.get('gram')
            t = r.get('t')
            T = r.get('T')
            k3_status = r.get('k3_status', '?')
            k3_str = (C.green('K3') if k3_status == 'k3_associated'
                      else C.warn('open') if k3_status == 'no_k3_association'
                      else C.muted('pending'))
            rows.append((
                str(d),
                f"[[3, {t}], [{t}, {T}]]",
                str(r.get('discriminant')),
                k3_str,
            ))
        summary_table(rows, ['d', 'Gram K_d', 'check d', 'K3-assoc?'],
                      fmt=['<4', '<22', '<8', '<10'])
        
        section("FERMAT CUBIC 4-FOLD FROBENIUS DATA")
        f_rows = []
        for r in good_fermat:
            ok = '✓' if r.get('weil_ok') else '✗'
            f_rows.append((
                str(r['p']),
                f"{r['n_X']:,}",
                f"{r['h4_trace']:+}",
                f"{r['tate_class_estimate']:+.2f}",
                ok,
            ))
        summary_table(f_rows, ['p', '#X(F_p)', 'tr(F|H^4)', 'k ≈ tr/p²', 'Weil?'],
                      fmt=['<4', '<14', '<12', '<10', '<6'])
        
        section("KEY OBSERVATIONS")
        print(f"  • Hassett K_d for d ≡ 0 mod 6: K_d = [[3, 0], [0, d/3]]")
        print(f"  • Hassett K_d for d ≡ 2 mod 6: K_d = [[3, 2], [2, (d+4)/3]]")
        print(f"  • Discriminant of K_d = 3T - t^2 = d (by construction ✓)")
        print()
        print(f"  • {C.green('Fermat cubic 4-fold')}: x_0^3 + ... + x_5^3 = 0 in P^5.")
        print(f"    For p ≡ 2 mod 3 (e.g., p = 5, 11): #X(F_p) = (p^5 - 1)/(p - 1) = "
              f"p^4+p^3+p^2+p+1 (closed form).")
        print(f"  • {C.warn('Tate-class estimate k')} = tr(F|H^4) / p^2 gives a heuristic "
              f"lower bound on algebraic codim-2 cycles visible over F_p.")
        print(f"  • The Fermat cubic 4-fold has CM-type Hodge structure → many algebraic "
              f"cycles → large k for most primes.")
        
        # ─────────────────────────────────────────────────
        # Save
        # ─────────────────────────────────────────────────
        step(5, 5, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'cubic_4fold_periods.csv'
        keys = ['d', 'k3_status', 't', 'T', 'discriminant',
                'algebraic_codim2_rank', 'transcendental_rank', 'signature']
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
            writer.writeheader()
            for r in good_periods:
                row = {k: r.get(k) for k in keys}
                writer.writerow(row)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'cubic_4fold_periods.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 27,
                'periods_data': good_periods,
                'summary': {
                    'n_admissible': len(admissible),
                    'n_good': len(good_periods),
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        fermat_path = output_dir / 'fermat_cubic_frobenius.json'
        with open(fermat_path, 'w', encoding='utf-8') as f:
            json.dump({
                'variety': 'Fermat cubic 4-fold (x_0^3 + ... + x_5^3 = 0 in P^5)',
                'data': good_fermat,
            }, f, indent=2)
        print(f"  {fermat_path.name}  ({fermat_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(good_periods) + len(good_fermat),
                       items_total=len(admissible) + len(primes),
                       artifacts=['cubic_4fold_periods.csv',
                                  'cubic_4fold_periods.json',
                                  'fermat_cubic_frobenius.json'])
        print()
        print(C.green("  ✓ ch_27_cubic_4fold_periods finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    mp.freeze_support()
    main()
