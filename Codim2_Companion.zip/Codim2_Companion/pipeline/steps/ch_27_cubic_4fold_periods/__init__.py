"""ch_27_cubic_4fold_periods — Cubic 4-fold periods and Frobenius."""
from .compute import main
if __name__ == '__main__':
    main()
