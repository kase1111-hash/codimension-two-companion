#!/usr/bin/env python3
"""
ch_33_counterexample_search — Identify variety classes with the largest
gap between Hodge classes and known algebraic cycle constructions.

For each CY 4-fold family (from ch_22), compute:
  - total_hodge_codim_2 = h^{2,2} (size of H^{2,2}(X) ∩ H^4(X, Z) lattice)
  - known_algebraic = number of explicit algebraic codim-2 classes known
  - tension_index = total_hodge_codim_2 - known_algebraic
  - tension_ratio = tension_index / total_hodge_codim_2

Sort by tension. The highest-tension entries are the "if a counter-
example exists, it lives somewhere in this neighborhood" candidates.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress, load_upstream


STEP_ID = 'ch_33_counterexample_search'


def known_algebraic_rank(cy_entry: dict) -> int:
    """How many explicit algebraic codim-2 classes are known to live in H^{2,2}(X)?"""
    src = cy_entry.get('cycle_source_rank_codim_2', 1)
    # If string-typed (e.g., 'extra (via Fermat motive)'), conservatively use 1
    if isinstance(src, int):
        return src
    if isinstance(src, str):
        if 'extra' in src.lower():
            return 2  # rough; "extra" means > 1
        return 1
    return 1


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_33_counterexample_search — Tension Index", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Load
        step(1, 3, "Loading CY 4-fold + HK + regulator upstream ...")
        cy = load_upstream('ch_22_cy_4fold_hodge_numbers', 'cy_4fold_atlas.json')
        hk = load_upstream('ch_20_hyperkahler_classification',
                           'hyperkahler_classification.json')
        print(f"    CY 4-fold families: {len(cy['data'])}")
        print(f"    HK deformation types: {len(hk['deformation_types'])}")
        
        write_progress(STEP_ID, status='running', items_done=0,
                       items_total=len(cy['data']) + len(hk['deformation_types']),
                       preset=args.preset)
        
        # Compute tension
        step(2, 3, "Computing tension index ...")
        results = []
        
        # CY 4-folds — use h^{2,2} as total Hodge
        for entry in cy['data']:
            # Use Chern-class back-solved h^{2,2} when available (since literature h^{2,2} may be wrong;
            # see VERIFICATION_LOG.md)
            h22_back = entry.get('h_2_2_back_solved')
            h22_stored = entry.get('h_2_2')
            h22 = h22_back if isinstance(h22_back, int) else h22_stored
            if not isinstance(h22, int):
                continue
            known = known_algebraic_rank(entry)
            tension = h22 - known
            ratio = tension / h22 if h22 > 0 else 0.0
            results.append({
                'variety_id': entry['id'],
                'variety_name': entry.get('name', ''),
                'variety_class': 'CY 4-fold',
                'h_2_2_used': h22,
                'h_2_2_source': 'chern-back-solved' if isinstance(h22_back, int) else 'stored',
                'known_algebraic_codim_2': known,
                'tension_index': tension,
                'tension_ratio': round(ratio, 4),
                'hc_codim_2_status': entry.get('hc_codim_2_status', '?'),
            })
        
        # HK manifolds — algebraic rank is determined by BB form + Picard
        # For each HK deformation type at canonical n (e.g., K3^[2] dim 4):
        # H^4(X) has b_4 contributions, of which the BB form gives roughly
        # b_2 + (b_2)(b_2-1)/2 algebraic via Sym^2 H^2 — but only a small
        # subspace is "known cycle constructions"
        for hk_type in hk['deformation_types']:
            t = hk_type['type']
            n = hk_type.get('n')
            dim_X = hk_type.get('dim_X')
            b_2 = int(hk_type.get('bb_rank', 0))
            
            # h^{2,2}(X) bounds: typically O(b_2^2) for K3^[n]
            # Specifically: b_4(K3^[n]) = b_2 + (b_2)(b_2-1)/2 + 23 partition-extra terms
            # For HK 4-folds (so n=2 or dim X = 4): we know h^{2,2}(K3^[2]) = 232.
            # Rough estimate: total_hodge_codim_2 ~ (b_2)(b_2+1)/2
            estimated_h22 = b_2 * (b_2 + 1) // 2 if b_2 else None
            
            # Known algebraic from BB / Sym² H^2 / monodromy:
            # for K3^[n]: many; for OG-6/10: fewer
            if 'K3^[n]' in t:
                known = estimated_h22  # essentially all known for K3^[n] (Charles-Markman)
                tension = 0
                ratio = 0.0
                hc_status = 'settled'
            elif 'Kum' in t:
                known = max(estimated_h22 - 5, 0) if estimated_h22 else 0
                tension = estimated_h22 - known if estimated_h22 else 0
                ratio = tension / estimated_h22 if estimated_h22 else 0
                hc_status = 'partial'
            elif 'OG-6' in t:
                # b_2 = 8, est h^{2,2} ~ 36; algebraic subset unclear
                known = 10  # rough literature estimate
                tension = (estimated_h22 or 0) - known
                ratio = tension / estimated_h22 if estimated_h22 else 0
                hc_status = 'partial'
            elif 'OG-10' in t:
                # b_2 = 24, est h^{2,2} ~ 300; algebraic subset very limited
                known = 24  # roughly: divisor squares + BB form
                tension = (estimated_h22 or 0) - known
                ratio = tension / estimated_h22 if estimated_h22 else 0
                hc_status = 'open'
            else:
                continue
            
            results.append({
                'variety_id': t,
                'variety_name': hk_type.get('name', t),
                'variety_class': 'hyperkähler',
                'h_2_2_used': estimated_h22,
                'h_2_2_source': 'estimated from b_2',
                'known_algebraic_codim_2': known,
                'tension_index': tension,
                'tension_ratio': round(ratio, 4),
                'hc_codim_2_status': hc_status,
            })
        
        # Sort by tension descending
        results.sort(key=lambda r: -r['tension_index'])
        
        # Display
        section("CODIM-2 TENSION INDEX (sorted by gap size)")
        rows = []
        for r in results[:20]:
            tension = r['tension_index']
            color = (C.cyan if tension > 500 else
                     C.warn if tension > 50 else
                     C.green if tension <= 0 else C.muted)
            rows.append((
                r['variety_id'][:26],
                str(r['h_2_2_used'])[:8],
                str(r['known_algebraic_codim_2'])[:8],
                color(f"{tension:+d}"),
                f"{r['tension_ratio']*100:.1f}%",
                r['hc_codim_2_status'][:12],
            ))
        summary_table(rows, ['Variety', 'Total Hdg', 'Known alg', 'Tension', '%', 'HC@2'],
                      fmt=['<26', '<10', '<10', '<10', '<8', '<14'])
        
        section("RANKED COUNTEREXAMPLE CANDIDATES (highest tension first)")
        for i, r in enumerate(results[:5], 1):
            tension = r['tension_index']
            if tension > 0:
                print(f"  {i}. {C.cyan(r['variety_id'])}")
                print(f"     h^{{2,2}} = {r['h_2_2_used']}, "
                      f"known algebraic = {r['known_algebraic_codim_2']}, "
                      f"gap = {tension} ({r['tension_ratio']*100:.0f}%)")
                print(f"     {C.muted(r.get('variety_name', ''))}")
        
        section("INTERPRETATION")
        print(f"  Tension index = (total Hodge-(2,2) classes) − (known algebraic constructions).")
        print(f"  A high tension does NOT imply a counterexample to HC. It implies that ")
        print(f"  {C.warn('current methods fall short of constructing the cycles HC predicts must exist')}.")
        print()
        print(f"  Top candidates for counterexample search OR for new cycle-construction methods:")
        for r in results[:3]:
            if r['tension_index'] > 0:
                print(f"    • {C.cyan(r['variety_id'])}: gap of {r['tension_index']} cycles unexplained")
        
        # Save
        step(3, 3, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'tension_index.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
            writer.writeheader()
            for r in results:
                writer.writerow(r)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'tension_index.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 33,
                'data': results,
                'summary': {
                    'total_varieties': len(results),
                    'highest_tension': results[0]['variety_id'] if results else None,
                    'max_tension_value': results[0]['tension_index'] if results else 0,
                    'mean_tension_ratio': round(sum(r['tension_ratio'] for r in results) / len(results), 4)
                                           if results else 0,
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(results), items_total=len(results),
                       artifacts=['tension_index.csv', 'tension_index.json'])
        print()
        print(C.green("  ✓ ch_33_counterexample_search finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
