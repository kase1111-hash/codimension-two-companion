"""ch_33_counterexample_search — Tension index."""
from .compute import main
if __name__ == '__main__':
    main()
