"""ch_21_hassett_discriminants — Hassett discriminants for cubic 4-folds."""
from .compute import main

if __name__ == '__main__':
    main()
