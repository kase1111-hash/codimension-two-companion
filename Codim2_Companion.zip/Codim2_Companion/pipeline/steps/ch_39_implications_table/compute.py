#!/usr/bin/env python3
"""
ch_39_implications_table — Implications graph aggregator.

Compiles the logical-implication graph between conjectures in the
codim-2 ecosystem and reports which directions are known + cited.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress, load_upstream, is_step_complete


STEP_ID = 'ch_39_implications_table'


IMPLICATIONS = [
    # ── Standard conjecture chain ────────────────────────
    {'from': 'B(X)', 'to': 'C(X)', 'direction': 'one-way',
     'condition': 'always', 'reference': 'Grothendieck 1969',
     'note': 'Lefschetz standard → Künneth.'},
    {'from': 'C(X)', 'to': 'D(X)', 'direction': 'one-way',
     'condition': 'with B(X)', 'reference': 'Grothendieck 1969',
     'note': 'Künneth + Lefschetz → Hodge standard.'},
    {'from': 'D(X)', 'to': 'I(X)', 'direction': 'one-way',
     'condition': 'always', 'reference': 'Grothendieck 1969',
     'note': 'Hodge standard → hom = num.'},
    
    # ── Standard conjectures → HC ─────────────────────────
    {'from': 'D(X)', 'to': 'HC(X) at codim k for k ≤ (dim X)/2', 'direction': 'one-way',
     'condition': 'when both algebraic and numerical equivalence agree',
     'reference': 'Grothendieck; Lieberman 1968',
     'note': 'On codim ≤ n/2, D(X) implies HC.'},
    {'from': 'B(X) + D(X)', 'to': 'HC(X) at all codim', 'direction': 'one-way',
     'condition': 'with C(X)', 'reference': 'standard',
     'note': 'Together, standard conjectures imply HC.'},
    
    # ── Voevodsky nilpotence ─────────────────────────────
    {'from': 'Voevodsky(X)', 'to': 'B(X) + D(X)', 'direction': 'one-way',
     'condition': 'when also Lieberman B(X) holds', 'reference': 'Voevodsky 1995',
     'note': 'Voevodsky nilpotence + Lieberman → standard conjectures.'},
    {'from': 'Voevodsky(X)', 'to': 'I(X) = hom = num', 'direction': 'one-way',
     'condition': 'always', 'reference': 'Voevodsky 1995',
     'note': 'Smash nilpotence → hom = num.'},
    
    # ── Bloch-Srinivas ────────────────────────────────────
    {'from': 'CH_0(X)_Q trivial (RC)', 'to': 'HC(X) all codim + Voevodsky + B', 'direction': 'one-way',
     'condition': 'always for RC', 'reference': 'Bloch-Srinivas 1983',
     'note': 'Diagonal decomposition gives everything.'},
    
    # ── Tate ⇔ HC ─────────────────────────────────────────
    {'from': 'Tate(X)', 'to': 'HC(X)', 'direction': 'one-way (under MT)',
     'condition': 'when Mumford-Tate group of X is "Tate-Mumford reasonable"',
     'reference': 'Faltings; comparison theorems',
     'note': 'Tate conjecture for X over a number field K + MT-good → HC for X over C.'},
    {'from': 'HC(X) + comparison', 'to': 'Tate(X)', 'direction': 'one-way (under MT)',
     'condition': 'with structural hypotheses on MT group',
     'reference': 'Deligne; Andre',
     'note': 'HC for X + good comparison theorems → Tate. Usually goes via Kuga-Satake / motives.'},
    
    # ── GHC implications ──────────────────────────────────
    {'from': 'GHC(X) at top coniveau (c = k/2)', 'to': 'HC(X) at codim k', 'direction': 'equivalent',
     'condition': 'always', 'reference': 'Grothendieck 1969',
     'note': 'GHC at top coniveau = HC.'},
    {'from': 'GHC(X) at all coniveau', 'to': 'HC(X) + finer transcendence info', 'direction': 'one-way',
     'condition': 'always', 'reference': 'standard',
     'note': 'GHC is strictly stronger than HC.'},
    
    # ── Beilinson L-value ────────────────────────────────
    {'from': 'Beilinson C(X) at (k, n)', 'to': 'L-value order = rank-gap', 'direction': 'one-way',
     'condition': 'predicted', 'reference': 'Beilinson 1985',
     'note': 'Beilinson conjecture predicts L-value order. Verifies via regulator computation.'},
    
    # ── Kuga-Satake ──────────────────────────────────────
    {'from': 'HC(K3) at codim 1', 'to': 'HC(X) for K3-fibered X', 'direction': 'one-way',
     'condition': 'when X has explicit K3-fibration', 'reference': 'Voisin 1992, et al.',
     'note': 'Cycles on K3 lift to fibered varieties (Borcea-Voisin construction).'},
    {'from': 'HC(K3)', 'to': 'HC(cubic 4-fold, K3-associated)', 'direction': 'one-way',
     'condition': 'when cubic 4-fold has Hassett-special K3 associate',
     'reference': 'Kuznetsov 2010; Addington-Thomas 2014',
     'note': 'Hassett bridge from K3 to cubic 4-fold.'},
    
    # ── Specific abelian → HC ────────────────────────────
    {'from': 'Faltings (Tate(A) at codim 1)', 'to': 'B(A) + D(A) + HC(A)', 'direction': 'one-way',
     'condition': 'for abelian varieties', 'reference': 'Faltings 1983; Lieberman 1968',
     'note': 'Faltings + Lieberman gives full standard conjectures and HC for AV.'},
    {'from': 'CM-type (abelian variety)', 'to': 'HC(A)', 'direction': 'one-way',
     'condition': 'for CM AV', 'reference': 'Pohlmann 1968',
     'note': 'Pohlmann settled HC for CM abelian varieties.'},
]


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_39_implications_table — Implications Graph", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(IMPLICATIONS), preset=args.preset)
    
    try:
        # Light upstream
        step(1, 3, "Verifying upstream readiness ...")
        for u in ['ch_13_standard_conjectures_status', 'ch_36_standard_conjectures_atlas',
                  'ch_37_tate_conjecture_atlas']:
            print(f"    {'✓' if is_step_complete(u) else '✗'} {u}")
        
        # Display
        step(2, 3, "Compiling implications graph ...")
        section("LOGICAL IMPLICATIONS BETWEEN CONJECTURES")
        rows = []
        for imp in IMPLICATIONS:
            arrow = '⇔' if imp['direction'] == 'equivalent' else '→'
            rows.append((
                imp['from'][:38],
                arrow,
                imp['to'][:38],
                imp['reference'][:24],
            ))
        summary_table(rows, ['From', '', 'To', 'Reference'],
                      fmt=['<40', '<3', '<40', '<26'])
        
        section("KEY CHAINS")
        print(f"  {C.green('Standard chain (Grothendieck 1969)')}:")
        print(f"    B(X) → C(X) → D(X) → I(X)")
        print(f"    ↓")
        print(f"    HC(X) at codim k for k ≤ (dim X)/2")
        print()
        print(f"  {C.green('Voevodsky route')}:")
        print(f"    Voevodsky(X) + Lieberman → B(X) + D(X) → HC(X)")
        print()
        print(f"  {C.green('Bloch-Srinivas route (Fano / RC)')}:")
        print(f"    CH_0(X) trivial → diagonal decomp → HC + standard conjectures + Voevodsky")
        print()
        print(f"  {C.warn('Tate-Hodge bridge')}:")
        print(f"    Tate(X) ⟷ HC(X)  via Mumford-Tate group structure (Faltings, comparison)")
        print()
        print(f"  {C.warn('GHC')}:")
        print(f"    GHC(X) at top coniveau ≡ HC(X)")
        print(f"    GHC(X) at lower coniveau ⇒ finer transcendence info")
        print()
        print(f"  {C.warn('Beilinson route')}:")
        print(f"    Beilinson C(X) → L-value orders predicted by motivic rank gap")
        
        # Save
        step(3, 3, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'implications_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(IMPLICATIONS[0].keys()))
            writer.writeheader()
            for r in IMPLICATIONS:
                writer.writerow(r)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'implications_table.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 39,
                'data': IMPLICATIONS,
                'summary': {
                    'total_implications': len(IMPLICATIONS),
                    'one_way': sum(1 for i in IMPLICATIONS if i['direction'].startswith('one-way')),
                    'equivalences': sum(1 for i in IMPLICATIONS if i['direction'] == 'equivalent'),
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        # Markdown graph
        md_path = output_dir / 'implications_graph.md'
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write(build_implications_md(IMPLICATIONS))
        print(f"  {md_path.name}  ({md_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(IMPLICATIONS), items_total=len(IMPLICATIONS),
                       artifacts=['implications_table.csv',
                                  'implications_table.json',
                                  'implications_graph.md'])
        print()
        print(C.green("  ✓ ch_39_implications_table finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


def build_implications_md(implications) -> str:
    out = []
    out.append("# Conjecture Implications Graph\n\n")
    out.append("*Generated by `ch_39_implications_table`. Maps logical implications "
               "in the codim-2 ecosystem.*\n\n")
    
    out.append("## Master implication graph\n\n")
    out.append("```\n")
    out.append("                              CH_0(X) trivial (RC)\n")
    out.append("                                       │\n")
    out.append("                                       ▼\n")
    out.append("                          ┌────────────────────────────┐\n")
    out.append("                          │ Voevodsky nilpotence + B   │\n")
    out.append("                          └────────────┬───────────────┘\n")
    out.append("                                       │\n")
    out.append("                            ┌──────────┴──────────┐\n")
    out.append("                            ▼                     ▼\n")
    out.append("                         B(X)                  hom = num (I)\n")
    out.append("                          │\n")
    out.append("                          ▼\n")
    out.append("                         C(X)\n")
    out.append("                          │\n")
    out.append("                          ▼\n")
    out.append("                         D(X)\n")
    out.append("                          │\n")
    out.append("                          ▼\n")
    out.append("                        HC(X) at codim k\n")
    out.append("                          ⇕\n")
    out.append("                       GHC at top coniveau\n")
    out.append("                          ⟷ (under MT)\n")
    out.append("                        Tate(X) at codim k\n")
    out.append("                          │\n")
    out.append("                          ▼\n")
    out.append("                       Beilinson L*(H^*(X), n) order\n")
    out.append("```\n\n")
    
    out.append("## Implications table\n\n")
    out.append("| From | → | To | Condition | Reference |\n")
    out.append("|---|---|---|---|---|\n")
    for imp in implications:
        arrow = '⇔' if imp['direction'] == 'equivalent' else '→'
        out.append(f"| {imp['from']} | {arrow} | {imp['to']} | "
                   f"{imp['condition']} | {imp['reference']} |\n")
    
    return ''.join(out)


if __name__ == '__main__':
    main()
