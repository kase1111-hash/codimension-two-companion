"""ch_40_web_graph — Conjecture web visualization."""
from .compute import main
if __name__ == '__main__':
    main()
