#!/usr/bin/env python3
"""
ch_40_web_graph — Visualization of the codim-2 conjecture web.

Renders the full web of variety classes, conjectures, and implications
as an SVG node graph. Each variety class is a node colored by HC@2
status; each implication is an arrow.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step, C,
)
from registry import get_artifact_path, write_progress, load_upstream, is_step_complete


STEP_ID = 'ch_40_web_graph'


# Color scheme
SETTLED = '#285E61'
PARTIAL = '#ED8936'
OPEN = '#E53E3E'
NEUTRAL = '#94A3B8'


def status_color(status: str) -> str:
    if not status:
        return NEUTRAL
    s = status.lower()
    if 'settled' in s or 'trivial' in s:
        return SETTLED
    if 'partial' in s:
        return PARTIAL
    if 'open' in s:
        return OPEN
    return NEUTRAL


def render_web_svg(nodes: list, edges: list) -> str:
    """Render variety-class web as SVG."""
    W, H = 1400, 1000
    out = []
    out.append('<?xml version="1.0" encoding="UTF-8"?>')
    out.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
               f'viewBox="0 0 {W} {H}">')
    out.append(f'  <rect width="{W}" height="{H}" fill="white"/>')
    out.append(f'  <text x="{W/2}" y="30" text-anchor="middle" font-family="serif" '
               f'font-size="22" font-weight="bold" fill="#1F2937">'
               f'Codim-2 Conjecture Web</text>')
    out.append(f'  <text x="{W/2}" y="52" text-anchor="middle" font-family="serif" '
               f'font-size="13" fill="#6B7280">Variety classes (nodes) + implications (edges)'
               f'</text>')
    
    # Arrow head defs
    out.append('  <defs>')
    out.append('    <marker id="arrow" markerWidth="10" markerHeight="10" '
               'refX="9" refY="5" orient="auto">')
    out.append('      <path d="M0,0 L10,5 L0,10 Z" fill="#6B7280"/>')
    out.append('    </marker>')
    out.append('  </defs>')
    
    # Edges first (drawn under nodes)
    node_pos = {n['id']: (n['x'], n['y']) for n in nodes}
    for e in edges:
        if e['from'] not in node_pos or e['to'] not in node_pos:
            continue
        x1, y1 = node_pos[e['from']]
        x2, y2 = node_pos[e['to']]
        out.append(f'  <line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
                   f'stroke="#94A3B8" stroke-width="1.2" '
                   f'marker-end="url(#arrow)" opacity="0.7"/>')
    
    # Nodes
    for n in nodes:
        color = status_color(n.get('status', ''))
        r = 36
        out.append(f'  <circle cx="{n["x"]}" cy="{n["y"]}" r="{r}" '
                   f'fill="{color}" stroke="#1F2937" stroke-width="1.5"/>')
        # Label
        label_lines = _wrap_label(n['label'], 12)
        for i, line in enumerate(label_lines[:3]):
            ly = n['y'] - len(label_lines[:3]) * 6 + i * 12 + 4
            text_color = 'white' if color in (SETTLED,) else '#1F2937'
            out.append(f'  <text x="{n["x"]}" y="{ly}" text-anchor="middle" '
                       f'font-family="sans-serif" font-size="9" fill="{text_color}">'
                       f'{_xml_escape(line)}</text>')
    
    # Legend
    legend_y = H - 40
    out.append(f'  <text x="50" y="{legend_y - 15}" font-family="serif" font-size="14" '
               f'font-weight="bold" fill="#1F2937">HC@codim-2 status:</text>')
    items = [(SETTLED, 'settled'), (PARTIAL, 'partial'), (OPEN, 'open'), (NEUTRAL, '—')]
    lx = 50
    for color, label in items:
        out.append(f'  <circle cx="{lx + 10}" cy="{legend_y}" r="9" fill="{color}" '
                   f'stroke="#1F2937" stroke-width="1"/>')
        out.append(f'  <text x="{lx + 25}" y="{legend_y + 5}" font-family="serif" '
                   f'font-size="12" fill="#374151">{label}</text>')
        lx += 130
    
    out.append('</svg>')
    return '\n'.join(out)


def _wrap_label(text: str, max_chars: int) -> list:
    words = text.split()
    lines, cur, cur_len = [], [], 0
    for w in words:
        if cur_len + len(w) + 1 > max_chars and cur:
            lines.append(' '.join(cur))
            cur, cur_len = [w], len(w)
        else:
            cur.append(w)
            cur_len += len(w) + 1
    if cur:
        lines.append(' '.join(cur))
    return lines


def _xml_escape(s: str) -> str:
    return (s.replace('&', '&amp;').replace('<', '&lt;')
             .replace('>', '&gt;').replace('"', '&quot;'))


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_40_web_graph — Conjecture Web Visualization", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Load master atlas
        step(1, 3, "Loading ch_36 master atlas ...")
        atlas = load_upstream('ch_36_standard_conjectures_atlas',
                              'standard_conjectures_atlas.json')
        classes = atlas['data']
        print(f"    {len(classes)} variety classes loaded")
        
        write_progress(STEP_ID, status='running', items_done=0,
                       items_total=len(classes), preset=args.preset)
        
        # Build node + edge structure
        step(2, 3, "Building web graph ...")
        
        # Position nodes — group by HC@2 status
        nodes = []
        positions = {
            'settled': {'col_x': 250, 'next_y': 130, 'dy': 90},
            'partial': {'col_x': 700, 'next_y': 130, 'dy': 90},
            'open':    {'col_x': 1150, 'next_y': 130, 'dy': 90},
        }
        for cls in classes:
            hc2 = cls.get('HC@2', '?').lower()
            if 'settled' in hc2 or 'trivial' in hc2:
                bucket = 'settled'
            elif 'partial' in hc2:
                bucket = 'partial'
            elif 'open' in hc2:
                bucket = 'open'
            else:
                bucket = 'partial'  # default
            
            p = positions[bucket]
            nodes.append({
                'id': cls['variety_class'],
                'label': cls['variety_class'],
                'status': hc2,
                'x': p['col_x'],
                'y': p['next_y'],
            })
            p['next_y'] += p['dy']
        
        # Edges: structural relationships
        # K3 → K3-related classes; abelian → CM cases; Fano → cubic 4-fold (RC)
        edges = [
            {'from': 'K3 surfaces', 'to': 'cubic 4-folds (K3-associated)',
             'label': 'Hassett bridge'},
            {'from': 'K3 surfaces', 'to': 'hyperkähler K3^[n]', 'label': 'Hilbert scheme'},
            {'from': 'abelian varieties', 'to': 'hyperkähler OG-6', 'label': 'O\'Grady from AV'},
            {'from': 'K3 surfaces', 'to': 'hyperkähler OG-10', 'label': 'O\'Grady from K3'},
            {'from': 'Fano 4-folds (rationally connected)', 'to': 'cubic 4-folds (K3-associated)',
             'label': 'Bloch-Srinivas'},
            {'from': 'cubic 4-folds (K3-associated)', 'to': 'cubic 4-folds (generic)',
             'label': 'specialization'},
            {'from': 'CY 4-folds (special families)', 'to': 'CY 4-folds (generic sextic / c.i.)',
             'label': 'degeneration'},
        ]
        
        # Filter edges to existing nodes
        node_ids = {n['id'] for n in nodes}
        edges = [e for e in edges if e['from'] in node_ids and e['to'] in node_ids]
        
        # Render
        svg = render_web_svg(nodes, edges)
        svg_path = output_dir / 'web_graph.svg'
        with open(svg_path, 'w', encoding='utf-8') as f:
            f.write(svg)
        
        # PNG render — optional. Requires libcairo native library.
        # Windows users without GTK+ runtime will hit OSError on dlopen;
        # in that case we skip PNG and ship just the SVG (which is the
        # primary visualization anyway — PDF embedding uses the SVG too).
        png_path = None
        try:
            import cairosvg
            png_path = output_dir / 'web_graph.png'
            cairosvg.svg2png(url=str(svg_path), write_to=str(png_path), output_width=1400)
        except (ImportError, OSError) as e:
            print(f"  ⚠ PNG render skipped: {type(e).__name__}: {str(e).splitlines()[0]}")
            print(f"     (Install GTK+ runtime to get libcairo on Windows, or "
                  f"ignore — SVG is the primary visualization.)")
            png_path = None
        
        # JSON description
        json_path = output_dir / 'web_graph.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 40,
                'nodes': nodes,
                'edges': edges,
                'summary': {
                    'total_nodes': len(nodes),
                    'total_edges': len(edges),
                    'n_settled': sum(1 for n in nodes if 'settled' in n['status']),
                    'n_partial': sum(1 for n in nodes if 'partial' in n['status']),
                    'n_open': sum(1 for n in nodes if 'open' in n['status']),
                },
            }, f, indent=2)
        
        section("WEB GRAPH STRUCTURE")
        print(f"  Total nodes: {len(nodes)}")
        print(f"  Total edges: {len(edges)}")
        print(f"  {C.green('Settled bucket')}: {sum(1 for n in nodes if 'settled' in n['status'])}")
        print(f"  {C.warn('Partial bucket')}:  {sum(1 for n in nodes if 'partial' in n['status'])}")
        print(f"  {C.cyan('Open bucket')}:     {sum(1 for n in nodes if 'open' in n['status'])}")
        
        section("BRIDGES (edges connecting settled → open classes)")
        for e in edges:
            from_node = next((n for n in nodes if n['id'] == e['from']), None)
            to_node = next((n for n in nodes if n['id'] == e['to']), None)
            if from_node and to_node:
                f_set = 'settled' in from_node['status']
                t_set = 'settled' in to_node['status']
                if f_set and not t_set:
                    print(f"  {C.cyan('→')} {e['from'][:30]:<32} → {e['to'][:30]:<32} "
                          f"({C.muted(e['label'])})")
        
        # Save
        step(3, 3, "Writing outputs ...")
        section("OUTPUT FILES")
        for p in sorted(output_dir.glob('*')):
            if p.name != 'progress.json':
                print(f"  {p.name}  ({p.stat().st_size/1024:.1f} KB)")
        
        artifacts = ['web_graph.svg', 'web_graph.json']
        if png_path:
            artifacts.append('web_graph.png')
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(classes), items_total=len(classes),
                       artifacts=artifacts)
        print()
        print(C.green("  ✓ ch_40_web_graph finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
