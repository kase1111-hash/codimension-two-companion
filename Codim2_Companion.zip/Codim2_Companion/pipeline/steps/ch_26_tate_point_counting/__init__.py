"""ch_26_tate_point_counting — Surface point counting and Tate detection."""
from .compute import main
if __name__ == '__main__':
    main()
