#!/usr/bin/env python3
"""
ch_26_tate_point_counting — Tate point counting on surfaces.

Implements naive point-counting for two families of surfaces over F_p:

  1. Diagonal quartic K3 surfaces: x^4 + y^4 + z^4 + w^4 = 0 in P^3
     (and twisted variants x^4 + y^4 + z^4 + c·w^4 for c ∈ F_p^*)

  2. Products of elliptic curves E_1 × E_2 (abelian surfaces)

For each (surface, p), counts #X(F_p) by enumerating all
[x : y : z : w] ∈ P^3(F_p) and testing the defining equation.
This is O(p^3) naive (or O(p^2) projective).

Frobenius polynomial extraction on H^2 then proceeds via the Weil
conjectures applied to #X(F_p), #X(F_{p^2}), ... — Ch 14's elliptic
framework gives a partial sketch but surfaces need higher-degree
recursion (P_2 has degree b_2 = 22 for K3, 6 for abelian surfaces).

For computational tractability at p ≤ 31, we count #X(F_p) directly
and report the Frobenius trace at H^2; full Frobenius polynomial
extraction needs counts at F_{p^k} for k = 1, .., b_2/2 — at p=11,
this requires #X(F_{11^11}) which is computationally infeasible
without algorithmic improvements. So this step does **partial Tate
detection**: it identifies p where the Frobenius trace on H^2 hints
at extra algebraic cycles, without claiming full eigenvalue
determination.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import multiprocessing as mp
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    parallel_map, summary_table, C, debug, Timer,
)
from registry import get_artifact_path, write_progress

# Import the ch_14 framework
sys.path.insert(0, str(Path(__file__).parent.parent / 'ch_14_tate_mirror_framework'))
from framework import (
    count_points_elliptic, frobenius_trace_elliptic,
    frobenius_polynomial_elliptic, frobenius_eigenvalues_from_poly,
    hasse_bound_holds,
)


STEP_ID = 'ch_26_tate_point_counting'


# ═══════════════════════════════════════════════════════════════════
#  POINT COUNTING — DIAGONAL QUARTIC K3
# ═══════════════════════════════════════════════════════════════════

def count_points_diag_quartic_K3(c1: int, c2: int, c3: int, c4: int, p: int) -> int:
    """Count #X(F_p) for X = V(c_1 x^4 + c_2 y^4 + c_3 z^4 + c_4 w^4) ⊂ P^3.
    
    Projective count: enumerate affine charts and dehomogenize.
    For p ≤ 23, this is fast (~10^5 operations).
    """
    # Affine 4-tuples on the quartic
    count = 0
    for x in range(p):
        for y in range(p):
            for z in range(p):
                for w in range(p):
                    val = (c1*x**4 + c2*y**4 + c3*z**4 + c4*w**4) % p
                    if val == 0 and not (x == 0 and y == 0 and z == 0 and w == 0):
                        count += 1
    # Projective count: divide affine zeros (excluding origin) by (p-1)
    return count // (p - 1)


def count_points_diag_quartic_K3_fast(c1: int, c2: int, c3: int, c4: int, p: int) -> int:
    """Faster count via Gauss-sum character formula or precomputed quartic
    residues. For small p we use a precomputed quartic-residue table.
    
    For the diagonal quartic, character-sum methods give explicit formulas
    in terms of Jacobi sums. But for small p we just do the naive count.
    """
    # Precompute 4th powers mod p
    fourth_powers = [(x ** 4) % p for x in range(p)]
    
    # Count affine quadruples (x,y,z,w) with c_1 x^4 + ... = 0
    count = 0
    for x4 in fourth_powers:
        cx = (c1 * x4) % p
        for y4 in fourth_powers:
            cy = (c2 * y4) % p
            for z4 in fourth_powers:
                cz = (c3 * z4) % p
                # Want: c_1 x^4 + c_2 y^4 + c_3 z^4 + c_4 w^4 ≡ 0
                # i.e., c_4 w^4 ≡ -(cx + cy + cz) (mod p)
                target = (-(cx + cy + cz)) % p
                # Count w ∈ F_p with c_4 w^4 ≡ target
                if c4 % p == 0:
                    if target == 0:
                        count += p  # all w work
                    # else: no w works
                else:
                    # Need w^4 ≡ target / c_4
                    rhs = (target * pow(c4, -1, p)) % p
                    if rhs == 0:
                        count += 1  # w = 0
                    else:
                        # Count w with w^4 = rhs
                        n_quartic_roots = sum(1 for w in range(1, p) if (w**4) % p == rhs)
                        count += n_quartic_roots
    # Subtract origin (x=y=z=w=0)
    if all(c % p == 0 for c in [c1, c2, c3, c4]):
        # all points on origin satisfy — but we want projective count
        pass
    # The origin (0,0,0,0) is always a solution but not a projective point.
    # Subtract it.
    count -= 1
    # Divide by (p-1) for projective
    return count // (p - 1)


# ═══════════════════════════════════════════════════════════════════
#  ABELIAN SURFACE A = E_1 × E_2
# ═══════════════════════════════════════════════════════════════════

def count_points_E1_x_E2(a1: int, b1: int, a2: int, b2: int, p: int) -> int:
    """#A(F_p) where A = E_1 × E_2, E_i: y^2 = x^3 + a_i x + b_i."""
    n1 = count_points_elliptic(a1, b1, p)
    n2 = count_points_elliptic(a2, b2, p)
    if n1 is None or n2 is None:
        return None
    return n1 * n2


def frobenius_trace_E1_x_E2(a1: int, b1: int, a2: int, b2: int, p: int):
    """Frobenius trace data for A = E_1 × E_2 on H^*.
    
    For product surface, Frobenius polynomial on H^k(A) is products of
    Frobenius eigenvalues from E_1 and E_2. In particular, H^2(A) has
    Frobenius eigenvalues: {α_i β_j, α_i α'_j conjugates, etc.}
    
    Returns: dict with H^1 traces, H^2 trace, etc.
    """
    a_p1 = frobenius_trace_elliptic(a1, b1, p)
    a_p2 = frobenius_trace_elliptic(a2, b2, p)
    if a_p1 is None or a_p2 is None:
        return None
    # H^1(A) = H^1(E_1) ⊕ H^1(E_2) → trace = a_p1 + a_p2
    h1_trace = a_p1 + a_p2
    # H^2(A) = H^2(E_1) ⊕ H^2(E_2) ⊕ (H^1(E_1) ⊗ H^1(E_2))
    # Frobenius on H^2(E_i) is p (top class); on the cross term, trace is a_p1 * a_p2
    h2_trace = 2 * p + a_p1 * a_p2
    return {
        'a_p_E1': a_p1,
        'a_p_E2': a_p2,
        'h1_trace': h1_trace,
        'h2_trace': h2_trace,
    }


# ═══════════════════════════════════════════════════════════════════
#  TEST SURFACES
# ═══════════════════════════════════════════════════════════════════

# K3 surfaces (diagonal quartics)
K3_TEST_SET = [
    {'id': 'Fermat_quartic', 'kind': 'diag_quartic', 'coeffs': (1, 1, 1, 1),
     'note': 'Fermat quartic (singular K3 with Picard 20)'},
    {'id': 'Quartic_x4y4z4_2w4', 'kind': 'diag_quartic', 'coeffs': (1, 1, 1, 2),
     'note': 'Twisted Fermat-like quartic'},
    {'id': 'Quartic_x4y4_-z4w4', 'kind': 'diag_quartic', 'coeffs': (1, 1, -1, -1),
     'note': 'Sign-twisted quartic'},
]

# Abelian surfaces (products of elliptic curves)
AV_TEST_SET = [
    {'id': 'A_cm_cm', 'kind': 'product', 'curves': ((-1, 0), (0, 1)),
     'note': 'CM(Z[i]) × CM(Z[ζ_3]) — should have Picard rank ≥ 2 on A'},
    {'id': 'A_cm_ord', 'kind': 'product', 'curves': ((-1, 0), (1, 1)),
     'note': 'CM × ordinary'},
    {'id': 'A_ord_ord', 'kind': 'product', 'curves': ((1, 1), (2, -1)),
     'note': 'Generic abelian surface (ordinary × ordinary)'},
    {'id': 'A_E_E_isog', 'kind': 'product', 'curves': ((-1, 0), (-1, 0)),
     'note': 'E × E for E with CM by Z[i] — extra Picard structure'},
]


# ═══════════════════════════════════════════════════════════════════
#  WORKER
# ═══════════════════════════════════════════════════════════════════

def worker(item: dict) -> dict:
    """Count points and extract Frobenius data for one (surface, p) pair."""
    try:
        debug(f"Worker: {item['id']} at p={item['p']}")
        p = item['p']
        if item['kind'] == 'diag_quartic':
            c1, c2, c3, c4 = item['coeffs']
            n_X = count_points_diag_quartic_K3_fast(c1, c2, c3, c4, p)
            # For smooth proj K3 surface (b_1 = b_3 = 0):
            #   #X(F_p) = tr(F|H^0) - tr(F|H^1) + tr(F|H^2) - tr(F|H^3) + tr(F|H^4)
            #          = 1     - 0          + tr(F|H^2) - 0          + p^2
            # So tr(F | H^2) = #X(F_p) - 1 - p^2
            expected_constant = p**2 + 1
            h2_trace = n_X - expected_constant
            # For a K3, eigenvalues on H^2 satisfy |α| = p, and there are 22 of them.
            # If h2_trace = k * p for some integer k, then k counts the "algebraic part"
            # eigenvalues that equal +p (Tate classes at codim 1).
            # By Weil bound: |h2_trace| ≤ 22 * p
            tate_classes_estimate = h2_trace / p if p > 0 else None
            return {
                **item,
                'n_X_F_p': n_X,
                'h2_trace': h2_trace,
                'tate_classes_lower_bound': tate_classes_estimate,
                'weil_bound_h2': 22 * p,
                'weil_ok': abs(h2_trace) <= 22 * p,
            }
        elif item['kind'] == 'product':
            (a1, b1), (a2, b2) = item['curves']
            data = frobenius_trace_E1_x_E2(a1, b1, a2, b2, p)
            if data is None:
                return {**item, 'error': 'point counting failed'}
            n_A = count_points_E1_x_E2(a1, b1, a2, b2, p)
            # For abelian surface: #A(F_p) = (p+1-a_p_E1)(p+1-a_p_E2)
            # b_2(A) = 6, so 6 eigenvalues on H^2, each of magnitude p
            # h2_trace = 2p + a_p_E1 * a_p_E2 (computed)
            h2_trace = data['h2_trace']
            tate_classes = h2_trace / p if p > 0 else None
            return {
                **item,
                'a_p_E1': data['a_p_E1'],
                'a_p_E2': data['a_p_E2'],
                'n_A_F_p': n_A,
                'h2_trace': h2_trace,
                'tate_classes_lower_bound': tate_classes,
                'weil_bound_h2': 6 * p,
                'weil_ok': abs(h2_trace) <= 6 * p,
            }
        else:
            return {**item, 'error': f"unknown kind {item['kind']}"}
    except Exception as e:
        return {**item, 'error': str(e)}


def build_work_list(p_max: int) -> list:
    """One work item per (surface, prime)."""
    primes = [p for p in [5, 7, 11, 13, 17, 19, 23, 29, 31] if p <= p_max]
    work = []
    for surf in K3_TEST_SET:
        for p in primes:
            work.append({**surf, 'p': p})
    for surf in AV_TEST_SET:
        for p in primes:
            work.append({**surf, 'p': p})
    return work


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    parser.add_argument('--p-max', type=int, default=None)
    args = parser.parse_args()
    args = resolve_args(args)
    
    p_max_map = {'quick': 13, 'standard': 19, 'long': 31}
    if args.p_max is None:
        args.p_max = p_max_map.get(args.preset, 19)
    
    banner("ch_26_tate_point_counting — Surface Point Counting", {
        'p_max': args.p_max,
        'workers': args.workers,
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    work = build_work_list(args.p_max)
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(work), preset=args.preset)
    
    try:
        step(1, 3, f"Counting {len(work)} (surface, prime) pairs on "
                   f"{args.workers} worker(s) ...")
        with Timer("Surface point counting"):
            results = parallel_map(worker, work, args.workers, desc="Surface × p")
        write_progress(STEP_ID, items_done=len(results), items_total=len(work))
        
        good = [r for r in results if 'error' not in r]
        errors = [r for r in results if 'error' in r]
        
        step(2, 3, "Analyzing ...")
        section("WEIL BOUND VERIFICATION")
        n_weil_ok = sum(1 for r in good if r.get('weil_ok'))
        print(f"  Total (surface, p) pairs:  {len(good)}")
        print(f"  {C.green('Weil bound holds')}:        {n_weil_ok}/{len(good)} "
              f"({100*n_weil_ok/max(len(good),1):.1f}%)")
        
        section("SAMPLE FROBENIUS TRACES")
        # Group by surface, show traces across primes
        by_surface = {}
        for r in good:
            by_surface.setdefault(r['id'], []).append(r)
        for sid, rows in list(by_surface.items())[:5]:
            print(f"  {C.highlight(sid)}")
            for r in rows[:5]:
                p = r['p']
                h2 = r.get('h2_trace')
                tate = r.get('tate_classes_lower_bound')
                ok = '✓' if r.get('weil_ok') else '✗'
                print(f"    p={p:>3}: h^2 trace = {h2:>+5}, "
                      f"Tate-class estimate = {tate:>+5.2f}, "
                      f"|H^2 trace| ≤ {r.get('weil_bound_h2', '?')}  {ok}")
        
        # Tate-class hints
        section("ALGEBRAIC CYCLE DETECTION (heuristic)")
        print(f"  When h^2 trace = k·p with k a large positive integer, the K3 / abelian")
        print(f"  surface likely has ≥ k algebraic divisor classes appearing over F_p")
        print(f"  (Tate conjecture at codim 1).")
        for sid, rows in list(by_surface.items())[:5]:
            ks = [round(r.get('tate_classes_lower_bound') or 0)
                  for r in rows if r.get('tate_classes_lower_bound') is not None]
            if ks:
                avg_k = sum(ks) / len(ks)
                print(f"    {sid:<25}  avg(k) ≈ {avg_k:.2f}")
        
        # ── SATO-TATE DISTRIBUTION CHECK ──────────────────────────────
        # For a non-CM elliptic curve E, the normalized Frobenius traces
        # x_p = a_p / (2√p) ∈ [-1, 1] should distribute according to the
        # semicircle law (2/π)√(1-x²) dx as p → ∞ (Sato-Tate conjecture,
        # proved by Taylor et al. 2008). For abelian-surface point counts
        # E_1 × E_2, the H^1 traces a_p_E1 and a_p_E2 should individually
        # follow Sato-Tate; their PRODUCT (which contributes to h^2_trace)
        # gives a derived distribution. This is a sanity check on the
        # point-count arithmetic.
        section("SATO-TATE DISTRIBUTION CHECK")
        import math
        from collections import defaultdict
        # Group elliptic-curve traces by curve
        curve_traces = defaultdict(list)  # curve_label → [(p, a_p)]
        for r in good:
            if r.get('kind') == 'product':
                p = r['p']
                a1 = r.get('a_p_E1')
                a2 = r.get('a_p_E2')
                cv1, cv2 = r.get('curves', [(None, None), (None, None)])
                if a1 is not None:
                    curve_traces[f"E({cv1[0]},{cv1[1]})"].append((p, a1))
                if a2 is not None:
                    curve_traces[f"E({cv2[0]},{cv2[1]})"].append((p, a2))
        
        # For each curve, compute normalized x_p and report the bin counts
        # in [-1, -0.5), [-0.5, 0), [0, 0.5), [0.5, 1]
        st_summary = {}
        any_st = False
        for curve, pts in curve_traces.items():
            if len(pts) < 3:
                continue
            any_st = True
            xs = []
            for p, a_p in pts:
                if p > 0:
                    x = a_p / (2 * math.sqrt(p))
                    xs.append(x)
            # Bin into quartiles
            bins = [0, 0, 0, 0]  # [-1,-0.5), [-0.5,0), [0,0.5), [0.5,1]
            in_bound = 0
            for x in xs:
                if abs(x) <= 1.0001:
                    in_bound += 1
                    if x < -0.5: bins[0] += 1
                    elif x < 0:  bins[1] += 1
                    elif x < 0.5: bins[2] += 1
                    else: bins[3] += 1
            mean_x = sum(xs) / len(xs) if xs else 0
            # Semicircle predicts mean 0, but with few samples we just check
            # |x_p| ≤ 1 (Hasse-Weil bound, which IS Sato-Tate's domain).
            hasse_ok = (in_bound == len(xs))
            st_summary[curve] = {
                'n_samples': len(xs),
                'mean_normalized_trace': round(mean_x, 4),
                'hasse_weil_bound_holds': hasse_ok,
                'quartile_counts': bins,
            }
            print(f"  {curve:<14} n={len(xs):>3}  mean(a_p/2√p) = {mean_x:>+.3f}  "
                  f"|x|≤1: {'✓' if hasse_ok else '✗'}  bins {bins}")
        if not any_st:
            print(f"  (insufficient elliptic-curve samples at preset='{args.preset}'; "
                  f"increase p_max or use 'long' preset)")
        else:
            print(f"  Sato-Tate predicts mean(x_p) → 0 and quartile counts → "
                  f"(~21%, ~29%, ~29%, ~21%) of total as p → ∞.")
            print(f"  For finite samples at small p, large deviations are normal; "
                  f"this is a Hasse-Weil sanity check, not a rigorous Sato-Tate test.")
        
        # Save
        step(3, 3, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'surface_point_counts.csv'
        all_keys = set()
        for r in good:
            all_keys.update(r.keys())
        keys = sorted(all_keys - {'curves', 'coeffs'})
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
            writer.writeheader()
            for r in good:
                writer.writerow(r)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'surface_point_counts.json'
        # Make JSON serializable (tuples → lists)
        json_data = []
        for r in good:
            cleaned = {}
            for k, v in r.items():
                if isinstance(v, tuple):
                    cleaned[k] = list(v)
                else:
                    cleaned[k] = v
            json_data.append(cleaned)
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 26,
                'p_max': args.p_max,
                'data': json_data,
                'sato_tate_summary': st_summary,
                'summary': {
                    'total_pairs': len(good),
                    'errors': len(errors),
                    'weil_bound_ok': n_weil_ok,
                    'sato_tate_curves_analyzed': len(st_summary),
                    'hasse_weil_universally_holds': all(
                        v.get('hasse_weil_bound_holds', False)
                        for v in st_summary.values()),
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(good), items_total=len(work),
                       errors=len(errors),
                       artifacts=['surface_point_counts.csv',
                                  'surface_point_counts.json'])
        print()
        print(C.green("  ✓ ch_26_tate_point_counting finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    mp.freeze_support()
    main()
