"""ch_17_voevodsky_status — Voevodsky nilpotence status by variety class."""
from .compute import main

if __name__ == '__main__':
    main()
