#!/usr/bin/env python3
"""
ch_24_moduli_status — Hodge conjecture status on moduli spaces.

Moduli space HC status depends on Kodaira dimension:
  - Rational / unirational moduli → HC settled trivially.
  - General-type moduli → HC widely open.

For M_g (moduli of curves of genus g):
  - g ≤ 14: unirational (Severi, then Eisenbud, Verra) → HC settled.
  - g ≥ 24: general type (Harris-Mumford, Eisenbud-Harris) → HC open.
  - 15 ≤ g ≤ 23: intermediate; status mixed.

For A_g (moduli of principally polarized abelian g-folds):
  - g ≤ 5: unirational → HC settled.
  - g = 7: Wakabayashi 2007 unirationality.
  - g ≥ 8 or so: general type.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_24_moduli_status'


MODULI_SPACES = [
    # ── M_g moduli of curves ───────────────────────────────
    {'space': 'M_g', 'parameter': 'g=2', 'description': 'Genus 2 curves',
     'kodaira_dim': '-∞ (unirational)', 'hc_status': 'settled',
     'reference': 'classical / Igusa', 'note': 'Unirational.'},
    {'space': 'M_g', 'parameter': 'g=3', 'description': 'Genus 3 curves',
     'kodaira_dim': '-∞ (unirational)', 'hc_status': 'settled',
     'reference': 'classical', 'note': 'Unirational.'},
    {'space': 'M_g', 'parameter': 'g=4 to 6', 'description': 'Low-genus curves',
     'kodaira_dim': '-∞', 'hc_status': 'settled', 'reference': 'Severi-style'},
    {'space': 'M_g', 'parameter': 'g=14', 'description': 'Verra unirationality',
     'kodaira_dim': '-∞', 'hc_status': 'settled', 'reference': 'Verra 2005',
     'note': 'Last g with proven unirationality.'},
    {'space': 'M_g', 'parameter': 'g=15-23', 'description': 'Intermediate',
     'kodaira_dim': 'unknown', 'hc_status': 'open',
     'reference': '—', 'note': 'Kodaira dim and HC both open.'},
    {'space': 'M_g', 'parameter': 'g≥24', 'description': 'General-type curves',
     'kodaira_dim': 'general type (kod(M_g) = 3g-3)', 'hc_status': 'open',
     'reference': 'Harris-Mumford 1982; Eisenbud-Harris 1987'},
    
    # ── A_g moduli of abelian varieties ───────────────────
    {'space': 'A_g', 'parameter': 'g=1', 'description': 'Elliptic curves',
     'kodaira_dim': '-∞', 'hc_status': 'settled', 'reference': 'classical'},
    {'space': 'A_g', 'parameter': 'g=2-5', 'description': 'Low-dim PPAV',
     'kodaira_dim': '-∞ (unirational)', 'hc_status': 'settled',
     'reference': 'Donagi, Mori-Mukai', 'note': 'A_g unirational for g ≤ 5.'},
    {'space': 'A_g', 'parameter': 'g=6', 'description': 'PPAV of dim 6',
     'kodaira_dim': '-∞', 'hc_status': 'settled',
     'reference': 'Verra 2008 (unirationality)'},
    {'space': 'A_g', 'parameter': 'g=7', 'description': 'PPAV of dim 7',
     'kodaira_dim': '-∞', 'hc_status': 'settled',
     'reference': 'Wakabayashi 2007'},
    {'space': 'A_g', 'parameter': 'g≥8', 'description': 'High-dim PPAV',
     'kodaira_dim': 'general type', 'hc_status': 'open',
     'reference': 'Tai 1982; Mumford 1983'},
    
    # ── F_g K3 moduli ─────────────────────────────────────
    {'space': 'F_g', 'parameter': 'g=2-12', 'description': 'Polarized K3 moduli',
     'kodaira_dim': '-∞ (unirational)', 'hc_status': 'settled',
     'reference': 'Mukai 1988', 'note': 'Mukai models give unirationality.'},
    {'space': 'F_g', 'parameter': 'g=13, 16, 18, 20', 'description': 'K3 special-deg moduli',
     'kodaira_dim': 'unirational', 'hc_status': 'settled',
     'reference': 'various Mukai-type'},
    {'space': 'F_g', 'parameter': 'g≥40 (most)', 'description': 'High-degree K3 moduli',
     'kodaira_dim': 'general type', 'hc_status': 'open',
     'reference': 'Gritsenko-Hulek-Sankaran 2007'},
    
    # ── C_d Hassett special divisors (treated separately) ─
    {'space': 'C_d', 'parameter': 'd = 8, 12, 14, ...',
     'description': 'Hassett discriminant moduli (cubic 4-fold)',
     'kodaira_dim': 'varies', 'hc_status': 'see ch_21',
     'reference': 'Hassett 2000', 'note': 'Treated by ch_21_hassett_discriminants.'},
    
    # ── HK moduli ──────────────────────────────────────────
    {'space': 'M_{K3^[n]}_{2d}',
     'parameter': 'low (n, d)',
     'description': 'Polarized K3^[n] HK moduli (small case)',
     'kodaira_dim': 'often unirational',
     'hc_status': 'partial',
     'reference': 'Apostolov-Lehn 2020 et al.',
     'note': 'Some explicit cases unirational.'},
    {'space': 'M_{OG-10}',
     'parameter': 'general',
     'description': 'OG-10 HK moduli',
     'kodaira_dim': 'unknown',
     'hc_status': 'open',
     'reference': '—'},
    
    # ── Hurwitz schemes ────────────────────────────────────
    {'space': 'H_{g, d}', 'parameter': 'low d, g',
     'description': 'Hurwitz scheme: degree-d covers of P^1 by genus-g curves',
     'kodaira_dim': '-∞ (rational for small d)', 'hc_status': 'settled',
     'reference': 'classical'},
    
    # ── M_g,n marked curves ────────────────────────────────
    {'space': 'M_{g,n}', 'parameter': 'g=0',
     'description': 'Marked rational curves (Deligne-Mumford)',
     'kodaira_dim': '-∞ (rational)', 'hc_status': 'settled',
     'reference': 'classical', 'note': 'Smooth projective varieties; HC via direct cycles.'},
]


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_24_moduli_status — Moduli Space HC Status", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(MODULI_SPACES), preset=args.preset)
    
    try:
        # Display
        step(1, 2, "Compiling moduli status ...")
        section("MODULI SPACE HODGE CONJECTURE STATUS")
        rows = []
        for m in MODULI_SPACES:
            status = m['hc_status']
            color = (C.green if status == 'settled' else
                     C.warn if status in ('partial', 'see ch_21') else C.cyan)
            rows.append((
                m['space'][:14],
                m['parameter'][:22],
                m['description'][:36],
                color(status[:10]),
            ))
        summary_table(rows, ['Space', 'Parameter', 'Description', 'HC'],
                      fmt=['<14', '<22', '<36', '<14'])
        
        section("PATTERN")
        # Counts
        n_settled = sum(1 for m in MODULI_SPACES if m['hc_status'] == 'settled')
        n_partial = sum(1 for m in MODULI_SPACES if 'partial' in m['hc_status'])
        n_open = sum(1 for m in MODULI_SPACES if m['hc_status'] == 'open')
        print(f"  {C.green('Settled')}:  {n_settled} cases (unirational / rational moduli)")
        print(f"  {C.warn('Partial')}:  {n_partial} cases")
        print(f"  {C.cyan('Open')}:     {n_open} cases (general-type moduli)")
        print()
        print(f"  {C.highlight('Rule of thumb')}: low-parameter moduli → unirational → HC settled.")
        print(f"  High-parameter (general type) → HC unconstrained → open.")
        print(f"  The transition for M_g happens around g ≈ 22-24 (Harris-Mumford boundary).")
        
        # Save
        step(2, 2, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'moduli_status.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            keys = list(MODULI_SPACES[0].keys())
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            for m in MODULI_SPACES:
                writer.writerow({k: m.get(k, '') for k in keys})
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'moduli_status.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 24,
                'data': MODULI_SPACES,
                'summary': {
                    'total': len(MODULI_SPACES),
                    'settled': n_settled,
                    'partial': n_partial,
                    'open': n_open,
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(MODULI_SPACES), items_total=len(MODULI_SPACES),
                       artifacts=['moduli_status.csv', 'moduli_status.json'])
        print()
        print(C.green("  ✓ ch_24_moduli_status finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
