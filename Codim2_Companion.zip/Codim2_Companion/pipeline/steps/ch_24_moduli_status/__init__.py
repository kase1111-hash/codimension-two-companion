"""ch_24_moduli_status — Moduli space HC status."""
from .compute import main
if __name__ == '__main__':
    main()
