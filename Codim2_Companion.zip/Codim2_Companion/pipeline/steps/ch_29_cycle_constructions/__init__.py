"""ch_29_cycle_constructions — Cycle construction atlas."""
from .compute import main
if __name__ == '__main__':
    main()
