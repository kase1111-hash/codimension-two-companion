"""ch_37_tate_conjecture_atlas — Tate atlas."""
from .compute import main
if __name__ == '__main__':
    main()
