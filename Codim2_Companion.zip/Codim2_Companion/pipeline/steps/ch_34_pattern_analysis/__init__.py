"""ch_34_pattern_analysis — Cross-cut pattern aggregator."""
from .compute import main
if __name__ == '__main__':
    main()
