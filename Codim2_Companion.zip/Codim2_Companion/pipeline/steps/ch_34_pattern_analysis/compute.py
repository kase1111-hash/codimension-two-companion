#!/usr/bin/env python3
"""
ch_34_pattern_analysis — Cross-cut pattern aggregator over the built atlas.

For each canonical variety class, build a "structural fingerprint":

  Feature              | What it captures
  ────────────────────────────────────────────────────────────────────────
  has_small_CH_0       | Rationally connected / Fano → BR diagonal works
  has_K3_lift          | Kuga-Satake / Hassett bridge applicable
  has_HK_structure     | BB form gives extra structure
  has_CM_motive        | Pohlmann settles HC (CM cases)
  has_trivial_J^2      | Codim-2 transcendence lives in H^{2,2}, not J^2
  has_griffiths_phen   | Codim-2 transcendence visible via Abel-Jacobi
  hc_codim_2_status    | settled / partial / open
  
Then cluster classes by fingerprint and report co-occurrences.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress, load_upstream


STEP_ID = 'ch_34_pattern_analysis'


FEATURES = [
    'has_small_CH_0',
    'has_K3_lift',
    'has_HK_structure',
    'has_CM_motive',
    'has_trivial_J2',
    'has_griffiths_phen',
    'has_BB_form',
    'has_arithmetic_special',
]


# Canonical variety classes and their structural fingerprints
# (Derived synthesizing the upstream atlases)
CANONICAL_CLASSES = [
    {
        'class': 'curves',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': False,
                        'has_HK_structure': False, 'has_CM_motive': 'sometimes',
                        'has_trivial_J2': 'vacuous', 'has_griffiths_phen': False,
                        'has_BB_form': False, 'has_arithmetic_special': False},
        'hc_codim_2': 'vacuous',
    },
    {
        'class': 'surfaces (smooth proj)',
        'fingerprint': {'has_small_CH_0': 'sometimes', 'has_K3_lift': False,
                        'has_HK_structure': False, 'has_CM_motive': False,
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': False, 'has_arithmetic_special': False},
        'hc_codim_2': 'settled (top class)',
    },
    {
        'class': 'K3 surface',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': True,
                        'has_HK_structure': True, 'has_CM_motive': 'sometimes (Pic 20)',
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': True, 'has_arithmetic_special': True},
        'hc_codim_2': 'settled (top class)',
    },
    {
        'class': 'abelian variety',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': False,
                        'has_HK_structure': False, 'has_CM_motive': 'sometimes',
                        'has_trivial_J2': False, 'has_griffiths_phen': True,
                        'has_BB_form': False, 'has_arithmetic_special': True},
        'hc_codim_2': 'settled (Lieberman/Pohlmann) — Mumford-type partial',
    },
    {
        'class': 'cubic 4-fold (K3-associated)',
        'fingerprint': {'has_small_CH_0': True, 'has_K3_lift': True,
                        'has_HK_structure': False, 'has_CM_motive': False,
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': False, 'has_arithmetic_special': True},
        'hc_codim_2': 'settled (Kuznetsov K3 category)',
    },
    {
        'class': 'cubic 4-fold (generic)',
        'fingerprint': {'has_small_CH_0': True, 'has_K3_lift': False,
                        'has_HK_structure': False, 'has_CM_motive': False,
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': False, 'has_arithmetic_special': False},
        'hc_codim_2': 'open',
    },
    {
        'class': 'hyperkähler K3^[n]',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': True,
                        'has_HK_structure': True, 'has_CM_motive': False,
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': True, 'has_arithmetic_special': False},
        'hc_codim_2': 'settled (Vial/Charles)',
    },
    {
        'class': 'hyperkähler OG-6',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': False,
                        'has_HK_structure': True, 'has_CM_motive': False,
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': True, 'has_arithmetic_special': False},
        'hc_codim_2': 'partial',
    },
    {
        'class': 'hyperkähler OG-10',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': False,
                        'has_HK_structure': True, 'has_CM_motive': False,
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': True, 'has_arithmetic_special': False},
        'hc_codim_2': 'open',
    },
    {
        'class': 'CY 3-fold (generic)',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': False,
                        'has_HK_structure': False, 'has_CM_motive': False,
                        'has_trivial_J2': False, 'has_griffiths_phen': True,
                        'has_BB_form': False, 'has_arithmetic_special': False},
        'hc_codim_2': 'partial (HL → codim 1)',
    },
    {
        'class': 'CY 3-fold (Borcea-Voisin)',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': True,
                        'has_HK_structure': False, 'has_CM_motive': False,
                        'has_trivial_J2': False, 'has_griffiths_phen': True,
                        'has_BB_form': False, 'has_arithmetic_special': True},
        'hc_codim_2': 'partial',
    },
    {
        'class': 'CY 4-fold (special families)',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': 'sometimes',
                        'has_HK_structure': False, 'has_CM_motive': 'sometimes',
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': False, 'has_arithmetic_special': True},
        'hc_codim_2': 'partial',
    },
    {
        'class': 'CY 4-fold (generic sextic / c.i.)',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': False,
                        'has_HK_structure': False, 'has_CM_motive': False,
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': False, 'has_arithmetic_special': False},
        'hc_codim_2': 'open(CENTRAL FRONTIER)',
    },
    {
        'class': 'Fano 4-fold (RC)',
        'fingerprint': {'has_small_CH_0': True, 'has_K3_lift': False,
                        'has_HK_structure': False, 'has_CM_motive': False,
                        'has_trivial_J2': True, 'has_griffiths_phen': False,
                        'has_BB_form': False, 'has_arithmetic_special': False},
        'hc_codim_2': 'settled (Bloch-Srinivas)',
    },
    {
        'class': 'general 4-fold',
        'fingerprint': {'has_small_CH_0': False, 'has_K3_lift': False,
                        'has_HK_structure': False, 'has_CM_motive': False,
                        'has_trivial_J2': 'depends', 'has_griffiths_phen': 'depends',
                        'has_BB_form': False, 'has_arithmetic_special': False},
        'hc_codim_2': 'open',
    },
]


def normalize_hc(s: str) -> str:
    if 'settled' in s:
        return 'settled'
    if 'partial' in s:
        return 'partial'
    if 'open' in s:
        return 'open'
    if 'vacuous' in s:
        return 'vacuous'
    return 'unknown'


def analyze_patterns(classes: list) -> dict:
    """Pattern statistics across the canonical classes."""
    # Count occurrences of each feature
    feature_counts = defaultdict(lambda: Counter())
    for cls in classes:
        for feat, val in cls['fingerprint'].items():
            if val is True:
                feature_counts[feat]['true'] += 1
            elif val is False:
                feature_counts[feat]['false'] += 1
            else:
                feature_counts[feat]['sometimes'] += 1
    
    # Feature × HC-status cross-tab
    feature_vs_hc = defaultdict(lambda: defaultdict(int))
    for cls in classes:
        hc = normalize_hc(cls['hc_codim_2'])
        for feat, val in cls['fingerprint'].items():
            if val is True:
                feature_vs_hc[feat][hc] += 1
    
    return {
        'feature_counts': {k: dict(v) for k, v in feature_counts.items()},
        'feature_vs_hc': {k: dict(v) for k, v in feature_vs_hc.items()},
    }


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_34_pattern_analysis — Cross-Part Pattern Aggregator", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(CANONICAL_CLASSES), preset=args.preset)
    
    try:
        # Light upstream verification (just count what's there)
        step(1, 4, "Verifying upstream readiness ...")
        upstream = ['ch_17_voevodsky_status', 'ch_18_abelian_status',
                    'ch_19_k3_atlas', 'ch_20_hyperkahler_classification',
                    'ch_21_hassett_discriminants', 'ch_22_cy_4fold_hodge_numbers',
                    'ch_23_fano_atlas', 'ch_24_moduli_status',
                    'ch_25_hyperkahler_lattices', 'ch_28_diagonal_decomposition',
                    'ch_29_cycle_constructions', 'ch_31_mumford_weil']
        n_ready = 0
        for u in upstream:
            from registry import is_step_complete
            if is_step_complete(u):
                n_ready += 1
        print(f"    Upstream ready: {n_ready}/{len(upstream)}")
        
        # Display fingerprints
        step(2, 4, "Compiling structural fingerprints ...")
        section("STRUCTURAL FINGERPRINTS BY VARIETY CLASS")
        rows = []
        for cls in CANONICAL_CLASSES:
            fp = cls['fingerprint']
            # Compact summary: count of TRUE features
            n_true = sum(1 for v in fp.values() if v is True)
            n_sometimes = sum(1 for v in fp.values()
                              if v not in (True, False))
            hc = cls['hc_codim_2']
            color = (C.green if 'settled' in hc else
                     C.warn if 'partial' in hc else
                     C.cyan if 'open' in hc else C.muted)
            rows.append((
                cls['class'][:34],
                str(n_true),
                str(n_sometimes),
                color(hc[:30]),
            ))
        summary_table(rows, ['Variety class', '# strong features', '# partial', 'HC@codim-2'],
                      fmt=['<34', '<18', '<10', '<32'])
        
        # Patterns
        step(3, 4, "Mining co-occurrence patterns ...")
        analysis = analyze_patterns(CANONICAL_CLASSES)
        
        section("FEATURE × HC-STATUS CROSS-TAB")
        rows2 = []
        for feat in FEATURES:
            cross = analysis['feature_vs_hc'].get(feat, {})
            total = sum(cross.values())
            n_settled = cross.get('settled', 0)
            n_partial = cross.get('partial', 0)
            n_open = cross.get('open', 0)
            if total > 0:
                rows2.append((
                    feat,
                    f"{n_settled}/{total}",
                    f"{n_partial}/{total}",
                    f"{n_open}/{total}",
                ))
        summary_table(rows2, ['Feature', 'Settled', 'Partial', 'Open'],
                      fmt=['<26', '<10', '<10', '<10'])
        
        section("PATTERN OBSERVATIONS")
        # Identify strong patterns
        print(f"  {C.green('Settling features')} (when present → mostly settled):")
        for feat in FEATURES:
            cross = analysis['feature_vs_hc'].get(feat, {})
            total = sum(cross.values())
            n_settled = cross.get('settled', 0)
            if total >= 2 and n_settled / total >= 0.66:
                print(f"    • {feat}: {n_settled}/{total} settled")
        
        print(f"\n  {C.warn('Risk features')} (high open count even when present):")
        for feat in FEATURES:
            cross = analysis['feature_vs_hc'].get(feat, {})
            total = sum(cross.values())
            n_open = cross.get('open', 0)
            if total >= 2 and n_open / total >= 0.5:
                print(f"    • {feat}: {n_open}/{total} open")
        
        # Key structural cluster
        section("KEY STRUCTURAL CLUSTERS")
        print(f"  {C.green('Cluster A — RC + small CH_0')}: Fano 4-folds, K3-associated cubic 4-folds.")
        print(f"     → HC settled via Bloch-Srinivas; one of the cleanest cluster of all.")
        print()
        print(f"  {C.green('Cluster B — K3-type Hodge structure + arithmetic special')}:")
        print(f"     K3 surfaces, K3^[n], abelian varieties, Hassett-special cubic 4-folds.")
        print(f"     → HC settled via Lefschetz / Kuga-Satake / Vial.")
        print()
        print(f"  {C.warn('Cluster C — HK with no K3-lift')}:")
        print(f"     OG-6, OG-10 — has BB form but lacks K3-bridge.")
        print(f"     → HC partial / open. Frontier cluster for the HK side.")
        print()
        print(f"  {C.cyan('Cluster D — Generic CY without structural shortcuts')}:")
        print(f"     CY 4-folds (sextic, c.i.), general 4-folds.")
        print(f"     → HC open. No small CH_0, no K3 lift, no HK structure, "
              f"no CM motive, no Griffiths-detectable J^2.")
        print(f"     → {C.highlight('THE central codim-2 frontier')}.")
        
        # Save
        step(4, 4, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'pattern_analysis.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            # Flatten fingerprint into columns
            base_fields = ['class', 'hc_codim_2']
            keys = base_fields + FEATURES
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            for cls in CANONICAL_CLASSES:
                row = {'class': cls['class'], 'hc_codim_2': cls['hc_codim_2']}
                for feat in FEATURES:
                    row[feat] = cls['fingerprint'].get(feat, '?')
                writer.writerow(row)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'pattern_analysis.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 34,
                'classes': CANONICAL_CLASSES,
                'analysis': analysis,
                'summary': {
                    'total_classes': len(CANONICAL_CLASSES),
                    'features_tracked': len(FEATURES),
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        # Markdown report
        md_path = output_dir / 'pattern_analysis.md'
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write(build_pattern_md(CANONICAL_CLASSES, analysis))
        print(f"  {md_path.name}  ({md_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(CANONICAL_CLASSES),
                       items_total=len(CANONICAL_CLASSES),
                       artifacts=['pattern_analysis.csv',
                                  'pattern_analysis.json',
                                  'pattern_analysis.md'])
        print()
        print(C.green("  ✓ ch_34_pattern_analysis finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


def build_pattern_md(classes, analysis) -> str:
    """Build markdown report."""
    out = []
    out.append("# Cross-Part Pattern Analysis\n\n")
    out.append("*Generated by `ch_34_pattern_analysis`. Synthesizes structural features "
               "across the variety atlas to identify cross-cutting patterns.*\n\n")
    
    out.append("## Structural fingerprints\n\n")
    out.append("| Variety class | small CH_0 | K3 lift | HK | CM | trivial J² | "
               "Griffiths | BB | arith. special | HC@2 |\n")
    out.append("|---|---|---|---|---|---|---|---|---|---|\n")
    for cls in classes:
        fp = cls['fingerprint']
        def cell(v):
            if v is True: return '✓'
            if v is False: return '·'
            return f"~ ({v})" if isinstance(v, str) else '?'
        out.append(f"| {cls['class']} | "
                   f"{cell(fp['has_small_CH_0'])} | "
                   f"{cell(fp['has_K3_lift'])} | "
                   f"{cell(fp['has_HK_structure'])} | "
                   f"{cell(fp['has_CM_motive'])} | "
                   f"{cell(fp['has_trivial_J2'])} | "
                   f"{cell(fp['has_griffiths_phen'])} | "
                   f"{cell(fp['has_BB_form'])} | "
                   f"{cell(fp['has_arithmetic_special'])} | "
                   f"{cls['hc_codim_2']} |\n")
    
    out.append("\n## Structural clusters\n\n")
    out.append("Four clusters emerge from the fingerprint analysis:\n\n")
    out.append("### A. RC + small CH_0 (settled cleanly)\n")
    out.append("**Members**: Fano 4-folds (RC), K3-associated cubic 4-folds\n\n")
    out.append("**Mechanism**: Bloch-Srinivas decomposition. The diagonal decomposes, "
               "all cohomology becomes algebraic.\n\n")
    
    out.append("### B. K3-type Hodge structure + arithmetic special (settled via bridges)\n")
    out.append("**Members**: K3 surfaces, K3^[n], abelian varieties\n\n")
    out.append("**Mechanism**: Kuga-Satake / Lefschetz / Lieberman / Vial.\n\n")
    
    out.append("### C. HK with no K3-lift (partial / open)\n")
    out.append("**Members**: OG-6, OG-10\n\n")
    out.append("**Mechanism**: BB form provides structure but no canonical bridge to "
               "K3 or abelian. Cycle constructions case-by-case.\n\n")
    
    out.append("### D. Generic CY / general 4-folds (CENTRAL FRONTIER)\n")
    out.append("**Members**: CY 4-folds (sextic / c.i.), general 4-folds\n\n")
    out.append("**Mechanism**: NONE — no small CH_0, no K3 lift, no HK structure, no CM motive, "
               "no Griffiths-detectable J². The codim-2 question lives directly in H^{2,2}(X) "
               "with no structural shortcut.\n\n")
    
    out.append("## Settling features\n\n")
    out.append("Features that, when present, predict HC@2 settlement:\n")
    for feat in FEATURES:
        cross = analysis['feature_vs_hc'].get(feat, {})
        total = sum(cross.values())
        n_settled = cross.get('settled', 0)
        if total >= 2 and n_settled / total >= 0.66:
            out.append(f"- **{feat}**: {n_settled}/{total} classes settled\n")
    
    out.append("\n## Risk features\n\n")
    out.append("Features that, when present, do not predict settlement (frontier features):\n")
    for feat in FEATURES:
        cross = analysis['feature_vs_hc'].get(feat, {})
        total = sum(cross.values())
        n_open = cross.get('open', 0)
        if total >= 2 and n_open / total >= 0.5:
            out.append(f"- **{feat}**: {n_open}/{total} classes open\n")
    
    return ''.join(out)


if __name__ == '__main__':
    main()
