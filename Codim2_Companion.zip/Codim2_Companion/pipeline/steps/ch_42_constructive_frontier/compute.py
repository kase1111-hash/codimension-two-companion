#!/usr/bin/env python3
"""ch_42_constructive_frontier — Frontier of needed cycle constructions."""
import argparse, csv, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from kase_utils import add_standard_args, resolve_args, banner, section, step, summary_table, C
from registry import get_artifact_path, write_progress

STEP_ID = 'ch_42_constructive_frontier'

FRONTIER = [
    {'open_case': 'generic cubic 4-fold (non-Hassett-special)',
     'codim': 2,
     'cycles_needed': 'Construction propagating Hodge classes outside the Hassett K3-association',
     'plausible_approach': 'Derived category methods (Kuznetsov K3 category at higher discriminant)',
     'pessimism': 'medium',
     'open_problem_ref': 'Hassett 2000; Bayer-Macri'},
    {'open_case': 'generic CY 4-fold (sextic in P^5)',
     'codim': 2,
     'cycles_needed': '~1751 transcendental codim-2 classes beyond h^2 ∪ h^2',
     'plausible_approach': 'New method needed — no current proposal',
     'pessimism': 'high',
     'open_problem_ref': 'Appendix C Problem 1.1'},
    {'open_case': '(2,5) complete-intersection CY 4-fold',
     'codim': 2,
     'cycles_needed': '~1637 transcendental codim-2 classes',
     'plausible_approach': 'Possibly: enumerative geometry from CI ambient',
     'pessimism': 'high',
     'open_problem_ref': 'Appendix C Problem 1.2'},
    {'open_case': 'hyperkähler OG-10',
     'codim': 2,
     'cycles_needed': 'Cycles beyond BB-form squares + divisor squares',
     'plausible_approach': 'Mongardi-Rapagnetta-Saccà constructions; Lagrangian fibration analysis',
     'pessimism': 'medium',
     'open_problem_ref': 'Appendix C Problem 2.3'},
    {'open_case': 'hyperkähler OG-6',
     'codim': 2,
     'cycles_needed': 'Cycles beyond BB-form squares',
     'plausible_approach': 'Inheritance from abelian surface input',
     'pessimism': 'low-medium',
     'open_problem_ref': 'Appendix C Problem 2.4'},
    {'open_case': 'Mumford-type abelian 4-folds (general)',
     'codim': 2,
     'cycles_needed': 'Explicit algebraic representatives of exotic Hodge classes',
     'plausible_approach': 'Andre 1996 method extended; theta correspondence',
     'pessimism': 'medium',
     'open_problem_ref': 'Appendix C Problem 3.2'},
    {'open_case': 'abelian 5-folds with exceptional MT',
     'codim': 2,
     'cycles_needed': 'Cycles for exotic classes beyond Hazama',
     'plausible_approach': 'Hodge group analysis + specific constructions',
     'pessimism': 'high',
     'open_problem_ref': 'Appendix C Problem 3.3'},
    {'open_case': 'general 4-fold (no extra structure)',
     'codim': 2,
     'cycles_needed': 'Construction for arbitrary smooth proj 4-fold',
     'plausible_approach': 'No known proposal',
     'pessimism': 'very high',
     'open_problem_ref': 'Appendix C Problem 1.4'},
    {'open_case': 'high-genus moduli M_g, A_g (g ≥ 24)',
     'codim': 2,
     'cycles_needed': 'Special-locus cycles on general-type moduli',
     'plausible_approach': 'Modular form geometry; tautological classes',
     'pessimism': 'medium',
     'open_problem_ref': 'Appendix C Problem 4.1'},
    {'open_case': 'higher-discriminant K3 associates (d > 70)',
     'codim': 2,
     'cycles_needed': 'Nikulin embedding verification for d > 70',
     'plausible_approach': 'Pure computation; doable',
     'pessimism': 'low',
     'open_problem_ref': 'Appendix C Problem 5.2'},
]

def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = resolve_args(parser.parse_args())
    banner("ch_42_constructive_frontier", {'preset': args.preset})
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_progress(STEP_ID, status='running', items_total=len(FRONTIER), preset=args.preset)
    try:
        step(1, 2, "Compiling constructive frontier ...")
        section("CYCLE CONSTRUCTIONS NEEDED")
        rows = []
        for r in FRONTIER:
            pessimism = r['pessimism']
            color = (C.green if 'low' in pessimism and 'high' not in pessimism
                     else C.warn if 'medium' in pessimism
                     else C.cyan if 'very high' in pessimism
                     else C.warn)
            rows.append((r['open_case'][:38], color(pessimism[:14]), r['plausible_approach'][:46]))
        summary_table(rows, ['Open case', 'Difficulty', 'Plausible approach'],
                      fmt=['<40', '<16', '<48'])
        
        section("KEY OBSERVATIONS")
        print(f"  {C.green('Low difficulty')}: extending Nikulin to higher d (~tools exist).")
        print(f"  {C.warn('Medium difficulty')}: OG-6, Mumford-type AV, generic cubic 4-fold — "
              f"plausible approaches identified.")
        print(f"  {C.cyan('Very high difficulty')}: generic CY 4-folds, general 4-folds — "
              f"no current proposals.")
        
        step(2, 2, "Writing outputs ...")
        csv_path = output_dir / 'constructive_frontier.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(FRONTIER[0].keys()))
            w.writeheader()
            for r in FRONTIER: w.writerow(r)
        json_path = output_dir / 'constructive_frontier.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({'step': STEP_ID, 'chapter': 42, 'data': FRONTIER,
                       'summary': {'total': len(FRONTIER)}}, f, indent=2)
        write_progress(STEP_ID, status='complete', items_done=len(FRONTIER),
                       items_total=len(FRONTIER),
                       artifacts=['constructive_frontier.csv', 'constructive_frontier.json'])
        print(C.green("\n  ✓ ch_42_constructive_frontier finished"))
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        raise

if __name__ == '__main__':
    main()
