"""ch_25_hyperkahler_lattices — Beauville-Bogomolov lattices."""
from .compute import main
if __name__ == '__main__':
    main()
