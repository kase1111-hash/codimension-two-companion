"""ch_14_tate_mirror_framework — Tate-mirror framework module."""
from .compute import main
if __name__ == '__main__':
    main()
