#!/usr/bin/env python3
"""
ch_10_griffiths_evidence — Griffiths group nontriviality results.

The Griffiths group:
  Griff^k(X) = {algebraic cycles of codim k, homol. equiv. to 0}
             / {alg. cycles algebraically equiv. to 0}

For k = 1: Griff^1 = 0 always (homological and algebraic equivalence
coincide for divisors).

For k ≥ 2: Griff^k can be nontrivial — and the size of Griff^k
measures the gap between "homologically zero" and "algebraically zero,"
which is roughly the transcendental part of intermediate Jacobian
Abel-Jacobi image.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress, load_upstream


STEP_ID = 'ch_10_griffiths_evidence'


GRIFFITHS_TABLE = [
    {'variety': 'generic quintic 3-fold (Y ⊂ P^4 deg 5)',
     'codim': 2,
     'griffiths_status': 'nontrivial',
     'cardinality': 'finitely generated nonzero (Griffiths 1969)',
     'strengthening': 'uncountable (Clemens 1983)',
     'method': 'Abel-Jacobi has transcendental image; uncountably many cycle '
               'classes with distinct AJ images.',
     'reference': 'Griffiths 1969; Clemens 1983',
     'significance': 'FIRST evidence that codim-2 cycles have a transcendental aspect '
                     'beyond what divisor theory captures.'},
    
    {'variety': 'CY 3-fold (general)',
     'codim': 2,
     'griffiths_status': 'expected nontrivial',
     'cardinality': 'expected uncountable',
     'strengthening': 'partial results',
     'method': 'Variation of Hodge structure; Voisin\'s relative theory.',
     'reference': 'Voisin 1992; many others',
     'significance': 'Griffiths phenomenon is generic on CY 3-folds.'},
    
    {'variety': 'Calabi-Yau 4-fold (sextic, c.i.)',
     'codim': 2,
     'griffiths_status': 'trivial in known sense',
     'cardinality': '— (since J^2 = 0 for CY 4-folds)',
     'strengthening': '—',
     'method': 'CY 4-folds have h^{2,1} = 0 ⇒ J^2 = 0 ⇒ algebraic and homological '
               'equivalences coincide on the image of AJ at codim 2.',
     'reference': '—',
     'significance': 'Griffiths phenomenon DOESN\'T apply to CY 4-folds because '
                     'J^2 is trivial. Codim-2 transcendence on CY 4-folds is a '
                     'different beast: it lives in H^{2,2}(X) directly.'},
    
    {'variety': 'abelian variety of dim ≥ 3',
     'codim': 2,
     'griffiths_status': 'nontrivial in general',
     'cardinality': 'finitely generated',
     'strengthening': 'Beauville-Voisin filtration',
     'method': 'Beauville eigenspace + Saito-Beilinson conjectures.',
     'reference': 'Beauville 1986',
     'significance': 'Griff^2(A) admits a precise eigenspace structure on '
                     'abelian varieties; computable.'},
    
    {'variety': 'K3 surface',
     'codim': 2,
     'griffiths_status': 'irrelevant (codim 2 = top class)',
     'cardinality': '—',
     'strengthening': '—',
     'method': 'Codim 2 on a surface = points (CH_0); Mumford 1968 said CH_0 is '
               'infinite-dim, but Griffiths group requires codim ≥ 2 on dim ≥ 3.',
     'reference': '—',
     'significance': 'No Griffiths group on surfaces.'},
    
    {'variety': 'cubic 3-fold',
     'codim': 2,
     'griffiths_status': 'trivial',
     'cardinality': '0',
     'strengthening': '—',
     'method': 'Clemens-Griffiths: J^2(cubic 3-fold) is an abelian variety, '
               'and AJ surjects onto it from algebraic cycles.',
     'reference': 'Clemens-Griffiths 1972',
     'significance': 'Counterexample-by-contrast: cubic 3-fold has J^2 algebraic, '
                     'so Griff^2 = 0. Quintic 3-fold has J^2 with transcendental '
                     'part, so Griff^2 ≠ 0. The dichotomy is illuminating.'},
    
    {'variety': 'hyperkähler manifold',
     'codim': 2,
     'griffiths_status': 'trivial (in usual sense)',
     'cardinality': '0',
     'strengthening': '—',
     'method': 'HKs have H^3 = 0 → J^2 = 0 → Griffiths phenomenon doesn\'t arise.',
     'reference': '—',
     'significance': 'Codim-2 HC on HK is NOT a Griffiths-style obstruction; '
                     'it\'s a direct H^{2,2} question (Beauville-Bogomolov + '
                     'cycle constructions).'},
    
    {'variety': 'cubic 4-fold (generic)',
     'codim': 2,
     'griffiths_status': 'unknown',
     'cardinality': '—',
     'strengthening': '—',
     'method': 'h^{2,1} = 0 → J^2 = 0; but J^3 may have content. Need analysis '
               'at the right codim.',
     'reference': '—',
     'significance': 'Cubic 4-fold codim-2 question lives in H^{2,2}, not J^2.'},
    
    {'variety': 'Fano 4-fold (rationally connected)',
     'codim': 2,
     'griffiths_status': 'trivial',
     'cardinality': '0',
     'strengthening': '—',
     'method': 'Bloch-Srinivas (small CH_0) ⇒ diagonal decomposition ⇒ Griff = 0.',
     'reference': 'Bloch-Srinivas 1983',
     'significance': 'Rationally connected ⇒ no Griffiths phenomenon. HC follows.'},
]


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_10_griffiths_evidence — Griffiths Group Nontriviality", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(GRIFFITHS_TABLE), preset=args.preset)
    
    try:
        # Light upstream check
        step(1, 2, "Verifying upstream readiness ...")
        try:
            ij = load_upstream('ch_09_intermediate_jacobian_check',
                               'intermediate_jacobian_table.json')
            print(f"    ✓ ch_09 (intermediate Jacobian) loaded: {len(ij['data'])} entries")
        except FileNotFoundError as e:
            print(C.warn(f"    ⚠ {e}"))
        
        section("GRIFFITHS GROUP STATUS BY VARIETY")
        rows = []
        for r in GRIFFITHS_TABLE:
            status = r['griffiths_status']
            color = (C.warn('nontrivial') if 'nontrivial' in status
                     else C.cyan('expected') if 'expected' in status
                     else C.green('trivial') if 'trivial' in status
                     else C.muted(status[:14]))
            rows.append((
                r['variety'][:36],
                color[:14],
                r['cardinality'][:24],
                r['reference'][:30],
            ))
        summary_table(rows, ['Variety', 'Griff^2', 'Cardinality', 'Reference'],
                      fmt=['<36', '<14', '<24', '<32'])
        
        section("KEY OBSERVATIONS")
        print(f"  • {C.warn('Griffiths 1969 + Clemens 1983')}: generic quintic 3-fold has "
              f"uncountable Griff^2. {C.highlight('FIRST evidence of codim-2 transcendence')}.")
        print(f"  • {C.warn('CY 3-folds')}: Griffiths phenomenon is generic; transcendental cycle "
              f"classes detected by Abel-Jacobi.")
        print(f"  • {C.green('Rationally connected (Fano)')}: Griff^2 = 0 trivially; no obstruction.")
        print(f"  • {C.cyan('CY 4-folds')}: Griffiths phenomenon DOESN\'T apply — J^2 is trivial. "
              f"Codim-2 transcendence in dim 4 is a {C.highlight('different kind')} of obstruction.")
        print()
        print(f"  {C.highlight('Conceptual map')}: in dim 3, transcendence shows up in J^2 (Griffiths).")
        print(f"  In dim 4 (CY/HK), transcendence shows up in H^{{2,2}}_prim directly — "
              f"a more direct, harder obstruction.")
        
        # Save
        step(2, 2, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'griffiths_evidence_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(GRIFFITHS_TABLE[0].keys()))
            writer.writeheader()
            for r in GRIFFITHS_TABLE:
                writer.writerow(r)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'griffiths_evidence_table.json'
        n_nontriv = sum(1 for r in GRIFFITHS_TABLE if 'nontrivial' in r['griffiths_status'])
        n_triv = sum(1 for r in GRIFFITHS_TABLE if 'trivial' in r['griffiths_status'] and 'nontrivial' not in r['griffiths_status'])
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 10,
                'data': GRIFFITHS_TABLE,
                'summary': {
                    'total': len(GRIFFITHS_TABLE),
                    'nontrivial_griff': n_nontriv,
                    'trivial_griff': n_triv,
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(GRIFFITHS_TABLE), items_total=len(GRIFFITHS_TABLE),
                       artifacts=['griffiths_evidence_table.csv',
                                  'griffiths_evidence_table.json'])
        print()
        print(C.green("  ✓ ch_10_griffiths_evidence finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
