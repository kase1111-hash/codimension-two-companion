"""ch_10_griffiths_evidence — Griffiths group nontriviality."""
from .compute import main
if __name__ == '__main__':
    main()
