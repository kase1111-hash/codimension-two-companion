"""ch_09_intermediate_jacobian_check — Intermediate Jacobian atlas."""
from .compute import main
if __name__ == '__main__':
    main()
