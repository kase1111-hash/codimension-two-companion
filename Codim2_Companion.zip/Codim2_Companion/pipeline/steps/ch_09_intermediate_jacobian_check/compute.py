#!/usr/bin/env python3
"""
ch_09_intermediate_jacobian_check — Intermediate Jacobian at codim 2.

For smooth proj X of dim n and integer k with 0 ≤ k ≤ n:

  J^k(X) = H^{2k-1}(X, C) / (F^k H^{2k-1} + H^{2k-1}(X, Z))

is the k-th intermediate Jacobian, a complex torus.

  - k = 1: J^1(X) = Pic^0(X), always an abelian variety.
  - k = n: J^n(X) = "Albanese in cycles" = some abelian piece.
  - k = 2 (codim 2): J^2(X) is a complex torus; whether it's algebraic
    is governed by whether H^{2,1}(X) lives in the "right" part.

The Abel-Jacobi map AJ: CH^k_{hom}(X) → J^k(X) lands in the algebraic
part of J^k(X). Its image is the algebraic intermediate Jacobian
J^k_alg(X) ⊂ J^k(X).

For codim 2 on a 4-fold, J^2(X) has trivial "algebraic" part (since
H^3(X) for a CY 4-fold is concentrated in pure Hodge type, no
intermediate weight) — so codim-2 Abel-Jacobi is trivial there.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_09_intermediate_jacobian_check'


IJ_TABLE = [
    # codim 1 — always algebraic
    {'variety_class': 'all smooth proj X', 'codim': 1,
     'J_k': 'J^1(X) = Pic^0(X)',
     'algebraic_part': 'all of J^1 (= Pic^0 is abelian variety)',
     'aj_status': 'surjective onto J^1_alg = Pic^0',
     'note': 'Lefschetz (1,1) gives HC at codim 1.',
     'reference': 'classical'},
    
    # codim 2 — varies dramatically
    {'variety_class': 'curves', 'codim': 2,
     'J_k': 'trivial (no codim 2 on curves)',
     'algebraic_part': 'trivial',
     'aj_status': 'vacuous',
     'note': 'No codim-2 cycles on a 1-fold.',
     'reference': '—'},
    
    {'variety_class': 'surfaces', 'codim': 2,
     'J_k': 'J^2(S) = trivial (since H^3 = 0 generically)',
     'algebraic_part': 'trivial',
     'aj_status': 'AJ is trivial; codim-2 = points; CH_0(S) controls things',
     'note': 'Codim 2 on surface = points. Mumford 1968: CH_0 is huge but '
             'AJ lands trivially in J^2.',
     'reference': 'Mumford 1968'},
    
    {'variety_class': 'abelian variety A (dim g)', 'codim': 2,
     'J_k': 'J^2(A) = complex torus of dim h^{2,1}(A) = g(g-1)(g+1)/6',
     'algebraic_part': 'algebraic part nonzero; lifts to A by Albanese',
     'aj_status': 'AJ surjective onto algebraic part',
     'note': 'Beauville eigenspace decomposition; HC via Lieberman.',
     'reference': 'Lieberman 1968; Beauville 1986'},
    
    {'variety_class': 'CY 3-fold', 'codim': 2,
     'J_k': 'J^2(X) = complex torus of dim h^{2,1}(X) (often hundreds)',
     'algebraic_part': 'Griffiths zero locus; partial algebraicity',
     'aj_status': 'AJ has transcendental image (Griffiths group)',
     'note': 'Clemens 1983: Griffiths group is uncountable for generic quintic 3-fold. '
             'First evidence of transcendental obstruction.',
     'reference': 'Griffiths 1969; Clemens 1983'},
    
    {'variety_class': 'cubic 3-fold', 'codim': 2,
     'J_k': 'J^2(X) = 5-dim PPAV (the intermediate Jacobian)',
     'algebraic_part': 'all of J^2 (Clemens-Griffiths)',
     'aj_status': 'AJ surjects onto J^2; HC at codim 2 settled',
     'note': 'Clemens-Griffiths 1972: J^2(cubic 3-fold) determines the cubic, '
             'and proves irrationality of cubic 3-folds.',
     'reference': 'Clemens-Griffiths 1972'},
    
    {'variety_class': '3-folds (general)', 'codim': 2,
     'J_k': 'J^2(X) = complex torus',
     'algebraic_part': 'partial',
     'aj_status': 'AJ image is the algebraic part; rest is Griffiths',
     'note': 'In dim 3, codim 2 ≅ codim 1 by HL — so HC follows from Lefschetz.',
     'reference': 'Griffiths 1969'},
    
    {'variety_class': '4-folds (general)', 'codim': 2,
     'J_k': 'J^2(X) = complex torus from H^3 = 0 region (often trivial)',
     'algebraic_part': 'often trivial (no codim-2 → codim-3 Abel-Jacobi target)',
     'aj_status': 'AJ trivial; codim-2 cycles can\'t be detected via J^2',
     'note': 'For CY 4-folds and most smooth 4-folds, H^3 is small or zero, '
             'so J^2 is small. Abel-Jacobi is therefore not useful at codim 2 '
             'in dim 4 — a major source of difficulty.',
     'reference': '—'},
    
    {'variety_class': 'CY 4-folds (sextic, c.i.)', 'codim': 2,
     'J_k': 'J^2(X) = trivial (since h^{2,1} = 0 for these CY 4-folds)',
     'algebraic_part': 'trivial',
     'aj_status': 'AJ trivial; codim-2 must be detected another way',
     'note': 'CY 4-folds have h^{2,1} = 0 by construction. So J^2 = 0. '
             'Abel-Jacobi gives NO information at codim 2. Forces other '
             'methods (Hassett, Kuga-Satake, etc.) to do all the work.',
     'reference': '—'},
    
    {'variety_class': 'hyperkähler', 'codim': 2,
     'J_k': 'J^2(X) is small (H^3 = 0 for HK manifolds)',
     'algebraic_part': 'trivial',
     'aj_status': 'AJ trivial at codim 2; cycle constructions via BB form',
     'note': 'HKs have H^3 = 0 (and all odd Betti numbers vanish), '
             'so intermediate Jacobian is trivial; cycle structure comes '
             'from BB form + monodromy.',
     'reference': 'Beauville 1983'},
    
    {'variety_class': 'Fano 4-folds', 'codim': 2,
     'J_k': 'J^2(X) varies; small for RC Fanos',
     'algebraic_part': 'when nonzero, all algebraic via Bloch-Srinivas',
     'aj_status': 'AJ surjective onto algebraic part',
     'note': 'For rationally connected Fanos, J^2(X) is small (often 0); '
             'when nonzero, the Bloch-Srinivas diagonal gives full algebraicity.',
     'reference': 'Bloch-Srinivas 1983'},
]


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_09_intermediate_jacobian_check — Intermediate Jacobian Atlas", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(IJ_TABLE), preset=args.preset)
    
    try:
        step(1, 2, "Compiling intermediate Jacobian atlas ...")
        section("INTERMEDIATE JACOBIAN AT CODIM 1 AND 2")
        rows = []
        for r in IJ_TABLE:
            rows.append((
                r['variety_class'][:30],
                str(r['codim']),
                r['J_k'][:36],
                r['aj_status'][:30],
            ))
        summary_table(rows, ['Variety class', 'codim', 'J^k(X)', 'AJ status'],
                      fmt=['<30', '<5', '<38', '<32'])
        
        section("KEY OBSERVATIONS")
        print(f"  • {C.green('Codim 1')}: J^1 = Pic^0 is always an abelian variety. "
              f"AJ is surjective onto Pic^0. HC at codim 1 universal.")
        print(f"  • {C.green('Cubic 3-fold')}: J^2 is 5-dim PPAV; Clemens-Griffiths uses this "
              f"to settle codim-2 HC AND prove irrationality.")
        print(f"  • {C.warn('CY 3-fold')}: J^2 can be huge; AJ has transcendental image "
              f"(Griffiths group). Codim 2 = codim 1 dual via HL, so HC follows.")
        print(f"  • {C.cyan('CY 4-fold')}: J^2 is TRIVIAL (h^{2,1} = 0). Abel-Jacobi gives "
              f"NO information at codim 2. This is a structural obstruction.")
        print(f"  • {C.cyan('Hyperkähler')}: all odd Betti = 0 → J^2 trivial → cycles must "
              f"come from BB form, monodromy, or fibered structure.")
        print()
        print(f"  {C.highlight('Structural punchline')}: in dim 3, J^2 carries the information.")
        print(f"  In dim 4 (for CY/HK), J^2 is trivial — Abel-Jacobi has no work to do, "
              f"so the proof methods change completely.")
        
        # Save
        step(2, 2, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'intermediate_jacobian_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(IJ_TABLE[0].keys()))
            writer.writeheader()
            for r in IJ_TABLE:
                writer.writerow(r)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'intermediate_jacobian_table.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({'step': STEP_ID, 'chapter': 9,
                       'data': IJ_TABLE,
                       'summary': {'total': len(IJ_TABLE)}}, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(IJ_TABLE), items_total=len(IJ_TABLE),
                       artifacts=['intermediate_jacobian_table.csv',
                                  'intermediate_jacobian_table.json'])
        print()
        print(C.green("  ✓ ch_09_intermediate_jacobian_check finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
