"""ch_23_fano_atlas — Fano 4-fold atlas."""
from .compute import main
if __name__ == '__main__':
    main()
