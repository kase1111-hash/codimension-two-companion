"""ch_16_motivic_cohomology_table — Motivic cohomology status."""
from .compute import main
if __name__ == '__main__':
    main()
