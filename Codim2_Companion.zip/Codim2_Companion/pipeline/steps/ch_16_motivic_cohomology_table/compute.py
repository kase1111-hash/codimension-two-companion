#!/usr/bin/env python3
"""
ch_16_motivic_cohomology_table — Motivic cohomology by variety class.

For smooth proj X / k, motivic cohomology H^{p,q}_M(X, Z) is a
graded refinement of K-theory. The cycle class map

  cl: H^{2p, p}_M(X, Z) → H^{2p}(X, Z)

has image lying inside Hdg^p(X). HC conjectures the image is exactly
Hdg^p(X) ⊗ Q (rationally surjective onto Hodge classes).

For codim 1: H^{2,1}_M(X, Z) ≅ Pic(X) (classical).
For codim 2: H^{4,2}_M(X, Z) is much more mysterious; this is where
HC at codim 2 lives motivically.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_16_motivic_cohomology_table'


MOTIVIC_TABLE = [
    # Variety class × codim × motivic-cohomology status
    {
        'variety_class': 'curves (smooth proj)',
        'codim': 1,
        'motivic_group': 'H^{2,1}_M = Pic(C)',
        'cycle_map_image': 'all of Pic(C) (= H^2(C, Z) since C is curve)',
        'beilinson_status': 'settled (matches HC trivially)',
        'reference': 'classical',
    },
    {
        'variety_class': 'curves (smooth proj)',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M = CH^2 = trivial in dim 1',
        'cycle_map_image': 'trivial',
        'beilinson_status': 'vacuous',
        'reference': '—',
    },
    {
        'variety_class': 'surfaces (smooth proj)',
        'codim': 1,
        'motivic_group': 'H^{2,1}_M = Pic(S)',
        'cycle_map_image': 'NS(S) ⊂ H^2(S, Z)',
        'beilinson_status': 'settled — Lefschetz (1,1)',
        'reference': 'Lefschetz 1924',
    },
    {
        'variety_class': 'surfaces (smooth proj)',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M = CH^2(S) = CH_0(S)',
        'cycle_map_image': 'image into H^4(S, Z) = Z (top class)',
        'beilinson_status': 'settled — surjective via top class',
        'reference': 'Mumford 1968 + Bloch-Srinivas',
    },
    {
        'variety_class': '3-folds (general)',
        'codim': 1,
        'motivic_group': 'H^{2,1}_M = Pic',
        'cycle_map_image': 'NS ⊂ H^2',
        'beilinson_status': 'settled — Lefschetz',
        'reference': 'Lefschetz',
    },
    {
        'variety_class': '3-folds (general)',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M ≅ CH^2(X)',
        'cycle_map_image': 'partial: Griffiths group nontrivial',
        'beilinson_status': 'partial — Hard Lefschetz reduces to codim 1',
        'reference': 'Griffiths 1969',
        'note': 'Codim 2 in dim 3 = codim 1 by HL; resolved.',
    },
    {
        'variety_class': '4-folds (general)',
        'codim': 1,
        'motivic_group': 'H^{2,1}_M = Pic',
        'cycle_map_image': 'NS ⊂ H^2',
        'beilinson_status': 'settled',
        'reference': 'Lefschetz',
    },
    {
        'variety_class': '4-folds (general)',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M ≅ CH^2(X)',
        'cycle_map_image': 'unknown in general',
        'beilinson_status': 'open — CENTRAL CODIM-2 FRONTIER',
        'reference': '—',
        'note': 'This is the codim-2 HC frontier expressed in motivic language.',
    },
    {
        'variety_class': 'abelian varieties (any dim)',
        'codim': 'any',
        'motivic_group': 'H^{2p,p}_M ≅ CH^p(A)',
        'cycle_map_image': 'all Hodge classes (Lieberman-Kahn-Sebastian)',
        'beilinson_status': 'settled',
        'reference': 'Lieberman 1968; Kahn-Sebastian 2009',
    },
    {
        'variety_class': 'K3 surfaces',
        'codim': 'any',
        'motivic_group': 'H^{2p,p}_M ≅ NS(S) (codim 1), Z (codim 2)',
        'cycle_map_image': 'full Hodge image',
        'beilinson_status': 'settled',
        'reference': 'Lefschetz + Mumford',
    },
    {
        'variety_class': 'cubic 4-folds (Hassett-special, K3-assoc)',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M',
        'cycle_map_image': 'matches H^{2,2} via K3 lift',
        'beilinson_status': 'settled (Kuznetsov K3 category)',
        'reference': 'Kuznetsov 2010; Addington-Thomas 2014',
    },
    {
        'variety_class': 'cubic 4-folds (generic)',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M',
        'cycle_map_image': 'partial: 1-dim (hyperplane^2); rest open',
        'beilinson_status': 'open',
        'reference': '—',
    },
    {
        'variety_class': 'CY 4-folds (sextic, c.i.)',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M',
        'cycle_map_image': 'tiny (1-dim) vs huge H^{2,2} (thousands)',
        'beilinson_status': 'open — primary codim-2 frontier',
        'reference': '—',
    },
    {
        'variety_class': 'hyperkähler K3^[n]',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M',
        'cycle_map_image': 'full Hodge image',
        'beilinson_status': 'settled (Vial 2017)',
        'reference': 'Vial 2017; Charles-Markman 2013',
    },
    {
        'variety_class': 'Fano varieties (rationally connected)',
        'codim': 'any',
        'motivic_group': 'H^{2p,p}_M',
        'cycle_map_image': 'all of Hdg^p',
        'beilinson_status': 'settled (Bloch-Srinivas via small CH_0)',
        'reference': 'Bloch-Srinivas 1983',
    },
    {
        'variety_class': 'moduli of curves M_g (g ≥ 24)',
        'codim': 2,
        'motivic_group': 'H^{4,2}_M',
        'cycle_map_image': 'partial',
        'beilinson_status': 'open',
        'reference': '—',
    },
]


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_16_motivic_cohomology_table — Motivic Cohomology Status", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(MOTIVIC_TABLE), preset=args.preset)
    
    try:
        # Display
        step(1, 2, "Compiling motivic cohomology table ...")
        section("MOTIVIC COHOMOLOGY × HODGE-CONJECTURE STATUS")
        rows = []
        for m in MOTIVIC_TABLE:
            status = m['beilinson_status']
            color = (C.green if 'settled' in status else
                     C.warn if 'partial' in status else
                     C.cyan if 'open' in status else C.muted)
            rows.append((
                m['variety_class'][:32],
                str(m['codim']),
                m['cycle_map_image'][:34],
                color(status[:24]),
            ))
        summary_table(rows, ['Variety class', 'k', 'cl(H^{2k,k}_M) image', 'Beilinson status'],
                      fmt=['<32', '<3', '<34', '<28'])
        
        # Distribution
        n_settled = sum(1 for m in MOTIVIC_TABLE if 'settled' in m['beilinson_status'])
        n_partial = sum(1 for m in MOTIVIC_TABLE if 'partial' in m['beilinson_status'])
        n_open = sum(1 for m in MOTIVIC_TABLE if 'open' in m['beilinson_status'])
        
        section("DISTRIBUTION")
        print(f"  {C.green('Settled')}: {n_settled}")
        print(f"  {C.warn('Partial')}: {n_partial}")
        print(f"  {C.cyan('Open')}: {n_open}")
        
        section("KEY OBSERVATIONS")
        print(f"  • {C.green('Codim 1')}: settled universally (Lefschetz (1,1) gives cl surjective onto Hdg^1).")
        print(f"  • {C.green('Codim 2 on surfaces / abelian / K3 / Fano / HK K3^[n]')}: settled.")
        print(f"  • {C.cyan('Codim 2 on generic CY 4-folds and generic cubic 4-folds')}: OPEN.")
        print(f"  • In motivic language: HC ≡ cycle class map cl: H^{{2k,k}}_M(X,Q) → Hdg^k(X)_Q is surjective.")
        print(f"  • The open codim-2 frontier is precisely where {C.warn('motivic groups CH^2(X)')} fail to fill out Hodge^{{2,2}}(X).")
        
        # Save
        step(2, 2, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'motivic_cohomology_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            keys = list(MOTIVIC_TABLE[0].keys())
            writer = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
            writer.writeheader()
            for m in MOTIVIC_TABLE:
                writer.writerow(m)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'motivic_cohomology_table.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 16,
                'data': MOTIVIC_TABLE,
                'summary': {
                    'total': len(MOTIVIC_TABLE),
                    'settled': n_settled,
                    'partial': n_partial,
                    'open': n_open,
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(MOTIVIC_TABLE), items_total=len(MOTIVIC_TABLE),
                       artifacts=['motivic_cohomology_table.csv', 'motivic_cohomology_table.json'])
        print()
        print(C.green("  ✓ ch_16_motivic_cohomology_table finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
