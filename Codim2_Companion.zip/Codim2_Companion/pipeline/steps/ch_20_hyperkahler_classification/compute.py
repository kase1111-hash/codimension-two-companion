#!/usr/bin/env python3
"""
ch_20_hyperkahler_classification — Compact hyperkähler classification.

The four known deformation types of compact hyperkähler manifolds:
  1. K3^[n]    Hilbert schemes of n points on K3 surfaces; dim 2n;
               b_2 = 23; BB form discrim 2(n-1)
  2. Kum^n     Generalized Kummer varieties; dim 2n; b_2 = 7;
               BB form discrim 2(n+1)
  3. OG-6      O'Grady's 6-dim'l example (resolution of moduli space);
               dim 6; b_2 = 8; BB form known
  4. OG-10     O'Grady's 10-dim'l example; dim 10; b_2 = 24;
               BB form known

For each: HC at codim 1 = Lefschetz settled; codim 2 status varies by
type and dimension.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C, Timer,
)
from registry import get_artifact_path, write_progress, load_upstream


STEP_ID = 'ch_20_hyperkahler_classification'


# The four deformation types
HK_DEFORMATION_TYPES = [
    {
        'type': 'K3^[n]',
        'name': 'Hilbert schemes of points on K3',
        'dim_formula': '2n',
        'b_2_formula': '23',
        'bb_lattice_rank': 23,
        'bb_lattice_signature': '(3, 20)',
        'bb_discriminant_formula': '2(n-1)',
        'construction': 'X = Hilb^n(S) for S a K3 surface',
        'first_introduced': 'Beauville 1983, Fujiki 1983',
        'hc_codim_1': 'settled',
        'hc_codim_2': 'settled',
        'hc_codim_2_ref': 'Charles-Markman 2013, Vial 2017',
        'note': 'Best-understood HK family. Standard conjectures resolved.',
    },
    {
        'type': 'Kum^n',
        'name': 'Generalized Kummer varieties',
        'dim_formula': '2n',
        'b_2_formula': '7',
        'bb_lattice_rank': 7,
        'bb_lattice_signature': '(3, 4)',
        'bb_discriminant_formula': '2(n+1)',
        'construction': 'X = K_n(A) = fiber of (A^{[n+1]} → A) over 0; A abelian surface',
        'first_introduced': 'Beauville 1983',
        'hc_codim_1': 'settled',
        'hc_codim_2': 'partial',
        'hc_codim_2_ref': 'Foster 2022, Charles ongoing',
        'note': 'Lower b_2 (only 7) means simpler Hodge structure, '
                'but cycle constructions less explicit.',
    },
    {
        'type': 'OG-6',
        'name': "O'Grady's 6-dim'l example",
        'dim_formula': '6',
        'b_2_formula': '8',
        'bb_lattice_rank': 8,
        'bb_lattice_signature': '(3, 5)',
        'bb_discriminant_formula': '4',
        'construction': "Symplectic resolution of M_{(2,0,-2)}(A) for A abelian surface",
        'first_introduced': "O'Grady 1999, 2003",
        'hc_codim_1': 'settled',
        'hc_codim_2': 'partial',
        'hc_codim_2_ref': 'Mongardi-Onorati ongoing',
        'note': 'Symplectic resolution; some cycle classes known via abelian inheritance.',
    },
    {
        'type': 'OG-10',
        'name': "O'Grady's 10-dim'l example",
        'dim_formula': '10',
        'b_2_formula': '24',
        'bb_lattice_rank': 24,
        'bb_lattice_signature': '(3, 21)',
        'bb_discriminant_formula': '3',
        'construction': "Symplectic resolution of moduli of sheaves on K3 with v=(2,0,-2)",
        'first_introduced': "O'Grady 1999",
        'hc_codim_1': 'settled',
        'hc_codim_2': 'open',
        'hc_codim_2_ref': 'open(Mongardi-Rapagnetta-Saccà constructions)',
        'note': 'Largest b_2 (24); rich Hodge structure but cycle constructions sparse. '
                'Central open frontier for HK HC at codim 2.',
    },
]


# Specific HK examples (named varieties)
HK_EXAMPLES = [
    {
        'name': 'Fano variety of lines on cubic 4-fold',
        'def_type': 'K3^[2]',
        'dim': 4,
        'construction': 'F(Y) = {ℓ ⊂ Y : line on smooth cubic 4-fold Y}',
        'reference': 'Beauville-Donagi 1985',
        'note': "Beauville-Donagi: F(Y) deformation-equivalent to K3^[2]; smallest HK 4-fold "
                "with non-trivial moduli.",
    },
    {
        'name': 'LLSvS 8-fold (Lehn-Lehn-Sorger-van Straten)',
        'def_type': 'K3^[4]',
        'dim': 8,
        'construction': 'Z(Y) = special component of generalized Kummer for twisted cubics on Y',
        'reference': 'Lehn-Lehn-Sorger-van Straten 2017',
        'note': "Constructed from cubic 4-folds; deformation-equiv to K3^[4].",
    },
    {
        'name': 'Hilbert scheme Hilb^n(S)',
        'def_type': 'K3^[n]',
        'dim': '2n',
        'construction': 'Hilb^n of any K3 surface S',
        'reference': 'classical',
        'note': "Generic K3^[n] example; varies with K3 polarization.",
    },
    {
        'name': "O'Grady's M_v(S, v)",
        'def_type': 'OG-10',
        'dim': 10,
        'construction': "Moduli of sheaves on K3 with Mukai vector (2,0,-2)",
        'reference': "O'Grady 1999",
        'note': 'Original OG-10 construction.',
    },
    {
        'name': 'K3^[2] from quartic double solid',
        'def_type': 'K3^[2]',
        'dim': 4,
        'construction': 'Fano variety of lines, alternate model from quartic DS',
        'reference': 'Iliev-Manivel 2011',
    },
    {
        'name': 'IHS variety from cubic 5-fold',
        'def_type': 'OG-10',
        'dim': 10,
        'construction': 'Lagrangian fibration related to special cubic 5-fold',
        'reference': 'Laza-Saccà-Voisin 2017',
    },
]


def get_hc_color(status):
    return {'settled': C.green, 'partial': C.warn, 'open': C.cyan}.get(status, C.muted)


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    parser.add_argument('--include-examples', action='store_true', default=True)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_20_hyperkahler_classification — Hyperkähler Manifolds", {
        'preset': args.preset,
        'include_examples': args.include_examples,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(HK_DEFORMATION_TYPES) + len(HK_EXAMPLES),
                   preset=args.preset)
    
    try:
        # Verify upstream Ch 19 K3 atlas is available (informational)
        step(1, 4, "Checking upstream K3 atlas ...")
        try:
            k3_atlas = load_upstream('ch_19_k3_atlas', 'k3_atlas.json')
            n_k3s = k3_atlas['summary']['total_k3s']
            print(f"    ✓ Loaded K3 atlas: {n_k3s} K3 surfaces available as base for K3^[n] and OG-10 construction")
        except FileNotFoundError as e:
            print(C.warn(f"    ⚠ K3 atlas not found: {e}"))
        
        # Display deformation types
        step(2, 4, "Compiling deformation type table ...")
        section("THE FOUR KNOWN HYPERKÄHLER DEFORMATION TYPES")
        rows = []
        for t in HK_DEFORMATION_TYPES:
            color_c2 = get_hc_color(t['hc_codim_2'])
            rows.append((
                t['type'],
                t['dim_formula'],
                t['b_2_formula'],
                t['bb_lattice_signature'],
                t['bb_discriminant_formula'],
                color_c2(t['hc_codim_2'][:8]),
            ))
        summary_table(rows, ['Type', 'dim', 'b_2', 'BB sig.', 'BB disc.', 'HC@2'],
                      fmt=['<10', '<8', '<6', '<10', '<10', '<10'])
        
        # Examples
        if args.include_examples:
            step(3, 4, "Compiling named examples ...")
            section("SPECIFIC NAMED HYPERKÄHLER VARIETIES")
            ex_rows = []
            for e in HK_EXAMPLES:
                ex_rows.append((
                    e['name'][:42],
                    e['def_type'],
                    str(e['dim']),
                    e['reference'][:30],
                ))
            summary_table(ex_rows, ['Example', 'Type', 'dim', 'Reference'],
                          fmt=['<42', '<10', '<5', '<30'])
        
        section("KEY OBSERVATIONS")
        print(f"  • {C.green('K3^[n]')} family — best understood; HC and standard conjectures resolved.")
        print(f"  • {C.warn('Kum^n, OG-6')} — partial results; cycles often inherit from abelian-surface input.")
        print(f"  • {C.cyan('OG-10')} — central frontier; b_2 = 24 (largest), few cycle constructions.")
        print(f"  • {C.highlight('Mongardi-Onorati monodromy')} — pivotal in distinguishing HK types via lattice.")
        print(f"  • {C.highlight('Beauville-Bogomolov form')} — additional structure beyond cohomology; "
              f"gives a quadratic form on H^2(X, Z) distinguishing HK types.")
        
        # Save
        step(4, 4, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'hyperkahler_classification.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(HK_DEFORMATION_TYPES[0].keys()))
            writer.writeheader()
            for t in HK_DEFORMATION_TYPES:
                writer.writerow(t)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'hyperkahler_classification.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID,
                'chapter': 20,
                'deformation_types': HK_DEFORMATION_TYPES,
                'examples': HK_EXAMPLES if args.include_examples else [],
                'summary': {
                    'n_deformation_types': len(HK_DEFORMATION_TYPES),
                    'hc_codim_2_settled': sum(1 for t in HK_DEFORMATION_TYPES
                                              if t['hc_codim_2'] == 'settled'),
                    'hc_codim_2_partial': sum(1 for t in HK_DEFORMATION_TYPES
                                              if t['hc_codim_2'] == 'partial'),
                    'hc_codim_2_open': sum(1 for t in HK_DEFORMATION_TYPES
                                           if t['hc_codim_2'] == 'open'),
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(HK_DEFORMATION_TYPES) + len(HK_EXAMPLES),
                       items_total=len(HK_DEFORMATION_TYPES) + len(HK_EXAMPLES),
                       artifacts=['hyperkahler_classification.csv',
                                  'hyperkahler_classification.json'])
        print()
        print(C.green("  ✓ ch_20_hyperkahler_classification finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
