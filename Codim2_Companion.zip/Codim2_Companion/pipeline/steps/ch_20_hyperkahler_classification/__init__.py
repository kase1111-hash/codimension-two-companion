"""ch_20_hyperkahler_classification — HK manifold classification."""
from .compute import main
if __name__ == '__main__':
    main()
