"""ch_36_standard_conjectures_atlas — Master atlas aggregator."""
from .compute import main
if __name__ == '__main__':
    main()
