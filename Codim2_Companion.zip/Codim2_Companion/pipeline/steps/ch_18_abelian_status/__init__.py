"""ch_18_abelian_status — HC status on abelian varieties."""
from .compute import main

if __name__ == '__main__':
    main()
