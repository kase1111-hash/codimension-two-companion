#!/usr/bin/env python3
"""
ch_15_noether_lefschetz_divisors — NL loci in moduli.

NL loci are codim-≥1 subvarieties of moduli spaces where the Picard
rank (or Hodge-(p,p) lattice rank) jumps. For surfaces, this is
classical. For 4-folds, the analog is the Hassett special-cubic
locus (treated in ch_21).

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_15_noether_lefschetz_divisors'


NL_DIVISORS = [
    # ── Classical surface NL loci ───────────────────────
    {
        'moduli_space': 'M_d (degree-d surfaces in P^3)',
        'parameter': 'd ≥ 4',
        'generic_pic': 1,
        'nl_codim': 1,
        'nl_structure': 'NL locus is union of countably many codim-1 components, '
                        'indexed by primitive Hodge classes h ∈ H^{1,1} ∩ H^2(S, Z)',
        'reference': 'Noether 1882; Lefschetz 1924; Green 1989',
        'note': 'Classical: NL components are dense in moduli but have density-0 '
                'union (Green 1989 Hilbert-Mumford style).',
    },
    {
        'moduli_space': 'F_g (polarized K3 moduli)',
        'parameter': 'g ≥ 2',
        'generic_pic': 1,
        'nl_codim': 1,
        'nl_structure': 'NL divisors NL_d parameterize K3s with Picard rank ≥ 2; '
                        'each NL_d has its own moduli of K3s with NS ⊃ <h, L> of '
                        'specified intersection form.',
        'reference': 'Maulik-Pandharipande 2013; Borcherds 1998',
        'note': 'NL theory for K3s is well-developed via modular forms (Borcherds).',
    },
    {
        'moduli_space': 'F_g (K3 moduli, codim 2)',
        'parameter': 'g ≥ 4',
        'generic_pic': 1,
        'nl_codim': 2,
        'nl_structure': 'Higher-codim NL loci: K3s with NS rank ≥ 3.',
        'reference': 'Maulik-Pandharipande 2013',
    },
    # ── HK NL loci ──────────────────────────────────────
    {
        'moduli_space': 'M_{K3^[n], 2d} (polarized K3^[n] moduli)',
        'parameter': 'n ≥ 2',
        'generic_pic': 1,
        'nl_codim': 1,
        'nl_structure': 'NL divisors on K3^[n] moduli parameterize HK varieties '
                        'with extra Hodge classes in H^{2,2}; via Markman/Verbitsky '
                        'monodromy these mirror NL divisors on K3 moduli.',
        'reference': 'Markman 2010; Bayer-Hassett-Tschinkel 2018',
    },
    # ── Cubic 4-fold NL loci = Hassett ──────────────────
    {
        'moduli_space': 'M_{cubic 4-fold}',
        'parameter': '20-dim moduli',
        'generic_pic': 1,
        'nl_codim': 1,
        'nl_structure': 'NL divisors = Hassett special-cubic divisors C_d, indexed '
                        'by admissible discriminants d (see ch_21).',
        'reference': 'Hassett 2000',
        'note': 'Hassett discriminants are the cubic-4-fold analog of NL theory.',
    },
    # ── Hilb K3 NL ──────────────────────────────────────
    {
        'moduli_space': 'Hilb^2(K3) (with polarization)',
        'parameter': 'specific',
        'generic_pic': 2,
        'nl_codim': 1,
        'nl_structure': 'NL_d parameterizes Hilb^2(K3) with H^{2,2} rank ≥ 3.',
        'reference': 'Markman 2011',
    },
    # ── CY 4-fold NL (limited) ──────────────────────────
    {
        'moduli_space': 'M_{CY 4-fold sextic}',
        'parameter': '~426-dim moduli',
        'generic_pic': 1,
        'nl_codim': 1,
        'nl_structure': 'NL divisors largely conjectural; some explicit families '
                        '(e.g., sextics containing a plane → +1 to NS rank).',
        'reference': '—',
        'note': 'CY-4-fold NL theory is underdeveloped; central open question is '
                'how to enumerate / classify components.',
    },
    {
        'moduli_space': 'M_{CY 4-fold (2,5) c.i.}',
        'parameter': 'high-dim',
        'generic_pic': 1,
        'nl_codim': 1,
        'nl_structure': 'NL divisors: c.i. CY 4-folds containing a P^1, a P^2, etc.',
        'reference': '—',
    },
    # ── Abelian moduli NL ──────────────────────────────
    {
        'moduli_space': 'A_g (PPAV moduli)',
        'parameter': 'g ≥ 4',
        'generic_pic': 1,
        'nl_codim': 1,
        'nl_structure': 'Andreotti-Mayer / Shimura subvarieties: AVs with non-generic '
                        'Mumford-Tate group. The CM locus is a countable union of '
                        'isolated points (dim 0).',
        'reference': 'Andreotti-Mayer 1967; Mumford 1969',
    },
    # ── Andre-style NL on motives ──────────────────────
    {
        'moduli_space': 'Variation of Hodge structure (general)',
        'parameter': '—',
        'generic_pic': '—',
        'nl_codim': 'varies',
        'nl_structure': 'Cattani-Deligne-Kaplan 1995: NL loci are algebraic '
                        '(not just analytic) — a deep theorem confirming Hodge '
                        'locus algebraicity.',
        'reference': 'Cattani-Deligne-Kaplan 1995',
        'note': 'Foundational: NL loci ARE algebraic subvarieties, not just '
                'transcendentally defined.',
    },
]


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_15_noether_lefschetz_divisors — NL Loci Atlas", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(NL_DIVISORS), preset=args.preset)
    
    try:
        # Display
        step(1, 2, "Compiling NL atlas ...")
        section("NOETHER-LEFSCHETZ LOCI ACROSS MODULI")
        rows = []
        for nl in NL_DIVISORS:
            rows.append((
                nl['moduli_space'][:34],
                nl['parameter'][:14],
                str(nl['generic_pic'])[:8],
                str(nl['nl_codim'])[:8],
                nl['reference'][:30],
            ))
        summary_table(rows, ['Moduli', 'Parameter', 'Gen. Pic', 'NL codim', 'Reference'],
                      fmt=['<34', '<14', '<8', '<10', '<30'])
        
        section("KEY OBSERVATIONS")
        print(f"  • {C.green('Classical NL theory')} (surfaces, K3 moduli) is well-developed.")
        print(f"  • {C.warn('CY 4-fold NL theory')} is largely conjectural — central open question.")
        print(f"  • {C.highlight('Hassett discriminants are NL divisors for cubic 4-folds')}.")
        print(f"  • {C.highlight('Cattani-Deligne-Kaplan')}: NL loci ARE algebraic subvarieties, "
              f"so NL components themselves carry algebraic-cycle structure.")
        print(f"  • For codim-2 HC: NL divisors are {C.green('where cycles come from')}. Building "
              f"a comprehensive NL catalog for CY 4-folds is a {C.warn('frontier task')}.")
        
        # Save
        step(2, 2, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'nl_divisors_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(NL_DIVISORS[0].keys()))
            writer.writeheader()
            for row in NL_DIVISORS:
                writer.writerow({k: row.get(k, '') for k in NL_DIVISORS[0].keys()})
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'nl_divisors_table.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 15,
                'data': NL_DIVISORS,
                'summary': {'total': len(NL_DIVISORS)},
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(NL_DIVISORS), items_total=len(NL_DIVISORS),
                       artifacts=['nl_divisors_table.csv', 'nl_divisors_table.json'])
        print()
        print(C.green("  ✓ ch_15_noether_lefschetz_divisors finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
