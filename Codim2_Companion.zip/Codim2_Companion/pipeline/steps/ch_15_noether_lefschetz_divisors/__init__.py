"""ch_15_noether_lefschetz_divisors — NL loci atlas."""
from .compute import main
if __name__ == '__main__':
    main()
