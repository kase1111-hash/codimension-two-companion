"""ch_22_cy_4fold_hodge_numbers — CY 4-fold Hodge numbers."""
from .compute import main
if __name__ == '__main__':
    main()
