"""ch_38_beilinson_l_values — Beilinson L-value framework."""
from .compute import main
if __name__ == '__main__':
    main()
