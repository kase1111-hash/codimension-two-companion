"""ch_07_three_gifts_table — The three gifts of codimension 1."""
from .compute import main

if __name__ == '__main__':
    main()
