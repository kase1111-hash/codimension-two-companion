#!/usr/bin/env python3
"""
ch_07_three_gifts_table — The three gifts of codimension 1.

From Chapter 7 of Codimension Two: codim 1 enjoys three structural
features that fail at codim 2:
  1. The exponential sequence (a classifying sheaf O*)
  2. The Lefschetz (1,1) theorem (which uses gift 1)
  3. The Picard variety (moduli for divisor classes)

This step renders the comparison table.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import add_standard_args, resolve_args, banner, section, step, C, Timer
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_07_three_gifts_table'


GIFTS = [
    {
        'gift': 'Classifying sheaf',
        'codim_1_has': 'The exponential sequence 0 → Z → O → O* → 0 produces O*, a sheaf whose first '
                       'cohomology classifies divisors (line bundles) up to linear equivalence: '
                       'Pic(X) = H^1(X, O*).',
        'codim_2_lacks': 'No analogous classifying sheaf exists for codim-2 cycles. There is no '
                         'short exact sequence whose middle term classifies codim-2 cycles globally.',
        'consequence_codim_1': 'Pic(X) is a Lie group; Lefschetz (1,1) embeds the algebraic part '
                               'directly into Pic(X).',
        'consequence_codim_2': 'Codim-2 cycle classes must be constructed individually; there is no '
                               'universal classifying map.',
    },
    {
        'gift': 'Lefschetz (1,1) theorem',
        'codim_1_has': 'Every integral class of Hodge type (1,1) is algebraic. This is the Hodge '
                       'conjecture for divisors, proven by Lefschetz 1924.',
        'codim_2_lacks': 'No analog at codim 2. Integral (2,2)-classes need not be algebraic '
                         '(Atiyah-Hirzebruch 1962 counterexamples); even the rational version is '
                         'the central open question.',
        'consequence_codim_1': 'The Hodge conjecture is proven for codim 1 on every smooth '
                               'projective variety.',
        'consequence_codim_2': 'Codim-2 verification proceeds class-by-class via constructive '
                               'methods (Hassett, Kuga-Satake, etc.) or remains open.',
    },
    {
        'gift': 'Picard variety',
        'codim_1_has': 'Pic^0(X) is a complex torus / abelian variety; the moduli space of '
                       'divisor classes carries algebraic group structure.',
        'codim_2_lacks': 'The intermediate Jacobian J^2(X) is a complex torus but generally not '
                         'algebraic in codim 2. Algebraic part vs transcendental part splits: '
                         'algebraic = Griffiths zero-locus.',
        'consequence_codim_1': 'Abel-Jacobi map for codim 1 is surjective onto Pic^0(X).',
        'consequence_codim_2': 'Abel-Jacobi map for codim 2 has image only in the algebraic part '
                               'of J^2(X); transcendental part may be detected (Griffiths group, '
                               'Clemens 1983: uncountable for generic quintic 3-fold).',
    },
]


def render_svg(gifts: list) -> str:
    """Render a simple table SVG."""
    canvas_w = 1200
    row_h = 130
    header_h = 50
    canvas_h = header_h + row_h * len(gifts) + 40
    col_widths = [180, 320, 320, 380]
    col_xs = [20]
    for w in col_widths[:-1]:
        col_xs.append(col_xs[-1] + w)
    
    out = []
    out.append('<?xml version="1.0" encoding="UTF-8"?>')
    out.append(f'<svg xmlns="http://www.w3.org/2000/svg" '
               f'width="{canvas_w}" height="{canvas_h}" '
               f'viewBox="0 0 {canvas_w} {canvas_h}">')
    out.append(f'  <rect width="{canvas_w}" height="{canvas_h}" fill="white"/>')
    
    # Title
    out.append(f'  <text x="{canvas_w/2}" y="30" text-anchor="middle" '
               f'font-family="serif" font-size="20" font-weight="bold" '
               f'fill="#1F2937">The Three Gifts of Codimension 1</text>')
    
    # Header
    headers = ['Gift', 'What codim 1 has', 'What codim 2 lacks', 'Consequence']
    header_y = 50
    out.append(f'  <rect x="0" y="{header_y}" width="{canvas_w}" height="{header_h-10}" '
               f'fill="#285E61"/>')
    for i, h in enumerate(headers):
        out.append(f'  <text x="{col_xs[i] + col_widths[i]/2}" y="{header_y + 28}" '
                   f'text-anchor="middle" font-family="serif" font-size="14" '
                   f'font-weight="bold" fill="white">{h}</text>')
    
    # Rows
    for i, gift in enumerate(gifts):
        row_y = header_y + header_h - 10 + i * row_h
        fill = '#F9FAFB' if i % 2 == 0 else '#FFFFFF'
        out.append(f'  <rect x="0" y="{row_y}" width="{canvas_w}" height="{row_h}" '
                   f'fill="{fill}" stroke="#D1D5DB" stroke-width="0.5"/>')
        # Gift name
        out.append(_wrap_text(gift['gift'], col_xs[0] + 10, row_y + 30, col_widths[0] - 20,
                              font_size=14, weight='bold', color='#7B3909'))
        # Has
        out.append(_wrap_text(gift['codim_1_has'], col_xs[1] + 10, row_y + 22, col_widths[1] - 20,
                              font_size=11, color='#1F2937'))
        # Lacks
        out.append(_wrap_text(gift['codim_2_lacks'], col_xs[2] + 10, row_y + 22, col_widths[2] - 20,
                              font_size=11, color='#1F2937'))
        # Consequence
        c1 = gift['consequence_codim_1']
        c2 = gift['consequence_codim_2']
        out.append(_wrap_text(f"Codim 1: {c1}", col_xs[3] + 10, row_y + 22,
                              col_widths[3] - 20, font_size=10, color='#285E61'))
        out.append(_wrap_text(f"Codim 2: {c2}", col_xs[3] + 10, row_y + 22 + 60,
                              col_widths[3] - 20, font_size=10, color='#7B3909'))
    
    out.append('</svg>')
    return '\n'.join(out)


def _wrap_text(text: str, x: int, y: int, max_width: int,
               font_size: int = 11, weight: str = 'normal', color: str = '#1F2937') -> str:
    """Naive text wrapping: split into ~max-width-character lines."""
    char_w = font_size * 0.55  # rough estimate
    max_chars = int(max_width / char_w)
    words = text.split()
    lines = []
    cur = []
    cur_len = 0
    for w in words:
        if cur_len + len(w) + 1 > max_chars:
            lines.append(' '.join(cur))
            cur = [w]
            cur_len = len(w)
        else:
            cur.append(w)
            cur_len += len(w) + 1
    if cur:
        lines.append(' '.join(cur))
    
    line_h = font_size * 1.3
    out = []
    for i, line in enumerate(lines[:5]):
        ly = y + i * line_h
        out.append(f'  <text x="{x}" y="{ly}" font-family="serif" font-size="{font_size}" '
                   f'font-weight="{weight}" fill="{color}">{_xml_escape(line)}</text>')
    return '\n'.join(out)


def _xml_escape(s: str) -> str:
    return (s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
             .replace('"', '&quot;'))


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_07_three_gifts_table — The Three Gifts of Codimension 1", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0, items_total=3, preset=args.preset)
    
    try:
        # CSV
        step(1, 3, "Writing CSV ...")
        csv_path = output_dir / 'three_gifts_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'gift', 'codim_1_has', 'codim_2_lacks',
                'consequence_codim_1', 'consequence_codim_2',
            ])
            writer.writeheader()
            for g in GIFTS:
                writer.writerow(g)
        write_progress(STEP_ID, items_done=1, items_total=3)
        
        # JSON
        step(2, 3, "Writing JSON ...")
        json_path = output_dir / 'three_gifts_table.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({'step': STEP_ID, 'chapter': 7, 'gifts': GIFTS}, f, indent=2)
        write_progress(STEP_ID, items_done=2, items_total=3)
        
        # SVG
        step(3, 3, "Rendering SVG ...")
        svg = render_svg(GIFTS)
        svg_path = output_dir / 'three_gifts_figure.svg'
        with open(svg_path, 'w', encoding='utf-8') as f:
            f.write(svg)
        write_progress(STEP_ID, items_done=3, items_total=3)
        
        section("RESULTS")
        for g in GIFTS:
            print(f"  {C.highlight(g['gift'])}")
            print(f"    Codim 1: {g['codim_1_has'][:80]}...")
            print(f"    Codim 2 lacks: {g['codim_2_lacks'][:80]}...")
        
        section("OUTPUT FILES")
        for p in sorted(output_dir.glob('*')):
            if p.name != 'progress.json':
                print(f"  {p.name:<28} ({p.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete', items_done=3, items_total=3,
                       artifacts=[p.name for p in output_dir.glob('*')
                                  if p.name != 'progress.json'])
        print()
        print(C.green("  ✓ ch_07_three_gifts_table finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
