"""ch_30_chow_regulators — Beilinson regulator framework."""
from .compute import main
if __name__ == '__main__':
    main()
