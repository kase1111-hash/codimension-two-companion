#!/usr/bin/env python3
"""
ch_04_codim_grid — Renders the codimension grid visualization.

The grid shows for each (n, k) with n = ambient dim, k = codimension:
  • TRIVIAL (gray): cells where k=0, k=n, or k=1 (Lefschetz settled)
  • SETTLED (teal): cells where the Hodge conjecture is fully established
  • OPEN-CANONICAL (amber, dashed): the (n=4, k=2) canonical open cell
  • OPEN (amber hatched): other open cells

Author: Kase Branham — Independent Researcher
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    Timer, C, debug,
)
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_04_codim_grid'

# Cell state definitions
TRIVIAL = 'trivial'
SETTLED = 'settled'
OPEN_CANONICAL = 'open_canonical'
OPEN = 'open'

# Color scheme (matches parent book Figure 4.1)
COLORS = {
    TRIVIAL:        {'fill': '#E2E8F0', 'stroke': '#94A3B8', 'text': '#475569'},
    SETTLED:        {'fill': '#285E61', 'stroke': '#134E4A', 'text': '#FFFFFF'},
    OPEN_CANONICAL: {'fill': '#ED8936', 'stroke': '#7B3909', 'text': '#7B3909'},
    OPEN:           {'fill': '#ED8936', 'stroke': '#7B3909', 'text': '#7B3909'},
}


def classify_cell(n: int, k: int) -> str:
    """Determine the state of cell (n, k) for the codim-2 Hodge conjecture landscape.
    
    Classification rules:
      - k = 0, or k > n: trivial (gray)
      - k = n: top class (trivially settled, but we'll show as 'settled')
      - k = 1: Lefschetz (1,1) settled
      - k = n-1: dual to k=1 via Hard Lefschetz, settled
      - (n=4, k=2): the canonical open cell
      - 2 ≤ k ≤ n-2 otherwise: open(dual pairs via Hard Lefschetz)
      - else: settled (low-dim cases where Hard Lefschetz reduces to codim-1)
    """
    debug(f"Classifying cell n={n}, k={k}")
    # Boundary / trivial cases
    if k < 0 or k > n:
        return TRIVIAL
    if k == 0:
        return TRIVIAL  # codim-0 = ambient, not a cycle question
    if k == n:
        return SETTLED  # top class
    if k == 1:
        return SETTLED  # Lefschetz (1,1)
    if k == n - 1:
        return SETTLED  # Hard Lefschetz dual to codim-1
    # Main open frontier: 2 ≤ k ≤ n-2
    if n == 4 and k == 2:
        return OPEN_CANONICAL
    if 2 <= k <= n - 2:
        return OPEN
    # Should not reach here for n ≤ k_max, but defensively return SETTLED
    return SETTLED


def build_grid_data(n_max: int, k_max: int) -> dict:
    """Build the (n, k) grid with classification per cell."""
    debug(f"Building grid n_max={n_max}, k_max={k_max}")
    cells = {}
    for n in range(1, n_max + 1):
        for k in range(0, k_max + 1):
            state = classify_cell(n, k)
            cells[f"{n},{k}"] = {
                'n': n,
                'k': k,
                'state': state,
                'label': _cell_label(n, k, state),
            }
    return {
        'n_max': n_max,
        'k_max': k_max,
        'cells': cells,
    }


def _cell_label(n: int, k: int, state: str) -> str:
    if state == TRIVIAL:
        return "—"
    if state == SETTLED:
        if k == 1:
            return "Lef"
        if k == n:
            return "top"
        return "✓"
    return "?"


def render_svg(grid: dict, cell_px: int = 60, margin: int = 80) -> str:
    """Render the grid to SVG."""
    debug("Rendering SVG")
    n_max = grid['n_max']
    k_max = grid['k_max']
    
    grid_w = (n_max + 1) * cell_px
    grid_h = (k_max + 1) * cell_px
    canvas_w = grid_w + 2 * margin
    canvas_h = grid_h + 2 * margin
    
    out = []
    out.append(f'<?xml version="1.0" encoding="UTF-8"?>')
    out.append(f'<svg xmlns="http://www.w3.org/2000/svg" '
               f'width="{canvas_w}" height="{canvas_h}" viewBox="0 0 {canvas_w} {canvas_h}">')
    out.append('  <defs>')
    out.append('    <pattern id="amber-hatch" patternUnits="userSpaceOnUse" '
               'width="6" height="6" patternTransform="rotate(45)">')
    out.append('      <line x1="0" y1="0" x2="0" y2="6" stroke="#7B3909" stroke-width="1.2"/>')
    out.append('    </pattern>')
    out.append('  </defs>')
    out.append(f'  <rect width="{canvas_w}" height="{canvas_h}" fill="white"/>')
    
    # Title
    out.append(f'  <text x="{canvas_w/2}" y="{margin/2 + 6}" '
               f'text-anchor="middle" font-family="serif" font-size="22" font-weight="bold" '
               f'fill="#1F2937">The Codimension Grid</text>')
    out.append(f'  <text x="{canvas_w/2}" y="{margin/2 + 30}" '
               f'text-anchor="middle" font-family="serif" font-size="13" '
               f'fill="#6B7280">codim k vs ambient dimension n</text>')
    
    # Axis labels
    out.append(f'  <text x="{margin + grid_w/2}" y="{canvas_h - margin/2 + 12}" '
               f'text-anchor="middle" font-family="serif" font-size="14" '
               f'fill="#1F2937">n (ambient dimension)</text>')
    out.append(f'  <text x="{margin/2 - 8}" y="{margin + grid_h/2}" '
               f'text-anchor="middle" font-family="serif" font-size="14" '
               f'fill="#1F2937" transform="rotate(-90 {margin/2 - 8} {margin + grid_h/2})">'
               f'k (codimension)</text>')
    
    # Grid cells
    for n in range(0, n_max + 1):
        for k in range(0, k_max + 1):
            # Cell position: n on x-axis, k on y-axis (inverted so k=0 at bottom)
            x = margin + n * cell_px
            y = margin + (k_max - k) * cell_px
            
            if n == 0 or k > k_max:
                # Header row / col
                continue
            
            key = f"{n},{k}"
            cell = grid['cells'].get(key)
            if cell is None:
                continue
            
            state = cell['state']
            colors = COLORS[state]
            
            if state in (OPEN, OPEN_CANONICAL):
                # Amber + hatch overlay
                out.append(f'  <rect x="{x}" y="{y}" width="{cell_px}" height="{cell_px}" '
                           f'fill="{colors["fill"]}" stroke="{colors["stroke"]}" stroke-width="1.5"/>')
                out.append(f'  <rect x="{x}" y="{y}" width="{cell_px}" height="{cell_px}" '
                           f'fill="url(#amber-hatch)" opacity="0.55"/>')
                if state == OPEN_CANONICAL:
                    # Dashed outline emphasis
                    out.append(f'  <rect x="{x+2}" y="{y+2}" width="{cell_px-4}" height="{cell_px-4}" '
                               f'fill="none" stroke="{colors["stroke"]}" stroke-width="2.5" '
                               f'stroke-dasharray="4,3"/>')
            else:
                out.append(f'  <rect x="{x}" y="{y}" width="{cell_px}" height="{cell_px}" '
                           f'fill="{colors["fill"]}" stroke="{colors["stroke"]}" stroke-width="1.5"/>')
            
            # Cell label
            out.append(f'  <text x="{x + cell_px/2}" y="{y + cell_px/2 + 5}" '
                       f'text-anchor="middle" font-family="serif" font-size="14" '
                       f'fill="{colors["text"]}">{cell["label"]}</text>')
    
    # Axis tick labels
    for n in range(1, n_max + 1):
        x = margin + n * cell_px + cell_px / 2
        y = margin + grid_h + 20
        out.append(f'  <text x="{x}" y="{y}" text-anchor="middle" '
                   f'font-family="serif" font-size="13" fill="#1F2937">{n}</text>')
    for k in range(1, k_max + 1):
        x = margin - 14
        y = margin + (k_max - k) * cell_px + cell_px / 2 + 5
        out.append(f'  <text x="{x}" y="{y}" text-anchor="middle" '
                   f'font-family="serif" font-size="13" fill="#1F2937">{k}</text>')
    
    # Legend
    legend_y = canvas_h - margin/2 - 40
    legend_items = [
        (SETTLED, "settled"),
        (OPEN, "open"),
        (OPEN_CANONICAL, "open(canonical: codim 2 on 4-fold)"),
        (TRIVIAL, "trivial"),
    ]
    lx = margin
    for state, label in legend_items:
        colors = COLORS[state]
        out.append(f'  <rect x="{lx}" y="{legend_y}" width="14" height="14" '
                   f'fill="{colors["fill"]}" stroke="{colors["stroke"]}" stroke-width="1"/>')
        if state in (OPEN, OPEN_CANONICAL):
            out.append(f'  <rect x="{lx}" y="{legend_y}" width="14" height="14" '
                       f'fill="url(#amber-hatch)" opacity="0.55"/>')
        out.append(f'  <text x="{lx + 20}" y="{legend_y + 11}" '
                   f'font-family="serif" font-size="11" fill="#374151">{label}</text>')
        lx += 18 + len(label) * 6.5 + 16
    
    out.append('</svg>')
    return '\n'.join(out)


def render_png(svg_path: Path, png_path: Path):
    """Convert SVG to PNG at 300 DPI using cairosvg."""
    try:
        import cairosvg
        debug(f"Converting SVG → PNG at 300 DPI")
        cairosvg.svg2png(url=str(svg_path), write_to=str(png_path),
                         output_width=None, output_height=None, dpi=300)
        return True
    except ImportError:
        print(C.warn("  cairosvg not available; PNG generation skipped"))
        return False
    except Exception as e:
        print(C.fail(f"  PNG conversion failed: {e}"))
        return False


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    parser.add_argument('--n-max', type=int, default=5,
                        help='Max ambient dimension (default: 5)')
    parser.add_argument('--k-max', type=int, default=5,
                        help='Max codimension (default: 5)')
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_04_codim_grid — The Codimension Grid", {
        'n_max': args.n_max,
        'k_max': args.k_max,
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0, items_total=3,
                   preset=args.preset)
    
    try:
        # Step 1: build grid data
        step(1, 3, "Building grid classification ...")
        with Timer("Grid classification"):
            grid = build_grid_data(args.n_max, args.k_max)
        grid_json_path = output_dir / 'grid_data.json'
        with open(grid_json_path, 'w', encoding='utf-8') as f:
            json.dump(grid, f, indent=2)
        print(f"    {len(grid['cells'])} cells classified")
        write_progress(STEP_ID, items_done=1, items_total=3)
        
        # Step 2: render SVG
        step(2, 3, "Rendering SVG ...")
        with Timer("SVG render"):
            svg = render_svg(grid)
        svg_path = output_dir / 'figure_4_1_codim_grid.svg'
        with open(svg_path, 'w', encoding='utf-8') as f:
            f.write(svg)
        print(f"    {svg_path}")
        write_progress(STEP_ID, items_done=2, items_total=3)
        
        # Step 3: render PNG
        step(3, 3, "Rendering PNG ...")
        png_path = output_dir / 'figure_4_1_codim_grid.png'
        png_ok = render_png(svg_path, png_path)
        if png_ok:
            print(f"    {png_path}")
        write_progress(STEP_ID, items_done=3, items_total=3)
        
        # Section: results
        section("RESULTS")
        from collections import Counter
        state_counts = Counter(c['state'] for c in grid['cells'].values())
        print(f"  Cell state distribution:")
        for state, count in state_counts.most_common():
            color_fn = (C.green if state == SETTLED
                        else C.fail if state == OPEN_CANONICAL
                        else C.warn if state == OPEN
                        else C.muted)
            print(f"    {state:>18}: {color_fn(str(count))}")
        
        section("OUTPUT FILES")
        for p in sorted(output_dir.glob('*')):
            if p.suffix in ('.svg', '.png', '.json'):
                size_kb = p.stat().st_size / 1024
                print(f"  {p.name:<35} ({size_kb:.1f} KB)")
        
        write_progress(STEP_ID, status='complete', items_done=3, items_total=3,
                       artifacts=[str(p.name) for p in output_dir.glob('*')
                                  if p.suffix != '.json' or p.name != 'progress.json'])
        
        section("COMPLETE")
        print(C.green("  ✓ ch_04_codim_grid finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
