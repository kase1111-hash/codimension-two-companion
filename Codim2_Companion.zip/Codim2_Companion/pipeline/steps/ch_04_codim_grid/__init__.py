"""ch_04_codim_grid — Renders the codimension grid visualization."""
from .compute import main

if __name__ == '__main__':
    main()
