#!/usr/bin/env python3
"""
ch_19_k3_atlas — K3 surface atlas.

For each K3 in the atlas: polarization, Picard rank ρ, Néron-Severi
lattice signature, transcendental lattice rank (22 - ρ), HC status,
references.

The full K3 cohomology lattice is H^2(X, Z) ≅ Λ_{K3} = E_8(-1)^2 ⊕ U^3
(rank 22, signature (3,19)).
  - Picard lattice NS(X) has signature (1, ρ-1), rank ρ ≤ 20.
  - Transcendental T(X) has signature (2, 20-ρ), rank 22-ρ.

HC for K3 surfaces is settled (codim 1 = Lefschetz; codim 2 = top class).
This step is about catalog construction, not HC verification per se.
The output feeds Kuga-Satake (Ch 12), hyperkähler lattices (Ch 25),
and Chow regulators (Ch 30).

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import multiprocessing as mp
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    parallel_map, summary_table, C, debug, Timer,
)
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_19_k3_atlas'

# K3 cohomology lattice rank
LAMBDA_K3_RANK = 22  # E_8(-1)^2 ⊕ U^3
LAMBDA_K3_SIG = (3, 19)


# ═══════════════════════════════════════════════════════════════════
#  K3 ATLAS ENTRIES
# ═══════════════════════════════════════════════════════════════════
#
# Each entry is a K3 surface specification. For generic members of
# polarized moduli F_g (where 2g - 2 is the polarization degree),
# Picard rank is 1. Higher Picard rank K3s arise from specific
# constructions (Kummer, Shioda-Inose, singular).
#
# Polarization degree d = (H, H) for the polarization H of NS(S).
# For F_g: d = 2g - 2, so F_2 = double covers, F_3 = quartics in P^3,
# F_4 = (2,3) in P^4, F_5 = (2,2,2) in P^5, etc.

K3_ATLAS_ENTRIES = [
    # ── Generic polarized K3s (Picard 1) ─────────────────
    {
        'id': 'K3_degree_2_generic',
        'family': 'F_2 (degree-2 K3, double cover of P^2)',
        'polarization_degree': 2,
        'picard_rank': 1,
        'construction': 'Double cover of P^2 branched along smooth sextic',
        'reference': 'classical; Huybrechts Lectures',
    },
    {
        'id': 'K3_degree_4_quartic',
        'family': 'F_3 (quartic in P^3)',
        'polarization_degree': 4,
        'picard_rank': 1,
        'construction': 'Smooth quartic surface in P^3',
        'reference': 'classical',
    },
    {
        'id': 'K3_degree_6_complete_int',
        'family': 'F_4 ((2,3) c.i. in P^4)',
        'polarization_degree': 6,
        'picard_rank': 1,
        'construction': 'Smooth (2,3) complete intersection in P^4',
        'reference': 'classical',
    },
    {
        'id': 'K3_degree_8_complete_int',
        'family': 'F_5 ((2,2,2) c.i. in P^5)',
        'polarization_degree': 8,
        'picard_rank': 1,
        'construction': 'Smooth (2,2,2) complete intersection in P^5',
        'reference': 'classical',
    },
    {
        'id': 'K3_degree_10_pfaffian',
        'family': 'F_6 (Mukai-Pfaffian model)',
        'polarization_degree': 10,
        'picard_rank': 1,
        'construction': 'Linear section of Grassmannian G(2,5) ∩ quadric',
        'reference': 'Mukai 1988',
    },
    {
        'id': 'K3_degree_12_mukai',
        'family': 'F_7 (Mukai model)',
        'polarization_degree': 12,
        'picard_rank': 1,
        'construction': 'Linear section of OGr(5,10) variety',
        'reference': 'Mukai 1988',
    },
    {
        'id': 'K3_degree_14_mukai',
        'family': 'F_8 (Mukai model)',
        'polarization_degree': 14,
        'picard_rank': 1,
        'construction': 'Linear section of G(3,6)',
        'reference': 'Mukai 1988',
    },
    # ── Higher Picard via construction ───────────────────
    {
        'id': 'K3_kummer_generic_AV',
        'family': 'Kummer K3 (generic abelian surface)',
        'polarization_degree': 2,
        'picard_rank': 17,
        'construction': 'Resolution of A/<-1> for generic abelian surface A',
        'reference': 'Beauville-Donagi 1985; Huybrechts Lectures',
        'note': 'Kummer K3s carry 16 nodes resolving to 16 (-2)-curves; '
                'NS lattice rank ρ = 17 = 1 (generic) + 16 (exceptional curves).',
    },
    {
        'id': 'K3_kummer_E_times_E',
        'family': 'Kummer K3 of E × E',
        'polarization_degree': 2,
        'picard_rank': 18,
        'construction': 'Kummer of product of two isogenous elliptic curves',
        'reference': 'classical',
        'note': 'Extra Pic-1 boost when both factors are isogenous.',
    },
    {
        'id': 'K3_kummer_CM_product',
        'family': 'Kummer K3 of CM(E)^2',
        'polarization_degree': 2,
        'picard_rank': 20,
        'construction': 'Kummer of E × E with E having complex multiplication',
        'reference': 'Shioda-Inose 1977',
        'note': 'Singular K3 (max Pic) — CM gives full Pic-20.',
    },
    {
        'id': 'K3_shioda_inose',
        'family': 'Shioda-Inose K3',
        'polarization_degree': 'varies',
        'picard_rank': 19,
        'construction': 'K3 with Shioda-Inose structure: covers Kummer of CM AV',
        'reference': 'Shioda-Inose 1977',
        'note': 'Pic 19 = "almost singular"; transcendental T(X) has rank 3.',
    },
    {
        'id': 'K3_singular_disc_3',
        'family': 'Singular K3 (Pic 20)',
        'polarization_degree': 'varies',
        'picard_rank': 20,
        'construction': 'Smallest discriminant singular K3 (T(X) rank 2, '
                        'discriminant 3)',
        'reference': 'Shioda-Inose 1977; Vinberg 1983',
        'note': 'Among the 13 isomorphism classes of singular K3s with small '
                'discriminant T(X).',
    },
    # ── Famous specific K3s ──────────────────────────────
    {
        'id': 'K3_fermat_quartic',
        'family': 'Fermat quartic',
        'polarization_degree': 4,
        'picard_rank': 20,
        'construction': 'x^4 + y^4 + z^4 + w^4 = 0 in P^3',
        'reference': 'Shioda-Mitani 1974',
        'note': 'Singular K3; Pic 20; arithmetic over Q(i).',
    },
    {
        'id': 'K3_schoen_X8',
        'family': 'Schoen 4-cycle K3',
        'polarization_degree': 4,
        'picard_rank': 18,
        'construction': 'Resolution of 4-cyclic quotient',
        'reference': 'Schoen 1988',
        'note': 'Used in Borcea-Voisin CY 3-fold construction.',
    },
    {
        'id': 'K3_BL_Inose',
        'family': 'Beauville-Inose K3',
        'polarization_degree': 'varies',
        'picard_rank': 19,
        'construction': 'Inose-type triple cover',
        'reference': 'Beauville 1984',
    },
    # ── Elliptic K3s ─────────────────────────────────────
    {
        'id': 'K3_elliptic_generic',
        'family': 'Generic elliptic K3',
        'polarization_degree': 'varies',
        'picard_rank': 2,
        'construction': 'K3 with section: NS = <h, f> where f = elliptic fiber',
        'reference': 'classical',
        'note': 'Pic 2: hyperbolic lattice <h, f> with (f, f) = 0.',
    },
    {
        'id': 'K3_elliptic_with_section_and_singular_fiber',
        'family': 'Elliptic K3 with extra sections',
        'polarization_degree': 'varies',
        'picard_rank': 'varies',
        'construction': 'K3 elliptic fibration with Mordell-Weil group',
        'reference': 'Schütt-Shioda 2019',
        'note': 'Pic = 2 + rank(MW) + sum(reducible fiber components - 1).',
    },
]


# ═══════════════════════════════════════════════════════════════════
#  WORKER
# ═══════════════════════════════════════════════════════════════════

def worker(item: dict) -> dict:
    """Enrich a K3 atlas entry with derived lattice and HC data."""
    try:
        debug(f"Worker: K3 {item['id']}")
        pic = item.get('picard_rank')
        # Compute transcendental rank
        if isinstance(pic, int):
            transcendental_rank = LAMBDA_K3_RANK - pic
            ns_signature = (1, pic - 1) if pic >= 1 else None
            t_signature = (2, 20 - pic) if pic <= 20 else None
            disc_pic_lattice = 'unknown'  # would need lattice db
        else:
            transcendental_rank = 'varies'
            ns_signature = 'varies'
            t_signature = 'varies'
            disc_pic_lattice = 'varies'
        
        # HC status for K3: always settled (Lefschetz codim-1; top class codim-2)
        hc_status = 'settled'
        hc_reference = 'Lefschetz (1,1); top class trivial'
        
        return {
            **item,
            'lambda_k3_rank': LAMBDA_K3_RANK,
            'lambda_k3_signature': LAMBDA_K3_SIG,
            'transcendental_rank': transcendental_rank,
            'ns_signature': ns_signature,
            't_signature': t_signature,
            'discriminant_pic_lattice': disc_pic_lattice,
            'hc_status': hc_status,
            'hc_reference': hc_reference,
        }
    except Exception as e:
        return {'error': str(e), **item}


# ═══════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    parser.add_argument('--pic-max', type=int, default=20)
    parser.add_argument('--include-singular', action='store_true', default=True)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_19_k3_atlas — K3 Surface Atlas", {
        'pic_max': args.pic_max,
        'include_singular': args.include_singular,
        'workers': args.workers,
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(K3_ATLAS_ENTRIES), preset=args.preset)
    
    try:
        # Filter
        step(1, 4, "Building work list ...")
        entries = K3_ATLAS_ENTRIES
        if not args.include_singular:
            entries = [e for e in entries
                       if isinstance(e.get('picard_rank'), int)
                       and e['picard_rank'] < 20]
        if isinstance(args.pic_max, int):
            entries = [e for e in entries
                       if not isinstance(e.get('picard_rank'), int)
                       or e['picard_rank'] <= args.pic_max]
        print(f"    {len(entries)} K3 entries selected")
        
        # Compute
        step(2, 4, f"Enriching atlas on {args.workers} worker(s) ...")
        with Timer("K3 atlas enrichment"):
            results = parallel_map(worker, entries, args.workers, desc="K3 surfaces")
        write_progress(STEP_ID, items_done=len(results), items_total=len(K3_ATLAS_ENTRIES))
        
        good = [r for r in results if 'error' not in r]
        errors = [r for r in results if 'error' in r]
        if errors:
            section(f"ERRORS ({len(errors)})")
            for e in errors[:5]:
                print(f"  {e}")
        
        # Analyze
        step(3, 4, "Analyzing ...")
        section("K3 ATLAS")
        rows = []
        for r in good:
            pic = r.get('picard_rank')
            pic_str = str(pic) if pic != 'varies' else 'var'
            tr = r.get('transcendental_rank')
            tr_str = str(tr) if tr != 'varies' else 'var'
            rows.append((
                r['id'][:32],
                str(r.get('polarization_degree', '?'))[:8],
                pic_str,
                tr_str,
                r['family'][:30],
            ))
        summary_table(rows, ['ID', 'deg', 'ρ', '22-ρ', 'Family'],
                      fmt=['<32', '<8', '<5', '<5', '<30'])
        
        # Distribution
        section("PICARD RANK DISTRIBUTION")
        from collections import Counter
        pic_counts = Counter(r.get('picard_rank') for r in good)
        for pic, n in sorted(pic_counts.items(),
                             key=lambda x: (isinstance(x[0], str), x[0])):
            color = C.green if isinstance(pic, int) and pic <= 5 else \
                    C.warn if isinstance(pic, int) and pic >= 19 else C.cyan
            print(f"  ρ = {color(str(pic)):<5}: {n} K3(s)")
        
        section("KEY FAMILIES")
        print(f"  • {C.green('Generic polarized K3s (Pic 1)')} — F_g moduli for various g")
        print(f"  • {C.warn('Kummer K3s (Pic 17-20)')} — resolutions of A/(±1)")
        print(f"  • {C.warn('Singular K3s (Pic 20)')} — Shioda-Inose; max-Pic; arithmetic")
        print(f"  • {C.cyan('Elliptic K3s')} — Pic = 2 + rank(MW) + reducible fibers")
        print(f"  • {C.cyan('Fermat quartic')} — singular, defined over Q(i)")
        
        # Save
        step(4, 4, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'k3_atlas.csv'
        if good:
            keys = ['id', 'family', 'polarization_degree', 'picard_rank',
                    'transcendental_rank', 'hc_status', 'construction', 'reference', 'note']
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
                writer.writeheader()
                for r in good:
                    writer.writerow(r)
            print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'k3_atlas.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID,
                'chapter': 19,
                'lambda_k3_rank': LAMBDA_K3_RANK,
                'lambda_k3_signature': LAMBDA_K3_SIG,
                'data': good,
                'summary': {
                    'total_k3s': len(good),
                    'errors': len(errors),
                    'picard_rank_distribution': {str(k): v for k, v in pic_counts.items()},
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        lat_path = output_dir / 'k3_lattices.json'
        lat_data = {r['id']: {
            'picard_rank': r.get('picard_rank'),
            'ns_signature': r.get('ns_signature'),
            'transcendental_rank': r.get('transcendental_rank'),
            't_signature': r.get('t_signature'),
        } for r in good}
        with open(lat_path, 'w', encoding='utf-8') as f:
            json.dump(lat_data, f, indent=2)
        print(f"  {lat_path.name}  ({lat_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(good), items_total=len(K3_ATLAS_ENTRIES),
                       errors=len(errors),
                       artifacts=['k3_atlas.csv', 'k3_atlas.json', 'k3_lattices.json'])
        print()
        print(C.green("  ✓ ch_19_k3_atlas finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    mp.freeze_support()
    main()
