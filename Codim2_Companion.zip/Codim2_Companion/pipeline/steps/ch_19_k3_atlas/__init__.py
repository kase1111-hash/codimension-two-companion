"""ch_19_k3_atlas — K3 surface atlas."""
from .compute import main
if __name__ == '__main__':
    main()
