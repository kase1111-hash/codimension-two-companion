#!/usr/bin/env python3
"""
ch_35_ghc_coniveau_table — Generalized Hodge Conjecture / coniveau filtration.

The coniveau filtration on H^k(X, Q):

  N^c H^k(X, Q) = sum of im(H^{k-2c}(Z, Q) → H^k(X, Q))
                  over closed subsets Z ⊂ X of codim ≥ c

  N^0 ⊇ N^1 ⊇ N^2 ⊇ ... ⊇ N^c ⊇ ...

The Hodge filtration F:

  F^c H^k(X, C) = ⊕_{p ≥ c} H^{p, k-p}(X)

Generalized Hodge Conjecture (Grothendieck 1969):

  N^c H^k(X, Q) = H^k(X, Q) ∩ F^c H^k(X, C)

For c = k/2 (top-coniveau case = codim-k cycles in H^{2k}): GHC = HC.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_35_ghc_coniveau_table'


GHC_TABLE = [
    {
        'variety_class': 'curves',
        'k': 2,
        'c': 1,
        'ghc_target': 'N^1 H^2 = H^2 (trivial)',
        'ghc_status': 'settled (trivial)',
        'note': 'H^2(C) = Z, all in coniveau 1.',
    },
    {
        'variety_class': 'surfaces (smooth proj)',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(S) = H^4(S) = Z (top class)',
        'ghc_status': 'settled (top class)',
        'note': 'GHC at top coniveau = top-class HC, trivial.',
    },
    {
        'variety_class': 'surfaces — codim 1 in H^2',
        'k': 2,
        'c': 1,
        'ghc_target': 'N^1 H^2(S) = NS(S) ⊗ Q',
        'ghc_status': 'settled — equivalent to Lefschetz (1,1)',
        'note': 'GHC at c=1, k=2 is exactly Lefschetz (1,1).',
    },
    {
        'variety_class': 'abelian varieties',
        'k': 'any',
        'c': 'any',
        'ghc_target': 'N^c H^k(A) = sub-HS of Hodge type ≥ c',
        'ghc_status': 'settled — Beauville-Voisin eigenspace gives explicit form',
        'reference': 'Beauville 1986; Voisin 1992',
    },
    {
        'variety_class': 'K3 surfaces',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(K3) = Z (top class)',
        'ghc_status': 'settled',
        'note': '',
    },
    {
        'variety_class': 'CY 3-folds (general)',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(X) = N^2 (algebraic codim-2 cycles on X)',
        'ghc_status': 'settled trivially (codim 2 in dim 3 = codim 1 via HL)',
        'note': 'In dim 3, codim 2 ≅ codim 1; both settled.',
    },
    {
        'variety_class': 'CY 3-folds — codim 2 GHC at lower level',
        'k': 3,
        'c': 1,
        'ghc_target': 'N^1 H^3(X) = algebraic-part of J^2(X)',
        'ghc_status': 'partial (Griffiths transcendence)',
        'reference': 'Griffiths 1969; Voisin 1992',
        'note': 'On CY 3-folds, Griffiths group nontriviality measures GHC failure '
                'at (k=3, c=1).',
    },
    {
        'variety_class': '4-folds (general) — codim 2',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(X) = ?',
        'ghc_status': 'open',
        'note': 'GHC at (k=4, c=2) = codim-2 HC. Central frontier.',
    },
    {
        'variety_class': 'CY 4-folds (sextic, c.i.) — codim 2',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(X)',
        'ghc_status': 'open(central frontier)',
        'note': 'Same as HC at codim 2 on these CY 4-folds.',
    },
    {
        'variety_class': 'cubic 4-folds — codim 2',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(X)',
        'ghc_status': 'partial (Hassett-special: settled; generic: open)',
        'note': 'Cleavage matches HC cleavage exactly.',
    },
    {
        'variety_class': 'hyperkähler K3^[n] — codim 2',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(X)',
        'ghc_status': 'settled (Vial / Charles-Markman)',
        'note': '',
    },
    {
        'variety_class': 'hyperkähler OG-10 — codim 2',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(X)',
        'ghc_status': 'open',
        'note': 'Frontier case.',
    },
    {
        'variety_class': 'Fano 4-folds (RC)',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4(X) = H^{2,2}(X) ∩ H^4(X, Q)',
        'ghc_status': 'settled (Bloch-Srinivas)',
        'note': '',
    },
    # Higher-codim cases
    {
        'variety_class': 'general 4-fold — codim 1',
        'k': 2,
        'c': 1,
        'ghc_target': 'N^1 H^2 = NS ⊗ Q',
        'ghc_status': 'settled universally — Lefschetz (1,1)',
        'note': '',
    },
    {
        'variety_class': '5-folds — codim 2 and 3',
        'k': 4,
        'c': 2,
        'ghc_target': 'N^2 H^4',
        'ghc_status': 'open',
        'note': 'Codim 2 in dim 5 is HL-dual to codim 3, both open.',
    },
]


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_35_ghc_coniveau_table — GHC and Coniveau", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(GHC_TABLE), preset=args.preset)
    
    try:
        # Display
        step(1, 2, "Compiling GHC / coniveau table ...")
        section("GENERALIZED HODGE CONJECTURE BY VARIETY × (k, c)")
        rows = []
        for r in GHC_TABLE:
            status = r['ghc_status']
            color = (C.green if 'settled' in status
                     else C.warn if 'partial' in status
                     else C.cyan if 'open' in status else C.muted)
            rows.append((
                r['variety_class'][:40],
                f"({r['k']}, {r['c']})",
                color(status[:30]),
            ))
        summary_table(rows, ['Variety class', '(k, c)', 'GHC status'],
                      fmt=['<40', '<14', '<32'])
        
        section("KEY POINT")
        print(f"  GHC at top coniveau (c = k/2) ≡ HC. So:")
        print(f"    GHC at (k=2, c=1) = Lefschetz (1,1) {C.green('settled')}")
        print(f"    GHC at (k=4, c=2) = codim-2 HC ({C.cyan('open frontier')})")
        print()
        print(f"  GHC at LOWER coniveau (c < k/2) is what gives the {C.warn('refinement')} "
              f"over HC. It's nontrivial on varieties with intermediate Hodge structures.")
        print()
        print(f"  Most notably: {C.warn('Griffiths transcendence on CY 3-folds')} is a GHC-at-low-coniveau "
              f"phenomenon (k=3, c=1), distinct from GHC-at-top (k=4, c=2 on 4-folds).")
        
        # Save
        step(2, 2, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'ghc_coniveau_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(GHC_TABLE[0].keys()),
                                     extrasaction='ignore')
            writer.writeheader()
            for r in GHC_TABLE:
                writer.writerow(r)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'ghc_coniveau_table.json'
        n_settled = sum(1 for r in GHC_TABLE if 'settled' in r['ghc_status'])
        n_open = sum(1 for r in GHC_TABLE if 'open' in r['ghc_status'])
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 35,
                'data': GHC_TABLE,
                'summary': {
                    'total': len(GHC_TABLE),
                    'settled': n_settled,
                    'open': n_open,
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(GHC_TABLE), items_total=len(GHC_TABLE),
                       artifacts=['ghc_coniveau_table.csv', 'ghc_coniveau_table.json'])
        print()
        print(C.green("  ✓ ch_35_ghc_coniveau_table finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
