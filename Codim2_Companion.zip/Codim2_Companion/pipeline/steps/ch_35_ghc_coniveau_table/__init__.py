"""ch_35_ghc_coniveau_table — Generalized HC / coniveau."""
from .compute import main
if __name__ == '__main__':
    main()
