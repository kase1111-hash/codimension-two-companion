#!/usr/bin/env python3
"""
ch_12_kuga_satake_construction — Kuga-Satake bridge K3 → AV.

Given a K3 surface S, the Kuga-Satake construction produces an
abelian variety A_KS(S) of dimension 2^{b_2 - 3} (working with the
transcendental part of H^2 minus the (1,1) part). The construction
provides an embedding of the K3 Hodge structure into End(H^1(A_KS)),
which can sometimes propagate HC information from A_KS down to S.

For each K3 surface in ch_19's atlas, we compute:
  - The rank of the transcendental lattice T(S) (= 22 - ρ)
  - The Kuga-Satake AV dimension (typically 2^{rank(T) - 2})
  - Whether the construction has been used to derive new HC results
    for S or for hyperkähler manifolds built from S

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C, Timer,
)
from registry import get_artifact_path, write_progress, load_upstream


STEP_ID = 'ch_12_kuga_satake_construction'


def ks_dimension(transcendental_rank):
    """Standard Kuga-Satake dimension formula: dim A_KS = 2^{rank(T)-2}.
    
    Caveat: when T is small (rank ≤ 3), the formula degenerates.
    For 'varies' / non-integer transcendental rank, returns None.
    """
    if not isinstance(transcendental_rank, int):
        return None
    if transcendental_rank < 2:
        return None
    return 2 ** (transcendental_rank - 2)


def ks_status_for_k3(k3_id, picard_rank, transcendental_rank):
    """Determine the status / impact of Kuga-Satake for this K3.
    
    For generic K3 surfaces of low Picard rank, the KS construction is
    well-defined but the abelian variety is high-dim (2^{22-ρ-2}), making
    explicit computation hard. For special K3s (Kummer, Shioda-Inose,
    singular), the KS AV simplifies and may match a known AV directly.
    """
    if isinstance(picard_rank, int) and picard_rank == 17:
        # Kummer K3 with generic abelian-surface base: KS recovers A × A
        return ('explicit', 'KS gives A × A for A the abelian surface; HC trivially via A.')
    if isinstance(picard_rank, int) and picard_rank == 18:
        return ('explicit', 'Kummer of E × E gives KS = product of CM/ordinary elliptic curves.')
    if isinstance(picard_rank, int) and picard_rank == 20:
        return ('explicit (small KS)', 'Singular K3: KS AV is product of CM elliptic curves; '
                                       'HC trivially settled via CM.')
    if isinstance(picard_rank, int) and picard_rank == 19:
        return ('partial', 'Shioda-Inose: KS related to AV of dim ≤ 2; HC controllable.')
    if isinstance(picard_rank, int) and picard_rank <= 2:
        return ('formal', 'KS construction defined but AV has high dim (2^{19}+); explicit '
                          'cycle computation infeasible.')
    return ('formal', 'KS defined; explicit cycle propagation case-by-case.')


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_12_kuga_satake_construction — KS Bridge", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Load K3 atlas
        step(1, 3, "Loading K3 atlas from ch_19 ...")
        try:
            k3_atlas = load_upstream('ch_19_k3_atlas', 'k3_atlas.json')
        except FileNotFoundError as e:
            print(C.fail(str(e)))
            write_progress(STEP_ID, status='error', error_message=str(e))
            return
        k3_data = k3_atlas['data']
        print(f"    Loaded {len(k3_data)} K3 surfaces")
        
        write_progress(STEP_ID, status='running', items_done=0,
                       items_total=len(k3_data), preset=args.preset)
        
        # Compute KS data for each
        step(2, 3, "Computing Kuga-Satake bridge per K3 ...")
        ks_table = []
        for k3 in k3_data:
            pic = k3.get('picard_rank')
            t_rank = k3.get('transcendental_rank')
            ks_dim = ks_dimension(t_rank) if isinstance(t_rank, int) else None
            status, note = ks_status_for_k3(k3['id'], pic, t_rank)
            ks_table.append({
                'k3_id': k3['id'],
                'k3_family': k3.get('family', ''),
                'picard_rank': pic,
                'transcendental_rank': t_rank,
                'ks_av_dim': ks_dim,
                'ks_status': status,
                'note': note,
            })
        
        # Display
        section("KUGA-SATAKE BRIDGE FOR K3 ATLAS")
        rows = []
        for row in ks_table:
            ks_dim_str = str(row['ks_av_dim']) if row['ks_av_dim'] else '—'
            status_color = (C.green if row['ks_status'] == 'explicit' or 'small' in row['ks_status']
                            else C.warn if 'partial' in row['ks_status']
                            else C.muted)
            rows.append((
                row['k3_id'][:30],
                str(row['picard_rank'])[:5],
                str(row['transcendental_rank'])[:5],
                ks_dim_str[:10],
                status_color(row['ks_status'][:14]),
            ))
        summary_table(rows, ['K3 ID', 'ρ', '22-ρ', 'dim A_KS', 'KS status'],
                      fmt=['<30', '<5', '<5', '<12', '<16'])
        
        # Counts
        section("DISTRIBUTION")
        n_explicit = sum(1 for r in ks_table if r['ks_status'].startswith('explicit'))
        n_partial = sum(1 for r in ks_table if 'partial' in r['ks_status'])
        n_formal = sum(1 for r in ks_table if r['ks_status'] == 'formal')
        print(f"  {C.green('Explicit KS (small AV)')}:  {n_explicit}")
        print(f"  {C.warn('Partial / case-by-case')}:  {n_partial}")
        print(f"  {C.muted('Formal (high-dim AV)')}:    {n_formal}")
        
        section("KEY OBSERVATIONS")
        print(f"  • {C.green('Singular K3s (ρ=20)')} → KS = product of CM elliptic curves; "
              f"HC propagates trivially via CM.")
        print(f"  • {C.green('Kummer K3s (ρ=17/18)')} → KS = abelian surface × ... explicit and small.")
        print(f"  • {C.warn('Shioda-Inose K3s (ρ=19)')} → KS related to small AVs; controllable.")
        print(f"  • {C.muted('Generic K3s (ρ ≤ 2)')} → KS AV has dim ≥ 2^{{19}} ≈ 500,000; "
              f"construction is formal, not computable.")
        print(f"  • {C.highlight('KS is the bridge')} used by Deligne (HC for K3) and Voisin "
              f"(K3-fibered varieties).")
        
        # Save
        step(3, 3, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'kuga_satake_bridge.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(ks_table[0].keys()))
            writer.writeheader()
            for row in ks_table:
                writer.writerow(row)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'kuga_satake_bridge.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 12,
                'data': ks_table,
                'summary': {
                    'total': len(ks_table),
                    'explicit_ks': n_explicit,
                    'partial': n_partial,
                    'formal': n_formal,
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(ks_table), items_total=len(ks_table),
                       artifacts=['kuga_satake_bridge.csv', 'kuga_satake_bridge.json'])
        print()
        print(C.green("  ✓ ch_12_kuga_satake_construction finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
