"""ch_12_kuga_satake_construction — Kuga-Satake bridge."""
from .compute import main
if __name__ == '__main__':
    main()
