"""ch_06_lefschetz_action — Hard Lefschetz duality analysis."""
from .compute import main
if __name__ == '__main__':
    main()
