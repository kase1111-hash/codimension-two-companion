#!/usr/bin/env python3
"""
ch_06_lefschetz_action — Hard Lefschetz action by variety class.

For each (variety class, dim n), tabulates:
  - Whether Hard Lefschetz holds (settled for projective smooth)
  - The primitive cohomology rank at each codim
  - The codim-pairing under Hard Lefschetz: k ↔ n-k
  - Whether codim-2 is self-dual (n = 4) or dualized (n ≠ 4)

The structural punchline: in dim 3, codim 2 = codim 1 (dual), settled.
In dim 4, codim 2 is self-dual — no dimensional shortcut. This is the
threshold.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress


STEP_ID = 'ch_06_lefschetz_action'


def codim_2_dual_codim(n: int) -> int:
    """Codim-2 ↔ codim-(n-2) under Hard Lefschetz."""
    return n - 2


def lefschetz_codim_2_status(n: int) -> dict:
    """Status of codim-2 HC under Hard Lefschetz reduction in dim n."""
    if n < 2:
        return {'applicable': False, 'reason': 'codim 2 vacuous for dim < 2',
                'dual_codim': None, 'settles_codim_2': None}
    if n == 2:
        return {'applicable': True, 'reason': 'codim 2 = top class in dim 2; trivially settled',
                'dual_codim': 0, 'settles_codim_2': True}
    if n == 3:
        return {'applicable': True, 'reason': 'codim 2 ↔ codim 1 via HL; reduces to Lefschetz (1,1)',
                'dual_codim': 1, 'settles_codim_2': True}
    if n == 4:
        return {'applicable': True, 'reason': 'codim 2 is self-dual (n-2 = 2); NO REDUCTION POSSIBLE',
                'dual_codim': 2, 'settles_codim_2': False}
    return {'applicable': True,
            'reason': f'codim 2 ↔ codim {n-2}; both open in general',
            'dual_codim': n - 2, 'settles_codim_2': False}


LEFSCHETZ_TABLE = [
    {'variety_class': 'curves', 'dim': 1, 'hard_lefschetz': 'trivial'},
    {'variety_class': 'surfaces', 'dim': 2, 'hard_lefschetz': 'classical (Lefschetz 1924)'},
    {'variety_class': '3-folds', 'dim': 3, 'hard_lefschetz': 'classical via Deligne 1968'},
    {'variety_class': '4-folds (general)', 'dim': 4, 'hard_lefschetz': 'Deligne 1968'},
    {'variety_class': 'cubic 4-fold', 'dim': 4, 'hard_lefschetz': 'Deligne 1968'},
    {'variety_class': 'K3 surface', 'dim': 2, 'hard_lefschetz': 'classical'},
    {'variety_class': 'abelian variety (dim g)', 'dim': 'g', 'hard_lefschetz': 'classical'},
    {'variety_class': 'hyperkähler K3^[n]', 'dim': '2n', 'hard_lefschetz': 'classical (smooth proj)'},
    {'variety_class': 'hyperkähler OG-10', 'dim': 10, 'hard_lefschetz': 'classical'},
    {'variety_class': 'CY 3-fold', 'dim': 3, 'hard_lefschetz': 'classical'},
    {'variety_class': 'CY 4-fold (sextic)', 'dim': 4, 'hard_lefschetz': 'classical'},
    {'variety_class': 'Fano 4-fold', 'dim': 4, 'hard_lefschetz': 'classical'},
    {'variety_class': 'moduli M_g', 'dim': '3g-3', 'hard_lefschetz': 'when smooth proj (DM compactification)'},
]


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_06_lefschetz_action — Hard Lefschetz Duality", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    write_progress(STEP_ID, status='running', items_done=0,
                   items_total=len(LEFSCHETZ_TABLE), preset=args.preset)
    
    try:
        step(1, 2, "Computing Lefschetz reductions ...")
        
        enriched = []
        for entry in LEFSCHETZ_TABLE:
            dim = entry['dim']
            if isinstance(dim, int):
                status = lefschetz_codim_2_status(dim)
                enriched.append({
                    **entry,
                    **status,
                })
            else:
                enriched.append({
                    **entry,
                    'applicable': True,
                    'reason': f'depends on dim (parameter {dim})',
                    'dual_codim': f'{dim} - 2',
                    'settles_codim_2': None,
                })
        
        section("HARD LEFSCHETZ AND CODIM-2 REDUCTION")
        rows = []
        for r in enriched:
            settles = r.get('settles_codim_2')
            settles_str = (C.green('YES') if settles is True
                           else C.cyan('NO') if settles is False
                           else C.muted('depends'))
            rows.append((
                r['variety_class'][:34],
                str(r['dim'])[:6],
                str(r.get('dual_codim'))[:6],
                settles_str,
                r['hard_lefschetz'][:22],
            ))
        summary_table(rows, ['Variety class', 'dim', 'codim-2 dual', 'HL settles HC@2?', 'HL holds via'],
                      fmt=['<34', '<8', '<14', '<20', '<24'])
        
        section("THE THRESHOLD")
        print(f"  In dim 1: codim 2 is vacuous.")
        print(f"  In dim 2: codim 2 = top class = Z. {C.green('Trivially settled.')}")
        print(f"  In dim 3: codim 2 ↔ codim 1 via Hard Lefschetz. {C.green('Reduces to Lefschetz (1,1).')}")
        print(f"  In dim 4: codim 2 is self-dual (n - 2 = 2). {C.warn('NO reduction. This is the threshold.')}")
        print(f"  In dim ≥ 5: codim 2 ↔ codim (n-2) ≥ 3, both open. {C.cyan('Two open codims interconnect.')}")
        print()
        print(f"  Hard Lefschetz {C.highlight('always holds')} for smooth proj X (Deligne 1968).")
        print(f"  What FAILS at dim 4 is the {C.highlight('codim-1 reduction')} — codim 2 cannot be")
        print(f"  pushed back to divisors in dim 4. That's the structural origin of the codim-2 problem.")
        
        # Save
        step(2, 2, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'lefschetz_action_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(enriched[0].keys()), extrasaction='ignore')
            writer.writeheader()
            for r in enriched:
                writer.writerow(r)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'lefschetz_action_table.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 6,
                'data': enriched,
                'summary': {
                    'total': len(enriched),
                    'codim_2_settled_via_HL': sum(1 for r in enriched if r.get('settles_codim_2') is True),
                    'codim_2_NOT_settled_via_HL': sum(1 for r in enriched if r.get('settles_codim_2') is False),
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(enriched), items_total=len(LEFSCHETZ_TABLE),
                       artifacts=['lefschetz_action_table.csv', 'lefschetz_action_table.json'])
        print()
        print(C.green("  ✓ ch_06_lefschetz_action finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
