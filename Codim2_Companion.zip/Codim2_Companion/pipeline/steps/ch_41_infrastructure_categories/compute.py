#!/usr/bin/env python3
"""ch_41_infrastructure_categories — Categories of mathematical infrastructure."""
import argparse, csv, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from kase_utils import add_standard_args, resolve_args, banner, section, step, summary_table, C
from registry import get_artifact_path, write_progress

STEP_ID = 'ch_41_infrastructure_categories'

INFRASTRUCTURE = [
    {'category': 'Lattice theory (Nikulin embedding)',
     'used_for': 'K3, hyperkähler, Hassett discriminants',
     'maturity': 'mature', 'gap': 'computational tooling for large rank lattices'},
    {'category': 'Derived categories of coherent sheaves',
     'used_for': 'K3 category in cubic 4-folds (Kuznetsov)',
     'maturity': 'developing', 'gap': 'algorithmic semiorthogonal decompositions'},
    {'category': 'Motivic cohomology / Voevodsky DM',
     'used_for': 'nilpotence, cycle class maps, B-D-I conjectures',
     'maturity': 'mature theoretically', 'gap': 'computational implementations'},
    {'category': 'Beauville-Bogomolov form',
     'used_for': 'hyperkähler classification + cycle algebra',
     'maturity': 'mature', 'gap': 'OG-6, OG-10 explicit Gram matrices'},
    {'category': 'Kuga-Satake / Mumford-Tate groups',
     'used_for': 'K3 → AV bridge; Hodge group computation',
     'maturity': 'mature', 'gap': 'computable for non-Shimura cases'},
    {'category': 'Periods of cubic 4-folds',
     'used_for': 'Hassett special divisors + Torelli',
     'maturity': 'mature', 'gap': 'extension to higher-discriminant K3 association'},
    {'category': 'Hilbert schemes and Bridgeland stability',
     'used_for': 'hyperkähler construction + cycle production',
     'maturity': 'developing', 'gap': 'explicit cycles on OG-10'},
    {'category': 'Toric / polytope geometry (Kreuzer-Skarke)',
     'used_for': 'CY 4-fold enumeration + Hodge atlas',
     'maturity': 'mature (data); developing (analysis)',
     'gap': 'cycle construction on toric CY 4-folds'},
    {'category': 'Etale cohomology / Galois representations',
     'used_for': 'Tate conjecture, Frobenius eigenvalue analysis',
     'maturity': 'mature', 'gap': 'efficient point counting on surfaces / 4-folds'},
    {'category': 'Hodge structures + variation of Hodge structure',
     'used_for': 'Cattani-Deligne-Kaplan, NL loci',
     'maturity': 'mature', 'gap': 'algorithmic detection of NL components on CY 4-folds'},
    {'category': 'Computer algebra systems (SageMath, Magma)',
     'used_for': 'all atlas computations',
     'maturity': 'mature', 'gap': 'specialized codim-2 packages'},
    {'category': 'Mock modular forms / quantum modular',
     'used_for': 'CY 3-fold regulators, mirror periods',
     'maturity': 'developing', 'gap': 'extension to CY 4-fold regulator periods'},
    {'category': 'Bloch-Srinivas / cycle theory',
     'used_for': 'rationally connected varieties → HC',
     'maturity': 'mature', 'gap': 'extending to non-RC varieties (CY 4-folds)'},
    {'category': 'Persistent homology / data-science methods',
     'used_for': 'pattern detection across atlases',
     'maturity': 'emerging', 'gap': 'not yet applied to HC frontier'},
]

def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = resolve_args(parser.parse_args())
    banner("ch_41_infrastructure_categories", {'preset': args.preset})
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_progress(STEP_ID, status='running', items_total=len(INFRASTRUCTURE), preset=args.preset)
    try:
        step(1, 2, "Compiling infrastructure catalog ...")
        section("INFRASTRUCTURE CATEGORIES FOR CODIM-2 PROGRAM")
        rows = []
        for r in INFRASTRUCTURE:
            mat = r['maturity']
            color = (C.green if 'mature' in mat and 'developing' not in mat
                     else C.warn if 'developing' in mat
                     else C.cyan)
            rows.append((r['category'][:46], color(mat[:22]), r['gap'][:42]))
        summary_table(rows, ['Category', 'Maturity', 'Open gap'],
                      fmt=['<48', '<24', '<44'])
        
        section("MATURITY BREAKDOWN")
        n_mature = sum(1 for r in INFRASTRUCTURE if 'mature' in r['maturity'] and 'developing' not in r['maturity'])
        n_dev = sum(1 for r in INFRASTRUCTURE if 'developing' in r['maturity'])
        n_emerg = sum(1 for r in INFRASTRUCTURE if 'emerging' in r['maturity'])
        print(f"  {C.green('Mature')}:     {n_mature}")
        print(f"  {C.warn('Developing')}: {n_dev}")
        print(f"  {C.cyan('Emerging')}:   {n_emerg}")
        
        step(2, 2, "Writing outputs ...")
        csv_path = output_dir / 'infrastructure_categories.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(INFRASTRUCTURE[0].keys()))
            w.writeheader()
            for r in INFRASTRUCTURE: w.writerow(r)
        json_path = output_dir / 'infrastructure_categories.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({'step': STEP_ID, 'chapter': 41, 'data': INFRASTRUCTURE,
                       'summary': {'total': len(INFRASTRUCTURE), 'mature': n_mature,
                                   'developing': n_dev, 'emerging': n_emerg}},
                      f, indent=2)
        write_progress(STEP_ID, status='complete', items_done=len(INFRASTRUCTURE),
                       items_total=len(INFRASTRUCTURE),
                       artifacts=['infrastructure_categories.csv', 'infrastructure_categories.json'])
        print(C.green("\n  ✓ ch_41_infrastructure_categories finished"))
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        raise

if __name__ == '__main__':
    main()
