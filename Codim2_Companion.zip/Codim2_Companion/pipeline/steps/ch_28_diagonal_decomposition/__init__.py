"""ch_28_diagonal_decomposition — Bloch-Srinivas diagonal decomposition."""
from .compute import main
if __name__ == '__main__':
    main()
