#!/usr/bin/env python3
"""
ch_28_diagonal_decomposition — Bloch-Srinivas diagonal decomposition.

Bloch-Srinivas 1983: if CH_0(X)_Q is finite-dimensional, the diagonal
Δ_X decomposes as

  Δ_X = X × {pt} + Z   in CH^n(X × X)_Q

where Z is supported on D × X for some divisor D ⊂ X. The decomposition
descends to actions on cohomology and proves:

  CH_0(X) trivial → Δ_X decomposes → HC at all codim for X.

Concretely:
  - Fano (and rationally connected) varieties: CH_0(X) = Z → HC at all codim.
  - Surfaces with trivial CH_0: BR-conjecture → HC at codim 2 = top class.
  - CY varieties: CH_0(X)_Q infinite-dim (Mumford 1968 for K3) → no
    Bloch-Srinivas; HC must be proved by other means.

Author: Kase Branham — Independent Researcher
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from kase_utils import (
    add_standard_args, resolve_args, banner, section, step,
    summary_table, C,
)
from registry import get_artifact_path, write_progress, load_upstream


STEP_ID = 'ch_28_diagonal_decomposition'


def classify_diagonal_decomposition(variety: dict) -> dict:
    """Determine if a variety admits a Bloch-Srinivas-style decomposition.
    
    The test: is CH_0(X) finite-dimensional?
      - Yes (trivial / small) → BR-decomp applies → HC at all codim.
      - No (CH_0 large) → no BR-decomp; HC requires other methods.
    
    Examples:
      Fano / rationally connected: CH_0 = Z (smallest possible)
      CY (with non-zero top form): CH_0 is infinite-dim (Mumford)
      Abelian: CH_0 has Albanese rank g
      K3: CH_0 has "Bloch's filtration" with infinite-dim part
    """
    kind = variety.get('family', '').lower()
    name = variety.get('name', '').lower()
    rc = variety.get('rationally_connected', False)
    
    if rc:
        return {
            'br_applies': True,
            'ch_0_dimension': 'trivial (CH_0 = Z)',
            'hc_consequence': 'HC at all codim',
            'mechanism': 'Bloch-Srinivas → diagonal decomposes → HC',
        }
    if 'calabi-yau' in kind or 'fermat' in name or 'borcea' in name or 'cy' in kind.lower():
        return {
            'br_applies': False,
            'ch_0_dimension': 'infinite (Mumford 1968)',
            'hc_consequence': 'BR does not apply; HC must use other methods',
            'mechanism': 'No structural shortcut; case-by-case via Hodge structure',
        }
    if 'abelian' in name or 'av' in name:
        return {
            'br_applies': False,
            'ch_0_dimension': 'g-dim Albanese',
            'hc_consequence': 'Partial: BR for top CH_0 → some classes',
            'mechanism': 'Albanese fiber-by-fiber + Lieberman/Voevodsky',
        }
    return {
        'br_applies': None,
        'ch_0_dimension': 'unknown',
        'hc_consequence': 'requires case analysis',
        'mechanism': 'unknown',
    }


def main():
    parser = argparse.ArgumentParser()
    add_standard_args(parser)
    args = parser.parse_args()
    args = resolve_args(args)
    
    banner("ch_28_diagonal_decomposition — Bloch-Srinivas Decomposition", {
        'preset': args.preset,
        'output': str(get_artifact_path(STEP_ID)),
    })
    
    output_dir = get_artifact_path(STEP_ID)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Load upstream
        step(1, 3, "Loading CY 4-fold (ch_22) and Fano (ch_23) atlases ...")
        cy = load_upstream('ch_22_cy_4fold_hodge_numbers', 'cy_4fold_atlas.json')
        fano = load_upstream('ch_23_fano_atlas', 'fano_atlas.json')
        all_varieties = cy['data'] + fano['data']
        print(f"    CY 4-folds: {len(cy['data'])}, Fano 4-folds: {len(fano['data'])}")
        
        write_progress(STEP_ID, status='running', items_done=0,
                       items_total=len(all_varieties), preset=args.preset)
        
        # Classify
        step(2, 3, "Classifying diagonal decompositions ...")
        results = []
        for v in all_varieties:
            br = classify_diagonal_decomposition(v)
            results.append({
                'variety_id': v.get('id', '?'),
                'variety_name': v.get('name', '?'),
                'family': v.get('family', ''),
                **br,
            })
        
        # Display
        section("DIAGONAL DECOMPOSITION STATUS")
        rows = []
        for r in results:
            applies = r['br_applies']
            color = (C.green('Yes') if applies is True
                     else C.cyan('No') if applies is False
                     else C.muted('?'))
            rows.append((
                r['variety_id'][:24],
                color,
                r['ch_0_dimension'][:24],
                r['hc_consequence'][:34],
            ))
        summary_table(rows, ['Variety', 'BR applies?', 'CH_0', 'HC consequence'],
                      fmt=['<24', '<14', '<24', '<36'])
        
        # Summary
        n_br_yes = sum(1 for r in results if r['br_applies'] is True)
        n_br_no = sum(1 for r in results if r['br_applies'] is False)
        n_br_unk = sum(1 for r in results if r['br_applies'] is None)
        
        section("DISTRIBUTION")
        print(f"  {C.green('BR applies (HC at all codim)')}: {n_br_yes}")
        print(f"  {C.cyan('BR does not apply (case-by-case)')}: {n_br_no}")
        print(f"  {C.muted('Unknown')}: {n_br_unk}")
        
        section("KEY OBSERVATIONS")
        print(f"  • {C.green('All rationally connected Fano 4-folds')} get HC for free via BR.")
        print(f"  • {C.warn('Cubic 4-folds')} are RC, so BR applies! But the cubic 4-fold case "
              f"is treated specially in ch_21 (Hassett-K3 association) because the BR-derived "
              f"cycles don't pin down WHICH explicit cycle realizes a given Hodge class.")
        print(f"  • {C.cyan('CY 4-folds')} have infinite-dim CH_0 (Mumford 1968 extension); "
              f"BR doesn't apply. HC must be proved class-by-class.")
        print(f"  • This dichotomy ({C.green('Fano: free')} vs {C.cyan('CY: hard')}) is the "
              f"main organizing principle of Part V.")
        
        # Save
        step(3, 3, "Writing outputs ...")
        section("OUTPUT FILES")
        
        csv_path = output_dir / 'diagonal_decomposition_table.csv'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
            writer.writeheader()
            for r in results:
                writer.writerow(r)
        print(f"  {csv_path.name}  ({csv_path.stat().st_size/1024:.1f} KB)")
        
        json_path = output_dir / 'diagonal_decomposition_table.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'step': STEP_ID, 'chapter': 28,
                'data': results,
                'summary': {
                    'total': len(results),
                    'br_applies': n_br_yes,
                    'br_does_not_apply': n_br_no,
                    'unknown': n_br_unk,
                },
            }, f, indent=2)
        print(f"  {json_path.name}  ({json_path.stat().st_size/1024:.1f} KB)")
        
        write_progress(STEP_ID, status='complete',
                       items_done=len(results), items_total=len(all_varieties),
                       artifacts=['diagonal_decomposition_table.csv',
                                  'diagonal_decomposition_table.json'])
        print()
        print(C.green("  ✓ ch_28_diagonal_decomposition finished successfully"))
    
    except Exception as e:
        write_progress(STEP_ID, status='error', error_message=str(e))
        print(C.fail(f"  ✗ Failed: {e}"))
        raise


if __name__ == '__main__':
    main()
