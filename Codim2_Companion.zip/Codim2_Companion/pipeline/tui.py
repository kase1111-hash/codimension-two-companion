#!/usr/bin/env python3
"""
pipeline/tui.py — Real live TUI for the Codim-2 Atlas Pipeline.

Replaces the --watch stopgap in pipeline/status.py. Provides a live-
updating, color-coded dashboard with:

  • Header panel: title + timestamp + pipeline rollup
  • Per-Part panels: step status grouped by Part I–VII + Appendix C
  • Running steps: live progress bars (when items_total available)
  • Footer panel: summary stats + keybind hints

Usage:
    python -m pipeline.tui                  # full TUI, 0.5s refresh
    python -m pipeline.tui --refresh 2      # custom refresh rate
    python -m pipeline.tui --compact        # condensed single-column layout
    python -m pipeline.tui --no-progress    # disable progress bars

Press Ctrl-C to exit cleanly.

Cross-platform: works on Windows Terminal, Linux, macOS. Falls back
gracefully when terminal capabilities are limited.

Author: Kase Branham — Independent Researcher
"""

import argparse
import sys
import time
from datetime import datetime
from pathlib import Path

# Add pipeline/ to path
sys.path.insert(0, str(Path(__file__).parent))

# Rich imports — should always succeed since we install with the pipeline
try:
    from rich.align import Align
    from rich.console import Console, Group
    from rich.layout import Layout
    from rich.live import Live
    from rich.panel import Panel
    from rich.progress import (BarColumn, Progress, TextColumn,
                                TimeElapsedColumn, MofNCompleteColumn)
    from rich.table import Table
    from rich.text import Text
    from rich.rule import Rule
except ImportError as e:
    print("ERROR: rich is required for the TUI. Install with:")
    print("    pip install rich --break-system-packages")
    print(f"(import failed: {e})")
    sys.exit(1)

from registry import (
    discover_steps, read_progress, get_step_status_summary,
)
from status import group_steps_by_part, _format_duration as format_duration

# ─────────────────────────────────────────────────────────────────
# COLOR + SYMBOL SCHEME
# ─────────────────────────────────────────────────────────────────

# Status → (symbol, color)
STATUS_STYLE = {
    'complete':    ('✓', 'green'),
    'running':     ('◐', 'yellow'),
    'in_progress': ('◐', 'yellow'),
    'error':       ('✗', 'red'),
    'partial':     ('◑', 'orange3'),
    'pending':     ('○', 'grey50'),
    'blocked':     ('·', 'grey37'),
    'unknown':     ('?', 'grey50'),
}


def status_symbol(status: str) -> Text:
    sym, color = STATUS_STYLE.get(status, STATUS_STYLE['unknown'])
    return Text(sym, style=color)


# ─────────────────────────────────────────────────────────────────
# RENDERING
# ─────────────────────────────────────────────────────────────────

def render_header() -> Panel:
    """Top header with title + timestamp."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    title = Text("CODIM-2 ATLAS PIPELINE — LIVE STATUS", style="bold cyan")
    sub = Text(f"  {now}", style="grey62")
    grp = Group(Align.center(title), Align.center(sub))
    return Panel(grp, border_style="cyan", padding=(0, 1))


def render_part_table(part_name: str, step_list: list, show_progress: bool) -> Table:
    """Render one Part's step list as a Table."""
    # Count statuses for this part for the header
    n_total = len(step_list)
    n_complete = 0
    n_running = 0
    n_error = 0
    for sid, _ in step_list:
        p = read_progress(sid) or {}
        s = p.get('status', 'pending')
        if s == 'complete':
            n_complete += 1
        elif s in ('running', 'in_progress'):
            n_running += 1
        elif s == 'error':
            n_error += 1
    
    # Title with rollup badge
    if n_complete == n_total:
        badge = f"[bold green]{n_complete}/{n_total} ✓[/bold green]"
    elif n_running > 0:
        badge = f"[bold yellow]{n_complete}/{n_total}  ◐ {n_running}[/bold yellow]"
    elif n_error > 0:
        badge = f"[bold red]{n_complete}/{n_total}  ✗ {n_error}[/bold red]"
    else:
        badge = f"[grey62]{n_complete}/{n_total}[/grey62]"
    
    table = Table(
        title=f"[bold]{part_name}[/bold]    {badge}",
        title_justify="left",
        show_header=False,
        show_lines=False,
        box=None,
        padding=(0, 1),
        expand=True,
    )
    table.add_column("sym", width=2, no_wrap=True)
    table.add_column("step", overflow="ellipsis", no_wrap=True, ratio=3)
    table.add_column("status", width=12, overflow="ellipsis", no_wrap=True)
    table.add_column("progress", width=24, no_wrap=True)
    table.add_column("dur", width=8, justify="right", no_wrap=True)
    
    for sid, spec in step_list:
        p = read_progress(sid) or {}
        status = p.get('status', 'pending')
        sym = status_symbol(status)
        
        # Step name
        name_style = ('grey62' if status == 'pending' else
                      'bold green' if status == 'complete' else
                      'bold yellow' if status in ('running', 'in_progress') else
                      'bold red' if status == 'error' else
                      'orange3' if status == 'partial' else
                      'white')
        name = Text(sid, style=name_style)
        
        # Status text
        status_text = Text(status, style=name_style)
        
        # Progress
        items_done = p.get('items_done')
        items_total = p.get('items_total')
        if (show_progress and status in ('running', 'in_progress')
                and items_total and items_total > 0):
            ratio = (items_done or 0) / items_total
            bar_width = 16
            filled = int(bar_width * ratio)
            bar = '━' * filled + '─' * (bar_width - filled)
            progress_text = Text(f"[{bar}] {items_done}/{items_total}", style="yellow")
        elif status == 'complete' and items_total:
            progress_text = Text(f"  {items_done or items_total}/{items_total}",
                                 style="green")
        elif items_total:
            progress_text = Text(f"  {items_done or 0}/{items_total}", style="grey50")
        else:
            progress_text = Text("", style="grey50")
        
        # Duration
        dur = p.get('duration_seconds')
        if dur:
            dur_text = Text(format_duration(dur), style="grey62")
        else:
            dur_text = Text("", style="grey62")
        
        table.add_row(sym, name, status_text, progress_text, dur_text)
    
    return table


def render_body(steps: dict, show_progress: bool) -> Group:
    """Render the body containing all Part panels."""
    if not steps:
        return Group(Text("No steps registered.", style="grey62"))
    
    groups = group_steps_by_part(steps)
    # Order parts canonically
    part_order = [
        'Part I — The Conjecture and Its Setting',
        'Part II — Why Dimension 4 Is the Threshold',
        'Part III — The Arsenal',
        'Part IV — The Map of Known and Open',
        'Part V — The Computational Atlas',
        'Part VI — Sister Conjectures and Implications',
        'Part VII — Closing Arguments',
        'Appendix C — Open Problems',
        'Other',
    ]
    ordered = [(p, groups[p]) for p in part_order if p in groups]
    # Also include any unrecognized
    for p, lst in groups.items():
        if p not in [x[0] for x in ordered]:
            ordered.append((p, lst))
    
    tables = [render_part_table(p, sl, show_progress) for p, sl in ordered]
    # Interleave with thin rules for visual separation
    items = []
    for i, t in enumerate(tables):
        items.append(t)
        if i < len(tables) - 1:
            items.append(Text(""))  # spacer
    return Group(*items)


def render_footer() -> Panel:
    """Footer with summary stats."""
    summary = get_step_status_summary()
    total = sum(summary.values())
    if total == 0:
        text = Text("No steps registered yet.", style="grey62")
    else:
        n_complete = summary.get('complete', 0)
        n_running = summary.get('running', 0) + summary.get('in_progress', 0)
        n_error = summary.get('error', 0)
        n_pending = summary.get('pending', 0) + summary.get('blocked', 0)
        
        pct = 100 * n_complete / total
        
        parts = []
        parts.append(Text(f"  {n_complete}/{total} ", style="bold"))
        parts.append(Text(f"({pct:.0f}%) ", style="bold cyan"))
        parts.append(Text("complete", style="green"))
        
        if n_running > 0:
            parts.append(Text(f"  •  {n_running} ", style="bold"))
            parts.append(Text("running", style="yellow"))
        if n_error > 0:
            parts.append(Text(f"  •  {n_error} ", style="bold"))
            parts.append(Text("errored", style="red"))
        if n_pending > 0:
            parts.append(Text(f"  •  {n_pending} ", style="bold"))
            parts.append(Text("pending", style="grey50"))
        
        text = Text("").join(parts)
    
    hint = Text("\n  Press Ctrl-C to exit", style="grey50 italic")
    grp = Group(text, hint)
    return Panel(grp, border_style="cyan", padding=(0, 0))


def render_dashboard(steps: dict, show_progress: bool, compact: bool = False) -> Layout:
    """Top-level renderable that combines header + body + footer."""
    layout = Layout()
    # Header and footer have fixed sizes; body fills the rest.
    # In screen=True mode, body gets full available terminal height,
    # which is enough for 39 steps + 8 part headers + spacers (~70 lines).
    # In smaller terminals the body content scrolls within its panel.
    layout.split_column(
        Layout(render_header(), size=4, name="header"),
        Layout(render_body(steps, show_progress), name="body", ratio=1),
        Layout(render_footer(), size=4, name="footer"),
    )
    
    return layout


# ─────────────────────────────────────────────────────────────────
# MAIN LOOP
# ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Live TUI dashboard for the Codim-2 Atlas Pipeline."
    )
    parser.add_argument('--refresh', type=float, default=0.5,
                        help="Refresh interval in seconds (default: 0.5)")
    parser.add_argument('--compact', action='store_true',
                        help="Condensed layout")
    parser.add_argument('--no-progress', action='store_true',
                        help="Disable per-step progress bars")
    parser.add_argument('--once', action='store_true',
                        help="Render once and exit (for testing / non-TTY)")
    args = parser.parse_args()
    
    console = Console()
    show_progress = not args.no_progress
    
    # If output is not a TTY, fall back to a single render
    if args.once or not console.is_terminal:
        steps = discover_steps()
        # In --once mode, don't use Layout (it size-constrains the body).
        # Print header + body + footer separately so everything is visible.
        console.print(render_header())
        console.print(render_body(steps, show_progress))
        console.print(render_footer())
        return
    
    # Live loop
    try:
        with Live(
            render_dashboard(discover_steps(), show_progress, args.compact),
            console=console,
            refresh_per_second=1.0 / max(args.refresh, 0.1),
            # screen=True: take over the terminal (like htop/top). Body gets
            # full available height; scrollback is preserved on exit. Required
            # for the pipeline's 39 steps in 8 part-groups to fit a typical
            # 30-line terminal without truncating.
            screen=True,
        ) as live:
            while True:
                time.sleep(args.refresh)
                steps = discover_steps()
                live.update(render_dashboard(steps, show_progress, args.compact))
    except KeyboardInterrupt:
        console.print()
        console.print("[grey62]TUI exited.[/grey62]")


if __name__ == '__main__':
    main()
