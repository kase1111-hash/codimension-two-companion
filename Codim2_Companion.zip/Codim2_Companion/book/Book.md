# Codimension Two: A Computational Companion

## 39 Pipeline Steps Atlas-ing the Hodge Conjecture at Codimension 2

*Kase Branham*  
*Independent Researcher*

---

# Copyright

Copyright © 2026 Kase Branham.

Dedicated to the public domain under **Creative Commons Zero (CC0 1.0 Universal)**.
To the extent possible under law, the author has waived all copyright and
related rights to this work.

ISBN: *TBA*

*This is the computational companion to* Codimension Two: The Hodge Conjecture
and What We Can Build Around It *(45 chapters, 6×9 paperback). Where the parent
volume surveys the codimension-two Hodge conjecture in prose, this companion
makes every claim computationally reproducible. The pipeline source is
available at the author's repository as CC0.*

---



# Introduction

*This is the companion volume to* Codimension Two *(45 chapters, 6×9 paperback).
Where the parent volume surveys the landscape of the codimension-two Hodge conjecture
in prose, this book makes every claim computationally executable.*

## How to read this book

Each chapter corresponds to a single pipeline step in the `Codim2_Companion`
project. Every chapter has the same skeleton:

1. **Overview** — what the step is about, in plain prose
2. **At a glance** — step ID, category, runtime targets, last-run status
3. **Dependencies** — what the step reads from and feeds into
4. **Computed outputs** — every artifact file the step produces, with size
5. **Summary statistics** — aggregate numbers extracted from the artifact JSON
6. **Reproduce** — exact commands to re-run the computation
7. **See also** — cross-references to upstream and downstream chapters

The book is therefore not just text: it is a working machine. Run the pipeline,
and every number reported below is regenerated from first principles.

## What the companion adds to the parent volume

- **Independent verification**: where the parent book cites a Hodge number,
  Picard rank, or discriminant, the companion recomputes it from Chern classes,
  lattice formulas, or point counts. When literature and computation disagree,
  the disagreement is logged in `docs/VERIFICATION_LOG.md` rather than papered
  over.
- **Computational atlas**: the K3 atlas, Hassett discriminants, CY 4-fold Hodge
  numbers, cubic 4-fold periods, abelian Mumford-Tate types — all are
  reproducible tables, not static lists.
- **Cross-cut aggregators**: ch_34 (pattern analysis), ch_36 (standard
  conjectures master atlas), ch_39 (implications graph), ch_40 (web
  visualization), and the Appendix C capstone connect everything into a single
  map.

## On the verification practice

The companion treats literature as input, not ground truth. Each step that
quotes a literature value also computes the same value via an independent path
(Chern class, lattice computation, brute-force enumeration). When they agree:
fine. When they disagree: the disagreement is logged with date, step, source
claim, pipeline finding, verification path, and resolution status.

During the build, several external checks have been logged:

1. **Ch 22 h<sup>2,2</sup> mismatch**: six of seven CY 4-fold
   complete-intersection Hodge values from the literature disagree with the
   Chern-class ground truth. **Status**: sextic case resolved (Jacobian-ring
   triple-verification matches literature). Six c.i. cases still open pending
   relative-Jacobian implementation.
2. **Ch 26 K3 Frobenius trace formula**: an own-code bug — a missing zero
   contribution from H<sup>1</sup>(K3) — caught at write-time and corrected
   before any artifact was saved as authoritative.
3. **External structural review** (2026-05-11): no critical computational
   errors or major inconsistencies detected. Pipeline cross-references coherent;
   data consistency holds across aggregators. Three follow-up priorities
   recommended; see Conclusion's "What comes next" section.
4. **Pipeline extensions** (2026-05-11): four new calculations added in
   response to the review:
   - **Jacobian ring** for hypersurface CY 4-folds (resolves sextic case)
   - **Nikulin / Loeschian K3-association** extending the Hassett classification
     beyond d = 70 (22 new K3-associated cubic 4-fold families up to d = 200)
   - **OG-6 inheritance from abelian surfaces** added to the cycle-construction
     atlas
   - **Sato-Tate sanity check** on Frobenius traces in the point-counting step

All are documented in `docs/VERIFICATION_LOG.md`. The first item should drive
a revision to the parent volume's Ch 22; the second is internal hygiene; the
third validates the practice itself; the fourth is the queue of follow-up
work from the review actually shipped.

## Convention and license

All code and data in the companion are released under **CC0** (public domain).
The author affiliation is **Independent Researcher**. The pipeline is designed
to run with no proprietary dependencies (Python 3 + pyyaml + tqdm + numpy +
cairosvg + rich); a complete sweep takes a few minutes on a laptop.

---

*Continue to the [Table of Contents](./_TOC.md).*

# CHAPTER 4 — The Codimension Grid
*Companion volume to* Codimension Two *— pipeline step `ch_04_codim_grid`.*

## Overview

Renders the codimension grid visualization showing settled (teal),
open (amber hatched), and trivial cells across (n, k) for the
codim-2 Hodge conjecture's landscape.

## At a glance

- **Step ID**: `ch_04_codim_grid`
- **Chapter**: Chapter 4
- **Category**: V
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 3/3 · duration —

## Computed outputs

| File | Type | Size |
|---|---|---|
| `figure_4_1_codim_grid.png` | png | 25.4 KB |
| `figure_4_1_codim_grid.svg` | svg | 9.5 KB |
| `grid_data.json` | json | 2.9 KB |

All artifacts are under `pipeline/artifacts/ch_04_codim_grid/`.

## Reproduce

```bash
python -m pipeline.runner --only ch_04_codim_grid
python -m pipeline.runner --only ch_04_codim_grid -- --quick
python -m pipeline.runner --only ch_04_codim_grid --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_04_codim_grid/spec.yaml` and `pipeline/artifacts/ch_04_codim_grid/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 6 — Hard Lefschetz Duality and the Lefschetz Action
*Companion volume to* Codimension Two *— pipeline step `ch_06_lefschetz_action`.*

## Overview

Tabulates the Lefschetz operator L: H^k → H^{k+2} (cup with polarization
class h) and the resulting sl_2 representation on H^*(X, Q) per variety
class. Hard Lefschetz: L^{n-k}: H^k → H^{2n-k} is an isomorphism for
k ≤ n. The primitive cohomology P^k = ker(L^{n-k+1}: H^k → H^{2n-k+2})
carries the irreducible content.

For codim-2 HC: the Lefschetz action gives codim-2 ↔ codim-(n-2) duality.
This pairing settles codim-2 trivially in dim 3 (codim 2 = codim 1 dual)
but does not extend to dim 4 (codim 2 is self-dual), which is exactly
the structural reason dim 4 is the threshold.

## At a glance

- **Step ID**: `ch_06_lefschetz_action`
- **Chapter**: Chapter 6
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 13/13 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_40_web_graph`](./40_ch_40_web_graph.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `lefschetz_action_table.csv` | csv | 1.2 KB |
| `lefschetz_action_table.json` | json | 3.5 KB |

All artifacts are under `pipeline/artifacts/ch_06_lefschetz_action/`.

## Summary statistics

From `lefschetz_action_table.json`:

- **total**: 13
- **codim_2_settled_via_HL**: 4
- **codim_2_NOT_settled_via_HL**: 5

## Reproduce

```bash
python -m pipeline.runner --only ch_06_lefschetz_action
python -m pipeline.runner --only ch_06_lefschetz_action -- --quick
python -m pipeline.runner --only ch_06_lefschetz_action --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_40_web_graph`](./40_ch_40_web_graph.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_06_lefschetz_action/spec.yaml` and `pipeline/artifacts/ch_06_lefschetz_action/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 7 — The Three Gifts of Codimension 1
*Companion volume to* Codimension Two *— pipeline step `ch_07_three_gifts_table`.*

## Overview

Renders the comparison table showing what codim 1 has that codim 2 lacks:
(1) the classifying sheaf (exponential sequence),
(2) the Lefschetz (1,1) theorem,
(3) the Picard variety as moduli.

Each gift is presented with: what codim-1 has, what codim-2 lacks,
and what the consequence is for the Hodge conjecture.

## At a glance

- **Step ID**: `ch_07_three_gifts_table`
- **Chapter**: Chapter 7
- **Category**: V
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 3/3 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_40_web_graph`](./40_ch_40_web_graph.md)
- [`ch_41_infrastructure_categories`](./41_ch_41_infrastructure_categories.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `three_gifts_figure.png` | png | 91.6 KB |
| `three_gifts_figure.svg` | svg | 7.0 KB |
| `three_gifts_table.csv` | csv | 1.6 KB |
| `three_gifts_table.json` | json | 2.0 KB |

All artifacts are under `pipeline/artifacts/ch_07_three_gifts_table/`.

## Reproduce

```bash
python -m pipeline.runner --only ch_07_three_gifts_table
python -m pipeline.runner --only ch_07_three_gifts_table -- --quick
python -m pipeline.runner --only ch_07_three_gifts_table --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_40_web_graph`](./40_ch_40_web_graph.md), [`ch_41_infrastructure_categories`](./41_ch_41_infrastructure_categories.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_07_three_gifts_table/spec.yaml` and `pipeline/artifacts/ch_07_three_gifts_table/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 9 — Intermediate Jacobian at Codimension 2
*Companion volume to* Codimension Two *— pipeline step `ch_09_intermediate_jacobian_check`.*

## Overview

Tabulates intermediate Jacobian J^k(X) data per variety class. For
codim k = 1, J^1(X) = Pic^0(X) is always an abelian variety. For
codim k ≥ 2, J^k(X) is a complex torus that may fail to be algebraic
— exactly when the Abel-Jacobi map has nontrivial transcendental
image.

## At a glance

- **Step ID**: `ch_09_intermediate_jacobian_check`
- **Chapter**: Chapter 9
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 11/11 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_10_griffiths_evidence`](./10_ch_10_griffiths_evidence.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `intermediate_jacobian_table.csv` | csv | 2.7 KB |
| `intermediate_jacobian_table.json` | json | 4.5 KB |

All artifacts are under `pipeline/artifacts/ch_09_intermediate_jacobian_check/`.

## Summary statistics

From `intermediate_jacobian_table.json`:

- **total**: 11

## Reproduce

```bash
python -m pipeline.runner --only ch_09_intermediate_jacobian_check
python -m pipeline.runner --only ch_09_intermediate_jacobian_check -- --quick
python -m pipeline.runner --only ch_09_intermediate_jacobian_check --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_10_griffiths_evidence`](./10_ch_10_griffiths_evidence.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_09_intermediate_jacobian_check/spec.yaml` and `pipeline/artifacts/ch_09_intermediate_jacobian_check/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 10 — Griffiths Group: Transcendence Evidence at Codim 2
*Companion volume to* Codimension Two *— pipeline step `ch_10_griffiths_evidence`.*

## Overview

Tabulates known nontriviality results for the Griffiths group Griff^k(X)
= {cycles homol. equiv. to 0} / {cycles algebraically equiv. to 0}.
Griffiths 1969 first showed Griff^2 is nontrivial for the generic
quintic 3-fold; Clemens 1983 strengthened to uncountable; subsequent
work extended to many CY 3-folds and special 4-folds.

Griffiths' result is the first genuine transcendental obstruction
detected in the codim-2 cycle theory: it shows that homological
equivalence is strictly finer than algebraic equivalence past codim 1.

## At a glance

- **Step ID**: `ch_10_griffiths_evidence`
- **Chapter**: Chapter 10
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 9/9 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_09_intermediate_jacobian_check`](./09_ch_09_intermediate_jacobian_check.md)

**Downstream** (these steps read from this one):

- [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `griffiths_evidence_table.csv` | csv | 2.5 KB |
| `griffiths_evidence_table.json` | json | 4.3 KB |

All artifacts are under `pipeline/artifacts/ch_10_griffiths_evidence/`.

## Summary statistics

From `griffiths_evidence_table.json`:

- **total**: 9
- **nontrivial_griff**: 3
- **trivial_griff**: 4

## Reproduce

```bash
python -m pipeline.runner --only ch_10_griffiths_evidence
python -m pipeline.runner --only ch_10_griffiths_evidence -- --quick
python -m pipeline.runner --only ch_10_griffiths_evidence --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_09_intermediate_jacobian_check`](./09_ch_09_intermediate_jacobian_check.md)
- Results feed forward into: [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_10_griffiths_evidence/spec.yaml` and `pipeline/artifacts/ch_10_griffiths_evidence/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 12 — Kuga-Satake Construction: K3 → Abelian Variety Bridge
*Companion volume to* Codimension Two *— pipeline step `ch_12_kuga_satake_construction`.*

## Overview

Tabulates the Kuga-Satake construction across the K3 atlas. For each
K3 in ch_19's atlas, identifies the dimension of the associated
Kuga-Satake abelian variety, the embedding of K3 Hodge structure into
that of KS(X), and whether the bridge has been used to propagate HC
in the literature.

The Kuga-Satake bridge takes a K3 surface S (or any K3-type Hodge
structure of weight 2, signature (2, b_2 - 2)) and produces an abelian
variety A_KS(S) of dimension 2^(b_2(S) - 2) / 2 such that
H^2(S, Q) embeds into End(H^1(A_KS)).

## At a glance

- **Step ID**: `ch_12_kuga_satake_construction`
- **Chapter**: Chapter 12
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 2s · long: 2s
- **Last run**: complete · items 17/17 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)

**Downstream** (these steps read from this one):

- [`ch_25_hyperkahler_lattices`](./25_ch_25_hyperkahler_lattices.md)
- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `kuga_satake_bridge.csv` | csv | 2.5 KB |
| `kuga_satake_bridge.json` | json | 5.3 KB |

All artifacts are under `pipeline/artifacts/ch_12_kuga_satake_construction/`.

## Summary statistics

From `kuga_satake_bridge.json`:

- **total**: 17
- **explicit_ks**: 6
- **partial**: 2
- **formal**: 9

## Reproduce

```bash
python -m pipeline.runner --only ch_12_kuga_satake_construction
python -m pipeline.runner --only ch_12_kuga_satake_construction -- --quick
python -m pipeline.runner --only ch_12_kuga_satake_construction --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)
- Results feed forward into: [`ch_25_hyperkahler_lattices`](./25_ch_25_hyperkahler_lattices.md), [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_12_kuga_satake_construction/spec.yaml` and `pipeline/artifacts/ch_12_kuga_satake_construction/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 13 — Standard Conjectures Status
*Companion volume to* Codimension Two *— pipeline step `ch_13_standard_conjectures_status`.*

## Overview

Compiles the verification status of Grothendieck's standard conjectures
B(X), C(X), D(X), I(X) across variety classes from Chapter 13. Each
conjecture is tracked separately, with literature references.

## At a glance

- **Step ID**: `ch_13_standard_conjectures_status`
- **Chapter**: Chapter 13
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 14/14 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_39_implications_table`](./39_ch_39_implications_table.md)
- [`ch_40_web_graph`](./40_ch_40_web_graph.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `standard_conjectures_status.csv` | csv | 5.7 KB |
| `standard_conjectures_status.json` | json | 6.3 KB |

All artifacts are under `pipeline/artifacts/ch_13_standard_conjectures_status/`.

## Summary statistics

From `standard_conjectures_status.json`:

- **B**:
  - settled: 7
  - partial: 5
  - open: 2
- **C**:
  - settled: 8
  - partial: 4
  - open: 2
- **D**:
  - settled: 6
  - partial: 2
  - open: 6
- **I**:
  - settled: 6
  - partial: 2
  - open: 6

## Reproduce

```bash
python -m pipeline.runner --only ch_13_standard_conjectures_status
python -m pipeline.runner --only ch_13_standard_conjectures_status -- --quick
python -m pipeline.runner --only ch_13_standard_conjectures_status --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_39_implications_table`](./39_ch_39_implications_table.md), [`ch_40_web_graph`](./40_ch_40_web_graph.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_13_standard_conjectures_status/spec.yaml` and `pipeline/artifacts/ch_13_standard_conjectures_status/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 14 — Tate-Mirror Framework: Point Counting → Frobenius → Tate Classes
*Companion volume to* Codimension Two *— pipeline step `ch_14_tate_mirror_framework`.*

## Overview

Defines the foundational arithmetic framework used by the Tate-side
computational chapters (Ch 26 point counting, Ch 27 cubic 4-fold
periods, Ch 37 Tate conjecture atlas, Ch 43 arithmetic frontier).

Pipeline: variety X / F_p → #X(F_{p^k}) for k = 1, 2, ... → zeta
function Z(X, t) → Frobenius polynomial P_i(t) on H^i → eigenvalues α
→ Tate-class detection (eigenvalue α = p^{i/2} ↔ algebraic cycle by
the Tate conjecture).

Provides both: (1) a runnable demonstration on elliptic curves over
small F_p (CM detection, Hasse bound verification), and (2) a
reusable library `framework.py` that downstream steps import.

## At a glance

- **Step ID**: `ch_14_tate_mirror_framework`
- **Chapter**: Chapter 14
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 5s · standard: 30s · long: 2-5min
- **Last run**: complete · items 10/10 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_26_tate_point_counting`](./26_ch_26_tate_point_counting.md)
- [`ch_27_cubic_4fold_periods`](./27_ch_27_cubic_4fold_periods.md)
- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)
- [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `framework.py` | py | 8.6 KB |
| `tate_framework_doc.md` | md | 2.6 KB |
| `tate_framework_examples.csv` | csv | 2.3 KB |
| `tate_framework_summary.json` | json | 19.0 KB |

All artifacts are under `pipeline/artifacts/ch_14_tate_mirror_framework/`.

## Reproduce

```bash
python -m pipeline.runner --only ch_14_tate_mirror_framework
python -m pipeline.runner --only ch_14_tate_mirror_framework -- --quick
python -m pipeline.runner --only ch_14_tate_mirror_framework --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_26_tate_point_counting`](./26_ch_26_tate_point_counting.md), [`ch_27_cubic_4fold_periods`](./27_ch_27_cubic_4fold_periods.md), [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md), [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_14_tate_mirror_framework/spec.yaml` and `pipeline/artifacts/ch_14_tate_mirror_framework/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 15 — Noether-Lefschetz Divisors
*Companion volume to* Codimension Two *— pipeline step `ch_15_noether_lefschetz_divisors`.*

## Overview

Tabulates Noether-Lefschetz loci in moduli of surfaces / 4-folds.
An NL locus is a (typically codim-1 or higher) subvariety of a
moduli space M parameterizing varieties X with Picard rank ρ(X)
strictly greater than the generic value on M.

The classical NL theorem (Noether 1882; Lefschetz 1924): a generic
surface of degree d ≥ 4 in P^3 has Picard rank 1. The NL locus
parameterizes the special d-fold surfaces where extra divisor
classes appear.

For codim-2 HC, NL divisors are the analog: loci in moduli of
4-folds where the Hodge-(2,2) lattice rank jumps. These are the
geometric backbone of "where the cycles come from."

## At a glance

- **Step ID**: `ch_15_noether_lefschetz_divisors`
- **Chapter**: Chapter 15
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 10/10 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `nl_divisors_table.csv` | csv | 2.2 KB |
| `nl_divisors_table.json` | json | 3.8 KB |

All artifacts are under `pipeline/artifacts/ch_15_noether_lefschetz_divisors/`.

## Summary statistics

From `nl_divisors_table.json`:

- **total**: 10

## Reproduce

```bash
python -m pipeline.runner --only ch_15_noether_lefschetz_divisors
python -m pipeline.runner --only ch_15_noether_lefschetz_divisors -- --quick
python -m pipeline.runner --only ch_15_noether_lefschetz_divisors --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_15_noether_lefschetz_divisors/spec.yaml` and `pipeline/artifacts/ch_15_noether_lefschetz_divisors/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 16 — Motivic Cohomology Status
*Companion volume to* Codimension Two *— pipeline step `ch_16_motivic_cohomology_table`.*

## Overview

Tabulates motivic cohomology H^{p,q}_M(X, Z) and its image in
ordinary cohomology, by variety class. Beilinson's conjectures
predict that the rank of the image (= "motivic divisor classes",
"motivic codim-2 classes", etc.) equals the rank of the Hodge
classes — i.e., HC is part of the motivic picture.

## At a glance

- **Step ID**: `ch_16_motivic_cohomology_table`
- **Chapter**: Chapter 16
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 16/16 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)
- [`ch_44_motivic_frontier`](./44_ch_44_motivic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `motivic_cohomology_table.csv` | csv | 1.8 KB |
| `motivic_cohomology_table.json` | json | 4.6 KB |

All artifacts are under `pipeline/artifacts/ch_16_motivic_cohomology_table/`.

## Summary statistics

From `motivic_cohomology_table.json`:

- **total**: 16
- **settled**: 10
- **partial**: 1
- **open**: 4

## Reproduce

```bash
python -m pipeline.runner --only ch_16_motivic_cohomology_table
python -m pipeline.runner --only ch_16_motivic_cohomology_table -- --quick
python -m pipeline.runner --only ch_16_motivic_cohomology_table --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md), [`ch_44_motivic_frontier`](./44_ch_44_motivic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_16_motivic_cohomology_table/spec.yaml` and `pipeline/artifacts/ch_16_motivic_cohomology_table/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 17 — Voevodsky Nilpotence Status
*Companion volume to* Codimension Two *— pipeline step `ch_17_voevodsky_status`.*

## Overview

Compiles the verification status of Voevodsky's nilpotence conjecture
across variety classes. Outputs a structured status table for use
by downstream aggregator steps.

## At a glance

- **Step ID**: `ch_17_voevodsky_status`
- **Chapter**: Chapter 17
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 16/16 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_34_pattern_analysis`](./34_ch_34_pattern_analysis.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_40_web_graph`](./40_ch_40_web_graph.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `voevodsky_status.csv` | csv | 2.2 KB |
| `voevodsky_status.json` | json | 3.8 KB |

All artifacts are under `pipeline/artifacts/ch_17_voevodsky_status/`.

## Summary statistics

From `voevodsky_status.json`:

- **total**: 16
- **settled**: 7
- **partial**: 4
- **open**: 5

## Reproduce

```bash
python -m pipeline.runner --only ch_17_voevodsky_status
python -m pipeline.runner --only ch_17_voevodsky_status -- --quick
python -m pipeline.runner --only ch_17_voevodsky_status --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_34_pattern_analysis`](./34_ch_34_pattern_analysis.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_40_web_graph`](./40_ch_40_web_graph.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_17_voevodsky_status/spec.yaml` and `pipeline/artifacts/ch_17_voevodsky_status/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 18 — Hodge Conjecture Status on Abelian Varieties
*Companion volume to* Codimension Two *— pipeline step `ch_18_abelian_status`.*

## Overview

Tabulates Hodge conjecture verification status across abelian variety
subclasses, organized by Albert classification (Type I-IV), dimension,
endomorphism structure, and Mumford-Tate group. Output feeds the
Mumford-Weil catalog (Ch 31) and the standard-conjectures atlas (Ch 36).

## At a glance

- **Step ID**: `ch_18_abelian_status`
- **Chapter**: Chapter 18
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 1s · standard: 5s · long: 5s
- **Last run**: complete · items 19/19 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_31_mumford_weil`](./31_ch_31_mumford_weil.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `abelian_hc_status.csv` | csv | 2.6 KB |
| `abelian_hc_status.json` | json | 5.9 KB |

All artifacts are under `pipeline/artifacts/ch_18_abelian_status/`.

## Summary statistics

From `abelian_hc_status.json`:

- **trivial**: 2
- **settled**: 12
- **partial**: 3
- **open**: 2

## Reproduce

```bash
python -m pipeline.runner --only ch_18_abelian_status
python -m pipeline.runner --only ch_18_abelian_status -- --quick
python -m pipeline.runner --only ch_18_abelian_status --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_31_mumford_weil`](./31_ch_31_mumford_weil.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_18_abelian_status/spec.yaml` and `pipeline/artifacts/ch_18_abelian_status/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 19 — K3 Surface Atlas
*Companion volume to* Codimension Two *— pipeline step `ch_19_k3_atlas`.*

## Overview

Constructs an atlas of K3 surfaces with Picard rank, Néron-Severi
lattice, transcendental lattice, and polarization data. Foundational
for downstream steps Ch 12 (Kuga-Satake), Ch 25 (hyperkähler lattices),
Ch 30 (Chow regulators).

Includes canonical families: degree-2g K3s (generic), Kummer K3s,
Shioda-Inose K3s, singular K3s (Picard 20), specific named examples
(Fermat quartic, Schoen X_8, double covers).

## At a glance

- **Step ID**: `ch_19_k3_atlas`
- **Chapter**: Chapter 19
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 2s · standard: 5s · long: 10s
- **Last run**: complete · items 17/17 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_12_kuga_satake_construction`](./12_ch_12_kuga_satake_construction.md)
- [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)
- [`ch_25_hyperkahler_lattices`](./25_ch_25_hyperkahler_lattices.md)
- [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `k3_atlas.csv` | csv | 2.7 KB |
| `k3_atlas.json` | json | 11.3 KB |
| `k3_lattices.json` | json | 2.9 KB |

All artifacts are under `pipeline/artifacts/ch_19_k3_atlas/`.

## Summary statistics

From `k3_atlas.json`:

- **total_k3s**: 17
- **errors**: 0
- **picard_rank_distribution**:
  - 1: 7
  - 17: 1
  - 18: 2
  - 20: 3
  - 19: 2
  - 2: 1
  - varies: 1

## Reproduce

```bash
python -m pipeline.runner --only ch_19_k3_atlas
python -m pipeline.runner --only ch_19_k3_atlas -- --quick
python -m pipeline.runner --only ch_19_k3_atlas --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_12_kuga_satake_construction`](./12_ch_12_kuga_satake_construction.md), [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md), [`ch_25_hyperkahler_lattices`](./25_ch_25_hyperkahler_lattices.md), [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_19_k3_atlas/spec.yaml` and `pipeline/artifacts/ch_19_k3_atlas/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 20 — Hyperkähler Manifolds: Classification by Deformation Type
*Companion volume to* Codimension Two *— pipeline step `ch_20_hyperkahler_classification`.*

## Overview

Tabulates the four known deformation types of compact hyperkähler
manifolds (K3^[n], Kum^n, OG-6, OG-10), with dimension, Beauville-
Bogomolov form data, second Betti number, Hodge numbers in low
weights, and HC status at each codimension where known.

Output is foundational for downstream lattice and cycle steps
(Ch 25, 29, 33).

## At a glance

- **Step ID**: `ch_20_hyperkahler_classification`
- **Chapter**: Chapter 20
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 1s · standard: 2s · long: 2s
- **Last run**: complete · items 10/10 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)

**Downstream** (these steps read from this one):

- [`ch_25_hyperkahler_lattices`](./25_ch_25_hyperkahler_lattices.md)
- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md)
- [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `hyperkahler_classification.csv` | csv | 1.2 KB |
| `hyperkahler_classification.json` | json | 4.2 KB |

All artifacts are under `pipeline/artifacts/ch_20_hyperkahler_classification/`.

## Summary statistics

From `hyperkahler_classification.json`:

- **n_deformation_types**: 4
- **hc_codim_2_settled**: 1
- **hc_codim_2_partial**: 2
- **hc_codim_2_open**: 1

## Reproduce

```bash
python -m pipeline.runner --only ch_20_hyperkahler_classification
python -m pipeline.runner --only ch_20_hyperkahler_classification -- --quick
python -m pipeline.runner --only ch_20_hyperkahler_classification --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)
- Results feed forward into: [`ch_25_hyperkahler_lattices`](./25_ch_25_hyperkahler_lattices.md), [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md), [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_20_hyperkahler_classification/spec.yaml` and `pipeline/artifacts/ch_20_hyperkahler_classification/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 21 — Hassett Discriminants for Cubic 4-folds
*Companion volume to* Codimension Two *— pipeline step `ch_21_hassett_discriminants`.*

## Overview

Enumerates admissible discriminants d for special cubic 4-folds,
classifies K3-association status, identifies embedded surface types,
produces the master Hassett table. This is one of the book's signature
atlases — Hassett 2000 introduced the discriminant classification of
the codimension-1 subvariety of cubic 4-folds with extra Hodge classes.

Admissibility (Hassett 2000): d > 6, d ≡ 0 or 2 (mod 6).
K3-association: refined arithmetic condition on prime factorization
and residues modulo small primes.

## At a glance

- **Step ID**: `ch_21_hassett_discriminants`
- **Chapter**: Chapter 21
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 5s · standard: 30s · long: 5-10min
- **Last run**: complete · items 70/70 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_27_cubic_4fold_periods`](./27_ch_27_cubic_4fold_periods.md)
- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `hassett_lattices.json` | json | 2.0 KB |
| `hassett_table.csv` | csv | 4.5 KB |
| `hassett_table.json` | json | 20.6 KB |

All artifacts are under `pipeline/artifacts/ch_21_hassett_discriminants/`.

## Summary statistics

From `hassett_table.json`:

- **candidates**: 70
- **admissible**: 21
- **k3_associated**: 7
- **no_k3_association**: 14
- **lattice_check_pending**: 0

## Reproduce

```bash
python -m pipeline.runner --only ch_21_hassett_discriminants
python -m pipeline.runner --only ch_21_hassett_discriminants -- --quick
python -m pipeline.runner --only ch_21_hassett_discriminants --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_27_cubic_4fold_periods`](./27_ch_27_cubic_4fold_periods.md), [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_21_hassett_discriminants/spec.yaml` and `pipeline/artifacts/ch_21_hassett_discriminants/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 22 — Calabi-Yau 4-fold Hodge Numbers
*Companion volume to* Codimension Two *— pipeline step `ch_22_cy_4fold_hodge_numbers`.*

## Overview

Computes Hodge numbers (h^{1,1}, h^{2,1}, h^{3,1}, h^{2,2}) for canonical
Calabi-Yau 4-fold families. Output feeds Ch 28 (diagonal decomposition),
Ch 32 (toric CY sweep), Ch 33 (counterexample hunt).

Standard families covered:
  • Smooth sextic 4-fold in P^5
  • Complete intersections (2,5), (3,4), (2,3,3), (2,2,4), (2,2,2,3),
    (2,2,2,2,2) in higher P^N
  • Fermat-type CY 4-folds
  • Borcea-Voisin construction (K3 × elliptic curve quotient)
  • Schoen / Tian-Yau type
  • Toric Calabi-Yau 4-folds (small h^{1,1} sample)

## At a glance

- **Step ID**: `ch_22_cy_4fold_hodge_numbers`
- **Chapter**: Chapter 22
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 1s · standard: 5s · long: 10s
- **Last run**: complete · items 11/11 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_28_diagonal_decomposition`](./28_ch_28_diagonal_decomposition.md)
- [`ch_32_toric_cy_sweep`](./32_ch_32_toric_cy_sweep.md)
- [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `cy_4fold_atlas.csv` | csv | 2.4 KB |
| `cy_4fold_atlas.json` | json | 8.4 KB |

All artifacts are under `pipeline/artifacts/ch_22_cy_4fold_hodge_numbers/`.

## Summary statistics

From `cy_4fold_atlas.json`:

- **total_families**: 11
- **errors**: 0

## Reproduce

```bash
python -m pipeline.runner --only ch_22_cy_4fold_hodge_numbers
python -m pipeline.runner --only ch_22_cy_4fold_hodge_numbers -- --quick
python -m pipeline.runner --only ch_22_cy_4fold_hodge_numbers --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_28_diagonal_decomposition`](./28_ch_28_diagonal_decomposition.md), [`ch_32_toric_cy_sweep`](./32_ch_32_toric_cy_sweep.md), [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_22_cy_4fold_hodge_numbers/spec.yaml` and `pipeline/artifacts/ch_22_cy_4fold_hodge_numbers/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 23 — Fano 4-fold Atlas: Bloch-Srinivas Applicability
*Companion volume to* Codimension Two *— pipeline step `ch_23_fano_atlas`.*

## Overview

Tabulates Fano 4-folds: index, Picard rank, rational connectedness,
and HC verification status. Key insight: all Fano varieties are
rationally connected, hence have small CH_0, hence satisfy
Bloch-Srinivas → Voevodsky nilpotence → HC at all codimensions.

## At a glance

- **Step ID**: `ch_23_fano_atlas`
- **Chapter**: Chapter 23
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 14/14 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_28_diagonal_decomposition`](./28_ch_28_diagonal_decomposition.md)
- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `fano_atlas.csv` | csv | 1.8 KB |
| `fano_atlas.json` | json | 4.3 KB |

All artifacts are under `pipeline/artifacts/ch_23_fano_atlas/`.

## Summary statistics

From `fano_atlas.json`:

- **total**: 14
- **settled_via_bloch_srinivas**: 13
- **special_case_cubic_4fold**: 1

## Reproduce

```bash
python -m pipeline.runner --only ch_23_fano_atlas
python -m pipeline.runner --only ch_23_fano_atlas -- --quick
python -m pipeline.runner --only ch_23_fano_atlas --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_28_diagonal_decomposition`](./28_ch_28_diagonal_decomposition.md), [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_23_fano_atlas/spec.yaml` and `pipeline/artifacts/ch_23_fano_atlas/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 24 — Moduli Spaces: Hodge Conjecture Status
*Companion volume to* Codimension Two *— pipeline step `ch_24_moduli_status`.*

## Overview

Tabulates HC status on moduli spaces appearing in the parent book:
M_g (curves), A_g (abelian varieties), F_g (K3s), C_d (cubic 4-folds),
M_K3^[n] (HK), Hurwitz schemes, etc.

Status varies dramatically with g: low g often rational → trivial HC;
high g of general type → open.

## At a glance

- **Step ID**: `ch_24_moduli_status`
- **Chapter**: Chapter 24
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 19/19 · duration —

## Dependencies

**Downstream** (these steps read from this one):

- [`ch_34_pattern_analysis`](./34_ch_34_pattern_analysis.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `moduli_status.csv` | csv | 1.7 KB |
| `moduli_status.json` | json | 4.7 KB |

All artifacts are under `pipeline/artifacts/ch_24_moduli_status/`.

## Summary statistics

From `moduli_status.json`:

- **total**: 19
- **settled**: 12
- **partial**: 1
- **open**: 5

## Reproduce

```bash
python -m pipeline.runner --only ch_24_moduli_status
python -m pipeline.runner --only ch_24_moduli_status -- --quick
python -m pipeline.runner --only ch_24_moduli_status --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Results feed forward into: [`ch_34_pattern_analysis`](./34_ch_34_pattern_analysis.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_24_moduli_status/spec.yaml` and `pipeline/artifacts/ch_24_moduli_status/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 25 — Hyperkähler Beauville-Bogomolov Lattices
*Companion volume to* Codimension Two *— pipeline step `ch_25_hyperkahler_lattices`.*

## Overview

Constructs the explicit Beauville-Bogomolov lattices for each HK
deformation type from ch_20, computes their discriminants and
signatures, and tabulates the second cohomology H^2(X, Z) structure
per HK family. The BB form is the analogue of the K3 lattice for
higher-dim hyperkähler manifolds.

For each lattice: rank, signature, discriminant, discriminant group,
whether the lattice admits Tate / BBF / monodromy structure aligned
with HC verification.

## At a glance

- **Step ID**: `ch_25_hyperkahler_lattices`
- **Chapter**: Chapter 25
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 5s · standard: 10s · long: 30s
- **Last run**: complete · items 6/6 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)
- [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)

**Downstream** (these steps read from this one):

- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md)
- [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `hk_bb_lattices.csv` | csv | 0.9 KB |
| `hk_bb_lattices.json` | json | 3.3 KB |

All artifacts are under `pipeline/artifacts/ch_25_hyperkahler_lattices/`.

## Summary statistics

From `hk_bb_lattices.json`:

- **total**: 6
- **errors**: 0
- **signature_consistent**: 6

## Reproduce

```bash
python -m pipeline.runner --only ch_25_hyperkahler_lattices
python -m pipeline.runner --only ch_25_hyperkahler_lattices -- --quick
python -m pipeline.runner --only ch_25_hyperkahler_lattices --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md), [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)
- Results feed forward into: [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md), [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_25_hyperkahler_lattices/spec.yaml` and `pipeline/artifacts/ch_25_hyperkahler_lattices/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 26 — Tate Point-Counting on Surfaces and Beyond
*Companion volume to* Codimension Two *— pipeline step `ch_26_tate_point_counting`.*

## Overview

Extends the Ch 14 framework from elliptic curves to surfaces:
point counting on K3 surfaces and abelian surfaces over F_p,
extraction of Frobenius eigenvalues on H^2, and Tate-class detection
at codim 1 (which is the Tate analog of Lefschetz (1,1)).

Provides the per-prime Frobenius polynomial data that ch_37 needs
for cross-prime aggregation.

## At a glance

- **Step ID**: `ch_26_tate_point_counting`
- **Chapter**: Chapter 26
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 10s · standard: 1m · long: 5-10min
- **Last run**: complete · items 28/28 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_14_tate_mirror_framework`](./14_ch_14_tate_mirror_framework.md)

**Downstream** (these steps read from this one):

- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)
- [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `surface_point_counts.csv` | csv | 2.7 KB |
| `surface_point_counts.json` | json | 12.0 KB |

All artifacts are under `pipeline/artifacts/ch_26_tate_point_counting/`.

## Summary statistics

From `surface_point_counts.json`:

- **total_pairs**: 28
- **errors**: 0
- **weil_bound_ok**: 28
- **sato_tate_curves_analyzed**: 4
- **hasse_weil_universally_holds**: True

## Reproduce

```bash
python -m pipeline.runner --only ch_26_tate_point_counting
python -m pipeline.runner --only ch_26_tate_point_counting -- --quick
python -m pipeline.runner --only ch_26_tate_point_counting --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_14_tate_mirror_framework`](./14_ch_14_tate_mirror_framework.md)
- Results feed forward into: [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md), [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_26_tate_point_counting/spec.yaml` and `pipeline/artifacts/ch_26_tate_point_counting/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 27 — Cubic 4-fold Periods: Hodge Structure and Frobenius Detection
*Companion volume to* Codimension Two *— pipeline step `ch_27_cubic_4fold_periods`.*

## Overview

For each Hassett discriminant d from ch_21 (admissible, K3-associated
or not), computes the Hodge-structure data on the rank-2 sublattice
K_d ⊂ H^4(X, Z): intersection form, discriminant, signature.

Uses ch_14's Frobenius framework to point-count Fermat cubic 4-folds
and special cubic 4-folds over small F_p, extracting per-prime
Frobenius eigenvalues on H^4 to detect arithmetic Tate classes.

This step is the bridge from Hassett's complex-analytic period
classification to arithmetic Frobenius detection, and feeds Ch 37
(Tate atlas) and Ch 43 (arithmetic frontier).

## At a glance

- **Step ID**: `ch_27_cubic_4fold_periods`
- **Chapter**: Chapter 27
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 10s · standard: 30s · long: 5min
- **Last run**: complete · items 10/10 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_14_tate_mirror_framework`](./14_ch_14_tate_mirror_framework.md)
- [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md)

**Downstream** (these steps read from this one):

- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)
- [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `cubic_4fold_periods.csv` | csv | 0.5 KB |
| `cubic_4fold_periods.json` | json | 2.9 KB |
| `fermat_cubic_frobenius.json` | json | 0.5 KB |

All artifacts are under `pipeline/artifacts/ch_27_cubic_4fold_periods/`.

## Summary statistics

From `cubic_4fold_periods.json`:

- **n_admissible**: 8
- **n_good**: 8

## Reproduce

```bash
python -m pipeline.runner --only ch_27_cubic_4fold_periods
python -m pipeline.runner --only ch_27_cubic_4fold_periods -- --quick
python -m pipeline.runner --only ch_27_cubic_4fold_periods --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_14_tate_mirror_framework`](./14_ch_14_tate_mirror_framework.md), [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md)
- Results feed forward into: [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md), [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_27_cubic_4fold_periods/spec.yaml` and `pipeline/artifacts/ch_27_cubic_4fold_periods/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 28 — Bloch-Srinivas Diagonal Decomposition
*Companion volume to* Codimension Two *— pipeline step `ch_28_diagonal_decomposition`.*

## Overview

For varieties with trivial CH_0 (mod n), the diagonal Δ_X ∈ CH^n(X×X)
decomposes as a sum of products X × {pt} + (cycles supported on
proper subvarieties). This is the Bloch-Srinivas decomposition theorem
(1983), and it powers HC for Fano varieties (rational connectedness
→ trivial CH_0 → diagonal decomposes → HC).

This step tabulates which varieties from ch_22 (CY 4-folds) and
ch_23 (Fano 4-folds) admit Bloch-Srinivas-style decompositions, and
for those, what HC consequences follow.

## At a glance

- **Step ID**: `ch_28_diagonal_decomposition`
- **Chapter**: Chapter 28
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 1s · standard: 2s · long: 2s
- **Last run**: complete · items 25/25 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)
- [`ch_23_fano_atlas`](./23_ch_23_fano_atlas.md)

**Downstream** (these steps read from this one):

- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `diagonal_decomposition_table.csv` | csv | 3.1 KB |
| `diagonal_decomposition_table.json` | json | 7.6 KB |

All artifacts are under `pipeline/artifacts/ch_28_diagonal_decomposition/`.

## Summary statistics

From `diagonal_decomposition_table.json`:

- **total**: 25
- **br_applies**: 14
- **br_does_not_apply**: 2
- **unknown**: 9

## Reproduce

```bash
python -m pipeline.runner --only ch_28_diagonal_decomposition
python -m pipeline.runner --only ch_28_diagonal_decomposition -- --quick
python -m pipeline.runner --only ch_28_diagonal_decomposition --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md), [`ch_23_fano_atlas`](./23_ch_23_fano_atlas.md)
- Results feed forward into: [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_28_diagonal_decomposition/spec.yaml` and `pipeline/artifacts/ch_28_diagonal_decomposition/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 29 — Explicit Cycle Constructions Atlas
*Companion volume to* Codimension Two *— pipeline step `ch_29_cycle_constructions`.*

## Overview

Tabulates all known explicit construction methods that produce
algebraic codim-2 cycles on the variety classes from Part IV:

- Schubert cycles (for Grassmannians, flag varieties)
- Diagonal embeddings (X × X via Δ_X)
- Lefschetz pencils → vanishing cycles → algebraic descent
- Kuga-Satake (K3 → AV → cycle pullback)
- Hassett-K3 association (cubic 4-fold → K3 → cycle transfer)
- Hyperkähler Beauville-Bogomolov classes
- Beauville-Voisin "canonical zero-cycle" on HK
- Borcea-Voisin construction (CY × K3 quotient)

Cross-tabulates: variety class × construction method × applicability.

## At a glance

- **Step ID**: `ch_29_cycle_constructions`
- **Chapter**: Chapter 29
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 1s · standard: 2s · long: 2s
- **Last run**: complete · items 13/13 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_18_abelian_status`](./18_ch_18_abelian_status.md)
- [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)
- [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md)

**Downstream** (these steps read from this one):

- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `cycle_constructions.csv` | csv | 5.1 KB |
| `cycle_constructions.json` | json | 7.4 KB |

All artifacts are under `pipeline/artifacts/ch_29_cycle_constructions/`.

## Summary statistics

From `cycle_constructions.json`:

- **total_constructions**: 13
- **codim_1_methods**: 2
- **codim_2_methods**: 8
- **general_methods**: 2

## Reproduce

```bash
python -m pipeline.runner --only ch_29_cycle_constructions
python -m pipeline.runner --only ch_29_cycle_constructions -- --quick
python -m pipeline.runner --only ch_29_cycle_constructions --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_18_abelian_status`](./18_ch_18_abelian_status.md), [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md), [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md)
- Results feed forward into: [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_29_cycle_constructions/spec.yaml` and `pipeline/artifacts/ch_29_cycle_constructions/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 30 — Chow Regulators and Beilinson Periods
*Companion volume to* Codimension Two *— pipeline step `ch_30_chow_regulators`.*

## Overview

Computes Beilinson regulator data for K3 surfaces (from ch_19),
abelian varieties (from ch_18), and CY 4-folds (from ch_22).

The Beilinson regulator

  reg: H^{2k-1, k}_M(X, Q) → H^{2k-1}(X, R) / (... + F^k ...)

is a transcendental period map computing motivic cohomology classes
as cohomology elements modulo Hodge-theoretic data. Its determinant
(the "Beilinson period") is conjecturally related to special values
of L-functions L(H^{2k-1}(X), k) via the Beilinson-Bloch conjectures.

For codim-2 specifically (k=2), the regulator detects motivic
cohomology that controls L'-values. Computing regulator periods is
the technical bridge to the arithmetic side of HC.

## At a glance

- **Step ID**: `ch_30_chow_regulators`
- **Chapter**: Chapter 30
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 2s · standard: 10s · long: 1min
- **Last run**: complete · items 52/52 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_18_abelian_status`](./18_ch_18_abelian_status.md)
- [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)
- [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)
- [`ch_10_griffiths_evidence`](./10_ch_10_griffiths_evidence.md)

**Downstream** (these steps read from this one):

- [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)
- [`ch_44_motivic_frontier`](./44_ch_44_motivic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `chow_regulators_table.csv` | csv | 15.4 KB |
| `chow_regulators_table.json` | json | 27.3 KB |

All artifacts are under `pipeline/artifacts/ch_30_chow_regulators/`.

## Summary statistics

From `chow_regulators_table.json`:

- **total**: 52
- **k3**: 17
- **abelian**: 19
- **cy_4fold**: 11

## Reproduce

```bash
python -m pipeline.runner --only ch_30_chow_regulators
python -m pipeline.runner --only ch_30_chow_regulators -- --quick
python -m pipeline.runner --only ch_30_chow_regulators --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_18_abelian_status`](./18_ch_18_abelian_status.md), [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md), [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md), [`ch_10_griffiths_evidence`](./10_ch_10_griffiths_evidence.md)
- Results feed forward into: [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md), [`ch_44_motivic_frontier`](./44_ch_44_motivic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_30_chow_regulators/spec.yaml` and `pipeline/artifacts/ch_30_chow_regulators/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 31 — Mumford-Weil Detector: Exotic Hodge Classes on Abelian Varieties
*Companion volume to* Codimension Two *— pipeline step `ch_31_mumford_weil`.*

## Overview

Implements the Mumford-Tate detector for abelian varieties: identifies
which abelian varieties from ch_18 carry "exotic" Hodge classes
(classes outside the Lefschetz algebra <h>·H^*) and tabulates known
HC verifications for these exotic cases.

Mumford 1969 constructed abelian 4-folds whose Hodge ring strictly
contains the divisor-generated part — making the codim-2 HC genuinely
nontrivial even on abelian varieties. Andre 1996 verified HC for
specific Mumford-type examples.

## At a glance

- **Step ID**: `ch_31_mumford_weil`
- **Chapter**: Chapter 31
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 1s · standard: 2s · long: 2s
- **Last run**: complete · items 19/19 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_18_abelian_status`](./18_ch_18_abelian_status.md)

**Downstream** (these steps read from this one):

- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `mumford_weil_table.csv` | csv | 3.4 KB |
| `mumford_weil_table.json` | json | 9.0 KB |

All artifacts are under `pipeline/artifacts/ch_31_mumford_weil/`.

## Summary statistics

From `mumford_weil_table.json`:

- **total**: 19
- **exotic_classes_expected**: 12
- **lefschetz_only**: 6
- **unknown**: 1

## Reproduce

```bash
python -m pipeline.runner --only ch_31_mumford_weil
python -m pipeline.runner --only ch_31_mumford_weil -- --quick
python -m pipeline.runner --only ch_31_mumford_weil --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_18_abelian_status`](./18_ch_18_abelian_status.md)
- Results feed forward into: [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_31_mumford_weil/spec.yaml` and `pipeline/artifacts/ch_31_mumford_weil/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 32 — Toric Calabi-Yau 4-fold Sweep
*Companion volume to* Codimension Two *— pipeline step `ch_32_toric_cy_sweep`.*

## Overview

Scans toric CY 4-folds derived from reflexive 4-polytopes (Kreuzer-Skarke
classification) and computes Hodge number statistics. Without the full
Kreuzer-Skarke download, this step uses a sample dataset of canonical
toric CY 4-folds with known Hodge numbers; with KS data available, the
full sweep can be activated.

## At a glance

- **Step ID**: `ch_32_toric_cy_sweep`
- **Chapter**: Chapter 32
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 2s · standard: 5s · long: 1-5min (depends on KS data availability)
- **Last run**: complete · items 17/17 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)

**Downstream** (these steps read from this one):

- [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md)
- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `toric_cy4_sweep.csv` | csv | 0.9 KB |
| `toric_cy4_sweep.json` | json | 4.1 KB |

All artifacts are under `pipeline/artifacts/ch_32_toric_cy_sweep/`.

## Summary statistics

From `toric_cy4_sweep.json`:

- **total**: 17
- **h11_distribution**:
  - 1: 5
  - 2-5: 9
  - 6-15: 3
  - 16+: 0
- **mean_tension**: 407.53
- **max_tension**: 1751

## Reproduce

```bash
python -m pipeline.runner --only ch_32_toric_cy_sweep
python -m pipeline.runner --only ch_32_toric_cy_sweep -- --quick
python -m pipeline.runner --only ch_32_toric_cy_sweep --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)
- Results feed forward into: [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md), [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_32_toric_cy_sweep/spec.yaml` and `pipeline/artifacts/ch_32_toric_cy_sweep/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 33 — Counterexample Search: Where Methods Reach Their Limits
*Companion volume to* Codimension Two *— pipeline step `ch_33_counterexample_search`.*

## Overview

For each variety class with potential codim-2 transcendence (CY 4-folds,
general 4-folds, OG-10, etc.), computes a "tension index": the gap
between (h^{2,2} = total Hodge-(2,2) dimension) and (algebraic codim-2
classes known by explicit construction).

The tension index ranks variety classes by how far their algebraic
cycle constructions fall short of explaining all Hodge classes. The
largest tensions are the most plausible counterexample candidates,
or — if no counterexample exists — the hardest cases needing new
cycle constructions.

## At a glance

- **Step ID**: `ch_33_counterexample_search`
- **Chapter**: Chapter 33
- **Category**: Medium (computational scan)
- **Runtime targets**: quick: 1s · standard: 2s · long: 2s
- **Last run**: complete · items 12/12 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)
- [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)
- [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md)

**Downstream** (these steps read from this one):

- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)
- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `tension_index.csv` | csv | 1.2 KB |
| `tension_index.json` | json | 4.2 KB |

All artifacts are under `pipeline/artifacts/ch_33_counterexample_search/`.

## Summary statistics

From `tension_index.json`:

- **total_varieties**: 12
- **highest_tension**: sextic_P5
- **max_tension_value**: 1751
- **mean_tension_ratio**: 0.666

## Reproduce

```bash
python -m pipeline.runner --only ch_33_counterexample_search
python -m pipeline.runner --only ch_33_counterexample_search -- --quick
python -m pipeline.runner --only ch_33_counterexample_search --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md), [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md), [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md)
- Results feed forward into: [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md), [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_33_counterexample_search/spec.yaml` and `pipeline/artifacts/ch_33_counterexample_search/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 34 — Cross-Part Pattern Analysis
*Companion volume to* Codimension Two *— pipeline step `ch_34_pattern_analysis`.*

## Overview

Aggregates structural observations across the entire built atlas
(Parts IV + V) to identify cross-cutting patterns:

- Which variety classes share which obstructions?
- Which proof methods recur across variety classes?
- Where does the codim-2 frontier cluster?
- What structural features predict HC-settled vs HC-open?

Produces a "structural fingerprint" per variety class and clusters
varieties by HC-relevant features.

## At a glance

- **Step ID**: `ch_34_pattern_analysis`
- **Chapter**: Chapter 34
- **Category**: Aggregator (synthesizes upstream)
- **Runtime targets**: quick: 1s · standard: 2s · long: 2s
- **Last run**: complete · items 15/15 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_17_voevodsky_status`](./17_ch_17_voevodsky_status.md)
- [`ch_18_abelian_status`](./18_ch_18_abelian_status.md)
- [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)
- [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)
- [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md)
- [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)
- [`ch_23_fano_atlas`](./23_ch_23_fano_atlas.md)
- [`ch_24_moduli_status`](./24_ch_24_moduli_status.md)
- [`ch_25_hyperkahler_lattices`](./25_ch_25_hyperkahler_lattices.md)
- [`ch_28_diagonal_decomposition`](./28_ch_28_diagonal_decomposition.md)
- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_31_mumford_weil`](./31_ch_31_mumford_weil.md)

**Downstream** (these steps read from this one):

- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_39_implications_table`](./39_ch_39_implications_table.md)
- [`ch_40_web_graph`](./40_ch_40_web_graph.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `pattern_analysis.csv` | csv | 1.4 KB |
| `pattern_analysis.json` | json | 7.3 KB |
| `pattern_analysis.md` | md | 2.9 KB |

All artifacts are under `pipeline/artifacts/ch_34_pattern_analysis/`.

## Summary statistics

From `pattern_analysis.json`:

- **total_classes**: 15
- **features_tracked**: 8

## Reproduce

```bash
python -m pipeline.runner --only ch_34_pattern_analysis
python -m pipeline.runner --only ch_34_pattern_analysis -- --quick
python -m pipeline.runner --only ch_34_pattern_analysis --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_17_voevodsky_status`](./17_ch_17_voevodsky_status.md), [`ch_18_abelian_status`](./18_ch_18_abelian_status.md), [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md), [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md), [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md), [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md), [`ch_23_fano_atlas`](./23_ch_23_fano_atlas.md), [`ch_24_moduli_status`](./24_ch_24_moduli_status.md), [`ch_25_hyperkahler_lattices`](./25_ch_25_hyperkahler_lattices.md), [`ch_28_diagonal_decomposition`](./28_ch_28_diagonal_decomposition.md), [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_31_mumford_weil`](./31_ch_31_mumford_weil.md)
- Results feed forward into: [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_39_implications_table`](./39_ch_39_implications_table.md), [`ch_40_web_graph`](./40_ch_40_web_graph.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_34_pattern_analysis/spec.yaml` and `pipeline/artifacts/ch_34_pattern_analysis/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 35 — Generalized Hodge Conjecture / Coniveau Filtration
*Companion volume to* Codimension Two *— pipeline step `ch_35_ghc_coniveau_table`.*

## Overview

Tabulates the coniveau filtration N^c H^k(X) and the GHC predictions
per variety class. The Generalized Hodge Conjecture (Grothendieck 1969)
refines HC: it predicts that the coniveau filtration coincides with
the largest sub-Hodge-structure supported in degree ≥ 2c.

GHC implies HC; in many cases GHC is provably equivalent to HC.

## At a glance

- **Step ID**: `ch_35_ghc_coniveau_table`
- **Chapter**: Chapter 35
- **Category**: Small (literature compilation)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 15/15 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_10_griffiths_evidence`](./10_ch_10_griffiths_evidence.md)

**Downstream** (these steps read from this one):

- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_39_implications_table`](./39_ch_39_implications_table.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `ghc_coniveau_table.csv` | csv | 1.7 KB |
| `ghc_coniveau_table.json` | json | 3.8 KB |

All artifacts are under `pipeline/artifacts/ch_35_ghc_coniveau_table/`.

## Summary statistics

From `ghc_coniveau_table.json`:

- **total**: 15
- **settled**: 10
- **open**: 5

## Reproduce

```bash
python -m pipeline.runner --only ch_35_ghc_coniveau_table
python -m pipeline.runner --only ch_35_ghc_coniveau_table -- --quick
python -m pipeline.runner --only ch_35_ghc_coniveau_table --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_10_griffiths_evidence`](./10_ch_10_griffiths_evidence.md)
- Results feed forward into: [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_39_implications_table`](./39_ch_39_implications_table.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_35_ghc_coniveau_table/spec.yaml` and `pipeline/artifacts/ch_35_ghc_coniveau_table/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 36 — Standard Conjectures Atlas (Aggregator)
*Companion volume to* Codimension Two *— pipeline step `ch_36_standard_conjectures_atlas`.*

## Overview

Synthesizes data from ch_13 (B/C/D/I status by class), ch_17 (Voevodsky),
ch_18 (abelian HC), ch_19 (K3 atlas), ch_20 (HK), ch_21 (cubic 4-fold
Hassett), ch_22 (CY 4-fold), ch_23 (Fano), ch_24 (moduli) into a single
master atlas showing the standard-conjectures landscape across the codim-2
HC frontier.

Cross-cuts: variety class × {B, C, D, I, HC@1, HC@2, Voevodsky, Tate}.
Produces a wide table with one row per variety class and one column per
conjecture/property, highlighting which conjectures need each other and
which variety classes hit the open frontier on multiple fronts.

## At a glance

- **Step ID**: `ch_36_standard_conjectures_atlas`
- **Chapter**: Chapter 36
- **Category**: Aggregator (synthesizes upstream)
- **Runtime targets**: quick: 2s · standard: 5s · long: 5s
- **Last run**: complete · items 18/18 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_13_standard_conjectures_status`](./13_ch_13_standard_conjectures_status.md)
- [`ch_17_voevodsky_status`](./17_ch_17_voevodsky_status.md)
- [`ch_18_abelian_status`](./18_ch_18_abelian_status.md)
- [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)
- [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)
- [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md)
- [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)
- [`ch_23_fano_atlas`](./23_ch_23_fano_atlas.md)
- [`ch_24_moduli_status`](./24_ch_24_moduli_status.md)

**Downstream** (these steps read from this one):

- [`ch_39_implications_table`](./39_ch_39_implications_table.md)
- [`ch_40_web_graph`](./40_ch_40_web_graph.md)
- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `open_frontier_summary.md` | md | 1.2 KB |
| `standard_conjectures_atlas.csv` | csv | 1.8 KB |
| `standard_conjectures_atlas.json` | json | 4.9 KB |

All artifacts are under `pipeline/artifacts/ch_36_standard_conjectures_atlas/`.

## Summary statistics

From `standard_conjectures_atlas.json`:

- **total_classes**: 18
- **open_frontier_count**: 10
- **cells_settled**: 44
- **cells_partial**: 13
- **cells_open**: 26
- **cells_unknown**: 43

## Reproduce

```bash
python -m pipeline.runner --only ch_36_standard_conjectures_atlas
python -m pipeline.runner --only ch_36_standard_conjectures_atlas -- --quick
python -m pipeline.runner --only ch_36_standard_conjectures_atlas --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_13_standard_conjectures_status`](./13_ch_13_standard_conjectures_status.md), [`ch_17_voevodsky_status`](./17_ch_17_voevodsky_status.md), [`ch_18_abelian_status`](./18_ch_18_abelian_status.md), [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md), [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md), [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md), [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md), [`ch_23_fano_atlas`](./23_ch_23_fano_atlas.md), [`ch_24_moduli_status`](./24_ch_24_moduli_status.md)
- Results feed forward into: [`ch_39_implications_table`](./39_ch_39_implications_table.md), [`ch_40_web_graph`](./40_ch_40_web_graph.md), [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_36_standard_conjectures_atlas/spec.yaml` and `pipeline/artifacts/ch_36_standard_conjectures_atlas/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 37 — Tate Conjecture Atlas
*Companion volume to* Codimension Two *— pipeline step `ch_37_tate_conjecture_atlas`.*

## Overview

Tate-side mirror of the Hodge atlas. For each variety class:

- State the Tate conjecture for X over a number field K:
  H^{2k}_ét(X̄, Q_ℓ)(k)^{G_K} = span(algebraic cycles of codim k)

- Status: settled / partial / open per class
- Bridges to / from HC via the Mumford-Tate connection

Uses ch_26 framework outputs (point counting → Frobenius eigenvalue
detection) for the codim-2 cases.

## At a glance

- **Step ID**: `ch_37_tate_conjecture_atlas`
- **Chapter**: Chapter 37
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 5s · standard: 10s · long: 30s
- **Last run**: complete · items 15/15 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_14_tate_mirror_framework`](./14_ch_14_tate_mirror_framework.md)
- [`ch_17_voevodsky_status`](./17_ch_17_voevodsky_status.md)
- [`ch_18_abelian_status`](./18_ch_18_abelian_status.md)
- [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md)
- [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)
- [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md)
- [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)
- [`ch_26_tate_point_counting`](./26_ch_26_tate_point_counting.md)
- [`ch_27_cubic_4fold_periods`](./27_ch_27_cubic_4fold_periods.md)

**Downstream** (these steps read from this one):

- [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)
- [`ch_39_implications_table`](./39_ch_39_implications_table.md)
- [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `tate_atlas.csv` | csv | 2.3 KB |
| `tate_atlas.json` | json | 4.5 KB |

All artifacts are under `pipeline/artifacts/ch_37_tate_conjecture_atlas/`.

## Summary statistics

From `tate_atlas.json`:

- **total**: 15
- **settled**: 9
- **partial**: 2
- **open**: 4

## Reproduce

```bash
python -m pipeline.runner --only ch_37_tate_conjecture_atlas
python -m pipeline.runner --only ch_37_tate_conjecture_atlas -- --quick
python -m pipeline.runner --only ch_37_tate_conjecture_atlas --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_14_tate_mirror_framework`](./14_ch_14_tate_mirror_framework.md), [`ch_17_voevodsky_status`](./17_ch_17_voevodsky_status.md), [`ch_18_abelian_status`](./18_ch_18_abelian_status.md), [`ch_19_k3_atlas`](./19_ch_19_k3_atlas.md), [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md), [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md), [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md), [`ch_26_tate_point_counting`](./26_ch_26_tate_point_counting.md), [`ch_27_cubic_4fold_periods`](./27_ch_27_cubic_4fold_periods.md)
- Results feed forward into: [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md), [`ch_39_implications_table`](./39_ch_39_implications_table.md), [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_37_tate_conjecture_atlas/spec.yaml` and `pipeline/artifacts/ch_37_tate_conjecture_atlas/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 38 — Beilinson L-Value Framework
*Companion volume to* Codimension Two *— pipeline step `ch_38_beilinson_l_values`.*

## Overview

Beilinson conjectures relate L-function special values L(H^k(X), s) to
regulator determinants computed from motivic cohomology. For codim-2
cycles on 4-folds, the relevant L-value is L(H^4(X), 2), and Beilinson's
Conjecture C predicts:

  ord_{s=2} L(H^4(X), s) = rank(motivic codim-2) − rank(algebraic codim-2)

This step compiles the Beilinson framework, lists varieties where
L-values have been computed, and tabulates the "Beilinson prediction
vs. computation" status.

## At a glance

- **Step ID**: `ch_38_beilinson_l_values`
- **Chapter**: Chapter 38
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 1s · standard: 2s · long: 2s
- **Last run**: complete · items 9/9 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_16_motivic_cohomology_table`](./16_ch_16_motivic_cohomology_table.md)
- [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md)
- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)

**Downstream** (these steps read from this one):

- [`ch_39_implications_table`](./39_ch_39_implications_table.md)
- [`ch_44_motivic_frontier`](./44_ch_44_motivic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `beilinson_l_values.csv` | csv | 1.8 KB |
| `beilinson_l_values.json` | json | 3.1 KB |

All artifacts are under `pipeline/artifacts/ch_38_beilinson_l_values/`.

## Summary statistics

From `beilinson_l_values.json`:

- **total**: 9
- **settled**: 1
- **partial**: 5
- **unstudied**: 2

## Reproduce

```bash
python -m pipeline.runner --only ch_38_beilinson_l_values
python -m pipeline.runner --only ch_38_beilinson_l_values -- --quick
python -m pipeline.runner --only ch_38_beilinson_l_values --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_16_motivic_cohomology_table`](./16_ch_16_motivic_cohomology_table.md), [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md), [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)
- Results feed forward into: [`ch_39_implications_table`](./39_ch_39_implications_table.md), [`ch_44_motivic_frontier`](./44_ch_44_motivic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_38_beilinson_l_values/spec.yaml` and `pipeline/artifacts/ch_38_beilinson_l_values/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 39 — Logical Implications: What Settles What
*Companion volume to* Codimension Two *— pipeline step `ch_39_implications_table`.*

## Overview

Aggregator that maps the logical implications between conjectures
in the codim-2 ecosystem:

  B(X) ⇒ C(X) ⇒ D(X) ⇒ I(X)             (standard conjecture chain)
  D(X) ⇒ HC(X) at codim k for various k  (Hodge conjecture follows)
  Voevodsky nilpotence + B(X) ⇒ HC(X)
  Tate(X) ⇔ HC(X) (via Mumford-Tate bridge, under hypotheses)
  Beilinson C ⇒ generalized HC
  GHC ⇒ HC

Compiles the precise statements + status from ch_36 (master atlas),
ch_37 (Tate), ch_38 (Beilinson L-values) into an implications graph.

## At a glance

- **Step ID**: `ch_39_implications_table`
- **Chapter**: Chapter 39
- **Category**: Aggregator (synthesizes upstream)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 17/17 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_13_standard_conjectures_status`](./13_ch_13_standard_conjectures_status.md)
- [`ch_35_ghc_coniveau_table`](./35_ch_35_ghc_coniveau_table.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)
- [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)

**Downstream** (these steps read from this one):

- [`ch_40_web_graph`](./40_ch_40_web_graph.md)
- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `implications_graph.md` | md | 3.0 KB |
| `implications_table.csv` | csv | 2.3 KB |
| `implications_table.json` | json | 4.5 KB |

All artifacts are under `pipeline/artifacts/ch_39_implications_table/`.

## Summary statistics

From `implications_table.json`:

- **total_implications**: 17
- **one_way**: 16
- **equivalences**: 1

## Reproduce

```bash
python -m pipeline.runner --only ch_39_implications_table
python -m pipeline.runner --only ch_39_implications_table -- --quick
python -m pipeline.runner --only ch_39_implications_table --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_13_standard_conjectures_status`](./13_ch_13_standard_conjectures_status.md), [`ch_35_ghc_coniveau_table`](./35_ch_35_ghc_coniveau_table.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md), [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)
- Results feed forward into: [`ch_40_web_graph`](./40_ch_40_web_graph.md), [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_39_implications_table/spec.yaml` and `pipeline/artifacts/ch_39_implications_table/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 40 — Conjecture Web Graph
*Companion volume to* Codimension Two *— pipeline step `ch_40_web_graph`.*

## Overview

SVG visualization of the codim-2 conjecture web: variety classes as
nodes colored by HC@2 status, structural relationships (Hassett bridge,
Hilbert scheme, etc.) as edges.

## At a glance

- **Step ID**: `ch_40_web_graph`
- **Chapter**: Chapter 40
- **Category**: Aggregator (synthesizes upstream)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 18/18 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)

**Downstream** (these steps read from this one):

- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `web_graph.json` | json | 4.0 KB |
| `web_graph.png` | png | 86.2 KB |
| `web_graph.svg` | svg | 8.2 KB |

All artifacts are under `pipeline/artifacts/ch_40_web_graph/`.

## Summary statistics

From `web_graph.json`:

- **total_nodes**: 18
- **total_edges**: 7
- **n_settled**: 9
- **n_partial**: 4
- **n_open**: 6

## Reproduce

```bash
python -m pipeline.runner --only ch_40_web_graph
python -m pipeline.runner --only ch_40_web_graph -- --quick
python -m pipeline.runner --only ch_40_web_graph --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- Results feed forward into: [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_40_web_graph/spec.yaml` and `pipeline/artifacts/ch_40_web_graph/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 41 — Infrastructure Categories: What the Codim-2 Program Needs
*Companion volume to* Codimension Two *— pipeline step `ch_41_infrastructure_categories`.*

## Overview

Cataloging the categories of mathematical infrastructure that the
codim-2 HC program requires or would benefit from. Each category is
a "type of tool" — lattice theory, derived categories, motives,
Frobenius traces, etc. — with status across the variety atlas.

## At a glance

- **Step ID**: `ch_41_infrastructure_categories`
- **Chapter**: Chapter 41
- **Category**: Aggregator (synthesizes upstream)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 14/14 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)

**Downstream** (these steps read from this one):

- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `infrastructure_categories.csv` | csv | 1.8 KB |
| `infrastructure_categories.json` | json | 3.1 KB |

All artifacts are under `pipeline/artifacts/ch_41_infrastructure_categories/`.

## Summary statistics

From `infrastructure_categories.json`:

- **total**: 14
- **mature**: 9
- **developing**: 4
- **emerging**: 1

## Reproduce

```bash
python -m pipeline.runner --only ch_41_infrastructure_categories
python -m pipeline.runner --only ch_41_infrastructure_categories -- --quick
python -m pipeline.runner --only ch_41_infrastructure_categories --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- Results feed forward into: [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_41_infrastructure_categories/spec.yaml` and `pipeline/artifacts/ch_41_infrastructure_categories/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 42 — Constructive Frontier: What Cycles Need to be Built
*Companion volume to* Codimension Two *— pipeline step `ch_42_constructive_frontier`.*

## Overview

For each open codim-2 case from the atlas, lists what cycle
constructions would have to be invented to settle HC for that case.
This is the "to-do list" of cycle construction methods that don't yet
exist but would close specific open frontiers.

## At a glance

- **Step ID**: `ch_42_constructive_frontier`
- **Chapter**: Chapter 42
- **Category**: Aggregator (synthesizes upstream)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 10/10 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md)
- [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md)
- [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md)
- [`ch_35_ghc_coniveau_table`](./35_ch_35_ghc_coniveau_table.md)

**Downstream** (these steps read from this one):

- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `constructive_frontier.csv` | csv | 1.6 KB |
| `constructive_frontier.json` | json | 3.2 KB |

All artifacts are under `pipeline/artifacts/ch_42_constructive_frontier/`.

## Summary statistics

From `constructive_frontier.json`:

- **total**: 10

## Reproduce

```bash
python -m pipeline.runner --only ch_42_constructive_frontier
python -m pipeline.runner --only ch_42_constructive_frontier -- --quick
python -m pipeline.runner --only ch_42_constructive_frontier --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_20_hyperkahler_classification`](./20_ch_20_hyperkahler_classification.md), [`ch_21_hassett_discriminants`](./21_ch_21_hassett_discriminants.md), [`ch_29_cycle_constructions`](./29_ch_29_cycle_constructions.md), [`ch_35_ghc_coniveau_table`](./35_ch_35_ghc_coniveau_table.md)
- Results feed forward into: [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_42_constructive_frontier/spec.yaml` and `pipeline/artifacts/ch_42_constructive_frontier/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 43 — Arithmetic Frontier: Open Tate / Frobenius / Galois Questions
*Companion volume to* Codimension Two *— pipeline step `ch_43_arithmetic_frontier`.*

## Overview

Lists the open arithmetic-side questions on the codim-2 frontier:
Tate conjecture for CY 4-folds, Frobenius eigenvalue structure on
OG-10, ℓ-adic / crystalline / p-adic comparisons, and conjectures
about Galois representations on H^4 of 4-folds.

## At a glance

- **Step ID**: `ch_43_arithmetic_frontier`
- **Chapter**: Chapter 43
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 8/8 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_14_tate_mirror_framework`](./14_ch_14_tate_mirror_framework.md)
- [`ch_26_tate_point_counting`](./26_ch_26_tate_point_counting.md)
- [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)

**Downstream** (these steps read from this one):

- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `arithmetic_frontier.csv` | csv | 1.8 KB |
| `arithmetic_frontier.json` | json | 3.2 KB |

All artifacts are under `pipeline/artifacts/ch_43_arithmetic_frontier/`.

## Summary statistics

From `arithmetic_frontier.json`:

- **total**: 8
- **high_difficulty**: 6
- **very_high**: 1

## Reproduce

```bash
python -m pipeline.runner --only ch_43_arithmetic_frontier
python -m pipeline.runner --only ch_43_arithmetic_frontier -- --quick
python -m pipeline.runner --only ch_43_arithmetic_frontier --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_14_tate_mirror_framework`](./14_ch_14_tate_mirror_framework.md), [`ch_26_tate_point_counting`](./26_ch_26_tate_point_counting.md), [`ch_37_tate_conjecture_atlas`](./37_ch_37_tate_conjecture_atlas.md)
- Results feed forward into: [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_43_arithmetic_frontier/spec.yaml` and `pipeline/artifacts/ch_43_arithmetic_frontier/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# CHAPTER 44 — Motivic Frontier: Open Beilinson / Regulator / Motive Questions
*Companion volume to* Codimension Two *— pipeline step `ch_44_motivic_frontier`.*

## Overview

Open motivic-side questions. Beilinson regulator for CY 4-folds at
codim 2, motivic decomposition of OG-10, finite-dimensionality of
motives, etc.

## At a glance

- **Step ID**: `ch_44_motivic_frontier`
- **Chapter**: Chapter 44
- **Category**: Large (compute-heavy)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 8/8 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_16_motivic_cohomology_table`](./16_ch_16_motivic_cohomology_table.md)
- [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md)
- [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)

**Downstream** (these steps read from this one):

- [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `motivic_frontier.csv` | csv | 1.7 KB |
| `motivic_frontier.json` | json | 2.8 KB |

All artifacts are under `pipeline/artifacts/ch_44_motivic_frontier/`.

## Summary statistics

From `motivic_frontier.json`:

- **total**: 8
- **cy_4fold_questions**: 5
- **hk_questions**: 2

## Reproduce

```bash
python -m pipeline.runner --only ch_44_motivic_frontier
python -m pipeline.runner --only ch_44_motivic_frontier -- --quick
python -m pipeline.runner --only ch_44_motivic_frontier --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_16_motivic_cohomology_table`](./16_ch_16_motivic_cohomology_table.md), [`ch_30_chow_regulators`](./30_ch_30_chow_regulators.md), [`ch_38_beilinson_l_values`](./38_ch_38_beilinson_l_values.md)
- Results feed forward into: [`appendix_c_problems_status`](./99_appendix_c_appendix_c_problems_status.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/ch_44_motivic_frontier/spec.yaml` and `pipeline/artifacts/ch_44_motivic_frontier/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# APPENDIX C — Appendix C Problems: Pipeline-Side Status
*Companion volume to* Codimension Two *— pipeline step `appendix_c_problems_status`.*

## Overview

Cross-references the 35 open problems from Appendix C of the parent
book *Codimension Two* (6 categories) with what the companion pipeline
has built. For each problem: is it tabulated? computed? aggregated?
what step covers it? Produces the "companion ↔ Appendix C" map.

## At a glance

- **Step ID**: `appendix_c_problems_status`
- **Chapter**: Appendix C
- **Category**: Aggregator (synthesizes upstream)
- **Runtime targets**: quick: 1s · standard: 1s · long: 1s
- **Last run**: complete · items 35/35 · duration —

## Dependencies

**Upstream** (this step reads from):

- [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md)
- [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md)
- [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md)
- [`ch_39_implications_table`](./39_ch_39_implications_table.md)
- [`ch_40_web_graph`](./40_ch_40_web_graph.md)
- [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md)
- [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md)
- [`ch_44_motivic_frontier`](./44_ch_44_motivic_frontier.md)

## Computed outputs

| File | Type | Size |
|---|---|---|
| `appendix_c_companion_map.md` | md | 8.8 KB |
| `appendix_c_problems_status.csv` | csv | 6.8 KB |
| `appendix_c_problems_status.json` | json | 13.9 KB |

All artifacts are under `pipeline/artifacts/appendix_c_problems_status/`.

## Summary statistics

From `appendix_c_problems_status.json`:

- **total**: 35
- **fully_covered**: 33
- **partially_covered**: 0
- **planned**: 0
- **out_of_scope**: 2
- **effective_coverage_pct**: 100.0

## Reproduce

```bash
python -m pipeline.runner --only appendix_c_problems_status
python -m pipeline.runner --only appendix_c_problems_status -- --quick
python -m pipeline.runner --only appendix_c_problems_status --force -- --workers 4
```

View progress live during a run:

```bash
python -m pipeline.tui
```

## See also

- Source data flows in from: [`ch_22_cy_4fold_hodge_numbers`](./22_ch_22_cy_4fold_hodge_numbers.md), [`ch_33_counterexample_search`](./33_ch_33_counterexample_search.md), [`ch_36_standard_conjectures_atlas`](./36_ch_36_standard_conjectures_atlas.md), [`ch_39_implications_table`](./39_ch_39_implications_table.md), [`ch_40_web_graph`](./40_ch_40_web_graph.md), [`ch_42_constructive_frontier`](./42_ch_42_constructive_frontier.md), [`ch_43_arithmetic_frontier`](./43_ch_43_arithmetic_frontier.md), [`ch_44_motivic_frontier`](./44_ch_44_motivic_frontier.md)

---

*Generated by `book/_build/generate_chapters.py` from `pipeline/steps/appendix_c_problems_status/spec.yaml` and `pipeline/artifacts/appendix_c_problems_status/`. Edit by hand to add prose, then run `--force` to regenerate the auto-sections without overwriting your text.*

# Conclusion

*The companion contains 39 pipeline steps across 7 parts plus Appendix C. Each
chapter is reproducible from `pipeline/steps/<step_id>/`.  What follows is a
brief stocktaking of what the atlas now makes legible — and what it leaves open.*

## What the atlas confirms

The structural picture from the parent volume holds up under computation:

- **Codimension 1 is settled** by Lefschetz (1,1) everywhere — no surprises.
- **Surfaces, K3, abelian, and rationally connected Fano**: codim-2 settled
  cleanly. Bloch-Srinivas diagonal decomposition handles the RC case; Lefschetz,
  Lieberman, and Mumford-Tate-bridge work handle the rest.
- **Hyperkähler K3<sup>[n]</sup>**: codim-2 settled via Charles-Markman and
  Vial.
- **Hassett-special cubic 4-folds with K3 association**: codim-2 settled via
  the Kuznetsov K3 category.

## What the atlas leaves open

The open frontier is sharp and concentrated:

- **Generic CY 4-folds** (sextic in P<sup>5</sup>, (2,5), (3,4), and other
  complete intersections): all open. The tension index from ch_33 ranks the
  generic sextic CY 4-fold at the top — 1,751 Hodge classes unexplained by any
  current cycle construction.
- **Generic cubic 4-folds** (non-Hassett-special): codim-2 open.
- **Hyperkähler OG-6 and OG-10**: open in HC, Tate, and Voevodsky
  simultaneously.
- **General smooth projective 4-folds**: open in all directions; no current
  proposal for a unifying construction.
- **High-genus moduli M<sub>g</sub>, A<sub>g</sub>**: open past the
  unirationality boundaries.

## What changed during the build

The pipeline identified two verification items that the parent volume should
address before publication. They are recorded in
`docs/VERIFICATION_LOG.md` and cross-referenced from the parent's
`PENDING_FOR_PUBLICATION.md`. Neither breaks the parent volume's argument;
both refine it.

A subsequent external structural review (2026-05-11) found no critical
computational errors or major inconsistencies in the assembled book or
pipeline. The review confirmed the verification practice itself and added
three follow-up priorities. As of the same date, four of these have been
shipped:

- **Jacobian-ring computation for Ch 22 hypersurfaces** — the sextic case is
  now triple-verified (literature, Chern-class, Jacobian ring all give
  h<sup>3,1</sup> = 426, h<sup>2,2</sup> = 1752).
- **Extended Nikulin K3-association** — 22 newly K3-associated cubic 4-fold
  discriminants in d ≤ 200, plus 22 newly classified as having no K3
  association.
- **OG-6 inheritance from abelian surfaces** — added to the
  cycle-construction atlas as construction #16.
- **Sato-Tate distribution check** on Frobenius traces — added as an
  arithmetic sanity check to the point-counting step.

## What still comes next

Reduced from the original five-item queue:

1. **Relative-Jacobian computation for Ch 22 complete intersections**. The
   six c.i. families (CI(2,5)/P<sup>6</sup>, CI(3,4)/P<sup>6</sup>, etc.) where
   literature h<sup>2,2</sup> disagrees with the Chern-class ground truth
   remain open. The relative-Jacobian or Koszul-complex generalization of the
   Griffiths-Steenbrink formula is the next path.
2. **Full Kreuzer-Skarke toric CY 4-fold sweep**. The ch_32 step still uses a
   22-entry sample. Downloading the 473-million-polytope KS list and activating
   `--use-full-ks` extends the toric CY atlas to its full scope.
3. **Higher-codimension companion volume**: codim 3 and higher on 4-folds,
   dim 5 and higher generally. The atlas methodology transfers; only the
   lattice data and variety atlases need rebuilding.
4. **Scale-up of the arithmetic side**: efficient point counting on cubic
   4-folds and CY 4-folds; build the Tate-Hodge bridge artifact-by-artifact at
   higher primes. The framework in ch_14, ch_26 (now including the new
   Sato-Tate sanity check), ch_27, ch_37 is ready; what's needed is
   computational scale, not new theory.

## Closing thought

The codim-2 Hodge conjecture is not a single statement awaiting a single proof:
it is a family of statements, indexed by variety class, each with its own
proof-attempt landscape. The atlas's job is not to solve it. The atlas's job
is to make the landscape legible — to a human, to a future researcher, and to
a future AI. The pipeline is the legibility.

---

*Return to the [Table of Contents](./_TOC.md).*