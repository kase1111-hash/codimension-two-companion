# Table of Contents — Codimension Two: A Computational Companion

*Each chapter mirrors a pipeline step that produces computed data + literature synthesis. Together, the 39 chapters atlas the codim-2 Hodge conjecture computationally.*

---

- [Introduction](./00_introduction.md)


## Part I — The Conjecture and Its Setting

- **Chapter 4** — [The Codimension Grid](./chapters/04_ch_04_codim_grid.md) <sub>`ch_04_codim_grid` · V</sub>

## Part II — Why Dimension 4 Is the Threshold

- **Chapter 6** — [Hard Lefschetz Duality and the Lefschetz Action](./chapters/06_ch_06_lefschetz_action.md) <sub>`ch_06_lefschetz_action` · S</sub>
- **Chapter 7** — [The Three Gifts of Codimension 1](./chapters/07_ch_07_three_gifts_table.md) <sub>`ch_07_three_gifts_table` · V</sub>
- **Chapter 9** — [Intermediate Jacobian at Codimension 2](./chapters/09_ch_09_intermediate_jacobian_check.md) <sub>`ch_09_intermediate_jacobian_check` · S</sub>
- **Chapter 10** — [Griffiths Group: Transcendence Evidence at Codim 2](./chapters/10_ch_10_griffiths_evidence.md) <sub>`ch_10_griffiths_evidence` · S</sub>

## Part III — The Arsenal

- **Chapter 12** — [Kuga-Satake Construction: K3 → Abelian Variety Bridge](./chapters/12_ch_12_kuga_satake_construction.md) <sub>`ch_12_kuga_satake_construction` · S</sub>
- **Chapter 13** — [Standard Conjectures Status](./chapters/13_ch_13_standard_conjectures_status.md) <sub>`ch_13_standard_conjectures_status` · S</sub>
- **Chapter 14** — [Tate-Mirror Framework: Point Counting → Frobenius → Tate Classes](./chapters/14_ch_14_tate_mirror_framework.md) <sub>`ch_14_tate_mirror_framework` · M</sub>
- **Chapter 15** — [Noether-Lefschetz Divisors](./chapters/15_ch_15_noether_lefschetz_divisors.md) <sub>`ch_15_noether_lefschetz_divisors` · S</sub>
- **Chapter 16** — [Motivic Cohomology Status](./chapters/16_ch_16_motivic_cohomology_table.md) <sub>`ch_16_motivic_cohomology_table` · S</sub>
- **Chapter 17** — [Voevodsky Nilpotence Status](./chapters/17_ch_17_voevodsky_status.md) <sub>`ch_17_voevodsky_status` · S</sub>

## Part IV — The Map of Known and Open

- **Chapter 18** — [Hodge Conjecture Status on Abelian Varieties](./chapters/18_ch_18_abelian_status.md) <sub>`ch_18_abelian_status` · M</sub>
- **Chapter 19** — [K3 Surface Atlas](./chapters/19_ch_19_k3_atlas.md) <sub>`ch_19_k3_atlas` · M</sub>
- **Chapter 20** — [Hyperkähler Manifolds: Classification by Deformation Type](./chapters/20_ch_20_hyperkahler_classification.md) <sub>`ch_20_hyperkahler_classification` · M</sub>
- **Chapter 21** — [Hassett Discriminants for Cubic 4-folds](./chapters/21_ch_21_hassett_discriminants.md) <sub>`ch_21_hassett_discriminants` · L</sub>
- **Chapter 22** — [Calabi-Yau 4-fold Hodge Numbers](./chapters/22_ch_22_cy_4fold_hodge_numbers.md) <sub>`ch_22_cy_4fold_hodge_numbers` · M</sub>
- **Chapter 23** — [Fano 4-fold Atlas: Bloch-Srinivas Applicability](./chapters/23_ch_23_fano_atlas.md) <sub>`ch_23_fano_atlas` · S</sub>
- **Chapter 24** — [Moduli Spaces: Hodge Conjecture Status](./chapters/24_ch_24_moduli_status.md) <sub>`ch_24_moduli_status` · S</sub>

## Part V — The Computational Atlas

- **Chapter 25** — [Hyperkähler Beauville-Bogomolov Lattices](./chapters/25_ch_25_hyperkahler_lattices.md) <sub>`ch_25_hyperkahler_lattices` · L</sub>
- **Chapter 26** — [Tate Point-Counting on Surfaces and Beyond](./chapters/26_ch_26_tate_point_counting.md) <sub>`ch_26_tate_point_counting` · L</sub>
- **Chapter 27** — [Cubic 4-fold Periods: Hodge Structure and Frobenius Detection](./chapters/27_ch_27_cubic_4fold_periods.md) <sub>`ch_27_cubic_4fold_periods` · L</sub>
- **Chapter 28** — [Bloch-Srinivas Diagonal Decomposition](./chapters/28_ch_28_diagonal_decomposition.md) <sub>`ch_28_diagonal_decomposition` · M</sub>
- **Chapter 29** — [Explicit Cycle Constructions Atlas](./chapters/29_ch_29_cycle_constructions.md) <sub>`ch_29_cycle_constructions` · M</sub>
- **Chapter 30** — [Chow Regulators and Beilinson Periods](./chapters/30_ch_30_chow_regulators.md) <sub>`ch_30_chow_regulators` · L</sub>
- **Chapter 31** — [Mumford-Weil Detector: Exotic Hodge Classes on Abelian Varieties](./chapters/31_ch_31_mumford_weil.md) <sub>`ch_31_mumford_weil` · M</sub>
- **Chapter 32** — [Toric Calabi-Yau 4-fold Sweep](./chapters/32_ch_32_toric_cy_sweep.md) <sub>`ch_32_toric_cy_sweep` · L</sub>
- **Chapter 33** — [Counterexample Search: Where Methods Reach Their Limits](./chapters/33_ch_33_counterexample_search.md) <sub>`ch_33_counterexample_search` · M</sub>
- **Chapter 34** — [Cross-Part Pattern Analysis](./chapters/34_ch_34_pattern_analysis.md) <sub>`ch_34_pattern_analysis` · A</sub>

## Part VI — Sister Conjectures and Implications

- **Chapter 35** — [Generalized Hodge Conjecture / Coniveau Filtration](./chapters/35_ch_35_ghc_coniveau_table.md) <sub>`ch_35_ghc_coniveau_table` · S</sub>
- **Chapter 36** — [Standard Conjectures Atlas (Aggregator)](./chapters/36_ch_36_standard_conjectures_atlas.md) <sub>`ch_36_standard_conjectures_atlas` · A</sub>
- **Chapter 37** — [Tate Conjecture Atlas](./chapters/37_ch_37_tate_conjecture_atlas.md) <sub>`ch_37_tate_conjecture_atlas` · L</sub>
- **Chapter 38** — [Beilinson L-Value Framework](./chapters/38_ch_38_beilinson_l_values.md) <sub>`ch_38_beilinson_l_values` · L</sub>
- **Chapter 39** — [Logical Implications: What Settles What](./chapters/39_ch_39_implications_table.md) <sub>`ch_39_implications_table` · A</sub>
- **Chapter 40** — [Conjecture Web Graph](./chapters/40_ch_40_web_graph.md) <sub>`ch_40_web_graph` · A</sub>

## Part VII — Closing Arguments

- **Chapter 41** — [Infrastructure Categories: What the Codim-2 Program Needs](./chapters/41_ch_41_infrastructure_categories.md) <sub>`ch_41_infrastructure_categories` · A</sub>
- **Chapter 42** — [Constructive Frontier: What Cycles Need to be Built](./chapters/42_ch_42_constructive_frontier.md) <sub>`ch_42_constructive_frontier` · A</sub>
- **Chapter 43** — [Arithmetic Frontier: Open Tate / Frobenius / Galois Questions](./chapters/43_ch_43_arithmetic_frontier.md) <sub>`ch_43_arithmetic_frontier` · L</sub>
- **Chapter 44** — [Motivic Frontier: Open Beilinson / Regulator / Motive Questions](./chapters/44_ch_44_motivic_frontier.md) <sub>`ch_44_motivic_frontier` · L</sub>

## Appendix C — Open Problems

- **Appendix C** — [Appendix C Problems: Pipeline-Side Status](./chapters/99_appendix_c_appendix_c_problems_status.md) <sub>`appendix_c_problems_status` · A</sub>

- [Conclusion](./99_conclusion.md)

---

Total: **39** chapters.
