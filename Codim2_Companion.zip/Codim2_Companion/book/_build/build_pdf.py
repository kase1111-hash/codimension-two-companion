#!/usr/bin/env python3
"""Build KDP-ready 6x9 paperback PDF for the companion volume.

Reads Book.md (run compile.py first) + _book.yaml; produces Book_6x9.pdf.

Production quirks (ported from parent Codimension_Two/_build/build_pdf.py):
- Merge '# CHAPTER N\\n## Title' into '# CHAPTER N — Title' (already merged here, kept for safety)
- xelatex unicode-math requires braces: '_\\mathbb{Q}' → '_{\\mathbb{Q}}'
- \\providecommand{\\Sha} for the Tate-Shafarevich group symbol
- secnumdepth=-1 disables auto-numbering
- raggedbottom + orphan/widow penalty 10000
- fancyhdr running heads (chapter title on recto)
- classoption=openany for trade paperback (no forced recto starts)
- --resource-path includes pipeline/artifacts/ so figures from the pipeline embed

Usage:
    python3 book/_build/build_pdf.py
"""
import re
import subprocess
import sys
from pathlib import Path
import yaml

BOOK_ROOT = Path(__file__).parent.parent
PROJECT_ROOT = BOOK_ROOT.parent
CONFIG = yaml.safe_load((BOOK_ROOT / '_book.yaml').read_text(encoding='utf-8'))
SOURCE = BOOK_ROOT / 'Book.md'
PREPROC = BOOK_ROOT / '_build' / '_preproc.md'
trim_w, trim_h = CONFIG['trim'].split('x')
OUTPUT = BOOK_ROOT / f"Book_{CONFIG['trim']}.pdf"

if not SOURCE.exists():
    print(f"⚠ {SOURCE.name} not found. Run compile.py first.")
    sys.exit(1)

# Preprocess: handle xelatex quirks
text = SOURCE.read_text(encoding='utf-8')

# Merge '# CHAPTER N\n## Title' → '# CHAPTER N — Title' (defensive; should already be merged)
text = re.sub(
    r'^# (CHAPTER \d+)\n+## ([^\n]+)',
    r'# \1 — \2',
    text,
    flags=re.MULTILINE,
)

# xelatex unicode-math requires braces around multi-token math-font subscripts/superscripts.
# Patterns like '_\\mathbb{Q}' must become '_{\\mathbb{Q}}'; same for other math fonts.
# Markdown/MathJax accepts the unbraced form, but xelatex does not.
text = re.sub(
    r'([_^])(\\(?:mathbb|mathcal|mathfrak|mathrm|mathsf|mathit|text|operatorname)\{[^{}]+\})',
    r'\1{\2}',
    text,
)

PREPROC.write_text(text, encoding='utf-8')

preamble = rf"""
\usepackage{{geometry}}
\geometry{{
  paperwidth={trim_w}in,
  paperheight={trim_h}in,
  inner={CONFIG['inner_margin_in']}in,
  outer={CONFIG['outer_margin_in']}in,
  top=0.75in,
  bottom=0.75in,
}}
\setcounter{{secnumdepth}}{{-1}}
\setlength{{\parindent}}{{1.5em}}
\usepackage{{setspace}}
\setstretch{{{CONFIG['leading']}}}
\usepackage{{titlesec}}
\titleformat{{\chapter}}[display]
  {{\normalfont\huge\bfseries\filcenter}}{{}}{{0pt}}{{\Huge}}
\titlespacing*{{\chapter}}{{0pt}}{{50pt}}{{40pt}}
\raggedbottom
\clubpenalty=10000
\widowpenalty=10000

% Tate-Shafarevich group symbol (Cyrillic Sha) — Unicode codepoint
\providecommand{{\Sha}}{{\textnormal{{Ш}}}}

\usepackage{{fancyhdr}}
\pagestyle{{fancy}}
\fancyhf{{}}
\fancyhead[LE]{{\small\itshape {CONFIG['running_head_verso']}}}
\fancyhead[RO]{{\small\itshape\nouppercase{{\leftmark}}}}
\fancyfoot[C]{{\thepage}}
\renewcommand{{\chaptermark}}[1]{{\markboth{{#1}}{{}}}}
\renewcommand{{\sectionmark}}[1]{{}}
\renewcommand{{\headrulewidth}}{{0pt}}
\fancypagestyle{{plain}}{{%
  \fancyhf{{}}%
  \fancyfoot[C]{{\thepage}}%
  \renewcommand{{\headrulewidth}}{{0pt}}%
}}
"""

preamble_file = BOOK_ROOT / '_build' / '_preamble.tex'
preamble_file.write_text(preamble, encoding='utf-8')

# Resource path: include the book root AND the pipeline artifacts dir so
# figures from the pipeline can be embedded by relative path
artifacts_dir = PROJECT_ROOT / 'pipeline' / 'artifacts'
resource_paths = f"{BOOK_ROOT}:{artifacts_dir}"

cmd = [
    'pandoc',
    str(PREPROC),
    '--pdf-engine=xelatex',
    '--top-level-division=chapter',
    f'--resource-path={resource_paths}',
    '-V', 'documentclass=book',
    '-V', 'classoption=openany',
    '-V', f"mainfont={CONFIG['body_font']}",
    '-V', f"fontsize={CONFIG['body_size_pt']}pt",
    '-V', 'colorlinks=true',
    '-V', 'linkcolor=black',
    '-H', str(preamble_file),
    '-o', str(OUTPUT),
]

print(f"Building {OUTPUT.name} ...")
result = subprocess.run(cmd, capture_output=True, text=True, cwd=BOOK_ROOT)
if result.returncode != 0:
    # Print last chunk of stderr for diagnosis
    print(result.stderr[-3000:])
    sys.exit(result.returncode)

size_mb = OUTPUT.stat().st_size / (1024 * 1024)
print(f"✓ Built {OUTPUT.name} ({size_mb:.2f} MB)")
