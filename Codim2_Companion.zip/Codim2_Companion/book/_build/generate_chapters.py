#!/usr/bin/env python3
"""
book/_build/generate_chapters.py — Generate book/chapters/ from pipeline steps.

For each pipeline step, reads:
  - spec.yaml (title, description, category, dependencies, runtime)
  - artifact JSON files (summary, top-level data structure)
  - progress.json (last-run status, duration, item counts)

Writes a templated chapter to book/chapters/<chapter_number>_<step_id>.md
suitable for editing into the companion book. Also writes _TOC.md.

Usage:
    python -m book._build.generate_chapters         # generate all
    python -m book._build.generate_chapters --step ch_22_cy_4fold_hodge_numbers
    python -m book._build.generate_chapters --force # overwrite manual edits

Author: Kase Branham — Independent Researcher
"""

import argparse
import json
import re
import sys
from pathlib import Path

# Pipeline imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'pipeline'))
import yaml
from registry import discover_steps, read_progress, PROJECT_ROOT


BOOK_ROOT = PROJECT_ROOT / 'book'
CHAPTERS_DIR = BOOK_ROOT / 'chapters'
ARTIFACTS_ROOT = PROJECT_ROOT / 'pipeline' / 'artifacts'


# ─────────────────────────────────────────────────────────────────
# CHAPTER NUMBERING
# ─────────────────────────────────────────────────────────────────

def chapter_sort_key(spec: dict) -> tuple:
    """Key for sorting chapters: numeric chapters first, then Appendix C."""
    ch = spec.get('chapter')
    if isinstance(ch, int):
        return (0, ch)
    if isinstance(ch, str):
        if 'appendix' in ch.lower():
            return (1, 99)  # last
        try:
            return (0, int(ch))
        except ValueError:
            return (2, 999)
    return (3, 9999)


def chapter_filename(spec: dict, step_id: str) -> str:
    """File name for a chapter: zero-padded number + step_id."""
    ch = spec.get('chapter')
    if isinstance(ch, int):
        return f"{ch:02d}_{step_id}.md"
    if isinstance(ch, str) and 'appendix' in ch.lower():
        return f"99_appendix_c_{step_id}.md"
    return f"{step_id}.md"


def chapter_label(spec: dict) -> str:
    """Display label for a chapter."""
    ch = spec.get('chapter')
    if isinstance(ch, int):
        return f"Chapter {ch}"
    if isinstance(ch, str) and 'appendix' in ch.lower():
        return "Appendix C"
    return str(ch) if ch else "—"


# ─────────────────────────────────────────────────────────────────
# CONTENT EXTRACTION
# ─────────────────────────────────────────────────────────────────

def load_step_spec(step_id: str) -> dict:
    """Load spec.yaml for a step."""
    p = PROJECT_ROOT / 'pipeline' / 'steps' / step_id / 'spec.yaml'
    if not p.exists():
        return {}
    with open(p, encoding='utf-8') as f:
        return yaml.safe_load(f) or {}


def collect_artifact_summaries(step_id: str) -> dict:
    """Read each JSON artifact and pull its summary block (if any)."""
    artifact_dir = ARTIFACTS_ROOT / step_id
    if not artifact_dir.exists():
        return {'artifacts': [], 'summaries': {}}
    
    artifacts = []
    summaries = {}
    for f in sorted(artifact_dir.glob('*')):
        if f.name == 'progress.json':
            continue
        size_kb = f.stat().st_size / 1024
        artifacts.append({
            'name': f.name,
            'size_kb': round(size_kb, 1),
            'type': f.suffix.lstrip('.'),
        })
        # Pull summary blocks from JSON files
        if f.suffix == '.json':
            try:
                with open(f, encoding='utf-8') as fp:
                    data = json.load(fp)
                if isinstance(data, dict) and 'summary' in data:
                    summaries[f.name] = data['summary']
            except (json.JSONDecodeError, IOError):
                pass
    return {'artifacts': artifacts, 'summaries': summaries}


def format_summary_dict(summary: dict) -> str:
    """Pretty-format a summary dict as a markdown bullet list."""
    lines = []
    for k, v in summary.items():
        if isinstance(v, dict):
            lines.append(f"- **{k}**:")
            for sk, sv in v.items():
                lines.append(f"  - {sk}: {sv}")
        elif isinstance(v, list):
            lines.append(f"- **{k}**: {', '.join(str(x) for x in v[:5])}"
                         f"{' ...' if len(v) > 5 else ''}")
        else:
            lines.append(f"- **{k}**: {v}")
    return '\n'.join(lines)


# ─────────────────────────────────────────────────────────────────
# CHAPTER TEMPLATE
# ─────────────────────────────────────────────────────────────────

def render_chapter(step_id: str, spec: dict, artifact_data: dict,
                    progress: dict) -> str:
    """Render the chapter markdown for one step."""
    label = chapter_label(spec)
    title = spec.get('title', step_id)
    description = spec.get('description', '').strip()
    category = spec.get('category', '—')
    
    # Category long form
    category_long = {
        'S': 'Small (literature compilation)',
        'M': 'Medium (computational scan)',
        'L': 'Large (compute-heavy)',
        'A': 'Aggregator (synthesizes upstream)',
    }.get(category, category)
    
    # Dependencies
    deps = spec.get('dependencies', {}) or {}
    upstream = deps.get('upstream', []) or []
    downstream = deps.get('downstream', []) or []
    
    # Runtime
    runtime = spec.get('runtime', {}) or {}
    
    # Progress info from last run
    p_status = (progress or {}).get('status', 'not yet run')
    p_items_done = (progress or {}).get('items_done')
    p_items_total = (progress or {}).get('items_total')
    p_duration = (progress or {}).get('duration_seconds')
    
    out = []
    out.append(f"# {label} — {title}\n")
    out.append(f"*Companion volume to* Codimension Two *— pipeline step "
               f"`{step_id}`.*\n\n")
    
    # ── Description ─────────────────────────────────────────────
    if description:
        out.append("## Overview\n\n")
        # Description from spec.yaml is already prose; just include it.
        out.append(description.strip())
        out.append("\n\n")
    
    # ── At a glance ─────────────────────────────────────────────
    out.append("## At a glance\n\n")
    out.append(f"- **Step ID**: `{step_id}`\n")
    out.append(f"- **Chapter**: {label}\n")
    out.append(f"- **Category**: {category_long}\n")
    if runtime:
        rs = " · ".join(f"{k}: {v}" for k, v in runtime.items())
        out.append(f"- **Runtime targets**: {rs}\n")
    if p_status != 'not yet run':
        items_str = (f"{p_items_done}/{p_items_total}"
                     if p_items_done is not None and p_items_total
                     else '—')
        dur_str = (f"{p_duration:.1f}s" if isinstance(p_duration, (int, float))
                   else '—')
        out.append(f"- **Last run**: {p_status} · items {items_str} · duration {dur_str}\n")
    out.append("\n")
    
    # ── Dependencies ────────────────────────────────────────────
    if upstream or downstream:
        out.append("## Dependencies\n\n")
        if upstream:
            out.append("**Upstream** (this step reads from):\n\n")
            for u in upstream:
                out.append(f"- [`{u}`](./{_chapter_link(u)})\n")
            out.append("\n")
        if downstream:
            out.append("**Downstream** (these steps read from this one):\n\n")
            for d in downstream:
                out.append(f"- [`{d}`](./{_chapter_link(d)})\n")
            out.append("\n")
    
    # ── Computed outputs ────────────────────────────────────────
    artifacts = artifact_data.get('artifacts', [])
    if artifacts:
        out.append("## Computed outputs\n\n")
        out.append("| File | Type | Size |\n")
        out.append("|---|---|---|\n")
        for a in artifacts:
            out.append(f"| `{a['name']}` | {a['type']} | {a['size_kb']} KB |\n")
        out.append("\n")
        out.append(f"All artifacts are under `pipeline/artifacts/{step_id}/`.\n\n")
    
    # ── Summary statistics ──────────────────────────────────────
    summaries = artifact_data.get('summaries', {})
    if summaries:
        out.append("## Summary statistics\n\n")
        for fname, summary in summaries.items():
            out.append(f"From `{fname}`:\n\n")
            out.append(format_summary_dict(summary))
            out.append("\n\n")
    
    # ── Reproduce ───────────────────────────────────────────────
    out.append("## Reproduce\n\n")
    out.append("```bash\n")
    out.append(f"python -m pipeline.runner --only {step_id}\n")
    out.append(f"python -m pipeline.runner --only {step_id} -- --quick\n")
    out.append(f"python -m pipeline.runner --only {step_id} --force -- --workers 4\n")
    out.append("```\n\n")
    out.append(f"View progress live during a run:\n\n")
    out.append("```bash\n")
    out.append("python -m pipeline.tui\n")
    out.append("```\n\n")
    
    # ── See also (cross-references) ─────────────────────────────
    if upstream or downstream:
        out.append("## See also\n\n")
        if upstream:
            out.append("- Source data flows in from: "
                       + ", ".join(f"[`{u}`](./{_chapter_link(u)})" for u in upstream)
                       + "\n")
        if downstream:
            out.append("- Results feed forward into: "
                       + ", ".join(f"[`{d}`](./{_chapter_link(d)})" for d in downstream)
                       + "\n")
        out.append("\n")
    
    out.append("---\n\n")
    out.append("*Generated by `book/_build/generate_chapters.py` from "
               "`pipeline/steps/" + step_id + "/spec.yaml` and "
               "`pipeline/artifacts/" + step_id + "/`. "
               "Edit by hand to add prose, then run `--force` to regenerate "
               "the auto-sections without overwriting your text.*\n")
    
    return ''.join(out)


def _chapter_link(step_id: str) -> str:
    """Build a relative link to another chapter file."""
    spec = load_step_spec(step_id)
    fname = chapter_filename(spec, step_id)
    return fname


# ─────────────────────────────────────────────────────────────────
# TOC + INTRO + CONCLUSION
# ─────────────────────────────────────────────────────────────────

PART_BOUNDARIES = [
    ('Part I — The Conjecture and Its Setting', 1, 4),
    ('Part II — Why Dimension 4 Is the Threshold', 5, 10),
    ('Part III — The Arsenal', 11, 17),
    ('Part IV — The Map of Known and Open', 18, 24),
    ('Part V — The Computational Atlas', 25, 34),
    ('Part VI — Sister Conjectures and Implications', 35, 40),
    ('Part VII — Closing Arguments', 41, 45),
    ('Appendix C — Open Problems', 99, 99),
]


def part_for_chapter_number(ch: int) -> str:
    for name, lo, hi in PART_BOUNDARIES:
        if lo <= ch <= hi:
            return name
    return 'Other'


def render_toc(steps: dict) -> str:
    """Render book/_TOC.md."""
    out = []
    out.append("# Table of Contents — Codimension Two: A Computational Companion\n\n")
    out.append("*Each chapter mirrors a pipeline step that produces computed data + "
               "literature synthesis. Together, the 39 chapters atlas the codim-2 Hodge "
               "conjecture computationally.*\n\n")
    out.append("---\n\n")
    out.append("- [Introduction](./00_introduction.md)\n\n")
    
    # Group by Part
    ordered = sorted(steps.items(), key=lambda kv: chapter_sort_key(kv[1]))
    last_part = None
    for step_id, spec in ordered:
        ch_num = spec.get('chapter')
        if isinstance(ch_num, str) and 'appendix' in ch_num.lower():
            part = 'Appendix C — Open Problems'
        elif isinstance(ch_num, int):
            part = part_for_chapter_number(ch_num)
        else:
            part = 'Other'
        if part != last_part:
            out.append(f"\n## {part}\n\n")
            last_part = part
        label = chapter_label(spec)
        title = spec.get('title', step_id)
        fname = chapter_filename(spec, step_id)
        category = spec.get('category', '—')
        out.append(f"- **{label}** — [{title}](./chapters/{fname}) "
                   f"<sub>`{step_id}` · {category}</sub>\n")
    
    out.append("\n- [Conclusion](./99_conclusion.md)\n")
    out.append("\n---\n")
    out.append(f"\nTotal: **{len(steps)}** chapters.\n")
    return ''.join(out)


INTRO_TEMPLATE = """# Introduction

*This is the companion volume to* Codimension Two *(45 chapters, 6×9 paperback).
Where the parent volume surveys the landscape of the codimension-two Hodge conjecture
in prose, this book makes every claim computationally executable.*

## How to read this book

Each chapter corresponds to a single pipeline step in the `Codim2_Companion`
project. Every chapter has the same skeleton:

1. **Overview** — what the step is about, in plain prose
2. **At a glance** — step ID, category, runtime targets, last-run status
3. **Dependencies** — what the step reads from and feeds into
4. **Computed outputs** — every artifact file the step produces, with size
5. **Summary statistics** — aggregate numbers extracted from the artifact JSON
6. **Reproduce** — exact commands to re-run the computation
7. **See also** — cross-references to upstream and downstream chapters

The book is therefore not just text: it is a working machine. Run the pipeline,
and every number reported below is regenerated from first principles.

## What the companion adds to the parent volume

- **Independent verification**: where the parent book cites a Hodge number,
  Picard rank, or discriminant, the companion recomputes it from Chern classes,
  lattice formulas, or point counts. When literature and computation disagree,
  the disagreement is logged in `docs/VERIFICATION_LOG.md` rather than papered
  over.
- **Computational atlas**: the K3 atlas, Hassett discriminants, CY 4-fold Hodge
  numbers, cubic 4-fold periods, abelian Mumford-Tate types — all are
  reproducible tables, not static lists.
- **Cross-cut aggregators**: ch_34 (pattern analysis), ch_36 (standard
  conjectures master atlas), ch_39 (implications graph), ch_40 (web
  visualization), and the Appendix C capstone connect everything into a single
  map.

## On the verification practice

The companion treats literature as input, not ground truth. Each step that
quotes a literature value also computes the same value via an independent path
(Chern class, lattice computation, brute-force enumeration). When they agree:
fine. When they disagree: the disagreement is logged with date, step, source
claim, pipeline finding, verification path, and resolution status.

During the build, two findings were logged:

1. **Ch 22 h<sup>2,2</sup> mismatch**: six of seven CY 4-fold
   complete-intersection Hodge values from the literature disagree with the
   Chern-class ground truth. Cause: under investigation (likely h<sup>3,1</sup>
   transcription or Jacobian-ring discrepancy).
2. **Ch 26 K3 Frobenius trace formula**: an own-code bug — a missing zero
   contribution from H<sup>1</sup>(K3) — caught at write-time and corrected
   before any artifact was saved as authoritative.

Both are documented in `docs/VERIFICATION_LOG.md`. The first should drive a
revision to the parent volume; the second is internal hygiene.

## Convention and license

All code and data in the companion are released under **CC0** (public domain).
The author affiliation is **Independent Researcher**. The pipeline is designed
to run with no proprietary dependencies (Python 3 + pyyaml + tqdm + numpy +
cairosvg + rich); a complete sweep takes a few minutes on a laptop.

---

*Continue to the [Table of Contents](./_TOC.md).*
"""


CONCLUSION_TEMPLATE = """# Conclusion

*The companion contains 39 pipeline steps across 7 parts plus Appendix C. Each
chapter is reproducible from `pipeline/steps/<step_id>/`.  What follows is a
brief stocktaking of what the atlas now makes legible — and what it leaves open.*

## What the atlas confirms

The structural picture from the parent volume holds up under computation:

- **Codimension 1 is settled** by Lefschetz (1,1) everywhere — no surprises.
- **Surfaces, K3, abelian, and rationally connected Fano**: codim-2 settled
  cleanly. Bloch-Srinivas diagonal decomposition handles the RC case; Lefschetz,
  Lieberman, and Mumford-Tate-bridge work handle the rest.
- **Hyperkähler K3<sup>[n]</sup>**: codim-2 settled via Charles-Markman and
  Vial.
- **Hassett-special cubic 4-folds with K3 association**: codim-2 settled via
  the Kuznetsov K3 category.

## What the atlas leaves open

The open frontier is sharp and concentrated:

- **Generic CY 4-folds** (sextic in P<sup>5</sup>, (2,5), (3,4), and other
  complete intersections): all open. The tension index from ch_33 ranks the
  generic sextic CY 4-fold at the top — 1,751 Hodge classes unexplained by any
  current cycle construction.
- **Generic cubic 4-folds** (non-Hassett-special): codim-2 open.
- **Hyperkähler OG-6 and OG-10**: open in HC, Tate, and Voevodsky
  simultaneously.
- **General smooth projective 4-folds**: open in all directions; no current
  proposal for a unifying construction.
- **High-genus moduli M<sub>g</sub>, A<sub>g</sub>**: open past the
  unirationality boundaries.

## What changed during the build

The pipeline identified two verification items that the parent volume should
address before publication. They are recorded in
`docs/VERIFICATION_LOG.md` and cross-referenced from the parent's
`PENDING_FOR_PUBLICATION.md`. Neither breaks the parent volume's argument;
both refine it.

## What comes next

The natural sequels:

1. **Higher-codimension companion**: codim 3 and higher on 4-folds, dim 5 and
   higher generally. The atlas methodology transfers; only the lattice data and
   variety atlases need rebuilding.
2. **Full Kreuzer-Skarke sweep**: activate `--use-full-ks` after downloading the
   473M-polytope dataset; the ch_32 toric CY sweep becomes a full enumeration.
3. **Jacobian-ring redo of Ch 22 h<sup>2,2</sup> values**: resolve the
   six-family mismatch through an independent computation path.
4. **Real arithmetic side**: scale up point-counting on cubic 4-folds and CY
   4-folds; build the Tate-Hodge bridge artifact-by-artifact.
5. **Cycle construction frontier**: ch_42 ranks open problems by difficulty.
   The low-difficulty cases (extending Nikulin to higher discriminants, OG-6
   inheritance from abelian surfaces) are concretely doable.

## Closing thought

The codim-2 Hodge conjecture is not a single statement awaiting a single proof:
it is a family of statements, indexed by variety class, each with its own
proof-attempt landscape. The atlas's job is not to solve it. The atlas's job
is to make the landscape legible — to a human, to a future researcher, and to
a future AI. The pipeline is the legibility.

---

*Return to the [Table of Contents](./_TOC.md).*
"""


# ─────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--step', help='Generate just one step')
    parser.add_argument('--force', action='store_true',
                        help='Overwrite existing chapter files (not intro/conclusion)')
    parser.add_argument('--force-intro', action='store_true',
                        help='Also overwrite intro and conclusion (DESTROYS hand-edits)')
    parser.add_argument('--skip-intro', action='store_true',
                        help='Do not generate intro/conclusion stubs even if missing')
    args = parser.parse_args()
    
    print("=" * 72)
    print("  Generating book/chapters/ from pipeline steps")
    print("=" * 72)
    
    BOOK_ROOT.mkdir(exist_ok=True)
    CHAPTERS_DIR.mkdir(exist_ok=True)
    
    # Discover steps
    steps = discover_steps()
    if args.step:
        if args.step not in steps:
            print(f"  ✗ Step {args.step} not found")
            sys.exit(1)
        steps = {args.step: steps[args.step]}
    
    print(f"\n  Found {len(steps)} step(s)")
    
    n_written = 0
    n_skipped = 0
    for step_id, spec in sorted(steps.items(), key=lambda kv: chapter_sort_key(kv[1])):
        fname = chapter_filename(spec, step_id)
        target = CHAPTERS_DIR / fname
        if target.exists() and not args.force:
            print(f"    - {fname}  (exists, skipping; use --force to regenerate)")
            n_skipped += 1
            continue
        
        artifact_data = collect_artifact_summaries(step_id)
        progress = read_progress(step_id) or {}
        content = render_chapter(step_id, spec, artifact_data, progress)
        
        with open(target, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"    ✓ {fname}  ({len(content):,} chars, "
              f"{len(artifact_data['artifacts'])} artifacts, "
              f"{len(artifact_data['summaries'])} summaries)")
        n_written += 1
    
    # TOC always regenerated
    toc_path = BOOK_ROOT / '_TOC.md'
    if not toc_path.exists() or args.force:
        toc = render_toc(discover_steps())  # always full list for TOC
        with open(toc_path, 'w', encoding='utf-8') as f:
            f.write(toc)
        print(f"\n  ✓ {toc_path.relative_to(PROJECT_ROOT)}  ({len(toc):,} chars)")
    
    # Intro + Conclusion — only generate if MISSING. --force does NOT clobber
    # these (they hold hand-edited prose). Use --force-intro for explicit
    # overwrite.
    if not args.skip_intro:
        intro_path = BOOK_ROOT / '00_introduction.md'
        if not intro_path.exists() or args.force_intro:
            with open(intro_path, 'w', encoding='utf-8') as f:
                f.write(INTRO_TEMPLATE)
            print(f"  ✓ {intro_path.relative_to(PROJECT_ROOT)}")
        else:
            print(f"  · {intro_path.relative_to(PROJECT_ROOT)} (preserved; "
                  f"use --force-intro to overwrite)")
        
        conc_path = BOOK_ROOT / '99_conclusion.md'
        if not conc_path.exists() or args.force_intro:
            with open(conc_path, 'w', encoding='utf-8') as f:
                f.write(CONCLUSION_TEMPLATE)
            print(f"  ✓ {conc_path.relative_to(PROJECT_ROOT)}")
        else:
            print(f"  · {conc_path.relative_to(PROJECT_ROOT)} (preserved; "
                  f"use --force-intro to overwrite)")
    
    print()
    print("─" * 72)
    print(f"  Written:  {n_written}")
    print(f"  Skipped:  {n_skipped}")
    print("─" * 72)
    print()
    print(f"  Output directory: {BOOK_ROOT.relative_to(PROJECT_ROOT)}/")
    print(f"  Edit chapters by hand to add prose. The auto-generated sections")
    print(f"  (At a glance, Computed outputs, Summary statistics, Reproduce)")
    print(f"  can be regenerated with --force without overwriting your edits if")
    print(f"  you use the chapter prose pattern (see book/_build/README.md).")


if __name__ == '__main__':
    main()
