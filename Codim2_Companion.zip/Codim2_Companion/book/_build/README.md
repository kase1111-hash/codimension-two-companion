# Companion Book — Build Pipeline

The book in this directory is auto-templated from the pipeline. Each step under
`pipeline/steps/<step_id>/` corresponds to one chapter under
`book/chapters/<chapter_num>_<step_id>.md`.

## Quick start

```bash
# From the project root:
python -m book._build.generate_chapters              # generate missing chapters
python -m book._build.generate_chapters --force      # regenerate everything
python -m book._build.generate_chapters --step ch_22_cy_4fold_hodge_numbers  # one chapter
```

The generator reads:

- **`pipeline/steps/<step_id>/spec.yaml`** — title, description, category, deps, runtime
- **`pipeline/artifacts/<step_id>/*.json`** — top-level `summary` block extracted
- **`pipeline/artifacts/<step_id>/progress.json`** — last-run status

And writes a chapter with these auto-sections:

1. Overview (from `spec.description`)
2. At a glance (step ID, category, runtime, last-run status)
3. Dependencies (upstream + downstream, with cross-links)
4. Computed outputs (all files in the artifact directory, with size)
5. Summary statistics (extracted from each JSON artifact's `summary` block)
6. Reproduce (commands to re-run the step)
7. See also (cross-references)

## Editing chapters by hand

Two workflows:

### Workflow A — auto-only (default for now)

Just regenerate when the pipeline changes. The chapters are functional reference
material without any prose elaboration. Run `--force` after any spec or artifact
change.

### Workflow B — manual prose insertion

Add prose between the auto-generated sections by inserting prose blocks that
will survive `--force` regeneration. The format isn't enforced yet; for now,
**copy a chapter to `book/chapters/<chapter_num>_<step_id>.manual.md`** to keep
your edits separate, and use the auto file as a starting point. A future
revision can add structured prose-merging.

Recommended approach right now: write a single prose passage in a hand-edited
file under `book/prose/<step_id>.md`, and let a future build step interleave
prose + auto-generated material at compile time.

## Build pipeline (working)

All four build stages are implemented and tested. End-to-end:

```bash
python3 book/_build/build_all.py
```

Produces (in `book/`):

- **`Book.md`** — assembled manuscript, ~102 KB, ~11,000 words across 41 sections
- **`Book_6x9.pdf`** — KDP-ready paperback, 124 pages at 6×9 trim, ~245 KB
- **`Book.epub`** — Kindle-compatible EPUB3, ~123 KB, 41 chapter files inside

### Individual stages

```bash
python3 book/_build/compile.py      # chapters → Book.md only
python3 book/_build/build_pdf.py    # Book.md → Book_6x9.pdf (xelatex)
python3 book/_build/build_epub.py   # Book.md → Book.epub (pandoc)
```

### Build-all options

```bash
python3 book/_build/build_all.py                       # full rebuild
python3 book/_build/build_all.py --skip-regenerate     # use existing chapters/
python3 book/_build/build_all.py --pdf-only            # skip EPUB
python3 book/_build/build_all.py --epub-only           # skip PDF
python3 book/_build/build_all.py --force-regenerate    # --force on chapter gen
```

### Production quirks (ported from parent volume)

- xelatex unicode-math requires braces: `_\mathbb{Q}` → `_{\mathbb{Q}}`. Regex handled in `build_pdf.py`.
- `\providecommand{\Sha}{\textnormal{Ш}}` defined in preamble for Tate-Shafarevich group.
- `secnumdepth=-1` disables auto-numbering — chapter heading provides "CHAPTER N".
- `classoption=openany` avoids forced recto starts (trade paperback convention).
- `raggedbottom` + `\clubpenalty=10000` + `\widowpenalty=10000` for clean page breaks.
- `fancyhdr` running heads: chapter title on recto pages.
- `--resource-path` includes `pipeline/artifacts/` so figures from the pipeline embed by relative path.

### Output stats from last build

```
Book.md         : 102.3 KB
Book_6x9.pdf    : 244.5 KB · 124 pages · 6×9 trim · 11pt TeX Gyre Pagella
Book.epub       : 123.0 KB · EPUB3 · 41 internal chapter XHTML files
```

## Future enhancements

Not yet implemented; natural follow-ons:

- **Figure embedding from pipeline artifacts** — `ch_40_web_graph/web_graph.png` could become Figure 1; needs an `\includegraphics` reference in the relevant chapter
- **Math notation** — chapters currently render `h^{1,1}` literally; wrapping in `$...$` would produce proper math typography but needs careful regex (some `^{...}` are file paths, etc.)
- **Per-chapter word count target** — parent has 2000-9000 range; companion chapters average ~280 words (auto-generated reference material); would benefit from prose elaboration before publication

## Layout

```
book/
├── _book.yaml                    ← metadata + assembly order
├── _build/
│   ├── __init__.py
│   ├── generate_chapters.py     ← chapter generator (Phase 1)
│   ├── compile.py               ← chapter files → Book.md
│   ├── build_pdf.py             ← Book.md → Book_6x9.pdf (xelatex)
│   ├── build_epub.py            ← Book.md → Book.epub (pandoc)
│   ├── build_all.py             ← orchestrator (one command)
│   └── README.md                ← this file
├── _TOC.md                       ← table of contents
├── 00_introduction.md            ← intro stub (edit by hand)
├── 99_conclusion.md              ← conclusion stub (edit by hand)
├── chapters/
│   ├── 04_ch_04_codim_grid.md
│   ├── 06_ch_06_lefschetz_action.md
│   ├── ...
│   └── 99_appendix_c_appendix_c_problems_status.md
├── Book.md                       ← compiled output (gitignore?)
├── Book_6x9.pdf                  ← paperback (gitignore?)
└── Book.epub                     ← Kindle (gitignore?)
```

## Convention

- Chapter filenames: `<zero-padded chapter number>_<step_id>.md`
- Appendix C uses `99_appendix_c_<step_id>.md`
- Cross-links in chapters use relative paths within `chapters/`
- All content is **CC0**, affiliation **Independent Researcher**
