#!/usr/bin/env python3
"""Concatenate the chapter/matter files in assembly_order into Book.md.

Usage:
    python3 book/_build/compile.py
"""
import re
from pathlib import Path
import yaml

BOOK_ROOT = Path(__file__).parent.parent
CONFIG = yaml.safe_load((BOOK_ROOT / '_book.yaml').read_text(encoding='utf-8'))
OUTPUT = BOOK_ROOT / 'Book.md'

TITLE_PAGE = f"""# {CONFIG['title']}

## {CONFIG['subtitle']}

*{CONFIG['author']}*  
*{CONFIG['affiliation']}*

---

# Copyright

Copyright © {CONFIG['year']} {CONFIG['author']}.

Dedicated to the public domain under **Creative Commons Zero (CC0 1.0 Universal)**.
To the extent possible under law, the author has waived all copyright and
related rights to this work.

ISBN: *{CONFIG.get('isbn', 'TBA')}*

*This is the computational companion to* Codimension Two: The Hodge Conjecture
and What We Can Build Around It *(45 chapters, 6×9 paperback). Where the parent
volume surveys the codimension-two Hodge conjecture in prose, this companion
makes every claim computationally reproducible. The pipeline source is
available at the author's repository as CC0.*

---

"""


def strip_html_comments(text: str) -> str:
    """Remove <!-- ... --> blocks (used in placeholder files)."""
    return re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)


def normalize_chapter_heading(text: str) -> str:
    """Rewrite '# Chapter N — Title' to '# CHAPTER N — Title' uniformly.
    
    The generator outputs '# Chapter 22 — ...'; pandoc with --top-level-division=chapter
    treats this as the chapter title cleanly, but we want consistent uppercase 'CHAPTER'
    for running-head display and to match the parent volume's typography.
    """
    text = re.sub(
        r'^# Chapter (\d+) — ',
        r'# CHAPTER \1 — ',
        text,
        flags=re.MULTILINE,
    )
    # Appendix C chapter
    text = re.sub(
        r'^# Appendix C — ',
        r'# APPENDIX C — ',
        text,
        flags=re.MULTILINE,
    )
    return text


def compile_book():
    parts = [TITLE_PAGE]
    missing = []
    for fname in CONFIG['assembly_order']:
        path = BOOK_ROOT / fname
        if not path.exists():
            missing.append(fname)
            continue
        text = path.read_text(encoding='utf-8')
        text = strip_html_comments(text).strip()
        text = normalize_chapter_heading(text)
        parts.append(text)
    OUTPUT.write_text('\n\n'.join(parts), encoding='utf-8')
    
    # Word count (approximate)
    words = sum(len(re.findall(r'\b\w+\b', p)) for p in parts)
    n_sections = len(CONFIG['assembly_order']) - len(missing)
    print(f"✓ Compiled {n_sections} sections → {OUTPUT.name}")
    print(f"  Approx word count: {words:,}")
    print(f"  Output size: {OUTPUT.stat().st_size / 1024:.1f} KB")
    if missing:
        print(f"  ⚠ Missing files (skipped): {missing}")


if __name__ == '__main__':
    compile_book()
