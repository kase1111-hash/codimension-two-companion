#!/usr/bin/env python3
"""Build KDP Kindle-compatible EPUB3 for the companion volume.

Reads Book.md (run compile.py first) + _book.yaml; produces Book.epub.

Usage:
    python3 book/_build/build_epub.py
"""
import re
import subprocess
import sys
from pathlib import Path
import yaml

BOOK_ROOT = Path(__file__).parent.parent
PROJECT_ROOT = BOOK_ROOT.parent
CONFIG = yaml.safe_load((BOOK_ROOT / '_book.yaml').read_text(encoding='utf-8'))
SOURCE = BOOK_ROOT / 'Book.md'
PREPROC = BOOK_ROOT / '_build' / '_preproc_epub.md'
OUTPUT = BOOK_ROOT / 'Book.epub'

if not SOURCE.exists():
    print(f"⚠ {SOURCE.name} not found. Run compile.py first.")
    sys.exit(1)

text = SOURCE.read_text(encoding='utf-8')
# Merge chapter heading lines (defensive)
text = re.sub(
    r'^# (CHAPTER \d+)\n+## ([^\n]+)',
    r'# \1 — \2',
    text,
    flags=re.MULTILINE,
)
PREPROC.write_text(text, encoding='utf-8')

metadata = f"""---
title: "{CONFIG['title']}"
subtitle: "{CONFIG['subtitle']}"
author: "{CONFIG['author']}"
date: "{CONFIG['year']}"
publisher: "{CONFIG['imprint']}"
identifier:
  - scheme: ISBN
    text: "{CONFIG['isbn']}"
rights: "Dedicated to the public domain under Creative Commons Zero (CC0 1.0 Universal)"
language: "{CONFIG['language']}"
---
"""
meta_file = BOOK_ROOT / '_build' / '_epub_meta.yaml'
meta_file.write_text(metadata, encoding='utf-8')

# Resource path: same as PDF — include pipeline artifacts for figures
artifacts_dir = PROJECT_ROOT / 'pipeline' / 'artifacts'
resource_paths = f"{BOOK_ROOT}:{artifacts_dir}"

cmd = [
    'pandoc',
    str(meta_file),
    str(PREPROC),
    '-t', 'epub3',
    '--top-level-division=chapter',
    f'--resource-path={resource_paths}',
    '--toc',
    '--toc-depth=2',
    '--split-level=1',
    '-o', str(OUTPUT),
]

print(f"Building {OUTPUT.name}...")
result = subprocess.run(cmd, capture_output=True, text=True, cwd=BOOK_ROOT)
if result.returncode != 0:
    print(result.stderr[-2000:])
    sys.exit(result.returncode)

size_kb = OUTPUT.stat().st_size / 1024
print(f"✓ Built {OUTPUT.name} ({size_kb:.1f} KB)")
