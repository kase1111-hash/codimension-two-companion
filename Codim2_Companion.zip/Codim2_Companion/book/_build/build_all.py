#!/usr/bin/env python3
"""One command to rebuild the entire companion book.

Sequence:
  1. Regenerate chapters from pipeline (generate_chapters.py)
  2. Compile chapters + intro + conclusion → Book.md
  3. Build Book_6x9.pdf (xelatex)
  4. Build Book.epub (pandoc)

Usage:
    python3 book/_build/build_all.py
    python3 book/_build/build_all.py --skip-regenerate   # skip chapter regen
    python3 book/_build/build_all.py --pdf-only          # PDF without EPUB
    python3 book/_build/build_all.py --epub-only         # EPUB without PDF
"""
import argparse
import subprocess
import sys
from pathlib import Path

BUILD = Path(__file__).parent
BOOK_ROOT = BUILD.parent
PROJECT_ROOT = BOOK_ROOT.parent


def run_step(label: str, cmd: list, cwd: Path = PROJECT_ROOT) -> int:
    print()
    print("=" * 72)
    print(f"  {label}")
    print("=" * 72)
    result = subprocess.run(cmd, cwd=cwd)
    if result.returncode != 0:
        print(f"\n⚠ {label} failed (exit {result.returncode})")
    return result.returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--skip-regenerate', action='store_true',
                        help='Skip the chapter regeneration step')
    parser.add_argument('--pdf-only', action='store_true',
                        help='Build PDF only (skip EPUB)')
    parser.add_argument('--epub-only', action='store_true',
                        help='Build EPUB only (skip PDF)')
    parser.add_argument('--force-regenerate', action='store_true',
                        help='Force regenerate all chapters (--force flag to generator)')
    args = parser.parse_args()
    
    # 1. Regenerate chapters (unless skipped)
    if not args.skip_regenerate:
        regen_cmd = ['python3', '-m', 'book._build.generate_chapters']
        if args.force_regenerate:
            regen_cmd.append('--force')
        rc = run_step("STEP 1/4 — Regenerate chapters from pipeline",
                       regen_cmd, cwd=PROJECT_ROOT)
        if rc != 0:
            sys.exit(rc)
    
    # 2. Compile
    rc = run_step("STEP 2/4 — Compile chapters into Book.md",
                   ['python3', str(BUILD / 'compile.py')])
    if rc != 0:
        sys.exit(rc)
    
    # 3. PDF
    if not args.epub_only:
        rc = run_step("STEP 3/4 — Build 6×9 paperback PDF",
                       ['python3', str(BUILD / 'build_pdf.py')])
        if rc != 0 and not args.pdf_only:
            # If PDF fails but we still want EPUB, continue with a warning
            print(f"\n⚠ PDF build failed, continuing to EPUB anyway...")
        elif rc != 0:
            sys.exit(rc)
    
    # 4. EPUB
    if not args.pdf_only:
        rc = run_step("STEP 4/4 — Build Kindle EPUB",
                       ['python3', str(BUILD / 'build_epub.py')])
        if rc != 0:
            sys.exit(rc)
    
    # Summary
    print()
    print("=" * 72)
    print("  BUILD COMPLETE")
    print("=" * 72)
    print()
    for name in ('Book.md', 'Book_6x9.pdf', 'Book.epub'):
        p = BOOK_ROOT / name
        if p.exists():
            size = p.stat().st_size
            if size > 1024 * 1024:
                size_str = f"{size / (1024*1024):.2f} MB"
            else:
                size_str = f"{size / 1024:.1f} KB"
            print(f"  ✓ {p.relative_to(PROJECT_ROOT)}  ({size_str})")
        else:
            print(f"  · {p.relative_to(PROJECT_ROOT)}  (not built)")
    print()


if __name__ == '__main__':
    main()
