# Introduction

*This is the companion volume to* Codimension Two *(45 chapters, 6×9 paperback).
Where the parent volume surveys the landscape of the codimension-two Hodge conjecture
in prose, this book makes every claim computationally executable.*

## How to read this book

Each chapter corresponds to a single pipeline step in the `Codim2_Companion`
project. Every chapter has the same skeleton:

1. **Overview** — what the step is about, in plain prose
2. **At a glance** — step ID, category, runtime targets, last-run status
3. **Dependencies** — what the step reads from and feeds into
4. **Computed outputs** — every artifact file the step produces, with size
5. **Summary statistics** — aggregate numbers extracted from the artifact JSON
6. **Reproduce** — exact commands to re-run the computation
7. **See also** — cross-references to upstream and downstream chapters

The book is therefore not just text: it is a working machine. Run the pipeline,
and every number reported below is regenerated from first principles.

## What the companion adds to the parent volume

- **Independent verification**: where the parent book cites a Hodge number,
  Picard rank, or discriminant, the companion recomputes it from Chern classes,
  lattice formulas, or point counts. When literature and computation disagree,
  the disagreement is logged in `docs/VERIFICATION_LOG.md` rather than papered
  over.
- **Computational atlas**: the K3 atlas, Hassett discriminants, CY 4-fold Hodge
  numbers, cubic 4-fold periods, abelian Mumford-Tate types — all are
  reproducible tables, not static lists.
- **Cross-cut aggregators**: ch_34 (pattern analysis), ch_36 (standard
  conjectures master atlas), ch_39 (implications graph), ch_40 (web
  visualization), and the Appendix C capstone connect everything into a single
  map.

## On the verification practice

The companion treats literature as input, not ground truth. Each step that
quotes a literature value also computes the same value via an independent path
(Chern class, lattice computation, brute-force enumeration). When they agree:
fine. When they disagree: the disagreement is logged with date, step, source
claim, pipeline finding, verification path, and resolution status.

During the build, several external checks have been logged:

1. **Ch 22 h<sup>2,2</sup> mismatch**: six of seven CY 4-fold
   complete-intersection Hodge values from the literature disagree with the
   Chern-class ground truth. **Status**: sextic case resolved (Jacobian-ring
   triple-verification matches literature). Six c.i. cases still open pending
   relative-Jacobian implementation.
2. **Ch 26 K3 Frobenius trace formula**: an own-code bug — a missing zero
   contribution from H<sup>1</sup>(K3) — caught at write-time and corrected
   before any artifact was saved as authoritative.
3. **External structural review** (2026-05-11): no critical computational
   errors or major inconsistencies detected. Pipeline cross-references coherent;
   data consistency holds across aggregators. Three follow-up priorities
   recommended; see Conclusion's "What comes next" section.
4. **Pipeline extensions** (2026-05-11): four new calculations added in
   response to the review:
   - **Jacobian ring** for hypersurface CY 4-folds (resolves sextic case)
   - **Nikulin / Loeschian K3-association** extending the Hassett classification
     beyond d = 70 (22 new K3-associated cubic 4-fold families up to d = 200)
   - **OG-6 inheritance from abelian surfaces** added to the cycle-construction
     atlas
   - **Sato-Tate sanity check** on Frobenius traces in the point-counting step

All are documented in `docs/VERIFICATION_LOG.md`. The first item should drive
a revision to the parent volume's Ch 22; the second is internal hygiene; the
third validates the practice itself; the fourth is the queue of follow-up
work from the review actually shipped.

## Convention and license

All code and data in the companion are released under **CC0** (public domain).
The author affiliation is **Independent Researcher**. The pipeline is designed
to run with no proprietary dependencies (Python 3 + pyyaml + tqdm + numpy +
cairosvg + rich); a complete sweep takes a few minutes on a laptop.

---

*Continue to the [Table of Contents](./_TOC.md).*
