"""book — Companion book chapters generated from pipeline steps."""
