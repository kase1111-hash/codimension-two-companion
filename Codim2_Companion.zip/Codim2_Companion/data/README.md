# External Data — Acquisition Guide

This directory holds external databases used by the pipeline. We don't redistribute these databases (CC0-incompatible licenses, large file sizes, or upstream maintainers prefer direct downloads). Tools in `pipeline/data_tools/` handle acquisition.

```
data/
├── raw/           # External databases as downloaded (compressed)
└── processed/     # Cleaned / reformatted versions ready for pipeline consumption
```

---

## Required databases

### Kreuzer-Skarke reflexive 4-polytopes

**Required for**: `ch_32_toric_cy_sweep`

**Source**: Maximilian Kreuzer & Harald Skarke. *Complete classification of reflexive polyhedra in four dimensions* (Adv. Theor. Math. Phys., 2002).

**Acquire**:
```bash
python -m pipeline.data_tools.download --dataset kreuzer-skarke
```
Downloads `kreuzer-skarke-4d.tar.gz` (~50 MB compressed, ~500 MB uncompressed, 473,800,776 polytopes) from the upstream mirror, places it at `data/raw/kreuzer-skarke-4d/`. The download tool verifies SHA-256 against the bundled manifest.

**Processed form**: `data/processed/kreuzer-skarke/polytopes-h11-le-N.json` (segmented by $h^{1,1}$ for fast loading).

---

### K3 lattice classification

**Required for**: `ch_19_k3_atlas`, `ch_25_hyperkahler_lattices`

**Source**: Compiled from Huybrechts, *Lectures on K3 Surfaces*; Nikulin, *Integral symmetric bilinear forms and some of their applications*; Brakkee, *Cubic fourfolds with associated K3 surfaces*.

**Acquire**:
```bash
python -m pipeline.data_tools.download --dataset k3-lattices
```
Small dataset (~5 MB), CC-BY where redistributable; otherwise constructed from the published lattice tables.

---

### Hassett discriminant table (extended)

**Required for**: `ch_21_hassett_discriminants` (for d > 70, where the lattice-embedding check requires more work)

**Source**: Brakkee 2018, *Two Polarised K3 Surfaces Associated to the Same Cubic Fourfold*; Bayer-Macrì 2014; Addington-Thomas 2014.

**Acquire**:
```bash
python -m pipeline.data_tools.download --dataset hassett-extended
```

---

## Download tool

The download tool is `pipeline/data_tools/download.py`. It:

- Reads `data/manifest.yaml` for dataset definitions (URL, checksum, format)
- Downloads to `data/raw/<dataset>/` with progress bar
- Verifies SHA-256
- Optionally unpacks and processes to `data/processed/<dataset>/`
- Reports success/failure clearly

```bash
# List available datasets
python -m pipeline.data_tools.download --list

# Download one
python -m pipeline.data_tools.download --dataset kreuzer-skarke

# Download all
python -m pipeline.data_tools.download --all

# Verify checksums without re-downloading
python -m pipeline.data_tools.download --verify
```

---

## Storage requirements

| Dataset | Compressed | Uncompressed | Required? |
|---|---|---|---|
| Kreuzer-Skarke 4-polytopes | 50 MB | 500 MB | Only for `ch_32_toric_cy_sweep` |
| K3 lattices | 5 MB | 15 MB | Several Part IV / V steps |
| Hassett extended | 1 MB | 3 MB | `ch_21` for d > 70 |
| **Total** | ~56 MB | ~520 MB | |

The full pipeline runs without external data if the user accepts the default `--quick` presets and skips `ch_32_toric_cy_sweep`. External downloads become necessary at `--standard` and `--long` presets for atlas-extension steps.

---

## License compatibility

The companion book and pipeline are CC0. External databases vary:

- **Kreuzer-Skarke**: redistributable, mirrored at multiple sites
- **K3 lattice tables**: published in textbooks (Huybrechts, Nikulin); we redistribute only the numerical extracts under fair-use rationale
- **Hassett tables**: published; same fair-use rationale for numerical extracts

If you intend to fork or redistribute the project, verify license compatibility with each upstream dataset.
